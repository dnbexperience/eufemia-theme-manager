/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/shared/Browser.js
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","RUNTIME_CHROME_EXTENSION_ID":"","RUNTIME_EXTENSION_DEV_LOCALHOST":"false","RUNTIME_EXTENSION_DEV_WATCH":"true","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const Browser = (useBrowser);

;// CONCATENATED MODULE: ./src/extension/hot-reload.js

const filesInDirectory = (dir) => new Promise((resolve) => dir.createReader().readEntries((entries) => Promise.all(entries.filter((e) => e.name[0] !== ".").map((e) => e.isDirectory ? filesInDirectory(e) : new Promise((resolve2) => e.file(resolve2)))).then((files) => [].concat(...files)).then(resolve)));
const timestampForFilesInDirectory = (dir) => filesInDirectory(dir).then((files) => files.map((f) => f.name + f.lastModifiedDate).join());
const watchChanges = (dir, lastTimestamp) => {
  timestampForFilesInDirectory(dir).then((timestamp) => {
    if (!lastTimestamp || lastTimestamp === timestamp) {
      setTimeout(() => watchChanges(dir, timestamp), 1e3);
    } else {
      Browser.runtime.reload();
    }
  });
};
if ({"RUNTIME_BROWSER":"chrome","RUNTIME_CHROME_EXTENSION_ID":"","RUNTIME_EXTENSION_DEV_LOCALHOST":"false","RUNTIME_EXTENSION_DEV_WATCH":"true","NODE_ENV":"production"}.RUNTIME_EXTENSION_DEV_WATCH) {
  Browser.management.getSelf((self) => {
    if (self.installType === "development") {
      if (typeof Browser.runtime.getPackageDirectoryEntry === "function") {
        Browser.runtime.getPackageDirectoryEntry((dir) => watchChanges(dir));
      }
      Browser.tabs.query({active: true, lastFocusedWindow: true}, (tabs) => {
        if (tabs[0]) {
          Browser.tabs.reload(tabs[0].id);
        }
      });
    }
  });
}

/******/ })()
;
//# sourceMappingURL=hot-reload.js.map