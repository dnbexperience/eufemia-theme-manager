/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 68138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ph": () => (/* binding */ extensionStorePlain),
/* harmony export */   "fl": () => (/* binding */ useThemeStore),
/* harmony export */   "qr": () => (/* binding */ useAppStore)
/* harmony export */ });
/* unused harmony exports useWindowStore, useErrorStore, useTheme */
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2742);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71818);
/* harmony import */ var _shared_Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15101);
/* harmony import */ var _shared_ColorController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44513);




const extensionStorePlain = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(themesStore);
const useThemeStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(themesStore, getPersistConfig("eufemia-theme-data")));
const useAppStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-app")));
const useWindowStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-window")));
const useErrorStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(errorStore);
function useTheme(themeId) {
  const {getTheme} = useThemeStore();
  return getTheme(themeId);
}
function themesStore(set, get) {
  return {
    themes: {},
    getThemes: () => {
      const {getThemeConstructs, themes} = get();
      if (!themes["dnb-ui"]) {
        themes["dnb-ui"] = getThemeConstructs();
        themes["demo"] = getThemeConstructs();
      }
      if (!themes["blue-test"]) {
        themes["blue-test"] = getThemeConstructs();
      }
      if (!themes["2x-test"]) {
        themes["2x-test"] = getThemeConstructs();
      }
      return themes;
    },
    importThemes: (themesData, {overwrite} = {}) => {
      try {
        if (themesData) {
          const existingThemes = get().themes;
          const themes = Object.entries(themesData).reduce((acc, [key, theme]) => {
            if (!["dnb-ui", "blue-test", "2x-test"].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }
            return acc;
          }, {...existingThemes});
          set({themes});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: (themeId) => {
      const {themes, getThemeConstructs} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...getThemeConstructs()};
        set({themes});
      }
    },
    copySelectedTheme: (themeId) => {
      const {themes, selectedThemeId} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...themes[selectedThemeId]};
        set({themes});
      }
    },
    removeTheme: (themeId) => {
      const themes = get().themes;
      if (themes[themeId]) {
        delete themes[themeId];
        set({themes});
      }
    },
    getThemeConstructs: () => {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: (themeId = null) => {
      if (!themeId) {
        themeId = get().selectedThemeId;
      }
      const setState = (object) => {
        const themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object);
        const state = {themes};
        state.selectedThemeId = themeId;
        set(state);
      };
      const getState = () => {
        const theme = get().themes[themeId] || null;
        return theme;
      };
      const getThemeChanges = () => {
        switch (themeId) {
          case "dnb-ui": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key, value}) => ({
                key,
                change: value
              }))
            ];
          }
          case "blue-test": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key}) => ({
                key,
                change: "blue"
              }))
            ];
          }
          case "2x-test": {
            return [
              {
                css: "html{font-size: 200%;}"
              }
            ];
          }
          default: {
            const theme = getState();
            return [
              ...theme?.colorsList || [],
              ...theme?.spacingsList || [],
              ...theme?.fontsizesList || []
            ];
          }
        }
      };
      const changeColor = (origKey, object) => {
        const theme = getState();
        let found = false;
        object.key = origKey;
        const colorsList = (theme?.colorsList || []).map((item) => {
          if (item.key === origKey) {
            item = {...item, ...object};
            found = Boolean(item);
          }
          return item;
        });
        if (!found) {
          colorsList.push(object);
        }
        setState({colorsList});
      };
      const setColor = (origKey, change, fallbackParams = {}) => {
        changeColor(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetColor = (rmKey) => {
        changeColor(rmKey, {
          change: null
        });
      };
      const useColorTools = () => {
        return {
          changeColor,
          setColor,
          resetColor
        };
      };
      const changeSpacing = (origKey, object) => {
        const theme = getState();
        let found;
        const spacingsList = (theme?.spacingsList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          spacingsList.push(Object.assign(object));
        }
        setState({spacingsList});
      };
      const setSpacing = (origKey, change, fallbackParams = {}) => {
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetSpacing = (rmKey) => {
        changeSpacing(rmKey, {
          change: null
        });
      };
      const useSpacingTools = () => {
        return {
          changeSpacing,
          setSpacing,
          resetSpacing
        };
      };
      const changeFontsize = (origKey, object) => {
        const theme = getState();
        let found;
        const fontsizesList = (theme?.fontsizesList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          fontsizesList.push(Object.assign(object));
        }
        setState({fontsizesList});
      };
      const setFontsize = (origKey, change, fallbackParams = {}) => {
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetFontsize = (rmKey) => {
        changeFontsize(rmKey, {
          change: null
        });
      };
      const useFontsizeTools = () => {
        return {
          changeFontsize,
          setFontsize,
          resetFontsize
        };
      };
      return {
        themeId,
        ...getState(),
        setState,
        getState,
        getThemeChanges,
        useColorTools,
        useSpacingTools,
        useFontsizeTools
      };
    }
  };
}
const defaultFallback = {
  enabled: false,
  selectedTab: "colors",
  currentThemeId: null,
  selectedThemeId: "demo"
};
function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: (enabled) => {
      get().setByHost({enabled});
    },
    setFilter: (cacheKey, filter) => {
      const filters = get().getHostData()?.filters || {};
      const existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({filters});
    },
    getFilter: (cacheKey) => {
      const data = get().getHostData();
      return data?.filters ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: (currentThemeId) => {
      get().setByHost({currentThemeId});
    },
    setSelectedThemeId: (selectedThemeId) => {
      get().setByHost({selectedThemeId});
    },
    setSelectedTab: (selectedTab) => {
      get().setByHost({selectedTab});
    },
    getHostData: () => {
      const {hosts} = get();
      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: (data) => {
      const {hosts} = get();
      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({hosts});
    },
    importAppData: (hostsData, {overwrite} = {}) => {
      try {
        if (hostsData) {
          const existingData = get().hosts;
          const hosts = Object.entries(hostsData).reduce((acc, [key, data]) => {
            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }
            return acc;
          }, {...existingData});
          set({hosts});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}
function errorStore(set) {
  return {
    error: null,
    setError: (error) => {
      console.warn(error);
      set({error});
    },
    hideError: () => {
      set({error: null});
    }
  };
}
function getPersistConfig(name) {
  let writeTimeoutId;
  const useBrowserStorage = true;
  return {
    name,
    getStorage: () => ({
      getItem: (name2) => {
        return new Promise((resolve, reject) => {
          if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.get */ .Z.storage.sync.get([name2], ({[name2]: themeData}) => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                } else {
                  resolve(themeData);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              resolve(window.localStorage?.getItem(name2) || "{}");
            }
          } else {
            resolve(window.localStorage?.getItem(name2) || "{}");
          }
        });
      },
      setItem: (name2, themeData) => {
        if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
          const write = () => {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.set */ .Z.storage.sync.set({[name2]: themeData}, () => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              window.localStorage?.setItem(name2, themeData);
            }
          };
          if (!writeTimeoutId) {
            writeTimeoutId = 1;
            write();
          } else {
            clearTimeout(writeTimeoutId);
            writeTimeoutId = setTimeout(() => {
              write();
            }, 1e3);
          }
        } else {
          window.localStorage?.setItem(name2, themeData);
        }
      }
    })
  };
}


/***/ }),

/***/ 29409:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: ./src/shared/Browser.js
var Browser = __webpack_require__(15101);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(94339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(77888);
// EXTERNAL MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js + 2 modules
var emotion_styled_browser_esm = __webpack_require__(65462);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButton.js + 5 modules
var ToggleButton = __webpack_require__(55028);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/Space.js
var Space = __webpack_require__(7171);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js + 5 modules
var Dropdown = __webpack_require__(38755);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/P.js
var P = __webpack_require__(93731);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Provider.js
var Provider = __webpack_require__(14024);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up.js
var chevron_up = __webpack_require__(1);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down.js
var chevron_down = __webpack_require__(79444);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/add.js
var add = __webpack_require__(43);
// EXTERNAL MODULE: ./src/shared/ColorController.js
var ColorController = __webpack_require__(44513);
// EXTERNAL MODULE: ../node_modules/zustand/index.js
var zustand = __webpack_require__(2742);
// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(71818);
// EXTERNAL MODULE: ./src/shared/Compiler.js
var Compiler = __webpack_require__(19301);
// EXTERNAL MODULE: ./src/shared/DOM.js
var DOM = __webpack_require__(9494);
;// CONCATENATED MODULE: ./src/extension/editor/EditorStore.js




const useEditorStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)((set, get) => ({
  enabled: false,
  themesHash: null,
  modifications: {},
  addModification: ({path, themeId = null}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  setTheme: ({path, themeId}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  removeTheme: ({path}) => {
    const {modifications} = get();
    delete modifications[path];
    set({modifications});
  },
  setEnabled: (enabled) => {
    set({enabled});
  }
}), getPersistConfig()));
function listenForModifications({onModification} = {}) {
  return useEditorStore.subscribe(() => {
    if (typeof onModification === "function") {
      onModification();
    }
  });
}
function getPersistConfig() {
  return {
    name: "eufemia-theme-editor",
    blacklist: ["themesHash"]
  };
}
function applyModifications({themes}) {
  const {modifications} = useEditorStore.getState();
  const {css} = (0,Compiler/* compileModifications */.VV)({
    modifications,
    themes,
    modifyDeclaration: ({key, change}) => {
      return `${key}: ${change};${key.replace("--", `--theme-`)}: ${change};`;
    }
  });
  (0,DOM/* insertCSS */.Q4)(css, {elementId: "eufemia-theme-custom"});
}
function removeCustomModifications() {
  (0,DOM/* insertCSS */.Q4)("", {elementId: "eufemia-theme-custom"});
}
function flushThemesHash() {
  useEditorStore.setState({themesHash: Date.now()});
}

// EXTERNAL MODULE: ./src/shared/Bridge.js
var Bridge = __webpack_require__(68208);
;// CONCATENATED MODULE: ./src/extension/editor/ExtensionEditor.jsx











const Layout = emotion_styled_browser_esm/* default.div */.Z.div`
  position: fixed;
  z-index: 10000;
  top: 1.5rem;
  bottom: 0;
  left: 2px;

  display: flex;
  flex-direction: column;

  width: var(--ete-width);
  height: 100vh;
  padding: 0.5rem;
  padding-top: 1rem;

  background-color: var(--color-black-3);
  border: 1px solid var(--color-black-8);
`;
const EditorButton = (0,emotion_styled_browser_esm/* default */.Z)(ToggleButton/* default */.Z)`
  position: fixed;
  z-index: 10001;
  top: 2px;
  left: 2px;

  button {
    border-radius: 0;
    color: var(--color-white);
  }

  button[aria-pressed='false'] {
    padding: 0;
    opacity: 0.5;
    box-shadow: none;
    background-color: var(--color-black-55);
  }
  button[aria-pressed='true'] {
    width: var(--ete-width);
  }
`;
const EteApp = emotion_styled_browser_esm/* default.div */.Z.div`
  --ete-width: 10rem;
  ${(0,ColorController/* generateThemeIgnoreColors */.RZ)()}
`;
const App = () => {
  const {enabled, setEnabled} = useEditorStore();
  const [logPath, setLogPath] = react.useState(null);
  const [toggleEnabled] = react.useState(() => ({checked}) => setEnabled(checked));
  return /* @__PURE__ */ react.createElement(EteApp, null, /* @__PURE__ */ react.createElement(EditorButton, {
    title: "Eufemia Theme Editor",
    id: "ete-toggle-enabled",
    size: "small",
    checked: enabled,
    on_change: toggleEnabled,
    icon: enabled ? chevron_up/* default */.Z : chevron_down/* default */.Z
  }), enabled && /* @__PURE__ */ react.createElement(Layout, {
    id: "ete",
    className: "dnb-core-style"
  }, /* @__PURE__ */ react.createElement(InspectorHandler, {
    onHover: ({path}) => {
      setLogPath(path);
    },
    onCancel: () => {
      setLogPath(null);
    }
  }), logPath ? /* @__PURE__ */ react.createElement(Path, {
    top: "1rem",
    modifier: "x-small"
  }, logPath) : /* @__PURE__ */ react.createElement(ModificationManager, {
    top: "1rem"
  })));
};
function InspectorHandler({onHover, onCancel}) {
  const {addModification} = useEditorStore();
  const [inspect, setInspect] = react.useState(false);
  const [toggleEnabled] = react.useState(() => () => setInspect((s) => {
    if (s && onCancel) {
      onCancel();
    }
    return !s;
  }));
  const [inspector] = react.useState(() => (0,DOM/* createDOMInspector */.yQ)({
    exclude: ["#ete", "#ete-toggle-inspector"],
    onHover: ({element, path}) => {
      if (onHover) {
        onHover({element, path});
      }
    },
    onClick: ({element, path}) => {
      if (onCancel) {
        onCancel({element, path});
      }
      setInspect(false);
      addModification({path});
    }
  }));
  if (inspect) {
    inspector.enable();
  } else {
    inspector.cancel();
  }
  return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(ToggleButton/* default */.Z, {
    id: "ete-toggle-inspector",
    icon: add/* default */.Z,
    icon_position: "left",
    checked: inspect,
    on_change: toggleEnabled
  }, inspect ? "Cancel" : "Inspect"));
}
const marker = (0,DOM/* createInspectorMarker */.gD)();
function hideOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.hide();
  });
}
function showOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.show(elem);
  });
}
function useThemes(themesHash) {
  const [listOfThemes, setListOfThemes] = react.useState([]);
  react.useEffect(() => {
    (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
      setListOfThemes(Object.keys(themes).map((key) => key).filter((key) => !["blue-test", "2x-test"].includes(key)));
    }).catch((e) => {
      console.warn(e);
    });
  }, [themesHash]);
  return listOfThemes;
}
function ModificationManager(props) {
  const {modifications, themesHash, setTheme, removeTheme} = useEditorStore();
  const listOfThemes = useThemes(themesHash);
  return /* @__PURE__ */ react.createElement(Space/* default */.Z, {
    ...props
  }, /* @__PURE__ */ react.createElement(List, null, Object.entries(modifications).map(([path, {themeId}]) => {
    const dontExist = !document.querySelectorAll(path);
    return /* @__PURE__ */ react.createElement("li", {
      key: path
    }, /* @__PURE__ */ react.createElement("div", {
      onMouseOver: () => showOutline({path}),
      onMouseOut: () => hideOutline({path})
    }, /* @__PURE__ */ react.createElement(Path, {
      className: dontExist ? "dont-exist" : "",
      modifier: "x-small"
    }, path), /* @__PURE__ */ react.createElement(StyledDropdown, {
      size: "small",
      skip_portal: true,
      data: [
        ...listOfThemes,
        {content: "Inactive", selected_key: "inactive"},
        {content: "Remove", selected_key: "remove"}
      ],
      value: themeId && listOfThemes ? listOfThemes.indexOf(themeId) : "inactive",
      on_change: ({data}) => {
        const themeId2 = typeof data?.selected_key !== "undefined" ? data?.selected_key : data;
        switch (themeId2) {
          case "remove": {
            removeTheme({path});
            break;
          }
          default: {
            setTheme({path, themeId: themeId2});
          }
        }
      }
    })));
  })));
}
const Path = (0,emotion_styled_browser_esm/* default */.Z)(P/* default */.Z)`
  color: var(--color-success-green);
  &.dont-exist {
    color: var(--color-fire-red);
  }
`;
const StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  display: flex;
  --dropdown-width: 8rem;
`;
const List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  list-style: none;
  padding: 0;

  > li {
    margin-top: 0.5rem;
    background-color: var(--color-pistachio);
  }
`;
function createThemeEditor() {
  let root = document.getElementById("eufemia-theme-editor");
  if (!root) {
    root = document.createElement("div");
    root.setAttribute("id", "eufemia-theme-editor");
    document.body.insertBefore(root, document.body.firstChild);
  }
  react_dom.render(/* @__PURE__ */ react.createElement(Provider/* default */.Z, {
    locale: "en-GB"
  }, /* @__PURE__ */ react.createElement(App, null)), root);
}
function removeThemeEditor() {
  const root = document.getElementById("eufemia-theme-editor");
  if (root) {
    root.remove();
  }
}

;// CONCATENATED MODULE: ./src/extension/content.js




if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
  setLocalThemeModifications();
  (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
    (0,Bridge/* setLocalThemeData */.YB)({themes});
    setLocalThemeModifications();
  });
}
(0,Bridge/* listenForExtensionRequests */.Pb)({
  onResponse: (response) => {
    switch (response.type) {
      case "store-themes": {
        const themes = response.themes;
        (0,Bridge/* setLocalThemeData */.YB)({themes});
        setLocalThemeModifications();
        flushThemesHash();
        if (response.themeId === "blue-test" && response.css) {
          removeCustomModifications();
        }
        break;
      }
      default: {
      }
    }
  }
});
Browser/* default.unsub */.Z.unsub;
function setLocalThemeModifications() {
  if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
    (0,Bridge/* setLocalThemeCSS */.eF)();
    const themes = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
    if (themes) {
      applyModifications({themes});
    }
    createThemeEditor();
    if (typeof Browser/* default.unsub */.Z.unsub === "undefined") {
      Browser/* default.unsub */.Z.unsub = listenForModifications({
        onModification: () => {
          const themes2 = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
          applyModifications({themes: themes2});
        }
      });
    }
  } else if (typeof Browser/* default.unsub */.Z.unsub === "function") {
    removeThemeEditor();
    removeCustomModifications();
    Browser/* default.unsub */.Z.unsub();
    Browser/* default.unsub */.Z.unsub = void 0;
  }
}


/***/ }),

/***/ 68208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pb": () => (/* binding */ listenForExtensionRequests),
/* harmony export */   "ys": () => (/* binding */ getThemesAsync),
/* harmony export */   "$x": () => (/* binding */ getLocalThemeData),
/* harmony export */   "YB": () => (/* binding */ setLocalThemeData),
/* harmony export */   "eF": () => (/* binding */ setLocalThemeCSS),
/* harmony export */   "R": () => (/* binding */ hasEnabledLocalThemeData),
/* harmony export */   "nn": () => (/* binding */ insertCSSIntoPage),
/* harmony export */   "rc": () => (/* binding */ storeCSSInPage),
/* harmony export */   "XW": () => (/* binding */ storeThemesInPage)
/* harmony export */ });
/* unused harmony exports getTabId, getModificationsFromContentAsync, getHost, listenForBackgroundMessages */
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15101);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9494);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68138);



const extensionId =  false || void 0;
function getTabId(cbFunc) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.query */ .Z.tabs.query({currentWindow: true, active: true}, (tabs) => {
      const tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests({onResponse = null} = {}) {
  if (!_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    return;
  }
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.onMessage.addListener */ .Z.runtime.onMessage.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-extension-url": {
        getTabId((tabId) => {
          _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.browserAction.getPopup */ .Z.browserAction.getPopup({tabId}, (popup) => {
            response(popup);
          });
        });
        break;
      }
      case "insert-css": {
        const {elementId, css} = request;
        if (typeof css !== "undefined") {
          (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(css, {elementId});
        }
        response(request);
        break;
      }
      case "store-css": {
        const {css} = request;
        if (typeof css !== "undefined") {
          setLocalThemeData({css});
        }
        response(request);
        break;
      }
      case "store-themes": {
        const {themes} = request;
        if (typeof themes !== "undefined") {
          setLocalThemeData({themes});
        }
        response(request);
        break;
      }
      case "get-modifications": {
        const modifications = JSON.parse(window.localStorage.getItem("eufemia-theme-editor") || "{}");
        response({modifications});
        break;
      }
      default:
        response(request);
        return false;
    }
    if (typeof onResponse === "function") {
      onResponse(request);
    }
    return true;
  });
}
function getThemesAsync() {
  return new Promise((resolve, reject) => {
    if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
      try {
        sendMessageToRuntime({
          type: "get-themes"
        }, (response) => {
          resolve(response || {themes: []});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({themes: null});
    }
  });
}
function getModificationsFromContentAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToTab({
          type: "get-modifications"
        }, (response) => {
          resolve(response || {modifications: {}});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({modifications: {}});
    }
  });
}
function getLocalThemeData() {
  return JSON.parse(window.localStorage?.getItem("eufemia-theme-content") || "{}");
}
function setLocalThemeData(data) {
  const localData = getLocalThemeData();
  window.localStorage?.setItem("eufemia-theme-content", JSON.stringify({...localData, ...data}));
}
function setLocalThemeCSS() {
  const localData = getLocalThemeData();
  if (localData && localData.css) {
    (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(localData.css, {elementId: "eufemia-theme"});
  }
}
function hasEnabledLocalThemeData() {
  const localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data, responseFunc = null) {
  sendMessageToTab({type: "insert-css", ...data}, responseFunc);
}
function storeCSSInPage(data, responseFunc = null) {
  sendMessageToTab({type: "store-css", ...data}, responseFunc);
}
async function getHost() {
  return new Promise((resolve) => {
    if (browser) {
      browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
        const url = new URL(tabs[0].url);
        resolve(url.hostname);
      });
    } else {
      resolve("localhost");
    }
  });
}
function storeThemesInPage(themes, responseFunc = null) {
  sendMessageToRuntime({type: "set-themes", themes}, responseFunc);
  sendMessageToTab({type: "store-themes", themes}, responseFunc);
}
function sendMessageToRuntime(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.sendMessage */ .Z.runtime.sendMessage(extensionId, data, responseFunc);
}
function sendMessageToTab(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    getTabId((tabId) => {
      const themeId = window.EXTENSION_HOST ? _app_core_Store__WEBPACK_IMPORTED_MODULE_1__/* .useAppStore.getState */ .qr.getState().getHostData().currentThemeId : null;
      _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.sendMessage */ .Z.tabs.sendMessage(tabId, Object.assign(data, {themeId}), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc("localhost");
  }
}
function listenForBackgroundMessages() {
  browser?.runtime?.onMessage?.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-themes": {
        const {themes} = backgroundStore.getState();
        response({themes});
        break;
      }
      case "set-themes": {
        const {themes} = request;
        backgroundStore.setState({themes});
        response({themes});
        break;
      }
      default:
        return false;
    }
    return true;
  });
}


/***/ }),

/***/ 15101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export isDev */
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useBrowser);


/***/ }),

/***/ 44513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v0": () => (/* binding */ originalColorsAsArray),
/* harmony export */   "RZ": () => (/* binding */ generateThemeIgnoreColors)
/* harmony export */ });
/* unused harmony exports originalColorsAsObject, fillRemaningColors, getOriginalColorsAsArray, getOriginalColorsAsObject */
/* harmony import */ var _dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37034);

const originalColorsAsObject = getOriginalColorsAsObject();
const originalColorsAsArray = getOriginalColorsAsArray();
function fillRemaningColors(originalColorsList, customColorsList) {
  const keyRef = originalColorsAsObject;
  const notInList = (customColorsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalColorsList.map((item) => ({
    ...item,
    ...(customColorsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalColorsAsArray() {
  const colors = Object.entries(originalColorsAsObject).map(([key, value]) => {
    const name = key.replace(/--color-/g, " ").replace(/-/g, " ").trim().replace(/(^|\s)([a-z])/g, (s) => s.toUpperCase());
    return {key, name, value};
  });
  return colors;
}
function getOriginalColorsAsObject() {
  const colors = Object.entries(_dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z).filter(([name]) => name.includes("--color-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("-border"))
      delete acc[key];
    if (key.includes("-background"))
      delete acc[key];
    if (key.includes("-light"))
      delete acc[key];
    if (key.includes("-medium"))
      delete acc[key];
    return acc;
  }, {});
  delete colors["--color-sea-green-alt-30"];
  delete colors["--color-signal-yellow-30"];
  delete colors["--color-black-30"];
  delete colors["--color-sea-green-alt"];
  delete colors["--color-signal-yellow"];
  return colors;
}
const generateThemeIgnoreColors = () => originalColorsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");


/***/ }),

/***/ 19301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VV": () => (/* binding */ compileModifications)
/* harmony export */ });
/* unused harmony exports useCompilerListener, default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(94339);
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15101);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68138);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9494);
/* harmony import */ var _shared_Bridge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68208);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {enumerable: true, configurable: true, writable: true, value}) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};





const useCompilerListener = () => React.useState(() => new Compiler().listen());
class Compiler {
  constructor() {
    __publicField(this, "run", () => {
      const {themes} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
      const {getHostData} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.getState */ .qr.getState();
      const {enabled, currentThemeId} = getHostData();
      if (enabled) {
        const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
        const theme = getTheme(currentThemeId);
        const css = this.compileList(theme.getThemeChanges());
        this.setCSS(css);
        this.storeCSS(css);
      } else {
        this.reset();
      }
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeThemesInPage */ .XW)(themes);
    });
  }
  listen() {
    const unsubStore = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.subscribe */ .fl.subscribe(this.run);
    const unsubHost = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.subscribe */ .qr.subscribe(this.run);
    return () => {
      unsubStore();
      unsubHost();
    };
  }
  reset() {
    this.setCSS("");
    this.storeCSS("");
  }
  compileList(listWithChanges) {
    const declarations = this.buildDeclarations(listWithChanges);
    const css = listWithChanges.filter((cur) => cur.css).map(({css: css2}) => css2).join("");
    return css + this.combineWithRoot(declarations);
  }
  setCSS(css, elementId = "eufemia-theme") {
    const hash = String(css) + String(elementId);
    if (this._cssMemoHash === hash) {
      return;
    }
    this._cssMemoHash = hash;
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .insertCSSIntoPage */ .nn)({css, elementId});
    } else {
      (0,_DOM__WEBPACK_IMPORTED_MODULE_4__/* .insertCSS */ .Q4)(css, {elementId});
    }
  }
  storeCSS(css) {
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeCSSInPage */ .rc)({css});
    }
  }
  compileFromTheme(theme, opts) {
    return this.buildDeclarations(theme.getThemeChanges(), opts);
  }
  buildDeclarations(listWithChanges, {modifyDeclaration = null} = {}) {
    return listWithChanges.filter((cur) => cur.change).map(({key, change}) => {
      if (typeof modifyDeclaration === "function") {
        return modifyDeclaration({key, change});
      }
      return `${key}: ${change};`;
    });
  }
  combineWithRoot(declarations) {
    return declarations?.length ? `:root{${declarations.join("")}}` : "";
  }
}
function compileModifications({modifications, themes, ...opts}) {
  if (themes) {
    _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.setState */ .ph.setState({themes});
    const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.getState */ .ph.getState();
    const css = Object.entries(modifications).map(([path, {themeId}]) => {
      if (themeId && themeId !== "inactive") {
        const theme = getTheme(themeId);
        const themeCSS = new Compiler().compileFromTheme(theme, opts).join("");
        return `${path}{${themeCSS}}`;
      }
      return null;
    }).filter(Boolean).join("\n");
    return {css};
  }
  return {css: ""};
}


/***/ }),

/***/ 9494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q4": () => (/* binding */ insertCSS),
/* harmony export */   "yQ": () => (/* binding */ createDOMInspector),
/* harmony export */   "gD": () => (/* binding */ createInspectorMarker)
/* harmony export */ });
/* harmony import */ var _dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36620);

const containers = [];
const styleElements = [];
function insertCSS(css, {
  elementId = "inserted-css",
  replace = true,
  prepend = false,
  targetElement = document.querySelector("head")
} = {}) {
  css = String(css || "");
  const position = prepend === true ? "prepend" : "append";
  let containerId = containers.indexOf(targetElement);
  if (containerId === -1) {
    containerId = containers.push(targetElement) - 1;
    styleElements[containerId] = {};
  }
  let styleElement;
  if (typeof styleElements[containerId] !== "undefined" && typeof styleElements[containerId][elementId] !== "undefined") {
    styleElement = styleElements[containerId][elementId];
  } else {
    styleElement = styleElements[containerId][elementId] = createStyleElement({
      elementId
    });
    if (position === "prepend") {
      targetElement.insertBefore(styleElement, targetElement.childNodes[0]);
    } else {
      targetElement.appendChild(styleElement);
    }
  }
  if (css.charCodeAt(0) === 65279) {
    css = css.substr(1, css.length);
  }
  if (replace) {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = css;
    } else {
      styleElement.textContent = css;
    }
  } else {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText += css;
    } else {
      styleElement.textContent += css;
    }
  }
  return styleElement;
}
function createStyleElement({elementId = null} = {}) {
  const styleElement = document.createElement("style");
  styleElement.setAttribute("type", "text/css");
  if (elementId) {
    styleElement.setAttribute("id", elementId);
  }
  return styleElement;
}
function constructCSSPath(el) {
  if (!(el instanceof Element)) {
    return;
  }
  const VALID_CLASSNAME = /^[_a-zA-Z\- ]*$/;
  let path = [];
  while (el.nodeType === Node.ELEMENT_NODE) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) {
      selector += `#${el.id}`;
      path.unshift(selector);
      break;
    } else if (el.className && VALID_CLASSNAME.test(el.className)) {
      selector += `.${el.className.trim().replace(/\s+/g, ".")}`;
    } else {
      let sib = el, nth = 1;
      while (sib = sib.previousElementSibling) {
        if (sib.nodeName.toLowerCase() === selector)
          nth++;
      }
      if (nth !== 1)
        selector += ":nth-of-type(" + nth + ")";
    }
    path.unshift(selector);
    el = el.parentNode;
  }
  return path.join(" > ");
}
function createDOMInspector({
  root = "body",
  exclude = [],
  preventClick = true,
  outlineStyle = "0.5rem solid rgba(0, 114, 114, 0.5)",
  onClick,
  onHover
} = {}) {
  let selected, excludedElements;
  const removeHighlight = (el) => {
    if (el) {
      el.style.outline = "";
      el.style.cursor = "";
    }
  };
  const highlight = (el) => {
    if (preventClick) {
      el.style.cursor = "";
    }
    el.style.outline = outlineStyle;
    el.style.outlineOffset = `-${el.style.outlineWidth}`;
  };
  const shouldBeExcluded = (ev) => {
    if (excludedElements && excludedElements.length && excludedElements.some((parent) => parent === ev.target || parent.contains(ev.target))) {
      return true;
    }
  };
  const handleMouseOver = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    selected = ev.target;
    highlight(selected);
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onHover === "function") {
      onHover({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const handleMouseOut = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    removeHighlight(ev.target);
  };
  const handleMouseDown = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  };
  const handleClick = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onClick === "function") {
      onClick({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const prepareExcluded = (rootEl) => {
    if (!exclude.length) {
      return [];
    }
    const excludedNested = exclude.flatMap((element) => {
      if (typeof element === "string" || element instanceof String) {
        return Array.from(rootEl.querySelectorAll(element));
      } else if (element instanceof Element) {
        return [element];
      } else if (element.length > 0 && element[0] instanceof Element) {
        return Array.from(element);
      }
      return [];
    });
    return Array.from(excludedNested).flat();
  };
  const enable = (onClickCallback) => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    if (exclude) {
      excludedElements = prepareExcluded(rootEl);
    }
    rootEl.addEventListener("mouseover", handleMouseOver, true);
    rootEl.addEventListener("mouseout", handleMouseOut, true);
    rootEl.addEventListener("mousedown", handleMouseDown, true);
    rootEl.addEventListener("click", handleClick, true);
    if (onClickCallback) {
      onClick = onClickCallback;
    }
  };
  const cancel = () => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    rootEl.removeEventListener("mouseover", handleMouseOver, true);
    rootEl.removeEventListener("mouseout", handleMouseOut, true);
    rootEl.removeEventListener("mousedown", handleMouseDown, true);
    rootEl.removeEventListener("click", handleClick, true);
    removeHighlight(selected);
  };
  return {
    enable,
    cancel
  };
}
function createInspectorMarker() {
  try {
    let markerEl = document.getElementById("eufmeia-theme-inspector-marker");
    if (!markerEl) {
      markerEl = document.createElement("div");
      markerEl.setAttribute("id", "eufmeia-theme-inspector-marker");
      markerEl.style.display = "none";
      markerEl.style.position = "absolute";
      markerEl.style.zIndex = "9000";
      markerEl.style.transition = "background 2s ease";
      markerEl.style.outline = "0.5rem solid rgba(0, 114, 114, 0.5)";
      document.body.appendChild(markerEl);
    }
    return {
      element: markerEl,
      hide: () => {
        if (markerEl) {
          markerEl.style.display = "none";
        }
      },
      show: (element) => {
        if (markerEl) {
          const style = getComputedStyle(element);
          markerEl.style.display = "block";
          markerEl.style.top = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetTop */ .oJ)(element)}px`;
          markerEl.style.left = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetLeft */ .pB)(element)}px`;
          markerEl.style.width = style.width;
          markerEl.style.height = style.height;
          markerEl.style.background = "rgba(0, 114, 114, 0.5)";
          setTimeout(() => {
            try {
              markerEl.style.background = "transparent";
            } catch (e) {
              console.warn(e);
            }
          }, 300);
        }
      }
    };
  } catch (e) {
    console.warn(e);
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					result = fn();
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 998;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			998: 0,
/******/ 			409: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			for(moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			__webpack_require__.O();
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkeufemia_theme_manager_extension"] = self["webpackChunkeufemia_theme_manager_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [216], () => (__webpack_require__(29409)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=content.js.map