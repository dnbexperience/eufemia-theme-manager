var global$1 = (typeof global !== "undefined" ? global :
            typeof self !== "undefined" ? self :
            typeof window !== "undefined" ? window : {});

// shim for using process in browser
// based off https://github.com/defunctzombie/node-process/blob/master/browser.js

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
var cachedSetTimeout = defaultSetTimout;
var cachedClearTimeout = defaultClearTimeout;
if (typeof global$1.setTimeout === 'function') {
    cachedSetTimeout = setTimeout;
}
if (typeof global$1.clearTimeout === 'function') {
    cachedClearTimeout = clearTimeout;
}

function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}
function nextTick(fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
}
// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
var title = 'browser';
var platform = 'browser';
var browser = true;
var env = {};
var argv = [];
var version = ''; // empty string to avoid regexp issues
var versions = {};
var release = {};
var config = {};

function noop() {}

var on = noop;
var addListener = noop;
var once = noop;
var off = noop;
var removeListener = noop;
var removeAllListeners = noop;
var emit = noop;

function binding(name) {
    throw new Error('process.binding is not supported');
}

function cwd () { return '/' }
function chdir (dir) {
    throw new Error('process.chdir is not supported');
}function umask() { return 0; }

// from https://github.com/kumavis/browser-process-hrtime/blob/master/index.js
var performance$1 = global$1.performance || {};
var performanceNow =
  performance$1.now        ||
  performance$1.mozNow     ||
  performance$1.msNow      ||
  performance$1.oNow       ||
  performance$1.webkitNow  ||
  function(){ return (new Date()).getTime() };

// generate timestamp or delta
// see http://nodejs.org/api/process.html#process_process_hrtime
function hrtime(previousTimestamp){
  var clocktime = performanceNow.call(performance$1)*1e-3;
  var seconds = Math.floor(clocktime);
  var nanoseconds = Math.floor((clocktime%1)*1e9);
  if (previousTimestamp) {
    seconds = seconds - previousTimestamp[0];
    nanoseconds = nanoseconds - previousTimestamp[1];
    if (nanoseconds<0) {
      seconds--;
      nanoseconds += 1e9;
    }
  }
  return [seconds,nanoseconds]
}

var startTime = new Date();
function uptime() {
  var currentTime = new Date();
  var dif = currentTime - startTime;
  return dif / 1000;
}

var process = {
  nextTick: nextTick,
  title: title,
  browser: browser,
  env: env,
  argv: argv,
  version: version,
  versions: versions,
  on: on,
  addListener: addListener,
  once: once,
  off: off,
  removeListener: removeListener,
  removeAllListeners: removeAllListeners,
  emit: emit,
  binding: binding,
  cwd: cwd,
  chdir: chdir,
  umask: umask,
  hrtime: hrtime,
  platform: platform,
  release: release,
  config: config,
  uptime: uptime
};

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn) {
  var module = { exports: {} };
	return fn(module, module.exports), module.exports;
}

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

var objectAssign = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};

/** @license React v17.0.1
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var react_production_min = createCommonjsModule(function (module, exports) {
var n=60103,p=60106;exports.Fragment=60107;exports.StrictMode=60108;exports.Profiler=60114;var q=60109,r=60110,t=60112;exports.Suspense=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");exports.Fragment=w("react.fragment");exports.StrictMode=w("react.strict_mode");exports.Profiler=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");exports.Suspense=w("react.suspense");u=w("react.memo");v=w("react.lazy");}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return "function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return "Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return !1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A;}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState");};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate");};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A;}var F=E.prototype=new D;F.constructor=E;objectAssign(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f;}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return {$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return {$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return "object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return "$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return "object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0;}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d);}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b);},function(b){0===a._status&&(a._status=2,a._result=b);});}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:objectAssign};
exports.Children={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments);},c);},count:function(a){var b=0;P(a,function(){b++;});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};exports.Component=C;exports.PureComponent=E;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=T;
exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=objectAssign({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f]);}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g;}return {$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};exports.createElement=J;exports.createFactory=function(a){var b=J.bind(null,a);b.type=a;return b};exports.createRef=function(){return {current:null}};exports.forwardRef=function(a){return {$$typeof:t,render:a}};exports.isValidElement=L;
exports.lazy=function(a){return {$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};exports.memo=function(a,b){return {$$typeof:u,type:a,compare:void 0===b?null:b}};exports.useCallback=function(a,b){return S().useCallback(a,b)};exports.useContext=function(a,b){return S().useContext(a,b)};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return S().useEffect(a,b)};exports.useImperativeHandle=function(a,b,c){return S().useImperativeHandle(a,b,c)};
exports.useLayoutEffect=function(a,b){return S().useLayoutEffect(a,b)};exports.useMemo=function(a,b){return S().useMemo(a,b)};exports.useReducer=function(a,b,c){return S().useReducer(a,b,c)};exports.useRef=function(a){return S().useRef(a)};exports.useState=function(a){return S().useState(a)};exports.version="17.0.1";
});

var react_development = createCommonjsModule(function (module, exports) {
});

var react = createCommonjsModule(function (module) {

{
  module.exports = react_production_min;
}
});

function memoize(fn) {
  var cache = Object.create(null);
  return function (arg) {
    if (cache[arg] === undefined) cache[arg] = fn(arg);
    return cache[arg];
  };
}

var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|inert|itemProp|itemScope|itemType|itemID|itemRef|on|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/; // https://esbench.com/bench/5bfee68a4cd7e6009ef61d23

var isPropValid = /* #__PURE__ */memoize(function (prop) {
  return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111
  /* o */
  && prop.charCodeAt(1) === 110
  /* n */
  && prop.charCodeAt(2) < 91;
}
/* Z+1 */
);

/*

Based off glamor's StyleSheet, thanks Sunil ❤️

high performance StyleSheet for css-in-js systems

- uses multiple style tags behind the scenes for millions of rules
- uses `insertRule` for appending in production for *much* faster performance

// usage

import { StyleSheet } from '@emotion/sheet'

let styleSheet = new StyleSheet({ key: '', container: document.head })

styleSheet.insert('#box { border: 1px solid red; }')
- appends a css rule into the stylesheet

styleSheet.flush()
- empties the stylesheet of all its contents

*/
// $FlowFixMe
function sheetForTag(tag) {
  if (tag.sheet) {
    // $FlowFixMe
    return tag.sheet;
  } // this weirdness brought to you by firefox

  /* istanbul ignore next */


  for (var i = 0; i < document.styleSheets.length; i++) {
    if (document.styleSheets[i].ownerNode === tag) {
      // $FlowFixMe
      return document.styleSheets[i];
    }
  }
}

function createStyleElement(options) {
  var tag = document.createElement('style');
  tag.setAttribute('data-emotion', options.key);

  if (options.nonce !== undefined) {
    tag.setAttribute('nonce', options.nonce);
  }

  tag.appendChild(document.createTextNode(''));
  tag.setAttribute('data-s', '');
  return tag;
}

var StyleSheet = /*#__PURE__*/function () {
  function StyleSheet(options) {
    var _this = this;

    this._insertTag = function (tag) {
      var before;

      if (_this.tags.length === 0) {
        before = _this.prepend ? _this.container.firstChild : _this.before;
      } else {
        before = _this.tags[_this.tags.length - 1].nextSibling;
      }

      _this.container.insertBefore(tag, before);

      _this.tags.push(tag);
    };

    this.isSpeedy = options.speedy === undefined ? "production" === 'production' : options.speedy;
    this.tags = [];
    this.ctr = 0;
    this.nonce = options.nonce; // key is the value of the data-emotion attribute, it's used to identify different sheets

    this.key = options.key;
    this.container = options.container;
    this.prepend = options.prepend;
    this.before = null;
  }

  var _proto = StyleSheet.prototype;

  _proto.hydrate = function hydrate(nodes) {
    nodes.forEach(this._insertTag);
  };

  _proto.insert = function insert(rule) {
    // the max length is how many rules we have per style tag, it's 65000 in speedy mode
    // it's 1 in dev because we insert source maps that map a single rule to a location
    // and you can only have one source map per style tag
    if (this.ctr % (this.isSpeedy ? 65000 : 1) === 0) {
      this._insertTag(createStyleElement(this));
    }

    var tag = this.tags[this.tags.length - 1];

    if (this.isSpeedy) {
      var sheet = sheetForTag(tag);

      try {
        // this is the ultrafast version, works across browsers
        // the big drawback is that the css won't be editable in devtools
        sheet.insertRule(rule, sheet.cssRules.length);
      } catch (e) {
      }
    } else {
      tag.appendChild(document.createTextNode(rule));
    }

    this.ctr++;
  };

  _proto.flush = function flush() {
    // $FlowFixMe
    this.tags.forEach(function (tag) {
      return tag.parentNode.removeChild(tag);
    });
    this.tags = [];
    this.ctr = 0;
  };

  return StyleSheet;
}();

var MS = '-ms-';
var MOZ = '-moz-';
var WEBKIT = '-webkit-';

var COMMENT = 'comm';
var RULESET = 'rule';
var DECLARATION = 'decl';
var IMPORT = '@import';
var KEYFRAMES = '@keyframes';

/**
 * @param {number}
 * @return {number}
 */
var abs = Math.abs;

/**
 * @param {number}
 * @return {string}
 */
var from = String.fromCharCode;

/**
 * @param {string} value
 * @param {number} length
 * @return {number}
 */
function hash (value, length) {
	return (((((((length << 2) ^ charat(value, 0)) << 2) ^ charat(value, 1)) << 2) ^ charat(value, 2)) << 2) ^ charat(value, 3)
}

/**
 * @param {string} value
 * @return {string}
 */
function trim (value) {
	return value.trim()
}

/**
 * @param {string} value
 * @param {RegExp} pattern
 * @return {string?}
 */
function match (value, pattern) {
	return (value = pattern.exec(value)) ? value[0] : value
}

/**
 * @param {string} value
 * @param {(string|RegExp)} pattern
 * @param {string} replacement
 * @return {string}
 */
function replace (value, pattern, replacement) {
	return value.replace(pattern, replacement)
}

/**
 * @param {string} value
 * @param {string} value
 * @return {number}
 */
function indexof (value, search) {
	return value.indexOf(search)
}

/**
 * @param {string} value
 * @param {number} index
 * @return {number}
 */
function charat (value, index) {
	return value.charCodeAt(index) | 0
}

/**
 * @param {string} value
 * @param {number} begin
 * @param {number} end
 * @return {string}
 */
function substr (value, begin, end) {
	return value.slice(begin, end)
}

/**
 * @param {string} value
 * @return {number}
 */
function strlen (value) {
	return value.length
}

/**
 * @param {any[]} value
 * @return {number}
 */
function sizeof (value) {
	return value.length
}

/**
 * @param {any} value
 * @param {any[]} array
 * @return {any}
 */
function append (value, array) {
	return array.push(value), value
}

/**
 * @param {string[]} array
 * @param {function} callback
 * @return {string}
 */
function combine (array, callback) {
	return array.map(callback).join('')
}

var line = 1;
var column = 1;
var length = 0;
var position = 0;
var character = 0;
var characters = '';

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {string} type
 * @param {string[]} props
 * @param {object[]} children
 * @param {number} length
 */
function node (value, root, parent, type, props, children, length) {
	return {value: value, root: root, parent: parent, type: type, props: props, children: children, line: line, column: column, length: length, return: ''}
}

/**
 * @param {string} value
 * @param {object} root
 * @param {string} type
 */
function copy (value, root, type) {
	return node(value, root.root, root.parent, type, root.props, root.children, 0)
}

/**
 * @return {number}
 */
function char () {
	return character
}

/**
 * @return {number}
 */
function next () {
	character = position < length ? charat(characters, position++) : 0;

	if (column++, character === 10)
		column = 1, line++;

	return character
}

/**
 * @return {number}
 */
function peek () {
	return charat(characters, position)
}

/**
 * @return {number}
 */
function caret () {
	return position
}

/**
 * @param {number} begin
 * @param {number} end
 * @return {string}
 */
function slice (begin, end) {
	return substr(characters, begin, end)
}

/**
 * @param {number} type
 * @return {number}
 */
function token (type) {
	switch (type) {
		// \0 \t \n \r \s whitespace token
		case 0: case 9: case 10: case 13: case 32:
			return 5
		// ! + , / > @ ~ isolate token
		case 33: case 43: case 44: case 47: case 62: case 64: case 126:
		// ; { } / breakpoint token
		case 59: case 123: case 125:
			return 4
		// : accompanied token
		case 58:
			return 3
		// " ' ( [ opening delimit token
		case 34: case 39: case 40: case 91:
			return 2
		// ) ] closing delimit token
		case 41: case 93:
			return 1
	}

	return 0
}

/**
 * @param {string} value
 * @return {any[]}
 */
function alloc (value) {
	return line = column = 1, length = strlen(characters = value), position = 0, []
}

/**
 * @param {any} value
 * @return {any}
 */
function dealloc (value) {
	return characters = '', value
}

/**
 * @param {number} type
 * @return {string}
 */
function delimit (type) {
	return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)))
}

/**
 * @param {number} type
 * @return {string}
 */
function whitespace (type) {
	while (character = peek())
		if (character < 33)
			next();
		else
			break

	return token(type) > 2 || token(character) > 3 ? '' : ' '
}

/**
 * @param {number} type
 * @return {number}
 */
function delimiter (type) {
	while (next())
		switch (character) {
			// ] ) " '
			case type:
				return position
			// " '
			case 34: case 39:
				return delimiter(type === 34 || type === 39 ? type : character)
			// (
			case 40:
				if (type === 41)
					delimiter(type);
				break
			// \
			case 92:
				next();
				break
		}

	return position
}

/**
 * @param {number} type
 * @param {number} index
 * @return {number}
 */
function commenter (type, index) {
	while (next())
		// //
		if (type + character === 47 + 10)
			break
		// /*
		else if (type + character === 42 + 42 && peek() === 47)
			break

	return '/*' + slice(index, position - 1) + '*' + from(type === 47 ? type : next())
}

/**
 * @param {number} index
 * @return {string}
 */
function identifier (index) {
	while (!token(peek()))
		next();

	return slice(index, position)
}

/**
 * @param {string} value
 * @return {object[]}
 */
function compile (value) {
	return dealloc(parse('', null, null, null, [''], value = alloc(value), 0, [0], value))
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {string[]} rule
 * @param {string[]} rules
 * @param {string[]} rulesets
 * @param {number[]} pseudo
 * @param {number[]} points
 * @param {string[]} declarations
 * @return {object}
 */
function parse (value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
	var index = 0;
	var offset = 0;
	var length = pseudo;
	var atrule = 0;
	var property = 0;
	var previous = 0;
	var variable = 1;
	var scanning = 1;
	var ampersand = 1;
	var character = 0;
	var type = '';
	var props = rules;
	var children = rulesets;
	var reference = rule;
	var characters = type;

	while (scanning)
		switch (previous = character, character = next()) {
			// " ' [ (
			case 34: case 39: case 91: case 40:
				characters += delimit(character);
				break
			// \t \n \r \s
			case 9: case 10: case 13: case 32:
				characters += whitespace(previous);
				break
			// /
			case 47:
				switch (peek()) {
					case 42: case 47:
						append(comment(commenter(next(), caret()), root, parent), declarations);
						break
					default:
						characters += '/';
				}
				break
			// {
			case 123 * variable:
				points[index++] = strlen(characters) * ampersand;
			// } ; \0
			case 125 * variable: case 59: case 0:
				switch (character) {
					// \0 }
					case 0: case 125: scanning = 0;
					// ;
					case 59 + offset:
						if (property > 0)
							append(property > 32 ? declaration(characters + ';', rule, parent, length - 1) : declaration(replace(characters, ' ', '') + ';', rule, parent, length - 2), declarations);
						break
					// @ ;
					case 59: characters += ';';
					// { rule/at-rule
					default:
						append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length), rulesets);

						if (character === 123)
							if (offset === 0)
								parse(characters, root, reference, reference, props, rulesets, length, points, children);
							else
								switch (atrule) {
									// d m s
									case 100: case 109: case 115:
										parse(value, reference, reference, rule && append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length), children), rules, children, length, points, rule ? props : children);
										break
									default:
										parse(characters, reference, reference, reference, [''], children, length, points, children);
								}
				}

				index = offset = property = 0, variable = ampersand = 1, type = characters = '', length = pseudo;
				break
			// :
			case 58:
				length = 1 + strlen(characters), property = previous;
			default:
				switch (characters += from(character), character * variable) {
					// &
					case 38:
						ampersand = offset > 0 ? 1 : (characters += '\f', -1);
						break
					// ,
					case 44:
						points[index++] = (strlen(characters) - 1) * ampersand, ampersand = 1;
						break
					// @
					case 64:
						// -
						if (peek() === 45)
							characters += delimit(next());

						atrule = peek(), offset = strlen(type = characters += identifier(caret())), character++;
						break
					// -
					case 45:
						if (previous === 45 && strlen(characters) == 2)
							variable = 0;
				}
		}

	return rulesets
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {number} index
 * @param {number} offset
 * @param {string[]} rules
 * @param {number[]} points
 * @param {string} type
 * @param {string[]} props
 * @param {string[]} children
 * @param {number} length
 * @return {object}
 */
function ruleset (value, root, parent, index, offset, rules, points, type, props, children, length) {
	var post = offset - 1;
	var rule = offset === 0 ? rules : [''];
	var size = sizeof(rule);

	for (var i = 0, j = 0, k = 0; i < index; ++i)
		for (var x = 0, y = substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x)
			if (z = trim(j > 0 ? rule[x] + ' ' + y : replace(y, /&\f/g, rule[x])))
				props[k++] = z;

	return node(value, root, parent, offset === 0 ? RULESET : type, props, children, length)
}

/**
 * @param {number} value
 * @param {object} root
 * @param {object?} parent
 * @return {object}
 */
function comment (value, root, parent) {
	return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0)
}

/**
 * @param {string} value
 * @param {object} root
 * @param {object?} parent
 * @param {number} length
 * @return {object}
 */
function declaration (value, root, parent, length) {
	return node(value, root, parent, DECLARATION, substr(value, 0, length), substr(value, length + 1, -1), length)
}

/**
 * @param {string} value
 * @param {number} length
 * @return {string}
 */
function prefix (value, length) {
	switch (hash(value, length)) {
		// animation, animation-(delay|direction|duration|fill-mode|iteration-count|name|play-state|timing-function)
		case 5737: case 4201: case 3177: case 3433: case 1641: case 4457: case 2921:
		// text-decoration, filter, clip-path, backface-visibility, column, box-decoration-break
		case 5572: case 6356: case 5844: case 3191: case 6645: case 3005:
		// mask, mask-image, mask-(mode|clip|size), mask-(repeat|origin), mask-position, mask-composite,
		case 6391: case 5879: case 5623: case 6135: case 4599: case 4855:
		// background-clip, columns, column-(count|fill|gap|rule|rule-color|rule-style|rule-width|span|width)
		case 4215: case 6389: case 5109: case 5365: case 5621: case 3829:
			return WEBKIT + value + value
		// appearance, user-select, transform, hyphens, text-size-adjust
		case 5349: case 4246: case 4810: case 6968: case 2756:
			return WEBKIT + value + MOZ + value + MS + value + value
		// flex, flex-direction
		case 6828: case 4268:
			return WEBKIT + value + MS + value + value
		// order
		case 6165:
			return WEBKIT + value + MS + 'flex-' + value + value
		// align-items
		case 5187:
			return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + 'box-$1$2' + MS + 'flex-$1$2') + value
		// align-self
		case 5443:
			return WEBKIT + value + MS + 'flex-item-' + replace(value, /flex-|-self/, '') + value
		// align-content
		case 4675:
			return WEBKIT + value + MS + 'flex-line-pack' + replace(value, /align-content|flex-|-self/, '') + value
		// flex-shrink
		case 5548:
			return WEBKIT + value + MS + replace(value, 'shrink', 'negative') + value
		// flex-basis
		case 5292:
			return WEBKIT + value + MS + replace(value, 'basis', 'preferred-size') + value
		// flex-grow
		case 6060:
			return WEBKIT + 'box-' + replace(value, '-grow', '') + WEBKIT + value + MS + replace(value, 'grow', 'positive') + value
		// transition
		case 4554:
			return WEBKIT + replace(value, /([^-])(transform)/g, '$1' + WEBKIT + '$2') + value
		// cursor
		case 6187:
			return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + '$1'), /(image-set)/, WEBKIT + '$1'), value, '') + value
		// background, background-image
		case 5495: case 3959:
			return replace(value, /(image-set\([^]*)/, WEBKIT + '$1' + '$`$1')
		// justify-content
		case 4968:
			return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + 'box-pack:$3' + MS + 'flex-pack:$3'), /s.+-b[^;]+/, 'justify') + WEBKIT + value + value
		// (margin|padding)-inline-(start|end)
		case 4095: case 3583: case 4068: case 2532:
			return replace(value, /(.+)-inline(.+)/, WEBKIT + '$1$2') + value
		// (min|max)?(width|height|inline-size|block-size)
		case 8116: case 7059: case 5753: case 5535:
		case 5445: case 5701: case 4933: case 4677:
		case 5533: case 5789: case 5021: case 4765:
			// stretch, max-content, min-content, fill-available
			if (strlen(value) - 1 - length > 6)
				switch (charat(value, length + 1)) {
					// (f)ill-available, (f)it-content
					case 102: length = charat(value, length + 3);
					// (m)ax-content, (m)in-content
					case 109:
						return replace(value, /(.+:)(.+)-([^]+)/, '$1' + WEBKIT + '$2-$3' + '$1' + MOZ + (length == 108 ? '$3' : '$2-$3')) + value
					// (s)tretch
					case 115:
						return ~indexof(value, 'stretch') ? prefix(replace(value, 'stretch', 'fill-available'), length) + value : value
				}
			break
		// position: sticky
		case 4949:
			// (s)ticky?
			if (charat(value, length + 1) !== 115)
				break
		// display: (flex|inline-flex|inline-box)
		case 6444:
			switch (charat(value, strlen(value) - 3 - (~indexof(value, '!important') && 10))) {
				// stic(k)y, inline-b(o)x
				case 107: case 111:
					return replace(value, value, WEBKIT + value) + value
				// (inline-)?fl(e)x
				case 101:
					return replace(value, /(.+:)([^;!]+)(;|!.+)?/, '$1' + WEBKIT + (charat(value, 14) === 45 ? 'inline-' : '') + 'box$3' + '$1' + WEBKIT + '$2$3' + '$1' + MS + '$2box$3') + value
			}
			break
		// writing-mode
		case 5936:
			switch (charat(value, length + 11)) {
				// vertical-l(r)
				case 114:
					return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, 'tb') + value
				// vertical-r(l)
				case 108:
					return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, 'tb-rl') + value
				// horizontal(-)tb
				case 45:
					return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, 'lr') + value
			}

			return WEBKIT + value + MS + value + value
	}

	return value
}

/**
 * @param {object[]} children
 * @param {function} callback
 * @return {string}
 */
function serialize (children, callback) {
	var output = '';
	var length = sizeof(children);

	for (var i = 0; i < length; i++)
		output += callback(children[i], i, children, callback) || '';

	return output
}

/**
 * @param {object} element
 * @param {number} index
 * @param {object[]} children
 * @param {function} callback
 * @return {string}
 */
function stringify (element, index, children, callback) {
	switch (element.type) {
		case IMPORT: case DECLARATION: return element.return = element.return || element.value
		case COMMENT: return ''
		case RULESET: element.value = element.props.join(',');
	}

	return strlen(children = serialize(element.children, callback)) ? element.return = element.value + '{' + children + '}' : ''
}

/**
 * @param {function[]} collection
 * @return {function}
 */
function middleware (collection) {
	var length = sizeof(collection);

	return function (element, index, children, callback) {
		var output = '';

		for (var i = 0; i < length; i++)
			output += collection[i](element, index, children, callback) || '';

		return output
	}
}

/**
 * @param {function} callback
 * @return {function}
 */
function rulesheet (callback) {
	return function (element) {
		if (!element.root)
			if (element = element.return)
				callback(element);
	}
}

/**
 * @param {object} element
 * @param {number} index
 * @param {object[]} children
 * @param {function} callback
 */
function prefixer (element, index, children, callback) {
	if (!element.return)
		switch (element.type) {
			case DECLARATION: element.return = prefix(element.value, element.length);
				break
			case KEYFRAMES:
				return serialize([copy(replace(element.value, '@', '@' + WEBKIT), element, '')], callback)
			case RULESET:
				if (element.length)
					return combine(element.props, function (value) {
						switch (match(value, /(::plac\w+|:read-\w+)/)) {
							// :read-(only|write)
							case ':read-only': case ':read-write':
								return serialize([copy(replace(value, /:(read-\w+)/, ':' + MOZ + '$1'), element, '')], callback)
							// :placeholder
							case '::placeholder':
								return serialize([
									copy(replace(value, /:(plac\w+)/, ':' + WEBKIT + 'input-$1'), element, ''),
									copy(replace(value, /:(plac\w+)/, ':' + MOZ + '$1'), element, ''),
									copy(replace(value, /:(plac\w+)/, MS + 'input-$1'), element, '')
								], callback)
						}

						return ''
					})
		}
}

var weakMemoize = function weakMemoize(func) {
  // $FlowFixMe flow doesn't include all non-primitive types as allowed for weakmaps
  var cache = new WeakMap();
  return function (arg) {
    if (cache.has(arg)) {
      // $FlowFixMe
      return cache.get(arg);
    }

    var ret = func(arg);
    cache.set(arg, ret);
    return ret;
  };
};

var toRules = function toRules(parsed, points) {
  // pretend we've started with a comma
  var index = -1;
  var character = 44;

  do {
    switch (token(character)) {
      case 0:
        // &\f
        if (character === 38 && peek() === 12) {
          // this is not 100% correct, we don't account for literal sequences here - like for example quoted strings
          // stylis inserts \f after & to know when & where it should replace this sequence with the context selector
          // and when it should just concatenate the outer and inner selectors
          // it's very unlikely for this sequence to actually appear in a different context, so we just leverage this fact here
          points[index] = 1;
        }

        parsed[index] += identifier(position - 1);
        break;

      case 2:
        parsed[index] += delimit(character);
        break;

      case 4:
        // comma
        if (character === 44) {
          // colon
          parsed[++index] = peek() === 58 ? '&\f' : '';
          points[index] = parsed[index].length;
          break;
        }

      // fallthrough

      default:
        parsed[index] += from(character);
    }
  } while (character = next());

  return parsed;
};

var getRules = function getRules(value, points) {
  return dealloc(toRules(alloc(value), points));
}; // WeakSet would be more appropriate, but only WeakMap is supported in IE11


var fixedElements = /* #__PURE__ */new WeakMap();
var compat = function compat(element) {
  if (element.type !== 'rule' || !element.parent || // .length indicates if this rule contains pseudo or not
  !element.length) {
    return;
  }

  var value = element.value,
      parent = element.parent;
  var isImplicitRule = element.column === parent.column && element.line === parent.line;

  while (parent.type !== 'rule') {
    parent = parent.parent;
    if (!parent) return;
  } // short-circuit for the simplest case


  if (element.props.length === 1 && value.charCodeAt(0) !== 58
  /* colon */
  && !fixedElements.get(parent)) {
    return;
  } // if this is an implicitly inserted rule (the one eagerly inserted at the each new nested level)
  // then the props has already been manipulated beforehand as they that array is shared between it and its "rule parent"


  if (isImplicitRule) {
    return;
  }

  fixedElements.set(element, true);
  var points = [];
  var rules = getRules(value, points);
  var parentRules = parent.props;

  for (var i = 0, k = 0; i < rules.length; i++) {
    for (var j = 0; j < parentRules.length; j++, k++) {
      element.props[k] = points[i] ? rules[i].replace(/&\f/g, parentRules[j]) : parentRules[j] + " " + rules[i];
    }
  }
};
var removeLabel = function removeLabel(element) {
  if (element.type === 'decl') {
    var value = element.value;

    if ( // charcode for l
    value.charCodeAt(0) === 108 && // charcode for b
    value.charCodeAt(2) === 98) {
      // this ignores label
      element["return"] = '';
      element.value = '';
    }
  }
};

var isBrowser = typeof document !== 'undefined';
var getServerStylisCache = isBrowser ? undefined : weakMemoize(function () {
  return memoize(function () {
    var cache = {};
    return function (name) {
      return cache[name];
    };
  });
});
var defaultStylisPlugins = [prefixer];

var createCache = function createCache(options) {
  var key = options.key;

  if (isBrowser && key === 'css') {
    var ssrStyles = document.querySelectorAll("style[data-emotion]:not([data-s])"); // get SSRed styles out of the way of React's hydration
    // document.head is a safe place to move them to

    Array.prototype.forEach.call(ssrStyles, function (node) {
      document.head.appendChild(node);
      node.setAttribute('data-s', '');
    });
  }

  var stylisPlugins = options.stylisPlugins || defaultStylisPlugins;

  var inserted = {}; // $FlowFixMe

  var container;
  var nodesToHydrate = [];

  if (isBrowser) {
    container = options.container || document.head;
    Array.prototype.forEach.call(document.querySelectorAll("style[data-emotion]"), function (node) {
      var attrib = node.getAttribute("data-emotion").split(' ');

      if (attrib[0] !== key) {
        return;
      } // $FlowFixMe


      for (var i = 1; i < attrib.length; i++) {
        inserted[attrib[i]] = true;
      }

      nodesToHydrate.push(node);
    });
  }

  var _insert;

  var omnipresentPlugins = [compat, removeLabel];

  if (isBrowser) {
    var currentSheet;
    var finalizingPlugins = [stringify,  rulesheet(function (rule) {
      currentSheet.insert(rule);
    })];
    var serializer = middleware(omnipresentPlugins.concat(stylisPlugins, finalizingPlugins));

    var stylis = function stylis(styles) {
      return serialize(compile(styles), serializer);
    };

    _insert = function insert(selector, serialized, sheet, shouldCache) {
      currentSheet = sheet;

      stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);

      if (shouldCache) {
        cache.inserted[serialized.name] = true;
      }
    };
  } else {
    var _finalizingPlugins = [stringify];

    var _serializer = middleware(omnipresentPlugins.concat(stylisPlugins, _finalizingPlugins));

    var _stylis = function _stylis(styles) {
      return serialize(compile(styles), _serializer);
    }; // $FlowFixMe


    var serverStylisCache = getServerStylisCache(stylisPlugins)(key);

    var getRules = function getRules(selector, serialized) {
      var name = serialized.name;

      if (serverStylisCache[name] === undefined) {
        serverStylisCache[name] = _stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);
      }

      return serverStylisCache[name];
    };

    _insert = function _insert(selector, serialized, sheet, shouldCache) {
      var name = serialized.name;
      var rules = getRules(selector, serialized);

      if (cache.compat === undefined) {
        // in regular mode, we don't set the styles on the inserted cache
        // since we don't need to and that would be wasting memory
        // we return them so that they are rendered in a style tag
        if (shouldCache) {
          cache.inserted[name] = true;
        }

        return rules;
      } else {
        // in compat mode, we put the styles on the inserted cache so
        // that emotion-server can pull out the styles
        // except when we don't want to cache it which was in Global but now
        // is nowhere but we don't want to do a major right now
        // and just in case we're going to leave the case here
        // it's also not affecting client side bundle size
        // so it's really not a big deal
        if (shouldCache) {
          cache.inserted[name] = rules;
        } else {
          return rules;
        }
      }
    };
  }

  var cache = {
    key: key,
    sheet: new StyleSheet({
      key: key,
      container: container,
      nonce: options.nonce,
      speedy: options.speedy,
      prepend: options.prepend
    }),
    nonce: options.nonce,
    inserted: inserted,
    registered: {},
    insert: _insert
  };
  cache.sheet.hydrate(nodesToHydrate);
  return cache;
};

/** @license React v16.13.1
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var b="function"===typeof Symbol&&Symbol.for,c=b?Symbol.for("react.element"):60103,d=b?Symbol.for("react.portal"):60106,e=b?Symbol.for("react.fragment"):60107,f=b?Symbol.for("react.strict_mode"):60108,g=b?Symbol.for("react.profiler"):60114,h=b?Symbol.for("react.provider"):60109,k=b?Symbol.for("react.context"):60110,l=b?Symbol.for("react.async_mode"):60111,m=b?Symbol.for("react.concurrent_mode"):60111,n=b?Symbol.for("react.forward_ref"):60112,p=b?Symbol.for("react.suspense"):60113,q=b?
Symbol.for("react.suspense_list"):60120,r=b?Symbol.for("react.memo"):60115,t=b?Symbol.for("react.lazy"):60116,v=b?Symbol.for("react.block"):60121,w=b?Symbol.for("react.fundamental"):60117,x=b?Symbol.for("react.responder"):60118,y=b?Symbol.for("react.scope"):60119;
function z(a){if("object"===typeof a&&null!==a){var u=a.$$typeof;switch(u){case c:switch(a=a.type,a){case l:case m:case e:case g:case f:case p:return a;default:switch(a=a&&a.$$typeof,a){case k:case n:case t:case r:case h:return a;default:return u}}case d:return u}}}function A(a){return z(a)===m}var AsyncMode=l;var ConcurrentMode=m;var ContextConsumer=k;var ContextProvider=h;var Element$1=c;var ForwardRef=n;var Fragment=e;var Lazy=t;var Memo=r;var Portal=d;
var Profiler=g;var StrictMode=f;var Suspense=p;var isAsyncMode=function(a){return A(a)||z(a)===l};var isConcurrentMode=A;var isContextConsumer=function(a){return z(a)===k};var isContextProvider=function(a){return z(a)===h};var isElement=function(a){return "object"===typeof a&&null!==a&&a.$$typeof===c};var isForwardRef=function(a){return z(a)===n};var isFragment=function(a){return z(a)===e};var isLazy=function(a){return z(a)===t};
var isMemo=function(a){return z(a)===r};var isPortal=function(a){return z(a)===d};var isProfiler=function(a){return z(a)===g};var isStrictMode=function(a){return z(a)===f};var isSuspense=function(a){return z(a)===p};
var isValidElementType=function(a){return "string"===typeof a||"function"===typeof a||a===e||a===m||a===g||a===f||a===p||a===q||"object"===typeof a&&null!==a&&(a.$$typeof===t||a.$$typeof===r||a.$$typeof===h||a.$$typeof===k||a.$$typeof===n||a.$$typeof===w||a.$$typeof===x||a.$$typeof===y||a.$$typeof===v)};var typeOf=z;

var reactIs_production_min = {
	AsyncMode: AsyncMode,
	ConcurrentMode: ConcurrentMode,
	ContextConsumer: ContextConsumer,
	ContextProvider: ContextProvider,
	Element: Element$1,
	ForwardRef: ForwardRef,
	Fragment: Fragment,
	Lazy: Lazy,
	Memo: Memo,
	Portal: Portal,
	Profiler: Profiler,
	StrictMode: StrictMode,
	Suspense: Suspense,
	isAsyncMode: isAsyncMode,
	isConcurrentMode: isConcurrentMode,
	isContextConsumer: isContextConsumer,
	isContextProvider: isContextProvider,
	isElement: isElement,
	isForwardRef: isForwardRef,
	isFragment: isFragment,
	isLazy: isLazy,
	isMemo: isMemo,
	isPortal: isPortal,
	isProfiler: isProfiler,
	isStrictMode: isStrictMode,
	isSuspense: isSuspense,
	isValidElementType: isValidElementType,
	typeOf: typeOf
};

var reactIs_development = createCommonjsModule(function (module, exports) {
});

var reactIs = createCommonjsModule(function (module) {

{
  module.exports = reactIs_production_min;
}
});

var FORWARD_REF_STATICS = {
  '$$typeof': true,
  render: true,
  defaultProps: true,
  displayName: true,
  propTypes: true
};
var MEMO_STATICS = {
  '$$typeof': true,
  compare: true,
  defaultProps: true,
  displayName: true,
  propTypes: true,
  type: true
};
var TYPE_STATICS = {};
TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;

var isBrowser$1 = typeof document !== 'undefined';
function getRegisteredStyles(registered, registeredStyles, classNames) {
  var rawClassName = '';
  classNames.split(' ').forEach(function (className) {
    if (registered[className] !== undefined) {
      registeredStyles.push(registered[className] + ";");
    } else {
      rawClassName += className + " ";
    }
  });
  return rawClassName;
}
var insertStyles = function insertStyles(cache, serialized, isStringTag) {
  var className = cache.key + "-" + serialized.name;

  if ( // we only need to add the styles to the registered cache if the
  // class name could be used further down
  // the tree but if it's a string tag, we know it won't
  // so we don't have to add it to registered cache.
  // this improves memory usage since we can avoid storing the whole style string
  (isStringTag === false || // we need to always store it if we're in compat mode and
  // in node since emotion-server relies on whether a style is in
  // the registered cache to know whether a style is global or not
  // also, note that this check will be dead code eliminated in the browser
  isBrowser$1 === false && cache.compat !== undefined) && cache.registered[className] === undefined) {
    cache.registered[className] = serialized.styles;
  }

  if (cache.inserted[serialized.name] === undefined) {
    var stylesForSSR = '';
    var current = serialized;

    do {
      var maybeStyles = cache.insert(serialized === current ? "." + className : '', current, cache.sheet, true);

      if (!isBrowser$1 && maybeStyles !== undefined) {
        stylesForSSR += maybeStyles;
      }

      current = current.next;
    } while (current !== undefined);

    if (!isBrowser$1 && stylesForSSR.length !== 0) {
      return stylesForSSR;
    }
  }
};

/* eslint-disable */
// Inspired by https://github.com/garycourt/murmurhash-js
// Ported from https://github.com/aappleby/smhasher/blob/61a0530f28277f2e850bfc39600ce61d02b518de/src/MurmurHash2.cpp#L37-L86
function murmur2(str) {
  // 'm' and 'r' are mixing constants generated offline.
  // They're not really 'magic', they just happen to work well.
  // const m = 0x5bd1e995;
  // const r = 24;
  // Initialize the hash
  var h = 0; // Mix 4 bytes at a time into the hash

  var k,
      i = 0,
      len = str.length;

  for (; len >= 4; ++i, len -= 4) {
    k = str.charCodeAt(i) & 0xff | (str.charCodeAt(++i) & 0xff) << 8 | (str.charCodeAt(++i) & 0xff) << 16 | (str.charCodeAt(++i) & 0xff) << 24;
    k =
    /* Math.imul(k, m): */
    (k & 0xffff) * 0x5bd1e995 + ((k >>> 16) * 0xe995 << 16);
    k ^=
    /* k >>> r: */
    k >>> 24;
    h =
    /* Math.imul(k, m): */
    (k & 0xffff) * 0x5bd1e995 + ((k >>> 16) * 0xe995 << 16) ^
    /* Math.imul(h, m): */
    (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  } // Handle the last few bytes of the input array


  switch (len) {
    case 3:
      h ^= (str.charCodeAt(i + 2) & 0xff) << 16;

    case 2:
      h ^= (str.charCodeAt(i + 1) & 0xff) << 8;

    case 1:
      h ^= str.charCodeAt(i) & 0xff;
      h =
      /* Math.imul(h, m): */
      (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  } // Do a few final mixes of the hash to ensure the last few
  // bytes are well-incorporated.


  h ^= h >>> 13;
  h =
  /* Math.imul(h, m): */
  (h & 0xffff) * 0x5bd1e995 + ((h >>> 16) * 0xe995 << 16);
  return ((h ^ h >>> 15) >>> 0).toString(36);
}

var unitlessKeys = {
  animationIterationCount: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  // SVG-related properties
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};

var hyphenateRegex = /[A-Z]|^ms/g;
var animationRegex = /_EMO_([^_]+?)_([^]*?)_EMO_/g;

var isCustomProperty = function isCustomProperty(property) {
  return property.charCodeAt(1) === 45;
};

var isProcessableValue = function isProcessableValue(value) {
  return value != null && typeof value !== 'boolean';
};

var processStyleName = /* #__PURE__ */memoize(function (styleName) {
  return isCustomProperty(styleName) ? styleName : styleName.replace(hyphenateRegex, '-$&').toLowerCase();
});

var processStyleValue = function processStyleValue(key, value) {
  switch (key) {
    case 'animation':
    case 'animationName':
      {
        if (typeof value === 'string') {
          return value.replace(animationRegex, function (match, p1, p2) {
            cursor = {
              name: p1,
              styles: p2,
              next: cursor
            };
            return p1;
          });
        }
      }
  }

  if (unitlessKeys[key] !== 1 && !isCustomProperty(key) && typeof value === 'number' && value !== 0) {
    return value + 'px';
  }

  return value;
};

function handleInterpolation(mergedProps, registered, interpolation) {
  if (interpolation == null) {
    return '';
  }

  if (interpolation.__emotion_styles !== undefined) {

    return interpolation;
  }

  switch (typeof interpolation) {
    case 'boolean':
      {
        return '';
      }

    case 'object':
      {
        if (interpolation.anim === 1) {
          cursor = {
            name: interpolation.name,
            styles: interpolation.styles,
            next: cursor
          };
          return interpolation.name;
        }

        if (interpolation.styles !== undefined) {
          var next = interpolation.next;

          if (next !== undefined) {
            // not the most efficient thing ever but this is a pretty rare case
            // and there will be very few iterations of this generally
            while (next !== undefined) {
              cursor = {
                name: next.name,
                styles: next.styles,
                next: cursor
              };
              next = next.next;
            }
          }

          var styles = interpolation.styles + ";";

          return styles;
        }

        return createStringFromObject(mergedProps, registered, interpolation);
      }

    case 'function':
      {
        if (mergedProps !== undefined) {
          var previousCursor = cursor;
          var result = interpolation(mergedProps);
          cursor = previousCursor;
          return handleInterpolation(mergedProps, registered, result);
        }

        break;
      }
  } // finalize string values (regular strings and functions interpolated into css calls)


  if (registered == null) {
    return interpolation;
  }

  var cached = registered[interpolation];
  return cached !== undefined ? cached : interpolation;
}

function createStringFromObject(mergedProps, registered, obj) {
  var string = '';

  if (Array.isArray(obj)) {
    for (var i = 0; i < obj.length; i++) {
      string += handleInterpolation(mergedProps, registered, obj[i]) + ";";
    }
  } else {
    for (var _key in obj) {
      var value = obj[_key];

      if (typeof value !== 'object') {
        if (registered != null && registered[value] !== undefined) {
          string += _key + "{" + registered[value] + "}";
        } else if (isProcessableValue(value)) {
          string += processStyleName(_key) + ":" + processStyleValue(_key, value) + ";";
        }
      } else {
        if (_key === 'NO_COMPONENT_SELECTOR' && "production" !== 'production') {
          throw new Error('Component selectors can only be used in conjunction with @emotion/babel-plugin.');
        }

        if (Array.isArray(value) && typeof value[0] === 'string' && (registered == null || registered[value[0]] === undefined)) {
          for (var _i = 0; _i < value.length; _i++) {
            if (isProcessableValue(value[_i])) {
              string += processStyleName(_key) + ":" + processStyleValue(_key, value[_i]) + ";";
            }
          }
        } else {
          var interpolated = handleInterpolation(mergedProps, registered, value);

          switch (_key) {
            case 'animation':
            case 'animationName':
              {
                string += processStyleName(_key) + ":" + interpolated + ";";
                break;
              }

            default:
              {

                string += _key + "{" + interpolated + "}";
              }
          }
        }
      }
    }
  }

  return string;
}

var labelPattern = /label:\s*([^\s;\n{]+)\s*;/g;
// keyframes are stored on the SerializedStyles object as a linked list


var cursor;
var serializeStyles = function serializeStyles(args, registered, mergedProps) {
  if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null && args[0].styles !== undefined) {
    return args[0];
  }

  var stringMode = true;
  var styles = '';
  cursor = undefined;
  var strings = args[0];

  if (strings == null || strings.raw === undefined) {
    stringMode = false;
    styles += handleInterpolation(mergedProps, registered, strings);
  } else {

    styles += strings[0];
  } // we start at 1 since we've already handled the first arg


  for (var i = 1; i < args.length; i++) {
    styles += handleInterpolation(mergedProps, registered, args[i]);

    if (stringMode) {

      styles += strings[i];
    }
  }


  labelPattern.lastIndex = 0;
  var identifierName = '';
  var match; // https://esbench.com/bench/5b809c2cf2949800a0f61fb5

  while ((match = labelPattern.exec(styles)) !== null) {
    identifierName += '-' + // $FlowFixMe we know it's not null
    match[1];
  }

  var name = murmur2(styles) + identifierName;

  return {
    name: name,
    styles: styles,
    next: cursor
  };
};

var isBrowser$2 = typeof document !== 'undefined';
var hasOwnProperty$1 = Object.prototype.hasOwnProperty;

var EmotionCacheContext = /* #__PURE__ */react.createContext( // we're doing this to avoid preconstruct's dead code elimination in this one case
// because this module is primarily intended for the browser and node
// but it's also required in react native and similar environments sometimes
// and we could have a special build just for that
// but this is much easier and the native packages
// might use a different theme context in the future anyway
typeof HTMLElement !== 'undefined' ? /* #__PURE__ */createCache({
  key: 'css'
}) : null);
var CacheProvider = EmotionCacheContext.Provider;

var withEmotionCache = function withEmotionCache(func) {
  // $FlowFixMe
  return /*#__PURE__*/react.forwardRef(function (props, ref) {
    // the cache will never be null in the browser
    var cache = react.useContext(EmotionCacheContext);
    return func(props, cache, ref);
  });
};

if (!isBrowser$2) {
  withEmotionCache = function withEmotionCache(func) {
    return function (props) {
      var cache = react.useContext(EmotionCacheContext);

      if (cache === null) {
        // yes, we're potentially creating this on every render
        // it doesn't actually matter though since it's only on the server
        // so there will only every be a single render
        // that could change in the future because of suspense and etc. but for now,
        // this works and i don't want to optimise for a future thing that we aren't sure about
        cache = createCache({
          key: 'css'
        });
        return /*#__PURE__*/react.createElement(EmotionCacheContext.Provider, {
          value: cache
        }, func(props, cache));
      } else {
        return func(props, cache);
      }
    };
  };
}

var ThemeContext = /* #__PURE__ */react.createContext({});

var typePropName = '__EMOTION_TYPE_PLEASE_DO_NOT_USE__';
var createEmotionProps = function createEmotionProps(type, props) {

  var newProps = {};

  for (var key in props) {
    if (hasOwnProperty$1.call(props, key)) {
      newProps[key] = props[key];
    }
  }

  newProps[typePropName] = type;

  return newProps;
};
var Emotion = /* #__PURE__ */withEmotionCache(function (props, cache, ref) {
  var cssProp = props.css; // so that using `css` from `emotion` and passing the result to the css prop works
  // not passing the registered cache to serializeStyles because it would
  // make certain babel optimisations not possible

  if (typeof cssProp === 'string' && cache.registered[cssProp] !== undefined) {
    cssProp = cache.registered[cssProp];
  }

  var type = props[typePropName];
  var registeredStyles = [cssProp];
  var className = '';

  if (typeof props.className === 'string') {
    className = getRegisteredStyles(cache.registered, registeredStyles, props.className);
  } else if (props.className != null) {
    className = props.className + " ";
  }

  var serialized = serializeStyles(registeredStyles, undefined, typeof cssProp === 'function' || Array.isArray(cssProp) ? react.useContext(ThemeContext) : undefined);

  var rules = insertStyles(cache, serialized, typeof type === 'string');
  className += cache.key + "-" + serialized.name;
  var newProps = {};

  for (var key in props) {
    if (hasOwnProperty$1.call(props, key) && key !== 'css' && key !== typePropName && ("production" === 'production' )) {
      newProps[key] = props[key];
    }
  }

  newProps.ref = ref;
  newProps.className = className;
  var ele = /*#__PURE__*/react.createElement(type, newProps);

  if (!isBrowser$2 && rules !== undefined) {
    var _ref;

    var serializedNames = serialized.name;
    var next = serialized.next;

    while (next !== undefined) {
      serializedNames += ' ' + next.name;
      next = next.next;
    }

    return /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("style", (_ref = {}, _ref["data-emotion"] = cache.key + " " + serializedNames, _ref.dangerouslySetInnerHTML = {
      __html: rules
    }, _ref.nonce = cache.sheet.nonce, _ref)), ele);
  }

  return ele;
});

var _extends_1 = createCommonjsModule(function (module) {
function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;
});

var jsx = function jsx(type, props) {
  var args = arguments;

  if (props == null || !hasOwnProperty$1.call(props, 'css')) {
    // $FlowFixMe
    return react.createElement.apply(undefined, args);
  }

  var argsLength = args.length;
  var createElementArgArray = new Array(argsLength);
  createElementArgArray[0] = Emotion;
  createElementArgArray[1] = createEmotionProps(type, props);

  for (var i = 2; i < argsLength; i++) {
    createElementArgArray[i] = args[i];
  } // $FlowFixMe


  return react.createElement.apply(null, createElementArgArray);
};

var testOmitPropsOnStringTag = isPropValid;

var testOmitPropsOnComponent = function testOmitPropsOnComponent(key) {
  return key !== 'theme';
};

var getDefaultShouldForwardProp = function getDefaultShouldForwardProp(tag) {
  return typeof tag === 'string' && // 96 is one less than the char code
  // for "a" so this is checking that
  // it's a lowercase character
  tag.charCodeAt(0) > 96 ? testOmitPropsOnStringTag : testOmitPropsOnComponent;
};
var composeShouldForwardProps = function composeShouldForwardProps(tag, options, isReal) {
  var shouldForwardProp;

  if (options) {
    var optionsShouldForwardProp = options.shouldForwardProp;
    shouldForwardProp = tag.__emotion_forwardProp && optionsShouldForwardProp ? function (propName) {
      return tag.__emotion_forwardProp(propName) && optionsShouldForwardProp(propName);
    } : optionsShouldForwardProp;
  }

  if (typeof shouldForwardProp !== 'function' && isReal) {
    shouldForwardProp = tag.__emotion_forwardProp;
  }

  return shouldForwardProp;
};
var isBrowser$3 = typeof document !== 'undefined';

var createStyled = function createStyled(tag, options) {

  var isReal = tag.__emotion_real === tag;
  var baseTag = isReal && tag.__emotion_base || tag;
  var identifierName;
  var targetClassName;

  if (options !== undefined) {
    identifierName = options.label;
    targetClassName = options.target;
  }

  var shouldForwardProp = composeShouldForwardProps(tag, options, isReal);
  var defaultShouldForwardProp = shouldForwardProp || getDefaultShouldForwardProp(baseTag);
  var shouldUseAs = !defaultShouldForwardProp('as');
  return function () {
    var args = arguments;
    var styles = isReal && tag.__emotion_styles !== undefined ? tag.__emotion_styles.slice(0) : [];

    if (identifierName !== undefined) {
      styles.push("label:" + identifierName + ";");
    }

    if (args[0] == null || args[0].raw === undefined) {
      styles.push.apply(styles, args);
    } else {

      styles.push(args[0][0]);
      var len = args.length;
      var i = 1;

      for (; i < len; i++) {

        styles.push(args[i], args[0][i]);
      }
    } // $FlowFixMe: we need to cast StatelessFunctionalComponent to our PrivateStyledComponent class


    var Styled = withEmotionCache(function (props, cache, ref) {
      var finalTag = shouldUseAs && props.as || baseTag;
      var className = '';
      var classInterpolations = [];
      var mergedProps = props;

      if (props.theme == null) {
        mergedProps = {};

        for (var key in props) {
          mergedProps[key] = props[key];
        }

        mergedProps.theme = react.useContext(ThemeContext);
      }

      if (typeof props.className === 'string') {
        className = getRegisteredStyles(cache.registered, classInterpolations, props.className);
      } else if (props.className != null) {
        className = props.className + " ";
      }

      var serialized = serializeStyles(styles.concat(classInterpolations), cache.registered, mergedProps);
      var rules = insertStyles(cache, serialized, typeof finalTag === 'string');
      className += cache.key + "-" + serialized.name;

      if (targetClassName !== undefined) {
        className += " " + targetClassName;
      }

      var finalShouldForwardProp = shouldUseAs && shouldForwardProp === undefined ? getDefaultShouldForwardProp(finalTag) : defaultShouldForwardProp;
      var newProps = {};

      for (var _key in props) {
        if (shouldUseAs && _key === 'as') continue;

        if ( // $FlowFixMe
        finalShouldForwardProp(_key)) {
          newProps[_key] = props[_key];
        }
      }

      newProps.className = className;
      newProps.ref = ref;
      var ele = /*#__PURE__*/react.createElement(finalTag, newProps);

      if (!isBrowser$3 && rules !== undefined) {
        var _ref;

        var serializedNames = serialized.name;
        var next = serialized.next;

        while (next !== undefined) {
          serializedNames += ' ' + next.name;
          next = next.next;
        }

        return /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("style", (_ref = {}, _ref["data-emotion"] = cache.key + " " + serializedNames, _ref.dangerouslySetInnerHTML = {
          __html: rules
        }, _ref.nonce = cache.sheet.nonce, _ref)), ele);
      }

      return ele;
    });
    Styled.displayName = identifierName !== undefined ? identifierName : "Styled(" + (typeof baseTag === 'string' ? baseTag : baseTag.displayName || baseTag.name || 'Component') + ")";
    Styled.defaultProps = tag.defaultProps;
    Styled.__emotion_real = Styled;
    Styled.__emotion_base = baseTag;
    Styled.__emotion_styles = styles;
    Styled.__emotion_forwardProp = shouldForwardProp;
    Object.defineProperty(Styled, 'toString', {
      value: function value() {
        if (targetClassName === undefined && "production" !== 'production') {
          return 'NO_COMPONENT_SELECTOR';
        } // $FlowFixMe: coerce undefined to string


        return "." + targetClassName;
      }
    });

    Styled.withComponent = function (nextTag, nextOptions) {
      return createStyled(nextTag, _extends({}, options, {}, nextOptions, {
        shouldForwardProp: composeShouldForwardProps(Styled, nextOptions, true)
      })).apply(void 0, styles);
    };

    return Styled;
  };
};

/** @license React v0.20.1
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var scheduler_production_min = createCommonjsModule(function (module, exports) {
var f,g,h,k;if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports.unstable_now=function(){return l.now()};}else {var p=Date,q=p.now();exports.unstable_now=function(){return p.now()-q};}
if("undefined"===typeof window||"function"!==typeof MessageChannel){var t=null,u=null,w=function(){if(null!==t)try{var a=exports.unstable_now();t(!0,a);t=null;}catch(b){throw setTimeout(w,0),b;}};f=function(a){null!==t?setTimeout(f,0,a):(t=a,setTimeout(w,0));};g=function(a,b){u=setTimeout(a,b);};h=function(){clearTimeout(u);};exports.unstable_shouldYield=function(){return !1};k=exports.unstable_forceFrameRate=function(){};}else {var x=window.setTimeout,y=window.clearTimeout;if("undefined"!==typeof console){var z=
window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");"function"!==typeof z&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");}var A=!1,B=null,C=-1,D=5,E=0;exports.unstable_shouldYield=function(){return exports.unstable_now()>=
E};k=function(){};exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):D=0<a?Math.floor(1E3/a):5;};var F=new MessageChannel,G=F.port2;F.port1.onmessage=function(){if(null!==B){var a=exports.unstable_now();E=a+D;try{B(!0,a)?G.postMessage(null):(A=!1,B=null);}catch(b){throw G.postMessage(null),b;}}else A=!1;};f=function(a){B=a;A||(A=!0,G.postMessage(null));};g=function(a,b){C=
x(function(){a(exports.unstable_now());},b);};h=function(){y(C);C=-1;};}function H(a,b){var c=a.length;a.push(b);a:for(;;){var d=c-1>>>1,e=a[d];if(void 0!==e&&0<I(e,b))a[d]=b,a[c]=e,c=d;else break a}}function J(a){a=a[0];return void 0===a?null:a}
function K(a){var b=a[0];if(void 0!==b){var c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length;d<e;){var m=2*(d+1)-1,n=a[m],v=m+1,r=a[v];if(void 0!==n&&0>I(n,c))void 0!==r&&0>I(r,n)?(a[d]=r,a[v]=c,d=v):(a[d]=n,a[m]=c,d=m);else if(void 0!==r&&0>I(r,c))a[d]=r,a[v]=c,d=v;else break a}}return b}return null}function I(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}var L=[],M=[],N=1,O=null,P=3,Q=!1,R=!1,S=!1;
function T(a){for(var b=J(M);null!==b;){if(null===b.callback)K(M);else if(b.startTime<=a)K(M),b.sortIndex=b.expirationTime,H(L,b);else break;b=J(M);}}function U(a){S=!1;T(a);if(!R)if(null!==J(L))R=!0,f(V);else {var b=J(M);null!==b&&g(U,b.startTime-a);}}
function V(a,b){R=!1;S&&(S=!1,h());Q=!0;var c=P;try{T(b);for(O=J(L);null!==O&&(!(O.expirationTime>b)||a&&!exports.unstable_shouldYield());){var d=O.callback;if("function"===typeof d){O.callback=null;P=O.priorityLevel;var e=d(O.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?O.callback=e:O===J(L)&&K(L);T(b);}else K(L);O=J(L);}if(null!==O)var m=!0;else {var n=J(M);null!==n&&g(U,n.startTime-b);m=!1;}return m}finally{O=null,P=c,Q=!1;}}var W=k;exports.unstable_IdlePriority=5;
exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null;};exports.unstable_continueExecution=function(){R||Q||(R=!0,f(V));};exports.unstable_getCurrentPriorityLevel=function(){return P};exports.unstable_getFirstCallbackNode=function(){return J(L)};
exports.unstable_next=function(a){switch(P){case 1:case 2:case 3:var b=3;break;default:b=P;}var c=P;P=b;try{return a()}finally{P=c;}};exports.unstable_pauseExecution=function(){};exports.unstable_requestPaint=W;exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3;}var c=P;P=a;try{return b()}finally{P=c;}};
exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3;}e=c+e;a={id:N++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,H(M,a),null===J(L)&&a===J(M)&&(S?h():S=!0,g(U,c-d))):(a.sortIndex=e,H(L,a),R||Q||(R=!0,f(V)));return a};
exports.unstable_wrapCallback=function(a){var b=P;return function(){var c=P;P=b;try{return a.apply(this,arguments)}finally{P=c;}}};
});

var scheduler_development = createCommonjsModule(function (module, exports) {
});

var scheduler = createCommonjsModule(function (module) {

{
  module.exports = scheduler_production_min;
}
});

/** @license React v17.0.1
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function y$1(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return "Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!react)throw Error(y$1(227));var ba=new Set,ca={};function da(a,b){ea(a,b);ea(a+"Capture",b);}
function ea(a,b){ca[a]=b;for(a=0;a<b.length;a++)ba.add(b[a]);}
var fa=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ha=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,ia=Object.prototype.hasOwnProperty,
ja={},ka={};function la(a){if(ia.call(ka,a))return !0;if(ia.call(ja,a))return !1;if(ha.test(a))return ka[a]=!0;ja[a]=!0;return !1}function ma(a,b,c,d){if(null!==c&&0===c.type)return !1;switch(typeof b){case "function":case "symbol":return !0;case "boolean":if(d)return !1;if(null!==c)return !c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return "data-"!==a&&"aria-"!==a;default:return !1}}
function na(a,b,c,d){if(null===b||"undefined"===typeof b||ma(a,b,c,d))return !0;if(d)return !1;if(null!==c)switch(c.type){case 3:return !b;case 4:return !1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return !1}function B(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g;}var D={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){D[a]=new B(a,0,!1,a,null,!1,!1);});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];D[b]=new B(b,1,!1,a[1],null,!1,!1);});["contentEditable","draggable","spellCheck","value"].forEach(function(a){D[a]=new B(a,2,!1,a.toLowerCase(),null,!1,!1);});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){D[a]=new B(a,2,!1,a,null,!1,!1);});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){D[a]=new B(a,3,!1,a.toLowerCase(),null,!1,!1);});
["checked","multiple","muted","selected"].forEach(function(a){D[a]=new B(a,3,!0,a,null,!1,!1);});["capture","download"].forEach(function(a){D[a]=new B(a,4,!1,a,null,!1,!1);});["cols","rows","size","span"].forEach(function(a){D[a]=new B(a,6,!1,a,null,!1,!1);});["rowSpan","start"].forEach(function(a){D[a]=new B(a,5,!1,a.toLowerCase(),null,!1,!1);});var oa=/[\-:]([a-z])/g;function pa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(oa,
pa);D[b]=new B(b,1,!1,a,null,!1,!1);});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/1999/xlink",!1,!1);});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(oa,pa);D[b]=new B(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1,!1);});["tabIndex","crossOrigin"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!1,!1);});
D.xlinkHref=new B("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(a){D[a]=new B(a,1,!1,a.toLowerCase(),null,!0,!0);});
function qa(a,b,c,d){var e=D.hasOwnProperty(b)?D[b]:null;var f=null!==e?0===e.type:d?!1:!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1]?!1:!0;f||(na(b,c,e,d)&&(c=null),d||null===e?la(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c))));}
var ra=react.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,sa=60103,ta=60106,ua=60107,wa=60108,xa=60114,ya=60109,za=60110,Aa=60112,Ba=60113,Ca=60120,Da=60115,Ea=60116,Fa=60121,Ga=60128,Ha=60129,Ia=60130,Ja=60131;
if("function"===typeof Symbol&&Symbol.for){var E=Symbol.for;sa=E("react.element");ta=E("react.portal");ua=E("react.fragment");wa=E("react.strict_mode");xa=E("react.profiler");ya=E("react.provider");za=E("react.context");Aa=E("react.forward_ref");Ba=E("react.suspense");Ca=E("react.suspense_list");Da=E("react.memo");Ea=E("react.lazy");Fa=E("react.block");E("react.scope");Ga=E("react.opaque.id");Ha=E("react.debug_trace_mode");Ia=E("react.offscreen");Ja=E("react.legacy_hidden");}
var Ka="function"===typeof Symbol&&Symbol.iterator;function La(a){if(null===a||"object"!==typeof a)return null;a=Ka&&a[Ka]||a["@@iterator"];return "function"===typeof a?a:null}var Ma;function Na(a){if(void 0===Ma)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);Ma=b&&b[1]||"";}return "\n"+Ma+a}var Oa=!1;
function Pa(a,b){if(!a||Oa)return "";Oa=!0;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[]);}catch(k){var d=k;}Reflect.construct(a,[],b);}else {try{b.call();}catch(k){d=k;}a.call(b.prototype);}else {try{throw Error();}catch(k){d=k;}a();}}catch(k){if(k&&d&&"string"===typeof k.stack){for(var e=k.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h])return "\n"+e[g].replace(" at new "," at ");while(1<=g&&0<=h)}break}}}finally{Oa=!1,Error.prepareStackTrace=c;}return (a=a?a.displayName||a.name:"")?Na(a):""}
function Qa(a){switch(a.tag){case 5:return Na(a.type);case 16:return Na("Lazy");case 13:return Na("Suspense");case 19:return Na("SuspenseList");case 0:case 2:case 15:return a=Pa(a.type,!1),a;case 11:return a=Pa(a.type.render,!1),a;case 22:return a=Pa(a.type._render,!1),a;case 1:return a=Pa(a.type,!0),a;default:return ""}}
function Ra(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ua:return "Fragment";case ta:return "Portal";case xa:return "Profiler";case wa:return "StrictMode";case Ba:return "Suspense";case Ca:return "SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case za:return (a.displayName||"Context")+".Consumer";case ya:return (a._context.displayName||"Context")+".Provider";case Aa:var b=a.render;b=b.displayName||b.name||"";
return a.displayName||(""!==b?"ForwardRef("+b+")":"ForwardRef");case Da:return Ra(a.type);case Fa:return Ra(a._render);case Ea:b=a._payload;a=a._init;try{return Ra(a(b))}catch(c){}}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "object":case "string":case "undefined":return a;default:return ""}}function Ta(a){var b=a.type;return (a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a);}});Object.defineProperty(a,b,{enumerable:c.enumerable});return {getValue:function(){return d},setValue:function(a){d=""+a;},stopTracking:function(){a._valueTracker=
null;delete a[b];}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a));}function Wa(a){if(!a)return !1;var b=a._valueTracker;if(!b)return !0;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return objectAssign({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value};}function $a(a,b){b=b.checked;null!=b&&qa(a,"checked",b,!1);}
function ab(a,b){$a(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c;}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?bb(a,b.type,c):b.hasOwnProperty("defaultValue")&&bb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked);}
function cb(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b;}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c);}
function bb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c);}function db(a){var b="";react.Children.forEach(a,function(a){null!=a&&(b+=a);});return b}function eb(a,b){a=objectAssign({children:void 0},b);if(b=db(b.children))a.children=b;return a}
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0);}else {c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return}null!==b||a[e].disabled||(b=a[e]);}null!==b&&(b.selected=!0);}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(y$1(91));return objectAssign({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(y$1(92));if(Array.isArray(c)){if(!(1>=c.length))throw Error(y$1(93));c=c[0];}b=c;}null==b&&(b="");c=b;}a._wrapperState={initialValue:Sa(c)};}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d);}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b);}var kb={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};
function lb(a){switch(a){case "svg":return "http://www.w3.org/2000/svg";case "math":return "http://www.w3.org/1998/Math/MathML";default:return "http://www.w3.org/1999/xhtml"}}function mb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?lb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var nb,ob=function(a){return "undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)});}:a}(function(a,b){if(a.namespaceURI!==kb.svg||"innerHTML"in a)a.innerHTML=b;else {nb=nb||document.createElement("div");nb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=nb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild);}});
function pb(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b;}
var qb={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,
floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},rb=["Webkit","ms","Moz","O"];Object.keys(qb).forEach(function(a){rb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);qb[b]=qb[a];});});function sb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||qb.hasOwnProperty(a)&&qb[a]?(""+b).trim():b+"px"}
function tb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=sb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e;}}var ub=objectAssign({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});
function vb(a,b){if(b){if(ub[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(y$1(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(y$1(60));if(!("object"===typeof b.dangerouslySetInnerHTML&&"__html"in b.dangerouslySetInnerHTML))throw Error(y$1(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(y$1(62));}}
function wb(a,b){if(-1===a.indexOf("-"))return "string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return !1;default:return !0}}function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(y$1(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b));}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a;}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a]);}}function Gb(a,b){return a(b)}function Hb(a,b,c,d,e){return a(b,c,d,e)}function Ib(){}var Jb=Gb,Kb=!1,Lb=!1;function Mb(){if(null!==zb||null!==Ab)Ib(),Fb();}
function Nb(a,b,c){if(Lb)return a(b,c);Lb=!0;try{return Jb(a,b,c)}finally{Lb=!1,Mb();}}
function Ob(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1;}if(a)return null;if(c&&"function"!==
typeof c)throw Error(y$1(231,b,typeof c));return c}var Pb=!1;if(fa)try{var Qb={};Object.defineProperty(Qb,"passive",{get:function(){Pb=!0;}});window.addEventListener("test",Qb,Qb);window.removeEventListener("test",Qb,Qb);}catch(a){Pb=!1;}function Rb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l);}catch(n){this.onError(n);}}var Sb=!1,Tb=null,Ub=!1,Vb=null,Wb={onError:function(a){Sb=!0;Tb=a;}};function Xb(a,b,c,d,e,f,g,h,k){Sb=!1;Tb=null;Rb.apply(Wb,arguments);}
function Yb(a,b,c,d,e,f,g,h,k){Xb.apply(this,arguments);if(Sb){if(Sb){var l=Tb;Sb=!1;Tb=null;}else throw Error(y$1(198));Ub||(Ub=!0,Vb=l);}}function Zb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else {a=b;do b=a,0!==(b.flags&1026)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function $b(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function ac(a){if(Zb(a)!==a)throw Error(y$1(188));}
function bc(a){var b=a.alternate;if(!b){b=Zb(a);if(null===b)throw Error(y$1(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return ac(e),a;if(f===d)return ac(e),b;f=f.sibling;}throw Error(y$1(188));}if(c.return!==d.return)c=e,d=f;else {for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break}if(h===d){g=!0;d=e;c=f;break}h=h.sibling;}if(!g){for(h=f.child;h;){if(h===
c){g=!0;c=f;d=e;break}if(h===d){g=!0;d=f;c=e;break}h=h.sibling;}if(!g)throw Error(y$1(189));}}if(c.alternate!==d)throw Error(y$1(190));}if(3!==c.tag)throw Error(y$1(188));return c.stateNode.current===c?a:b}function cc(a){a=bc(a);if(!a)return null;for(var b=a;;){if(5===b.tag||6===b.tag)return b;if(b.child)b.child.return=b,b=b.child;else {if(b===a)break;for(;!b.sibling;){if(!b.return||b.return===a)return null;b=b.return;}b.sibling.return=b.return;b=b.sibling;}}return null}
function dc(a,b){for(var c=a.alternate;null!==b;){if(b===a||b===c)return !0;b=b.return;}return !1}var ec,fc,gc,hc,ic=!1,jc=[],kc=null,lc=null,mc=null,nc=new Map,oc=new Map,pc=[],qc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function rc(a,b,c,d,e){return {blockedOn:a,domEventName:b,eventSystemFlags:c|16,nativeEvent:e,targetContainers:[d]}}function sc(a,b){switch(a){case "focusin":case "focusout":kc=null;break;case "dragenter":case "dragleave":lc=null;break;case "mouseover":case "mouseout":mc=null;break;case "pointerover":case "pointerout":nc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":oc.delete(b.pointerId);}}
function tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a=rc(b,c,d,e,f),null!==b&&(b=Cb(b),null!==b&&fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function uc(a,b,c,d,e){switch(b){case "focusin":return kc=tc(kc,a,b,c,d,e),!0;case "dragenter":return lc=tc(lc,a,b,c,d,e),!0;case "mouseover":return mc=tc(mc,a,b,c,d,e),!0;case "pointerover":var f=e.pointerId;nc.set(f,tc(nc.get(f)||null,a,b,c,d,e));return !0;case "gotpointercapture":return f=e.pointerId,oc.set(f,tc(oc.get(f)||null,a,b,c,d,e)),!0}return !1}
function vc(a){var b=wc(a.target);if(null!==b){var c=Zb(b);if(null!==c)if(b=c.tag,13===b){if(b=$b(c),null!==b){a.blockedOn=b;hc(a.lanePriority,function(){scheduler.unstable_runWithPriority(a.priority,function(){gc(c);});});return}}else if(3===b&&c.stateNode.hydrate){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null;}
function xc(a){if(null!==a.blockedOn)return !1;for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c)return b=Cb(c),null!==b&&fc(b),a.blockedOn=c,!1;b.shift();}return !0}function zc(a,b,c){xc(a)&&c.delete(b);}
function Ac(){for(ic=!1;0<jc.length;){var a=jc[0];if(null!==a.blockedOn){a=Cb(a.blockedOn);null!==a&&ec(a);break}for(var b=a.targetContainers;0<b.length;){var c=yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null!==c){a.blockedOn=c;break}b.shift();}null===a.blockedOn&&jc.shift();}null!==kc&&xc(kc)&&(kc=null);null!==lc&&xc(lc)&&(lc=null);null!==mc&&xc(mc)&&(mc=null);nc.forEach(zc);oc.forEach(zc);}
function Bc(a,b){a.blockedOn===b&&(a.blockedOn=null,ic||(ic=!0,scheduler.unstable_scheduleCallback(scheduler.unstable_NormalPriority,Ac)));}
function Cc(a){function b(b){return Bc(b,a)}if(0<jc.length){Bc(jc[0],a);for(var c=1;c<jc.length;c++){var d=jc[c];d.blockedOn===a&&(d.blockedOn=null);}}null!==kc&&Bc(kc,a);null!==lc&&Bc(lc,a);null!==mc&&Bc(mc,a);nc.forEach(b);oc.forEach(b);for(c=0;c<pc.length;c++)d=pc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<pc.length&&(c=pc[0],null===c.blockedOn);)vc(c),null===c.blockedOn&&pc.shift();}
function Dc(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var Ec={animationend:Dc("Animation","AnimationEnd"),animationiteration:Dc("Animation","AnimationIteration"),animationstart:Dc("Animation","AnimationStart"),transitionend:Dc("Transition","TransitionEnd")},Fc={},Gc={};
fa&&(Gc=document.createElement("div").style,"AnimationEvent"in window||(delete Ec.animationend.animation,delete Ec.animationiteration.animation,delete Ec.animationstart.animation),"TransitionEvent"in window||delete Ec.transitionend.transition);function Hc(a){if(Fc[a])return Fc[a];if(!Ec[a])return a;var b=Ec[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Gc)return Fc[a]=b[c];return a}
var Ic=Hc("animationend"),Jc=Hc("animationiteration"),Kc=Hc("animationstart"),Lc=Hc("transitionend"),Mc=new Map,Nc=new Map,Oc=["abort","abort",Ic,"animationEnd",Jc,"animationIteration",Kc,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart",
"lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Lc,"transitionEnd","waiting","waiting"];function Pc(a,b){for(var c=0;c<a.length;c+=2){var d=a[c],e=a[c+1];e="on"+(e[0].toUpperCase()+e.slice(1));Nc.set(d,b);Mc.set(d,e);da(e,[d]);}}var Qc=scheduler.unstable_now;Qc();var F=8;
function Rc(a){if(0!==(1&a))return F=15,1;if(0!==(2&a))return F=14,2;if(0!==(4&a))return F=13,4;var b=24&a;if(0!==b)return F=12,b;if(0!==(a&32))return F=11,32;b=192&a;if(0!==b)return F=10,b;if(0!==(a&256))return F=9,256;b=3584&a;if(0!==b)return F=8,b;if(0!==(a&4096))return F=7,4096;b=4186112&a;if(0!==b)return F=6,b;b=62914560&a;if(0!==b)return F=5,b;if(a&67108864)return F=4,67108864;if(0!==(a&134217728))return F=3,134217728;b=805306368&a;if(0!==b)return F=2,b;if(0!==(1073741824&a))return F=1,1073741824;
F=8;return a}function Sc(a){switch(a){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}function Tc(a){switch(a){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(y$1(358,a));}}
function Uc(a,b){var c=a.pendingLanes;if(0===c)return F=0;var d=0,e=0,f=a.expiredLanes,g=a.suspendedLanes,h=a.pingedLanes;if(0!==f)d=f,e=F=15;else if(f=c&134217727,0!==f){var k=f&~g;0!==k?(d=Rc(k),e=F):(h&=f,0!==h&&(d=Rc(h),e=F));}else f=c&~g,0!==f?(d=Rc(f),e=F):0!==h&&(d=Rc(h),e=F);if(0===d)return 0;d=31-Vc(d);d=c&((0>d?0:1<<d)<<1)-1;if(0!==b&&b!==d&&0===(b&g)){Rc(b);if(e<=F)return b;F=e;}b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-Vc(b),e=1<<c,d|=a[c],b&=~e;return d}
function Wc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function Xc(a,b){switch(a){case 15:return 1;case 14:return 2;case 12:return a=Yc(24&~b),0===a?Xc(10,b):a;case 10:return a=Yc(192&~b),0===a?Xc(8,b):a;case 8:return a=Yc(3584&~b),0===a&&(a=Yc(4186112&~b),0===a&&(a=512)),a;case 2:return b=Yc(805306368&~b),0===b&&(b=268435456),b}throw Error(y$1(358,a));}function Yc(a){return a&-a}function Zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function $c(a,b,c){a.pendingLanes|=b;var d=b-1;a.suspendedLanes&=d;a.pingedLanes&=d;a=a.eventTimes;b=31-Vc(b);a[b]=c;}var Vc=Math.clz32?Math.clz32:ad,bd=Math.log,cd=Math.LN2;function ad(a){return 0===a?32:31-(bd(a)/cd|0)|0}var dd=scheduler.unstable_UserBlockingPriority,ed=scheduler.unstable_runWithPriority,fd=!0;function gd(a,b,c,d){Kb||Ib();var e=hd,f=Kb;Kb=!0;try{Hb(e,a,b,c,d);}finally{(Kb=f)||Mb();}}function id(a,b,c,d){ed(dd,hd.bind(null,a,b,c,d));}
function hd(a,b,c,d){if(fd){var e;if((e=0===(b&4))&&0<jc.length&&-1<qc.indexOf(a))a=rc(null,a,b,c,d),jc.push(a);else {var f=yc(a,b,c,d);if(null===f)e&&sc(a,d);else {if(e){if(-1<qc.indexOf(a)){a=rc(f,a,b,c,d);jc.push(a);return}if(uc(f,a,b,c,d))return;sc(a,d);}jd(a,b,d,null,c);}}}}
function yc(a,b,c,d){var e=xb(d);e=wc(e);if(null!==e){var f=Zb(e);if(null===f)e=null;else {var g=f.tag;if(13===g){e=$b(f);if(null!==e)return e;e=null;}else if(3===g){if(f.stateNode.hydrate)return 3===f.tag?f.stateNode.containerInfo:null;e=null;}else f!==e&&(e=null);}}jd(a,b,d,e,c);return null}var kd=null,ld=null,md=null;
function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return !0}function qd(){return !1}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:!1===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}objectAssign(b.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=!1),this.isDefaultPrevented=pd);},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=pd);},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=objectAssign({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=objectAssign({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return "movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=objectAssign({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=objectAssign({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=objectAssign({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=objectAssign({},sd,{clipboardData:function(a){return "clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=objectAssign({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:!1}function zd(){return Pd}
var Qd=objectAssign({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return "keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return "keypress"===a.type?od(a):0},keyCode:function(a){return "keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return "keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=objectAssign({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=objectAssign({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=objectAssign({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=objectAssign({},Ad,{deltaX:function(a){return "deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return "deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=fa&&"CompositionEvent"in window,be=null;fa&&"documentMode"in document&&(be=document.documentMode);var ce=fa&&"TextEvent"in window&&!be,de=fa&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=!1;
function ge(a,b){switch(a){case "keyup":return -1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return !0;default:return !1}}function he(a){a=a.detail;return "object"===typeof a&&"data"in a?a.data:null}var ie=!1;function je(a,b){switch(a){case "compositionend":return he(b);case "keypress":if(32!==b.which)return null;fe=!0;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke(a,b){if(ie)return "compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=!1,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return "input"===b?!!le[a.type]:"textarea"===b?!0:!1}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}));}var pe=null,qe=null;function re(a){se(a,0);}function te(a){var b=ue(a);if(Wa(b))return a}
function ve(a,b){if("change"===a)return b}var we=!1;if(fa){var xe;if(fa){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput;}xe=ye;}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode);}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null);}function Be(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));a=re;if(Kb)a(b);else {Kb=!0;try{Gb(a,b);}finally{Kb=!1,Mb();}}}}
function Ce(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be)):"focusout"===a&&Ae();}function De(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe(a,b){if("input"===a||"change"===a)return te(b)}function Ge(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He="function"===typeof Object.is?Object.is:Ge,Ie=Object.prototype.hasOwnProperty;
function Je(a,b){if(He(a,b))return !0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return !1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return !1;for(d=0;d<c.length;d++)if(!Ie.call(b,c[d])||!He(a[c[d]],b[c[d]]))return !1;return !0}function Ke(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Le(a,b){var c=Ke(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return {node:c,offset:b-a};a=d;}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode;}c=void 0;}c=Ke(c);}}function Me(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?Me(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1}
function Ne(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href;}catch(d){c=!1;}if(c)a=b.contentWindow;else break;b=Xa(a.document);}return b}function Oe(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
var Pe=fa&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;
function Ue(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Oe(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se&&Je(Se,d)||(Se=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)));}
Pc("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),
0);Pc("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1);Pc(Oc,2);for(var Ve="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),We=0;We<Ve.length;We++)Nc.set(Ve[We],0);ea("onMouseEnter",["mouseout","mouseover"]);
ea("onMouseLeave",["mouseout","mouseover"]);ea("onPointerEnter",["pointerout","pointerover"]);ea("onPointerLeave",["pointerout","pointerover"]);da("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));da("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));da("onBeforeInput",["compositionend","keypress","textInput","paste"]);da("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));da("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Xe="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ye=new Set("cancel close invalid load scroll toggle".split(" ").concat(Xe));
function Ze(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Yb(d,b,void 0,a);a.currentTarget=null;}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k;}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;Ze(e,h,l);f=k;}}}if(Ub)throw a=Vb,Ub=!1,Vb=null,a;}
function G(a,b){var c=$e(b),d=a+"__bubble";c.has(d)||(af(b,a,2,!1),c.add(d));}var bf="_reactListening"+Math.random().toString(36).slice(2);function cf(a){a[bf]||(a[bf]=!0,ba.forEach(function(b){Ye.has(b)||df(b,!1,a,null);df(b,!0,a,null);}));}
function df(a,b,c,d){var e=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,f=c;"selectionchange"===a&&9!==c.nodeType&&(f=c.ownerDocument);if(null!==d&&!b&&Ye.has(a)){if("scroll"!==a)return;e|=2;f=d;}var g=$e(f),h=a+"__"+(b?"capture":"bubble");g.has(h)||(b&&(e|=4),af(f,a,e,b),g.add(h));}
function af(a,b,c,d){var e=Nc.get(b);switch(void 0===e?2:e){case 0:e=gd;break;case 1:e=id;break;default:e=hd;}c=e.bind(null,b,c,a);e=void 0;!Pb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=!0);d?void 0!==e?a.addEventListener(b,c,{capture:!0,passive:e}):a.addEventListener(b,c,!0):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,!1);}
function jd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return;}for(;null!==h;){g=wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode;}}d=d.return;}Nb(function(){var d=f,e=xb(c),g=[];
a:{var h=Mc.get(a);if(void 0!==h){var k=td,x=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":x="focus";k=Fd;break;case "focusout":x="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case Ic:case Jc:case Kc:k=Hd;break;case Lc:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td;}var w=0!==(b&4),z=!w&&"scroll"===a,u=w?null!==h?h+"Capture":null:h;w=[];for(var t=d,q;null!==
t;){q=t;var v=q.stateNode;5===q.tag&&null!==v&&(q=v,null!==u&&(v=Ob(t,u),null!=v&&w.push(ef(t,v,q))));if(z)break;t=t.return;}0<w.length&&(h=new k(h,x,null,c,e),g.push({event:h,listeners:w}));}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&0===(b&16)&&(x=c.relatedTarget||c.fromElement)&&(wc(x)||x[ff]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(x=c.relatedTarget||c.toElement,k=d,x=x?wc(x):null,null!==
x&&(z=Zb(x),x!==z||5!==x.tag&&6!==x.tag))x=null;}else k=null,x=d;if(k!==x){w=Bd;v="onMouseLeave";u="onMouseEnter";t="mouse";if("pointerout"===a||"pointerover"===a)w=Td,v="onPointerLeave",u="onPointerEnter",t="pointer";z=null==k?h:ue(k);q=null==x?h:ue(x);h=new w(v,t+"leave",k,c,e);h.target=z;h.relatedTarget=q;v=null;wc(e)===d&&(w=new w(u,t+"enter",x,c,e),w.target=q,w.relatedTarget=z,v=w);z=v;if(k&&x)b:{w=k;u=x;t=0;for(q=w;q;q=gf(q))t++;q=0;for(v=u;v;v=gf(v))q++;for(;0<t-q;)w=gf(w),t--;for(;0<q-t;)u=
gf(u),q--;for(;t--;){if(w===u||null!==u&&w===u.alternate)break b;w=gf(w);u=gf(u);}w=null;}else w=null;null!==k&&hf(g,h,k,w,!1);null!==x&&null!==z&&hf(g,z,x,w,!0);}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var J=ve;else if(me(h))if(we)J=Fe;else {J=De;var K=Ce;}else (k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(J=Ee);if(J&&(J=J(a,d))){ne(g,J,c,e);break a}K&&K(a,h,d);"focusout"===a&&(K=h._wrapperState)&&
K.controlled&&"number"===h.type&&bb(h,"number",h.value);}K=d?ue(d):window;switch(a){case "focusin":if(me(K)||"true"===K.contentEditable)Qe=K,Re=d,Se=null;break;case "focusout":Se=Re=Qe=null;break;case "mousedown":Te=!0;break;case "contextmenu":case "mouseup":case "dragend":Te=!1;Ue(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue(g,c,e);}var Q;if(ae)b:{switch(a){case "compositionstart":var L="onCompositionStart";break b;case "compositionend":L="onCompositionEnd";break b;
case "compositionupdate":L="onCompositionUpdate";break b}L=void 0;}else ie?ge(a,c)&&(L="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(L="onCompositionStart");L&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==L?"onCompositionEnd"===L&&ie&&(Q=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=!0)),K=oe(d,L),0<K.length&&(L=new Ld(L,a,null,c,e),g.push({event:L,listeners:K}),Q?L.data=Q:(Q=he(c),null!==Q&&(L.data=Q))));if(Q=ce?je(a,c):ke(a,c))d=oe(d,"onBeforeInput"),0<d.length&&(e=new Ld("onBeforeInput",
"beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=Q);}se(g,b);});}function ef(a,b,c){return {instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Ob(a,c),null!=f&&d.unshift(ef(a,f,e)),f=Ob(a,b),null!=f&&d.push(ef(a,f,e)));a=a.return;}return d}function gf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function hf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Ob(c,f),null!=k&&g.unshift(ef(c,k,h))):e||(k=Ob(c,f),null!=k&&g.push(ef(c,k,h))));c=c.return;}0!==g.length&&a.push({event:b,listeners:g});}function jf(){}var kf=null,lf=null;function mf(a,b){switch(a){case "button":case "input":case "select":case "textarea":return !!b.autoFocus}return !1}
function nf(a,b){return "textarea"===a||"option"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}var of="function"===typeof setTimeout?setTimeout:void 0,pf="function"===typeof clearTimeout?clearTimeout:void 0;function qf(a){1===a.nodeType?a.textContent="":9===a.nodeType&&(a=a.body,null!=a&&(a.textContent=""));}
function rf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break}return a}function sf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--;}else "/$"===c&&b++;}a=a.previousSibling;}return null}var tf=0;function uf(a){return {$$typeof:Ga,toString:a,valueOf:a}}var vf=Math.random().toString(36).slice(2),wf="__reactFiber$"+vf,xf="__reactProps$"+vf,ff="__reactContainer$"+vf,yf="__reactEvents$"+vf;
function wc(a){var b=a[wf];if(b)return b;for(var c=a.parentNode;c;){if(b=c[ff]||c[wf]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=sf(a);null!==a;){if(c=a[wf])return c;a=sf(a);}return b}a=c;c=a.parentNode;}return null}function Cb(a){a=a[wf]||a[ff];return !a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(y$1(33));}function Db(a){return a[xf]||null}
function $e(a){var b=a[yf];void 0===b&&(b=a[yf]=new Set);return b}var zf=[],Af=-1;function Bf(a){return {current:a}}function H(a){0>Af||(a.current=zf[Af],zf[Af]=null,Af--);}function I(a,b){Af++;zf[Af]=a.current;a.current=b;}var Cf={},M=Bf(Cf),N=Bf(!1),Df=Cf;
function Ef(a,b){var c=a.type.contextTypes;if(!c)return Cf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}function Ff(a){a=a.childContextTypes;return null!==a&&void 0!==a}function Gf(){H(N);H(M);}function Hf(a,b,c){if(M.current!==Cf)throw Error(y$1(168));I(M,b);I(N,c);}
function If(a,b,c){var d=a.stateNode;a=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in a))throw Error(y$1(108,Ra(b)||"Unknown",e));return objectAssign({},c,d)}function Jf(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Cf;Df=M.current;I(M,a);I(N,N.current);return !0}function Kf(a,b,c){var d=a.stateNode;if(!d)throw Error(y$1(169));c?(a=If(a,b,Df),d.__reactInternalMemoizedMergedChildContext=a,H(N),H(M),I(M,a)):H(N);I(N,c);}
var Lf=null,Mf=null,Nf=scheduler.unstable_runWithPriority,Of=scheduler.unstable_scheduleCallback,Pf=scheduler.unstable_cancelCallback,Qf=scheduler.unstable_shouldYield,Rf=scheduler.unstable_requestPaint,Sf=scheduler.unstable_now,Tf=scheduler.unstable_getCurrentPriorityLevel,Uf=scheduler.unstable_ImmediatePriority,Vf=scheduler.unstable_UserBlockingPriority,Wf=scheduler.unstable_NormalPriority,Xf=scheduler.unstable_LowPriority,Yf=scheduler.unstable_IdlePriority,Zf={},$f=void 0!==Rf?Rf:function(){},ag=null,bg=null,cg=!1,dg=Sf(),O=1E4>dg?Sf:function(){return Sf()-dg};
function eg(){switch(Tf()){case Uf:return 99;case Vf:return 98;case Wf:return 97;case Xf:return 96;case Yf:return 95;default:throw Error(y$1(332));}}function fg(a){switch(a){case 99:return Uf;case 98:return Vf;case 97:return Wf;case 96:return Xf;case 95:return Yf;default:throw Error(y$1(332));}}function gg(a,b){a=fg(a);return Nf(a,b)}function hg(a,b,c){a=fg(a);return Of(a,b,c)}function ig(){if(null!==bg){var a=bg;bg=null;Pf(a);}jg();}
function jg(){if(!cg&&null!==ag){cg=!0;var a=0;try{var b=ag;gg(99,function(){for(;a<b.length;a++){var c=b[a];do c=c(!0);while(null!==c)}});ag=null;}catch(c){throw null!==ag&&(ag=ag.slice(a+1)),Of(Uf,ig),c;}finally{cg=!1;}}}var kg=ra.ReactCurrentBatchConfig;function lg(a,b){if(a&&a.defaultProps){b=objectAssign({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);return b}return b}var mg=Bf(null),ng=null,og=null,pg=null;function qg(){pg=og=ng=null;}
function rg(a){var b=mg.current;H(mg);a.type._context._currentValue=b;}function sg(a,b){for(;null!==a;){var c=a.alternate;if((a.childLanes&b)===b)if(null===c||(c.childLanes&b)===b)break;else c.childLanes|=b;else a.childLanes|=b,null!==c&&(c.childLanes|=b);a=a.return;}}function tg(a,b){ng=a;pg=og=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(ug=!0),a.firstContext=null);}
function vg(a,b){if(pg!==a&&!1!==b&&0!==b){if("number"!==typeof b||1073741823===b)pg=a,b=1073741823;b={context:a,observedBits:b,next:null};if(null===og){if(null===ng)throw Error(y$1(308));og=b;ng.dependencies={lanes:0,firstContext:b,responders:null};}else og=og.next=b;}return a._currentValue}var wg=!1;function xg(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null};}
function yg(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects});}function zg(a,b){return {eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}function Ag(a,b){a=a.updateQueue;if(null!==a){a=a.shared;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b;}}
function Bg(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next;}while(null!==c);null===f?e=f=b:f=f.next=b;}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b;}
function Cg(a,b,c,d){var e=a.updateQueue;wg=!1;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var n=a.alternate;if(null!==n){n=n.updateQueue;var A=n.lastBaseUpdate;A!==g&&(null===A?n.firstBaseUpdate=l:A.next=l,n.lastBaseUpdate=k);}}if(null!==f){A=e.baseState;g=0;n=l=k=null;do{h=f.lane;var p=f.eventTime;if((d&h)===h){null!==n&&(n=n.next={eventTime:p,lane:0,tag:f.tag,payload:f.payload,callback:f.callback,
next:null});a:{var C=a,x=f;h=b;p=c;switch(x.tag){case 1:C=x.payload;if("function"===typeof C){A=C.call(p,A,h);break a}A=C;break a;case 3:C.flags=C.flags&-4097|64;case 0:C=x.payload;h="function"===typeof C?C.call(p,A,h):C;if(null===h||void 0===h)break a;A=objectAssign({},A,h);break a;case 2:wg=!0;}}null!==f.callback&&(a.flags|=32,h=e.effects,null===h?e.effects=[f]:h.push(f));}else p={eventTime:p,lane:h,tag:f.tag,payload:f.payload,callback:f.callback,next:null},null===n?(l=n=p,k=A):n=n.next=p,g|=h;f=f.next;if(null===
f)if(h=e.shared.pending,null===h)break;else f=h.next,h.next=null,e.lastBaseUpdate=h,e.shared.pending=null;}while(1);null===n&&(k=A);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=n;Dg|=g;a.lanes=g;a.memoizedState=A;}}function Eg(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(y$1(191,e));e.call(d);}}}var Fg=(new react.Component).refs;
function Gg(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:objectAssign({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c);}
var Kg={isMounted:function(a){return (a=a._reactInternals)?Zb(a)===a:!1},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d);},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=Hg(),e=Ig(a),f=zg(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);Ag(a,f);Jg(a,e,d);},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=Hg(),d=Ig(a),e=zg(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=
b);Ag(a,e);Jg(a,d,c);}};function Lg(a,b,c,d,e,f,g){a=a.stateNode;return "function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Je(c,d)||!Je(e,f):!0}
function Mg(a,b,c){var d=!1,e=Cf;var f=b.contextType;"object"===typeof f&&null!==f?f=vg(f):(e=Ff(b)?Df:M.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Ef(a,e):Cf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Kg;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function Ng(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Kg.enqueueReplaceState(b,b.state,null);}
function Og(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=Fg;xg(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=vg(f):(f=Ff(b)?Df:M.current,e.context=Ef(a,f));Cg(a,c,e,d);e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Gg(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||
(b=e.state,"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Kg.enqueueReplaceState(e,e.state,null),Cg(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4);}var Pg=Array.isArray;
function Qg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(y$1(309));var d=c.stateNode;}if(!d)throw Error(y$1(147,a));var e=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===e)return b.ref;b=function(a){var b=d.refs;b===Fg&&(b=d.refs={});null===a?delete b[e]:b[e]=a;};b._stringRef=e;return b}if("string"!==typeof a)throw Error(y$1(284));if(!c._owner)throw Error(y$1(290,a));}return a}
function Rg(a,b){if("textarea"!==a.type)throw Error(y$1(31,"[object Object]"===Object.prototype.toString.call(b)?"object with keys {"+Object.keys(b).join(", ")+"}":b));}
function Sg(a){function b(b,c){if(a){var d=b.lastEffect;null!==d?(d.nextEffect=c,b.lastEffect=c):b.firstEffect=b.lastEffect=c;c.nextEffect=null;c.flags=8;}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=Tg(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags=2,
c):d;b.flags=2;return c}function g(b){a&&null===b.alternate&&(b.flags=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Ug(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){if(null!==b&&b.elementType===c.type)return d=e(b,c.props),d.ref=Qg(a,b,c),d.return=a,d;d=Vg(c.type,c.key,c.props,null,a.mode,d);d.ref=Qg(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=
Wg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function n(a,b,c,d,f){if(null===b||7!==b.tag)return b=Xg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function A(a,b,c){if("string"===typeof b||"number"===typeof b)return b=Ug(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case sa:return c=Vg(b.type,b.key,b.props,null,a.mode,c),c.ref=Qg(a,null,b),c.return=a,c;case ta:return b=Wg(b,a.mode,c),b.return=a,b}if(Pg(b)||La(b))return b=Xg(b,
a.mode,c,null),b.return=a,b;Rg(a,b);}return null}function p(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case sa:return c.key===e?c.type===ua?n(a,b,c.props.children,d,e):k(a,b,c,d):null;case ta:return c.key===e?l(a,b,c,d):null}if(Pg(c)||La(c))return null!==e?null:n(a,b,c,d,null);Rg(a,c);}return null}function C(a,b,c,d,e){if("string"===typeof d||"number"===typeof d)return a=a.get(c)||
null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case sa:return a=a.get(null===d.key?c:d.key)||null,d.type===ua?n(b,a,d.props.children,e,d.key):k(b,a,d,e);case ta:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e)}if(Pg(d)||La(d))return a=a.get(c)||null,n(b,a,d,e,null);Rg(b,d);}return null}function x(e,g,h,k){for(var l=null,t=null,u=g,z=g=0,q=null;null!==u&&z<h.length;z++){u.index>z?(q=u,u=null):q=u.sibling;var n=p(e,u,h[z],k);if(null===n){null===u&&(u=q);break}a&&u&&null===
n.alternate&&b(e,u);g=f(n,g,z);null===t?l=n:t.sibling=n;t=n;u=q;}if(z===h.length)return c(e,u),l;if(null===u){for(;z<h.length;z++)u=A(e,h[z],k),null!==u&&(g=f(u,g,z),null===t?l=u:t.sibling=u,t=u);return l}for(u=d(e,u);z<h.length;z++)q=C(u,e,z,h[z],k),null!==q&&(a&&null!==q.alternate&&u.delete(null===q.key?z:q.key),g=f(q,g,z),null===t?l=q:t.sibling=q,t=q);a&&u.forEach(function(a){return b(e,a)});return l}function w(e,g,h,k){var l=La(h);if("function"!==typeof l)throw Error(y$1(150));h=l.call(h);if(null==
h)throw Error(y$1(151));for(var t=l=null,u=g,z=g=0,q=null,n=h.next();null!==u&&!n.done;z++,n=h.next()){u.index>z?(q=u,u=null):q=u.sibling;var w=p(e,u,n.value,k);if(null===w){null===u&&(u=q);break}a&&u&&null===w.alternate&&b(e,u);g=f(w,g,z);null===t?l=w:t.sibling=w;t=w;u=q;}if(n.done)return c(e,u),l;if(null===u){for(;!n.done;z++,n=h.next())n=A(e,n.value,k),null!==n&&(g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);return l}for(u=d(e,u);!n.done;z++,n=h.next())n=C(u,e,z,n.value,k),null!==n&&(a&&null!==n.alternate&&
u.delete(null===n.key?z:n.key),g=f(n,g,z),null===t?l=n:t.sibling=n,t=n);a&&u.forEach(function(a){return b(e,a)});return l}return function(a,d,f,h){var k="object"===typeof f&&null!==f&&f.type===ua&&null===f.key;k&&(f=f.props.children);var l="object"===typeof f&&null!==f;if(l)switch(f.$$typeof){case sa:a:{l=f.key;for(k=d;null!==k;){if(k.key===l){switch(k.tag){case 7:if(f.type===ua){c(a,k.sibling);d=e(k,f.props.children);d.return=a;a=d;break a}break;default:if(k.elementType===f.type){c(a,k.sibling);
d=e(k,f.props);d.ref=Qg(a,k,f);d.return=a;a=d;break a}}c(a,k);break}else b(a,k);k=k.sibling;}f.type===ua?(d=Xg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Vg(f.type,f.key,f.props,null,a.mode,h),h.ref=Qg(a,d,f),h.return=a,a=h);}return g(a);case ta:a:{for(k=f.key;null!==d;){if(d.key===k)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else {c(a,d);break}else b(a,d);d=d.sibling;}d=
Wg(f,a.mode,h);d.return=a;a=d;}return g(a)}if("string"===typeof f||"number"===typeof f)return f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):(c(a,d),d=Ug(f,a.mode,h),d.return=a,a=d),g(a);if(Pg(f))return x(a,d,f,h);if(La(f))return w(a,d,f,h);l&&Rg(a,f);if("undefined"===typeof f&&!k)switch(a.tag){case 1:case 22:case 0:case 11:case 15:throw Error(y$1(152,Ra(a.type)||"Component"));}return c(a,d)}}var Yg=Sg(!0),Zg=Sg(!1),$g={},ah=Bf($g),bh=Bf($g),ch=Bf($g);
function dh(a){if(a===$g)throw Error(y$1(174));return a}function eh(a,b){I(ch,b);I(bh,a);I(ah,$g);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:mb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=mb(b,a);}H(ah);I(ah,b);}function fh(){H(ah);H(bh);H(ch);}function gh(a){dh(ch.current);var b=dh(ah.current);var c=mb(b,a.type);b!==c&&(I(bh,a),I(ah,c));}function hh(a){bh.current===a&&(H(ah),H(bh));}var P=Bf(0);
function ih(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&64))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return;}b.sibling.return=b.return;b=b.sibling;}return null}var jh=null,kh=null,lh=!1;
function mh(a,b){var c=nh(5,null,null,0);c.elementType="DELETED";c.type="DELETED";c.stateNode=b;c.return=a;c.flags=8;null!==a.lastEffect?(a.lastEffect.nextEffect=c,a.lastEffect=c):a.firstEffect=a.lastEffect=c;}function oh(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,!0):!1;case 13:return !1;default:return !1}}
function ph(a){if(lh){var b=kh;if(b){var c=b;if(!oh(a,b)){b=rf(c.nextSibling);if(!b||!oh(a,b)){a.flags=a.flags&-1025|2;lh=!1;jh=a;return}mh(jh,c);}jh=a;kh=rf(b.firstChild);}else a.flags=a.flags&-1025|2,lh=!1,jh=a;}}function qh(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;jh=a;}
function rh(a){if(a!==jh)return !1;if(!lh)return qh(a),lh=!0,!1;var b=a.type;if(5!==a.tag||"head"!==b&&"body"!==b&&!nf(b,a.memoizedProps))for(b=kh;b;)mh(a,b),b=rf(b.nextSibling);qh(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(y$1(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){kh=rf(a.nextSibling);break a}b--;}else "$"!==c&&"$!"!==c&&"$?"!==c||b++;}a=a.nextSibling;}kh=null;}}else kh=jh?rf(a.stateNode.nextSibling):null;return !0}
function sh(){kh=jh=null;lh=!1;}var th=[];function uh(){for(var a=0;a<th.length;a++)th[a]._workInProgressVersionPrimary=null;th.length=0;}var vh=ra.ReactCurrentDispatcher,wh=ra.ReactCurrentBatchConfig,xh=0,R=null,S=null,T=null,yh=!1,zh=!1;function Ah(){throw Error(y$1(321));}function Bh(a,b){if(null===b)return !1;for(var c=0;c<b.length&&c<a.length;c++)if(!He(a[c],b[c]))return !1;return !0}
function Ch(a,b,c,d,e,f){xh=f;R=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;vh.current=null===a||null===a.memoizedState?Dh:Eh;a=c(d,e);if(zh){f=0;do{zh=!1;if(!(25>f))throw Error(y$1(301));f+=1;T=S=null;b.updateQueue=null;vh.current=Fh;a=c(d,e);}while(zh)}vh.current=Gh;b=null!==S&&null!==S.next;xh=0;T=S=R=null;yh=!1;if(b)throw Error(y$1(300));return a}function Hh(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===T?R.memoizedState=T=a:T=T.next=a;return T}
function Ih(){if(null===S){var a=R.alternate;a=null!==a?a.memoizedState:null;}else a=S.next;var b=null===T?R.memoizedState:T.next;if(null!==b)T=b,S=a;else {if(null===a)throw Error(y$1(310));S=a;a={memoizedState:S.memoizedState,baseState:S.baseState,baseQueue:S.baseQueue,queue:S.queue,next:null};null===T?R.memoizedState=T=a:T=T.next=a;}return T}function Jh(a,b){return "function"===typeof b?b(a):b}
function Kh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y$1(311));c.lastRenderedReducer=a;var d=S,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g;}d.baseQueue=e=f;c.pending=null;}if(null!==e){e=e.next;d=d.baseState;var h=g=f=null,k=e;do{var l=k.lane;if((xh&l)===l)null!==h&&(h=h.next={lane:0,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null}),d=k.eagerReducer===a?k.eagerState:a(d,k.action);else {var n={lane:l,action:k.action,eagerReducer:k.eagerReducer,
eagerState:k.eagerState,next:null};null===h?(g=h=n,f=d):h=h.next=n;R.lanes|=l;Dg|=l;}k=k.next;}while(null!==k&&k!==e);null===h?f=d:h.next=g;He(d,b.memoizedState)||(ug=!0);b.memoizedState=d;b.baseState=f;b.baseQueue=h;c.lastRenderedState=d;}return [b.memoizedState,c.dispatch]}
function Lh(a){var b=Ih(),c=b.queue;if(null===c)throw Error(y$1(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He(f,b.memoizedState)||(ug=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f;}return [f,d]}
function Mh(a,b,c){var d=b._getVersion;d=d(b._source);var e=b._workInProgressVersionPrimary;if(null!==e)a=e===d;else if(a=a.mutableReadLanes,a=(xh&a)===a)b._workInProgressVersionPrimary=d,th.push(b);if(a)return c(b._source);th.push(b);throw Error(y$1(350));}
function Nh(a,b,c,d){var e=U;if(null===e)throw Error(y$1(349));var f=b._getVersion,g=f(b._source),h=vh.current,k=h.useState(function(){return Mh(e,b,c)}),l=k[1],n=k[0];k=T;var A=a.memoizedState,p=A.refs,C=p.getSnapshot,x=A.source;A=A.subscribe;var w=R;a.memoizedState={refs:p,source:b,subscribe:d};h.useEffect(function(){p.getSnapshot=c;p.setSnapshot=l;var a=f(b._source);if(!He(g,a)){a=c(b._source);He(n,a)||(l(a),a=Ig(w),e.mutableReadLanes|=a&e.pendingLanes);a=e.mutableReadLanes;e.entangledLanes|=a;for(var d=
e.entanglements,h=a;0<h;){var k=31-Vc(h),v=1<<k;d[k]|=a;h&=~v;}}},[c,b,d]);h.useEffect(function(){return d(b._source,function(){var a=p.getSnapshot,c=p.setSnapshot;try{c(a(b._source));var d=Ig(w);e.mutableReadLanes|=d&e.pendingLanes;}catch(q){c(function(){throw q;});}})},[b,d]);He(C,c)&&He(x,b)&&He(A,d)||(a={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:n},a.dispatch=l=Oh.bind(null,R,a),k.queue=a,k.baseQueue=null,n=Mh(e,b,c),k.memoizedState=k.baseState=n);return n}
function Ph(a,b,c){var d=Ih();return Nh(d,a,b,c)}function Qh(a){var b=Hh();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a=b.queue={pending:null,dispatch:null,lastRenderedReducer:Jh,lastRenderedState:a};a=a.dispatch=Oh.bind(null,R,a);return [b.memoizedState,a]}
function Rh(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=R.updateQueue;null===b?(b={lastEffect:null},R.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function Sh(a){var b=Hh();a={current:a};return b.memoizedState=a}function Th(){return Ih().memoizedState}function Uh(a,b,c,d){var e=Hh();R.flags|=a;e.memoizedState=Rh(1|b,c,void 0,void 0===d?null:d);}
function Vh(a,b,c,d){var e=Ih();d=void 0===d?null:d;var f=void 0;if(null!==S){var g=S.memoizedState;f=g.destroy;if(null!==d&&Bh(d,g.deps)){Rh(b,c,f,d);return}}R.flags|=a;e.memoizedState=Rh(1|b,c,f,d);}function Wh(a,b){return Uh(516,4,a,b)}function Xh(a,b){return Vh(516,4,a,b)}function Yh(a,b){return Vh(4,2,a,b)}function Zh(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null);};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null;}}
function $h(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Vh(4,2,Zh.bind(null,b,a),c)}function ai(){}function bi(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}function ci(a,b){var c=Ih();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Bh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}
function di(a,b){var c=eg();gg(98>c?98:c,function(){a(!0);});gg(97<c?97:c,function(){var c=wh.transition;wh.transition=1;try{a(!1),b();}finally{wh.transition=c;}});}
function Oh(a,b,c){var d=Hg(),e=Ig(a),f={lane:e,action:c,eagerReducer:null,eagerState:null,next:null},g=b.pending;null===g?f.next=f:(f.next=g.next,g.next=f);b.pending=f;g=a.alternate;if(a===R||null!==g&&g===R)zh=yh=!0;else {if(0===a.lanes&&(null===g||0===g.lanes)&&(g=b.lastRenderedReducer,null!==g))try{var h=b.lastRenderedState,k=g(h,c);f.eagerReducer=g;f.eagerState=k;if(He(k,h))return}catch(l){}finally{}Jg(a,e,d);}}
var Gh={readContext:vg,useCallback:Ah,useContext:Ah,useEffect:Ah,useImperativeHandle:Ah,useLayoutEffect:Ah,useMemo:Ah,useReducer:Ah,useRef:Ah,useState:Ah,useDebugValue:Ah,useDeferredValue:Ah,useTransition:Ah,useMutableSource:Ah,useOpaqueIdentifier:Ah,unstable_isNewReconciler:!1},Dh={readContext:vg,useCallback:function(a,b){Hh().memoizedState=[a,void 0===b?null:b];return a},useContext:vg,useEffect:Wh,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Uh(4,2,Zh.bind(null,
b,a),c)},useLayoutEffect:function(a,b){return Uh(4,2,a,b)},useMemo:function(a,b){var c=Hh();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=Hh();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a=d.queue={pending:null,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};a=a.dispatch=Oh.bind(null,R,a);return [d.memoizedState,a]},useRef:Sh,useState:Qh,useDebugValue:ai,useDeferredValue:function(a){var b=Qh(a),c=b[0],d=b[1];Wh(function(){var b=wh.transition;
wh.transition=1;try{d(a);}finally{wh.transition=b;}},[a]);return c},useTransition:function(){var a=Qh(!1),b=a[0];a=di.bind(null,a[1]);Sh(a);return [a,b]},useMutableSource:function(a,b,c){var d=Hh();d.memoizedState={refs:{getSnapshot:b,setSnapshot:null},source:a,subscribe:c};return Nh(d,a,b,c)},useOpaqueIdentifier:function(){if(lh){var a=!1,b=uf(function(){a||(a=!0,c("r:"+(tf++).toString(36)));throw Error(y$1(355));}),c=Qh(b)[1];0===(R.mode&2)&&(R.flags|=516,Rh(5,function(){c("r:"+(tf++).toString(36));},
void 0,null));return b}b="r:"+(tf++).toString(36);Qh(b);return b},unstable_isNewReconciler:!1},Eh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Kh,useRef:Th,useState:function(){return Kh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Kh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a);}finally{wh.transition=b;}},[a]);return c},useTransition:function(){var a=Kh(Jh)[0];return [Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Kh(Jh)[0]},unstable_isNewReconciler:!1},Fh={readContext:vg,useCallback:bi,useContext:vg,useEffect:Xh,useImperativeHandle:$h,useLayoutEffect:Yh,useMemo:ci,useReducer:Lh,useRef:Th,useState:function(){return Lh(Jh)},useDebugValue:ai,useDeferredValue:function(a){var b=Lh(Jh),c=b[0],d=b[1];Xh(function(){var b=wh.transition;wh.transition=1;try{d(a);}finally{wh.transition=b;}},[a]);return c},useTransition:function(){var a=Lh(Jh)[0];return [Th().current,
a]},useMutableSource:Ph,useOpaqueIdentifier:function(){return Lh(Jh)[0]},unstable_isNewReconciler:!1},ei=ra.ReactCurrentOwner,ug=!1;function fi(a,b,c,d){b.child=null===a?Zg(b,null,c,d):Yg(b,a.child,c,d);}function gi(a,b,c,d,e){c=c.render;var f=b.ref;tg(b,e);d=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,d,e);return b.child}
function ii(a,b,c,d,e,f){if(null===a){var g=c.type;if("function"===typeof g&&!ji(g)&&void 0===g.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=g,ki(a,b,g,d,e,f);a=Vg(c.type,null,d,b,b.mode,f);a.ref=b.ref;a.return=b;return b.child=a}g=a.child;if(0===(e&f)&&(e=g.memoizedProps,c=c.compare,c=null!==c?c:Je,c(e,d)&&a.ref===b.ref))return hi(a,b,f);b.flags|=1;a=Tg(g,d);a.ref=b.ref;a.return=b;return b.child=a}
function ki(a,b,c,d,e,f){if(null!==a&&Je(a.memoizedProps,d)&&a.ref===b.ref)if(ug=!1,0!==(f&e))0!==(a.flags&16384)&&(ug=!0);else return b.lanes=a.lanes,hi(a,b,f);return li(a,b,c,d,f)}
function mi(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode||"unstable-defer-without-hiding"===d.mode)if(0===(b.mode&4))b.memoizedState={baseLanes:0},ni(b,c);else if(0!==(c&1073741824))b.memoizedState={baseLanes:0},ni(b,null!==f?f.baseLanes:c);else return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a},ni(b,a),null;else null!==f?(d=f.baseLanes|c,b.memoizedState=null):d=c,ni(b,d);fi(a,b,e,c);return b.child}
function oi(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=128;}function li(a,b,c,d,e){var f=Ff(c)?Df:M.current;f=Ef(b,f);tg(b,e);c=Ch(a,b,c,d,f,e);if(null!==a&&!ug)return b.updateQueue=a.updateQueue,b.flags&=-517,a.lanes&=~e,hi(a,b,e);b.flags|=1;fi(a,b,c,e);return b.child}
function pi(a,b,c,d,e){if(Ff(c)){var f=!0;Jf(b);}else f=!1;tg(b,e);if(null===b.stateNode)null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),Mg(b,c,d),Og(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=vg(l):(l=Ff(c)?Df:M.current,l=Ef(b,l));var n=c.getDerivedStateFromProps,A="function"===typeof n||"function"===typeof g.getSnapshotBeforeUpdate;A||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&
"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Ng(b,g,d,l);wg=!1;var p=b.memoizedState;g.state=p;Cg(b,d,g,e);k=b.memoizedState;h!==d||p!==k||N.current||wg?("function"===typeof n&&(Gg(b,c,n,d),k=b.memoizedState),(h=wg||Lg(b,c,h,d,p,k,l))?(A||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===
typeof g.componentDidMount&&(b.flags|=4)):("function"===typeof g.componentDidMount&&(b.flags|=4),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4),d=!1);}else {g=b.stateNode;yg(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:lg(b.type,h);g.props=l;A=b.pendingProps;p=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=vg(k):(k=Ff(c)?Df:M.current,k=Ef(b,k));var C=c.getDerivedStateFromProps;(n="function"===typeof C||
"function"===typeof g.getSnapshotBeforeUpdate)||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==A||p!==k)&&Ng(b,g,d,k);wg=!1;p=b.memoizedState;g.state=p;Cg(b,d,g,e);var x=b.memoizedState;h!==A||p!==x||N.current||wg?("function"===typeof C&&(Gg(b,c,C,d),x=b.memoizedState),(l=wg||Lg(b,c,l,d,p,x,k))?(n||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,
x,k),"function"===typeof g.UNSAFE_componentWillUpdate&&g.UNSAFE_componentWillUpdate(d,x,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=256)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),b.memoizedProps=d,b.memoizedState=x),g.props=d,g.state=x,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||
h===a.memoizedProps&&p===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&p===a.memoizedState||(b.flags|=256),d=!1);}return qi(a,b,c,d,f,e)}
function qi(a,b,c,d,e,f){oi(a,b);var g=0!==(b.flags&64);if(!d&&!g)return e&&Kf(b,c,!1),hi(a,b,f);d=b.stateNode;ei.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Yg(b,a.child,null,f),b.child=Yg(b,null,h,f)):fi(a,b,h,f);b.memoizedState=d.state;e&&Kf(b,c,!0);return b.child}function ri(a){var b=a.stateNode;b.pendingContext?Hf(a,b.pendingContext,b.pendingContext!==b.context):b.context&&Hf(a,b.context,!1);eh(a,b.containerInfo);}
var si={dehydrated:null,retryLane:0};
function ti(a,b,c){var d=b.pendingProps,e=P.current,f=!1,g;(g=0!==(b.flags&64))||(g=null!==a&&null===a.memoizedState?!1:0!==(e&2));g?(f=!0,b.flags&=-65):null!==a&&null===a.memoizedState||void 0===d.fallback||!0===d.unstable_avoidThisFallback||(e|=1);I(P,e&1);if(null===a){void 0!==d.fallback&&ph(b);a=d.children;e=d.fallback;if(f)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},b.memoizedState=si,a;if("number"===typeof d.unstable_expectedLoadTime)return a=ui(b,a,e,c),b.child.memoizedState={baseLanes:c},
b.memoizedState=si,b.lanes=33554432,a;c=vi({mode:"visible",children:a},b.mode,c,null);c.return=b;return b.child=c}if(null!==a.memoizedState){if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}if(f)return d=wi(a,b,d.children,d.fallback,c),f=b.child,e=a.child.memoizedState,f.memoizedState=null===e?{baseLanes:c}:
{baseLanes:e.baseLanes|c},f.childLanes=a.childLanes&~c,b.memoizedState=si,d;c=xi(a,b,d.children,c);b.memoizedState=null;return c}function ui(a,b,c,d){var e=a.mode,f=a.child;b={mode:"hidden",children:b};0===(e&2)&&null!==f?(f.childLanes=0,f.pendingProps=b):f=vi(b,e,0,null);c=Xg(c,e,d,null);f.return=a;c.return=a;f.sibling=c;a.child=f;return c}
function xi(a,b,c,d){var e=a.child;a=e.sibling;c=Tg(e,{mode:"visible",children:c});0===(b.mode&2)&&(c.lanes=d);c.return=b;c.sibling=null;null!==a&&(a.nextEffect=null,a.flags=8,b.firstEffect=b.lastEffect=a);return b.child=c}
function wi(a,b,c,d,e){var f=b.mode,g=a.child;a=g.sibling;var h={mode:"hidden",children:c};0===(f&2)&&b.child!==g?(c=b.child,c.childLanes=0,c.pendingProps=h,g=c.lastEffect,null!==g?(b.firstEffect=c.firstEffect,b.lastEffect=g,g.nextEffect=null):b.firstEffect=b.lastEffect=null):c=Tg(g,h);null!==a?d=Tg(a,d):(d=Xg(d,f,e,null),d.flags|=2);d.return=b;c.return=b;c.sibling=d;b.child=c;return d}function yi(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);sg(a.return,b);}
function zi(a,b,c,d,e,f){var g=a.memoizedState;null===g?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e,lastEffect:f}:(g.isBackwards=b,g.rendering=null,g.renderingStartTime=0,g.last=d,g.tail=c,g.tailMode=e,g.lastEffect=f);}
function Ai(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;fi(a,b,d.children,c);d=P.current;if(0!==(d&2))d=d&1|2,b.flags|=64;else {if(null!==a&&0!==(a.flags&64))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&yi(a,c);else if(19===a.tag)yi(a,c);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return;}a.sibling.return=a.return;a=a.sibling;}d&=1;}I(P,d);if(0===(b.mode&2))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===ih(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);zi(b,!1,e,c,f,b.lastEffect);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===ih(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a;}zi(b,!0,c,null,f,b.lastEffect);break;case "together":zi(b,!1,null,null,void 0,b.lastEffect);break;default:b.memoizedState=null;}return b.child}
function hi(a,b,c){null!==a&&(b.dependencies=a.dependencies);Dg|=b.lanes;if(0!==(c&b.childLanes)){if(null!==a&&b.child!==a.child)throw Error(y$1(153));if(null!==b.child){a=b.child;c=Tg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Tg(a,a.pendingProps),c.return=b;c.sibling=null;}return b.child}return null}var Bi,Ci,Di,Ei;
Bi=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;}c.sibling.return=c.return;c=c.sibling;}};Ci=function(){};
Di=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;dh(ah.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "option":e=eb(a,e);d=eb(a,d);f=[];break;case "select":e=objectAssign({},e,{value:void 0});d=objectAssign({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=jf);}vb(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===
l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&(c||(c={}),c[g]="");}else "dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ca.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||
(c={}),c[g]=k[g]);}else c||(f||(f=[]),f.push(l,c)),c=k;else "dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ca.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&G("scroll",a),f||h===k||(f=[])):"object"===typeof k&&null!==k&&k.$$typeof===Ga?k.toString():(f=f||[]).push(l,k));}c&&(f=f||[]).push("style",
c);var l=f;if(b.updateQueue=l)b.flags|=4;}};Ei=function(a,b,c,d){c!==d&&(b.flags|=4);};function Fi(a,b){if(!lh)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null;}}
function Gi(a,b,c){var d=b.pendingProps;switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return Ff(b.type)&&Gf(),null;case 3:fh();H(N);H(M);uh();d=b.stateNode;d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)rh(b)?b.flags|=4:d.hydrate||(b.flags|=256);Ci(b);return null;case 5:hh(b);var e=dh(ch.current);c=b.type;if(null!==a&&null!=b.stateNode)Di(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=128);else {if(!d){if(null===
b.stateNode)throw Error(y$1(166));return null}a=dh(ah.current);if(rh(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[wf]=b;d[xf]=f;switch(c){case "dialog":G("cancel",d);G("close",d);break;case "iframe":case "object":case "embed":G("load",d);break;case "video":case "audio":for(a=0;a<Xe.length;a++)G(Xe[a],d);break;case "source":G("error",d);break;case "img":case "image":case "link":G("error",d);G("load",d);break;case "details":G("toggle",d);break;case "input":Za(d,f);G("invalid",d);break;case "select":d._wrapperState=
{wasMultiple:!!f.multiple};G("invalid",d);break;case "textarea":hb(d,f),G("invalid",d);}vb(c,f);a=null;for(var g in f)f.hasOwnProperty(g)&&(e=f[g],"children"===g?"string"===typeof e?d.textContent!==e&&(a=["children",e]):"number"===typeof e&&d.textContent!==""+e&&(a=["children",""+e]):ca.hasOwnProperty(g)&&null!=e&&"onScroll"===g&&G("scroll",d));switch(c){case "input":Va(d);cb(d,f,!0);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=
jf);}d=a;b.updateQueue=d;null!==d&&(b.flags|=4);}else {g=9===e.nodeType?e:e.ownerDocument;a===kb.html&&(a=lb(c));a===kb.html?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[wf]=b;a[xf]=d;Bi(a,b,!1,!1);b.stateNode=a;g=wb(c,d);switch(c){case "dialog":G("cancel",a);G("close",a);
e=d;break;case "iframe":case "object":case "embed":G("load",a);e=d;break;case "video":case "audio":for(e=0;e<Xe.length;e++)G(Xe[e],a);e=d;break;case "source":G("error",a);e=d;break;case "img":case "image":case "link":G("error",a);G("load",a);e=d;break;case "details":G("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);G("invalid",a);break;case "option":e=eb(a,d);break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=objectAssign({},d,{value:void 0});G("invalid",a);break;case "textarea":hb(a,d);e=
gb(a,d);G("invalid",a);break;default:e=d;}vb(c,e);var h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?tb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&ob(a,k)):"children"===f?"string"===typeof k?("textarea"!==c||""!==k)&&pb(a,k):"number"===typeof k&&pb(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ca.hasOwnProperty(f)?null!=k&&"onScroll"===f&&G("scroll",a):null!=k&&qa(a,f,k,g));}switch(c){case "input":Va(a);cb(a,d,!1);
break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,!1):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,!0);break;default:"function"===typeof e.onClick&&(a.onclick=jf);}mf(c,d)&&(b.flags|=4);}null!==b.ref&&(b.flags|=128);}return null;case 6:if(a&&null!=b.stateNode)Ei(a,b,a.memoizedProps,d);else {if("string"!==typeof d&&null===b.stateNode)throw Error(y$1(166));
c=dh(ch.current);dh(ah.current);rh(b)?(d=b.stateNode,c=b.memoizedProps,d[wf]=b,d.nodeValue!==c&&(b.flags|=4)):(d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[wf]=b,b.stateNode=d);}return null;case 13:H(P);d=b.memoizedState;if(0!==(b.flags&64))return b.lanes=c,b;d=null!==d;c=!1;null===a?void 0!==b.memoizedProps.fallback&&rh(b):c=null!==a.memoizedState;if(d&&!c&&0!==(b.mode&2))if(null===a&&!0!==b.memoizedProps.unstable_avoidThisFallback||0!==(P.current&1))0===V&&(V=3);else {if(0===V||3===V)V=
4;null===U||0===(Dg&134217727)&&0===(Hi&134217727)||Ii(U,W);}if(d||c)b.flags|=4;return null;case 4:return fh(),Ci(b),null===a&&cf(b.stateNode.containerInfo),null;case 10:return rg(b),null;case 17:return Ff(b.type)&&Gf(),null;case 19:H(P);d=b.memoizedState;if(null===d)return null;f=0!==(b.flags&64);g=d.rendering;if(null===g)if(f)Fi(d,!1);else {if(0!==V||null!==a&&0!==(a.flags&64))for(a=b.child;null!==a;){g=ih(a);if(null!==g){b.flags|=64;Fi(d,!1);f=g.updateQueue;null!==f&&(b.updateQueue=f,b.flags|=4);
null===d.lastEffect&&(b.firstEffect=null);b.lastEffect=d.lastEffect;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=2,f.nextEffect=null,f.firstEffect=null,f.lastEffect=null,g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,
f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;I(P,P.current&1|2);return b.child}a=a.sibling;}null!==d.tail&&O()>Ji&&(b.flags|=64,f=!0,Fi(d,!1),b.lanes=33554432);}else {if(!f)if(a=ih(g),null!==a){if(b.flags|=64,f=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Fi(d,!0),null===d.tail&&"hidden"===d.tailMode&&!g.alternate&&!lh)return b=b.lastEffect=d.lastEffect,null!==b&&(b.nextEffect=null),null}else 2*O()-d.renderingStartTime>Ji&&1073741824!==c&&(b.flags|=
64,f=!0,Fi(d,!1),b.lanes=33554432);d.isBackwards?(g.sibling=b.child,b.child=g):(c=d.last,null!==c?c.sibling=g:b.child=g,d.last=g);}return null!==d.tail?(c=d.tail,d.rendering=c,d.tail=c.sibling,d.lastEffect=b.lastEffect,d.renderingStartTime=O(),c.sibling=null,b=P.current,I(P,f?b&1|2:b&1),c):null;case 23:case 24:return Ki(),null!==a&&null!==a.memoizedState!==(null!==b.memoizedState)&&"unstable-defer-without-hiding"!==d.mode&&(b.flags|=4),null}throw Error(y$1(156,b.tag));}
function Li(a){switch(a.tag){case 1:Ff(a.type)&&Gf();var b=a.flags;return b&4096?(a.flags=b&-4097|64,a):null;case 3:fh();H(N);H(M);uh();b=a.flags;if(0!==(b&64))throw Error(y$1(285));a.flags=b&-4097|64;return a;case 5:return hh(a),null;case 13:return H(P),b=a.flags,b&4096?(a.flags=b&-4097|64,a):null;case 19:return H(P),null;case 4:return fh(),null;case 10:return rg(a),null;case 23:case 24:return Ki(),null;default:return null}}
function Mi(a,b){try{var c="",d=b;do c+=Qa(d),d=d.return;while(d);var e=c;}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack;}return {value:a,source:b,stack:e}}function Ni(a,b){try{console.error(b.value);}catch(c){setTimeout(function(){throw c;});}}var Oi="function"===typeof WeakMap?WeakMap:Map;function Pi(a,b,c){c=zg(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Qi||(Qi=!0,Ri=d);Ni(a,b);};return c}
function Si(a,b,c){c=zg(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){Ni(a,b);return d(e)};}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){"function"!==typeof d&&(null===Ti?Ti=new Set([this]):Ti.add(this),Ni(a,b));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""});});return c}var Ui="function"===typeof WeakSet?WeakSet:Set;
function Vi(a){var b=a.ref;if(null!==b)if("function"===typeof b)try{b(null);}catch(c){Wi(a,c);}else b.current=null;}function Xi(a,b){switch(b.tag){case 0:case 11:case 15:case 22:return;case 1:if(b.flags&256&&null!==a){var c=a.memoizedProps,d=a.memoizedState;a=b.stateNode;b=a.getSnapshotBeforeUpdate(b.elementType===b.type?c:lg(b.type,c),d);a.__reactInternalSnapshotBeforeUpdate=b;}return;case 3:b.flags&256&&qf(b.stateNode.containerInfo);return;case 5:case 6:case 4:case 17:return}throw Error(y$1(163));}
function Yi(a,b,c){switch(c.tag){case 0:case 11:case 15:case 22:b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{if(3===(a.tag&3)){var d=a.create;a.destroy=d();}a=a.next;}while(a!==b)}b=c.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){a=b=b.next;do{var e=a;d=e.next;e=e.tag;0!==(e&4)&&0!==(e&1)&&(Zi(c,a),$i(c,a));a=d;}while(a!==b)}return;case 1:a=c.stateNode;c.flags&4&&(null===b?a.componentDidMount():(d=c.elementType===c.type?b.memoizedProps:lg(c.type,b.memoizedProps),a.componentDidUpdate(d,
b.memoizedState,a.__reactInternalSnapshotBeforeUpdate)));b=c.updateQueue;null!==b&&Eg(c,b,a);return;case 3:b=c.updateQueue;if(null!==b){a=null;if(null!==c.child)switch(c.child.tag){case 5:a=c.child.stateNode;break;case 1:a=c.child.stateNode;}Eg(c,b,a);}return;case 5:a=c.stateNode;null===b&&c.flags&4&&mf(c.type,c.memoizedProps)&&a.focus();return;case 6:return;case 4:return;case 12:return;case 13:null===c.memoizedState&&(c=c.alternate,null!==c&&(c=c.memoizedState,null!==c&&(c=c.dehydrated,null!==c&&Cc(c))));
return;case 19:case 17:case 20:case 21:case 23:case 24:return}throw Error(y$1(163));}
function aj(a,b){for(var c=a;;){if(5===c.tag){var d=c.stateNode;if(b)d=d.style,"function"===typeof d.setProperty?d.setProperty("display","none","important"):d.display="none";else {d=c.stateNode;var e=c.memoizedProps.style;e=void 0!==e&&null!==e&&e.hasOwnProperty("display")?e.display:null;d.style.display=sb("display",e);}}else if(6===c.tag)c.stateNode.nodeValue=b?"":c.memoizedProps;else if((23!==c.tag&&24!==c.tag||null===c.memoizedState||c===a)&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===
a)break;for(;null===c.sibling;){if(null===c.return||c.return===a)return;c=c.return;}c.sibling.return=c.return;c=c.sibling;}}
function bj(a,b){if(Mf&&"function"===typeof Mf.onCommitFiberUnmount)try{Mf.onCommitFiberUnmount(Lf,b);}catch(f){}switch(b.tag){case 0:case 11:case 14:case 15:case 22:a=b.updateQueue;if(null!==a&&(a=a.lastEffect,null!==a)){var c=a=a.next;do{var d=c,e=d.destroy;d=d.tag;if(void 0!==e)if(0!==(d&4))Zi(b,c);else {d=b;try{e();}catch(f){Wi(d,f);}}c=c.next;}while(c!==a)}break;case 1:Vi(b);a=b.stateNode;if("function"===typeof a.componentWillUnmount)try{a.props=b.memoizedProps,a.state=b.memoizedState,a.componentWillUnmount();}catch(f){Wi(b,
f);}break;case 5:Vi(b);break;case 4:cj(a,b);}}function dj(a){a.alternate=null;a.child=null;a.dependencies=null;a.firstEffect=null;a.lastEffect=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.return=null;a.updateQueue=null;}function ej(a){return 5===a.tag||3===a.tag||4===a.tag}
function fj(a){a:{for(var b=a.return;null!==b;){if(ej(b))break a;b=b.return;}throw Error(y$1(160));}var c=b;b=c.stateNode;switch(c.tag){case 5:var d=!1;break;case 3:b=b.containerInfo;d=!0;break;case 4:b=b.containerInfo;d=!0;break;default:throw Error(y$1(161));}c.flags&16&&(pb(b,""),c.flags&=-17);a:b:for(c=a;;){for(;null===c.sibling;){if(null===c.return||ej(c.return)){c=null;break a}c=c.return;}c.sibling.return=c.return;for(c=c.sibling;5!==c.tag&&6!==c.tag&&18!==c.tag;){if(c.flags&2)continue b;if(null===
c.child||4===c.tag)continue b;else c.child.return=c,c=c.child;}if(!(c.flags&2)){c=c.stateNode;break a}}d?gj(a,c,b):hj(a,c,b);}
function gj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=jf));else if(4!==d&&(a=a.child,null!==a))for(gj(a,b,c),a=a.sibling;null!==a;)gj(a,b,c),a=a.sibling;}
function hj(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(hj(a,b,c),a=a.sibling;null!==a;)hj(a,b,c),a=a.sibling;}
function cj(a,b){for(var c=b,d=!1,e,f;;){if(!d){d=c.return;a:for(;;){if(null===d)throw Error(y$1(160));e=d.stateNode;switch(d.tag){case 5:f=!1;break a;case 3:e=e.containerInfo;f=!0;break a;case 4:e=e.containerInfo;f=!0;break a}d=d.return;}d=!0;}if(5===c.tag||6===c.tag){a:for(var g=a,h=c,k=h;;)if(bj(g,k),null!==k.child&&4!==k.tag)k.child.return=k,k=k.child;else {if(k===h)break a;for(;null===k.sibling;){if(null===k.return||k.return===h)break a;k=k.return;}k.sibling.return=k.return;k=k.sibling;}f?(g=e,h=c.stateNode,
8===g.nodeType?g.parentNode.removeChild(h):g.removeChild(h)):e.removeChild(c.stateNode);}else if(4===c.tag){if(null!==c.child){e=c.stateNode.containerInfo;f=!0;c.child.return=c;c=c.child;continue}}else if(bj(a,c),null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;4===c.tag&&(d=!1);}c.sibling.return=c.return;c=c.sibling;}}
function ij(a,b){switch(b.tag){case 0:case 11:case 14:case 15:case 22:var c=b.updateQueue;c=null!==c?c.lastEffect:null;if(null!==c){var d=c=c.next;do 3===(d.tag&3)&&(a=d.destroy,d.destroy=void 0,void 0!==a&&a()),d=d.next;while(d!==c)}return;case 1:return;case 5:c=b.stateNode;if(null!=c){d=b.memoizedProps;var e=null!==a?a.memoizedProps:d;a=b.type;var f=b.updateQueue;b.updateQueue=null;if(null!==f){c[xf]=d;"input"===a&&"radio"===d.type&&null!=d.name&&$a(c,d);wb(a,e);b=wb(a,d);for(e=0;e<f.length;e+=
2){var g=f[e],h=f[e+1];"style"===g?tb(c,h):"dangerouslySetInnerHTML"===g?ob(c,h):"children"===g?pb(c,h):qa(c,g,h,b);}switch(a){case "input":ab(c,d);break;case "textarea":ib(c,d);break;case "select":a=c._wrapperState.wasMultiple,c._wrapperState.wasMultiple=!!d.multiple,f=d.value,null!=f?fb(c,!!d.multiple,f,!1):a!==!!d.multiple&&(null!=d.defaultValue?fb(c,!!d.multiple,d.defaultValue,!0):fb(c,!!d.multiple,d.multiple?[]:"",!1));}}}return;case 6:if(null===b.stateNode)throw Error(y$1(162));b.stateNode.nodeValue=
b.memoizedProps;return;case 3:c=b.stateNode;c.hydrate&&(c.hydrate=!1,Cc(c.containerInfo));return;case 12:return;case 13:null!==b.memoizedState&&(jj=O(),aj(b.child,!0));kj(b);return;case 19:kj(b);return;case 17:return;case 23:case 24:aj(b,null!==b.memoizedState);return}throw Error(y$1(163));}function kj(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Ui);b.forEach(function(b){var d=lj.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d));});}}
function mj(a,b){return null!==a&&(a=a.memoizedState,null===a||null!==a.dehydrated)?(b=b.memoizedState,null!==b&&null===b.dehydrated):!1}var nj=Math.ceil,oj=ra.ReactCurrentDispatcher,pj=ra.ReactCurrentOwner,X=0,U=null,Y=null,W=0,qj=0,rj=Bf(0),V=0,sj=null,tj=0,Dg=0,Hi=0,uj=0,vj=null,jj=0,Ji=Infinity;function wj(){Ji=O()+500;}var Z=null,Qi=!1,Ri=null,Ti=null,xj=!1,yj=null,zj=90,Aj=[],Bj=[],Cj=null,Dj=0,Ej=null,Fj=-1,Gj=0,Hj=0,Ij=null,Jj=!1;function Hg(){return 0!==(X&48)?O():-1!==Fj?Fj:Fj=O()}
function Ig(a){a=a.mode;if(0===(a&2))return 1;if(0===(a&4))return 99===eg()?1:2;0===Gj&&(Gj=tj);if(0!==kg.transition){0!==Hj&&(Hj=null!==vj?vj.pendingLanes:0);a=Gj;var b=4186112&~Hj;b&=-b;0===b&&(a=4186112&~a,b=a&-a,0===b&&(b=8192));return b}a=eg();0!==(X&4)&&98===a?a=Xc(12,Gj):(a=Sc(a),a=Xc(a,Gj));return a}
function Jg(a,b,c){if(50<Dj)throw Dj=0,Ej=null,Error(y$1(185));a=Kj(a,b);if(null===a)return null;$c(a,b,c);a===U&&(Hi|=b,4===V&&Ii(a,W));var d=eg();1===b?0!==(X&8)&&0===(X&48)?Lj(a):(Mj(a,c),0===X&&(wj(),ig())):(0===(X&4)||98!==d&&99!==d||(null===Cj?Cj=new Set([a]):Cj.add(a)),Mj(a,c));vj=a;}function Kj(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}
function Mj(a,b){for(var c=a.callbackNode,d=a.suspendedLanes,e=a.pingedLanes,f=a.expirationTimes,g=a.pendingLanes;0<g;){var h=31-Vc(g),k=1<<h,l=f[h];if(-1===l){if(0===(k&d)||0!==(k&e)){l=b;Rc(k);var n=F;f[h]=10<=n?l+250:6<=n?l+5E3:-1;}}else l<=b&&(a.expiredLanes|=k);g&=~k;}d=Uc(a,a===U?W:0);b=F;if(0===d)null!==c&&(c!==Zf&&Pf(c),a.callbackNode=null,a.callbackPriority=0);else {if(null!==c){if(a.callbackPriority===b)return;c!==Zf&&Pf(c);}15===b?(c=Lj.bind(null,a),null===ag?(ag=[c],bg=Of(Uf,jg)):ag.push(c),
c=Zf):14===b?c=hg(99,Lj.bind(null,a)):(c=Tc(b),c=hg(c,Nj.bind(null,a)));a.callbackPriority=b;a.callbackNode=c;}}
function Nj(a){Fj=-1;Hj=Gj=0;if(0!==(X&48))throw Error(y$1(327));var b=a.callbackNode;if(Oj()&&a.callbackNode!==b)return null;var c=Uc(a,a===U?W:0);if(0===c)return null;var d=c;var e=X;X|=16;var f=Pj();if(U!==a||W!==d)wj(),Qj(a,d);do try{Rj();break}catch(h){Sj(a,h);}while(1);qg();oj.current=f;X=e;null!==Y?d=0:(U=null,W=0,d=V);if(0!==(tj&Hi))Qj(a,0);else if(0!==d){2===d&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),c=Wc(a),0!==c&&(d=Tj(a,c)));if(1===d)throw b=sj,Qj(a,0),Ii(a,c),Mj(a,O()),b;a.finishedWork=
a.current.alternate;a.finishedLanes=c;switch(d){case 0:case 1:throw Error(y$1(345));case 2:Uj(a);break;case 3:Ii(a,c);if((c&62914560)===c&&(d=jj+500-O(),10<d)){if(0!==Uc(a,0))break;e=a.suspendedLanes;if((e&c)!==c){Hg();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=of(Uj.bind(null,a),d);break}Uj(a);break;case 4:Ii(a,c);if((c&4186112)===c)break;d=a.eventTimes;for(e=-1;0<c;){var g=31-Vc(c);f=1<<g;g=d[g];g>e&&(e=g);c&=~f;}c=e;c=O()-c;c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3E3>c?3E3:4320>
c?4320:1960*nj(c/1960))-c;if(10<c){a.timeoutHandle=of(Uj.bind(null,a),c);break}Uj(a);break;case 5:Uj(a);break;default:throw Error(y$1(329));}}Mj(a,O());return a.callbackNode===b?Nj.bind(null,a):null}function Ii(a,b){b&=~uj;b&=~Hi;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-Vc(b),d=1<<c;a[c]=-1;b&=~d;}}
function Lj(a){if(0!==(X&48))throw Error(y$1(327));Oj();if(a===U&&0!==(a.expiredLanes&W)){var b=W;var c=Tj(a,b);0!==(tj&Hi)&&(b=Uc(a,b),c=Tj(a,b));}else b=Uc(a,0),c=Tj(a,b);0!==a.tag&&2===c&&(X|=64,a.hydrate&&(a.hydrate=!1,qf(a.containerInfo)),b=Wc(a),0!==b&&(c=Tj(a,b)));if(1===c)throw c=sj,Qj(a,0),Ii(a,b),Mj(a,O()),c;a.finishedWork=a.current.alternate;a.finishedLanes=b;Uj(a);Mj(a,O());return null}
function Vj(){if(null!==Cj){var a=Cj;Cj=null;a.forEach(function(a){a.expiredLanes|=24&a.pendingLanes;Mj(a,O());});}ig();}function Wj(a,b){var c=X;X|=1;try{return a(b)}finally{X=c,0===X&&(wj(),ig());}}function Xj(a,b){var c=X;X&=-2;X|=8;try{return a(b)}finally{X=c,0===X&&(wj(),ig());}}function ni(a,b){I(rj,qj);qj|=b;tj|=b;}function Ki(){qj=rj.current;H(rj);}
function Qj(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,pf(c));if(null!==Y)for(c=Y.return;null!==c;){var d=c;switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&Gf();break;case 3:fh();H(N);H(M);uh();break;case 5:hh(d);break;case 4:fh();break;case 13:H(P);break;case 19:H(P);break;case 10:rg(d);break;case 23:case 24:Ki();}c=c.return;}U=a;Y=Tg(a.current,null);W=qj=tj=b;V=0;sj=null;uj=Hi=Dg=0;}
function Sj(a,b){do{var c=Y;try{qg();vh.current=Gh;if(yh){for(var d=R.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next;}yh=!1;}xh=0;T=S=R=null;zh=!1;pj.current=null;if(null===c||null===c.return){V=1;sj=b;Y=null;break}a:{var f=a,g=c.return,h=c,k=b;b=W;h.flags|=2048;h.firstEffect=h.lastEffect=null;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k;if(0===(h.mode&2)){var n=h.alternate;n?(h.updateQueue=n.updateQueue,h.memoizedState=n.memoizedState,h.lanes=n.lanes):
(h.updateQueue=null,h.memoizedState=null);}var A=0!==(P.current&1),p=g;do{var C;if(C=13===p.tag){var x=p.memoizedState;if(null!==x)C=null!==x.dehydrated?!0:!1;else {var w=p.memoizedProps;C=void 0===w.fallback?!1:!0!==w.unstable_avoidThisFallback?!0:A?!1:!0;}}if(C){var z=p.updateQueue;if(null===z){var u=new Set;u.add(l);p.updateQueue=u;}else z.add(l);if(0===(p.mode&2)){p.flags|=64;h.flags|=16384;h.flags&=-2981;if(1===h.tag)if(null===h.alternate)h.tag=17;else {var t=zg(-1,1);t.tag=2;Ag(h,t);}h.lanes|=1;break a}k=
void 0;h=b;var q=f.pingCache;null===q?(q=f.pingCache=new Oi,k=new Set,q.set(l,k)):(k=q.get(l),void 0===k&&(k=new Set,q.set(l,k)));if(!k.has(h)){k.add(h);var v=Yj.bind(null,f,l,h);l.then(v,v);}p.flags|=4096;p.lanes=b;break a}p=p.return;}while(null!==p);k=Error((Ra(h.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.");}5!==V&&(V=2);k=Mi(k,h);p=
g;do{switch(p.tag){case 3:f=k;p.flags|=4096;b&=-b;p.lanes|=b;var J=Pi(p,f,b);Bg(p,J);break a;case 1:f=k;var K=p.type,Q=p.stateNode;if(0===(p.flags&64)&&("function"===typeof K.getDerivedStateFromError||null!==Q&&"function"===typeof Q.componentDidCatch&&(null===Ti||!Ti.has(Q)))){p.flags|=4096;b&=-b;p.lanes|=b;var L=Si(p,f,b);Bg(p,L);break a}}p=p.return;}while(null!==p)}Zj(c);}catch(va){b=va;Y===c&&null!==c&&(Y=c=c.return);continue}break}while(1)}
function Pj(){var a=oj.current;oj.current=Gh;return null===a?Gh:a}function Tj(a,b){var c=X;X|=16;var d=Pj();U===a&&W===b||Qj(a,b);do try{ak();break}catch(e){Sj(a,e);}while(1);qg();X=c;oj.current=d;if(null!==Y)throw Error(y$1(261));U=null;W=0;return V}function ak(){for(;null!==Y;)bk(Y);}function Rj(){for(;null!==Y&&!Qf();)bk(Y);}function bk(a){var b=ck(a.alternate,a,qj);a.memoizedProps=a.pendingProps;null===b?Zj(a):Y=b;pj.current=null;}
function Zj(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&2048)){c=Gi(c,b,qj);if(null!==c){Y=c;return}c=b;if(24!==c.tag&&23!==c.tag||null===c.memoizedState||0!==(qj&1073741824)||0===(c.mode&4)){for(var d=0,e=c.child;null!==e;)d|=e.lanes|e.childLanes,e=e.sibling;c.childLanes=d;}null!==a&&0===(a.flags&2048)&&(null===a.firstEffect&&(a.firstEffect=b.firstEffect),null!==b.lastEffect&&(null!==a.lastEffect&&(a.lastEffect.nextEffect=b.firstEffect),a.lastEffect=b.lastEffect),1<b.flags&&(null!==
a.lastEffect?a.lastEffect.nextEffect=b:a.firstEffect=b,a.lastEffect=b));}else {c=Li(b);if(null!==c){c.flags&=2047;Y=c;return}null!==a&&(a.firstEffect=a.lastEffect=null,a.flags|=2048);}b=b.sibling;if(null!==b){Y=b;return}Y=b=a;}while(null!==b);0===V&&(V=5);}function Uj(a){var b=eg();gg(99,dk.bind(null,a,b));return null}
function dk(a,b){do Oj();while(null!==yj);if(0!==(X&48))throw Error(y$1(327));var c=a.finishedWork;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(y$1(177));a.callbackNode=null;var d=c.lanes|c.childLanes,e=d,f=a.pendingLanes&~e;a.pendingLanes=e;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=e;a.mutableReadLanes&=e;a.entangledLanes&=e;e=a.entanglements;for(var g=a.eventTimes,h=a.expirationTimes;0<f;){var k=31-Vc(f),l=1<<k;e[k]=0;g[k]=-1;h[k]=-1;f&=~l;}null!==
Cj&&0===(d&24)&&Cj.has(a)&&Cj.delete(a);a===U&&(Y=U=null,W=0);1<c.flags?null!==c.lastEffect?(c.lastEffect.nextEffect=c,d=c.firstEffect):d=c:d=c.firstEffect;if(null!==d){e=X;X|=32;pj.current=null;kf=fd;g=Ne();if(Oe(g)){if("selectionStart"in g)h={start:g.selectionStart,end:g.selectionEnd};else a:if(h=(h=g.ownerDocument)&&h.defaultView||window,(l=h.getSelection&&h.getSelection())&&0!==l.rangeCount){h=l.anchorNode;f=l.anchorOffset;k=l.focusNode;l=l.focusOffset;try{h.nodeType,k.nodeType;}catch(va){h=null;
break a}var n=0,A=-1,p=-1,C=0,x=0,w=g,z=null;b:for(;;){for(var u;;){w!==h||0!==f&&3!==w.nodeType||(A=n+f);w!==k||0!==l&&3!==w.nodeType||(p=n+l);3===w.nodeType&&(n+=w.nodeValue.length);if(null===(u=w.firstChild))break;z=w;w=u;}for(;;){if(w===g)break b;z===h&&++C===f&&(A=n);z===k&&++x===l&&(p=n);if(null!==(u=w.nextSibling))break;w=z;z=w.parentNode;}w=u;}h=-1===A||-1===p?null:{start:A,end:p};}else h=null;h=h||{start:0,end:0};}else h=null;lf={focusedElem:g,selectionRange:h};fd=!1;Ij=null;Jj=!1;Z=d;do try{ek();}catch(va){if(null===
Z)throw Error(y$1(330));Wi(Z,va);Z=Z.nextEffect;}while(null!==Z);Ij=null;Z=d;do try{for(g=a;null!==Z;){var t=Z.flags;t&16&&pb(Z.stateNode,"");if(t&128){var q=Z.alternate;if(null!==q){var v=q.ref;null!==v&&("function"===typeof v?v(null):v.current=null);}}switch(t&1038){case 2:fj(Z);Z.flags&=-3;break;case 6:fj(Z);Z.flags&=-3;ij(Z.alternate,Z);break;case 1024:Z.flags&=-1025;break;case 1028:Z.flags&=-1025;ij(Z.alternate,Z);break;case 4:ij(Z.alternate,Z);break;case 8:h=Z;cj(g,h);var J=h.alternate;dj(h);null!==
J&&dj(J);}Z=Z.nextEffect;}}catch(va){if(null===Z)throw Error(y$1(330));Wi(Z,va);Z=Z.nextEffect;}while(null!==Z);v=lf;q=Ne();t=v.focusedElem;g=v.selectionRange;if(q!==t&&t&&t.ownerDocument&&Me(t.ownerDocument.documentElement,t)){null!==g&&Oe(t)&&(q=g.start,v=g.end,void 0===v&&(v=q),"selectionStart"in t?(t.selectionStart=q,t.selectionEnd=Math.min(v,t.value.length)):(v=(q=t.ownerDocument||document)&&q.defaultView||window,v.getSelection&&(v=v.getSelection(),h=t.textContent.length,J=Math.min(g.start,h),g=void 0===
g.end?J:Math.min(g.end,h),!v.extend&&J>g&&(h=g,g=J,J=h),h=Le(t,J),f=Le(t,g),h&&f&&(1!==v.rangeCount||v.anchorNode!==h.node||v.anchorOffset!==h.offset||v.focusNode!==f.node||v.focusOffset!==f.offset)&&(q=q.createRange(),q.setStart(h.node,h.offset),v.removeAllRanges(),J>g?(v.addRange(q),v.extend(f.node,f.offset)):(q.setEnd(f.node,f.offset),v.addRange(q))))));q=[];for(v=t;v=v.parentNode;)1===v.nodeType&&q.push({element:v,left:v.scrollLeft,top:v.scrollTop});"function"===typeof t.focus&&t.focus();for(t=
0;t<q.length;t++)v=q[t],v.element.scrollLeft=v.left,v.element.scrollTop=v.top;}fd=!!kf;lf=kf=null;a.current=c;Z=d;do try{for(t=a;null!==Z;){var K=Z.flags;K&36&&Yi(t,Z.alternate,Z);if(K&128){q=void 0;var Q=Z.ref;if(null!==Q){var L=Z.stateNode;switch(Z.tag){case 5:q=L;break;default:q=L;}"function"===typeof Q?Q(q):Q.current=q;}}Z=Z.nextEffect;}}catch(va){if(null===Z)throw Error(y$1(330));Wi(Z,va);Z=Z.nextEffect;}while(null!==Z);Z=null;$f();X=e;}else a.current=c;if(xj)xj=!1,yj=a,zj=b;else for(Z=d;null!==Z;)b=
Z.nextEffect,Z.nextEffect=null,Z.flags&8&&(K=Z,K.sibling=null,K.stateNode=null),Z=b;d=a.pendingLanes;0===d&&(Ti=null);1===d?a===Ej?Dj++:(Dj=0,Ej=a):Dj=0;c=c.stateNode;if(Mf&&"function"===typeof Mf.onCommitFiberRoot)try{Mf.onCommitFiberRoot(Lf,c,void 0,64===(c.current.flags&64));}catch(va){}Mj(a,O());if(Qi)throw Qi=!1,a=Ri,Ri=null,a;if(0!==(X&8))return null;ig();return null}
function ek(){for(;null!==Z;){var a=Z.alternate;Jj||null===Ij||(0!==(Z.flags&8)?dc(Z,Ij)&&(Jj=!0):13===Z.tag&&mj(a,Z)&&dc(Z,Ij)&&(Jj=!0));var b=Z.flags;0!==(b&256)&&Xi(a,Z);0===(b&512)||xj||(xj=!0,hg(97,function(){Oj();return null}));Z=Z.nextEffect;}}function Oj(){if(90!==zj){var a=97<zj?97:zj;zj=90;return gg(a,fk)}return !1}function $i(a,b){Aj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}));}function Zi(a,b){Bj.push(b,a);xj||(xj=!0,hg(97,function(){Oj();return null}));}
function fk(){if(null===yj)return !1;var a=yj;yj=null;if(0!==(X&48))throw Error(y$1(331));var b=X;X|=32;var c=Bj;Bj=[];for(var d=0;d<c.length;d+=2){var e=c[d],f=c[d+1],g=e.destroy;e.destroy=void 0;if("function"===typeof g)try{g();}catch(k){if(null===f)throw Error(y$1(330));Wi(f,k);}}c=Aj;Aj=[];for(d=0;d<c.length;d+=2){e=c[d];f=c[d+1];try{var h=e.create;e.destroy=h();}catch(k){if(null===f)throw Error(y$1(330));Wi(f,k);}}for(h=a.current.firstEffect;null!==h;)a=h.nextEffect,h.nextEffect=null,h.flags&8&&(h.sibling=
null,h.stateNode=null),h=a;X=b;ig();return !0}function gk(a,b,c){b=Mi(c,b);b=Pi(a,b,1);Ag(a,b);b=Hg();a=Kj(a,1);null!==a&&($c(a,1,b),Mj(a,b));}
function Wi(a,b){if(3===a.tag)gk(a,a,b);else for(var c=a.return;null!==c;){if(3===c.tag){gk(c,a,b);break}else if(1===c.tag){var d=c.stateNode;if("function"===typeof c.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d))){a=Mi(b,a);var e=Si(c,a,1);Ag(c,e);e=Hg();c=Kj(c,1);if(null!==c)$c(c,1,e),Mj(c,e);else if("function"===typeof d.componentDidCatch&&(null===Ti||!Ti.has(d)))try{d.componentDidCatch(b,a);}catch(f){}break}}c=c.return;}}
function Yj(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=Hg();a.pingedLanes|=a.suspendedLanes&c;U===a&&(W&c)===c&&(4===V||3===V&&(W&62914560)===W&&500>O()-jj?Qj(a,0):uj|=c);Mj(a,b);}function lj(a,b){var c=a.stateNode;null!==c&&c.delete(b);b=0;0===b&&(b=a.mode,0===(b&2)?b=1:0===(b&4)?b=99===eg()?1:2:(0===Gj&&(Gj=tj),b=Yc(62914560&~Gj),0===b&&(b=4194304)));c=Hg();a=Kj(a,b);null!==a&&($c(a,b,c),Mj(a,c));}var ck;
ck=function(a,b,c){var d=b.lanes;if(null!==a)if(a.memoizedProps!==b.pendingProps||N.current)ug=!0;else if(0!==(c&d))ug=0!==(a.flags&16384)?!0:!1;else {ug=!1;switch(b.tag){case 3:ri(b);sh();break;case 5:gh(b);break;case 1:Ff(b.type)&&Jf(b);break;case 4:eh(b,b.stateNode.containerInfo);break;case 10:d=b.memoizedProps.value;var e=b.type._context;I(mg,e._currentValue);e._currentValue=d;break;case 13:if(null!==b.memoizedState){if(0!==(c&b.child.childLanes))return ti(a,b,c);I(P,P.current&1);b=hi(a,b,c);return null!==
b?b.sibling:null}I(P,P.current&1);break;case 19:d=0!==(c&b.childLanes);if(0!==(a.flags&64)){if(d)return Ai(a,b,c);b.flags|=64;}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);I(P,P.current);if(d)break;else return null;case 23:case 24:return b.lanes=0,mi(a,b,c)}return hi(a,b,c)}else ug=!1;b.lanes=0;switch(b.tag){case 2:d=b.type;null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);a=b.pendingProps;e=Ef(b,M.current);tg(b,c);e=Ch(null,b,d,a,e,c);b.flags|=1;if("object"===
typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof){b.tag=1;b.memoizedState=null;b.updateQueue=null;if(Ff(d)){var f=!0;Jf(b);}else f=!1;b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null;xg(b);var g=d.getDerivedStateFromProps;"function"===typeof g&&Gg(b,d,g,a);e.updater=Kg;b.stateNode=e;e._reactInternals=b;Og(b,d,a,c);b=qi(null,b,d,!0,f,c);}else b.tag=0,fi(null,b,e,c),b=b.child;return b;case 16:e=b.elementType;a:{null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);
a=b.pendingProps;f=e._init;e=f(e._payload);b.type=e;f=b.tag=hk(e);a=lg(e,a);switch(f){case 0:b=li(null,b,e,a,c);break a;case 1:b=pi(null,b,e,a,c);break a;case 11:b=gi(null,b,e,a,c);break a;case 14:b=ii(null,b,e,lg(e.type,a),d,c);break a}throw Error(y$1(306,e,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),li(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),pi(a,b,d,e,c);case 3:ri(b);d=b.updateQueue;if(null===a||null===d)throw Error(y$1(282));
d=b.pendingProps;e=b.memoizedState;e=null!==e?e.element:null;yg(a,b);Cg(b,d,null,c);d=b.memoizedState.element;if(d===e)sh(),b=hi(a,b,c);else {e=b.stateNode;if(f=e.hydrate)kh=rf(b.stateNode.containerInfo.firstChild),jh=b,f=lh=!0;if(f){a=e.mutableSourceEagerHydrationData;if(null!=a)for(e=0;e<a.length;e+=2)f=a[e],f._workInProgressVersionPrimary=a[e+1],th.push(f);c=Zg(b,null,d,c);for(b.child=c;c;)c.flags=c.flags&-3|1024,c=c.sibling;}else fi(a,b,d,c),sh();b=b.child;}return b;case 5:return gh(b),null===a&&
ph(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,nf(d,e)?g=null:null!==f&&nf(d,f)&&(b.flags|=16),oi(a,b),fi(a,b,g,c),b.child;case 6:return null===a&&ph(b),null;case 13:return ti(a,b,c);case 4:return eh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Yg(b,null,d,c):fi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),gi(a,b,d,e,c);case 7:return fi(a,b,b.pendingProps,c),b.child;case 8:return fi(a,b,b.pendingProps.children,
c),b.child;case 12:return fi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;g=b.memoizedProps;f=e.value;var h=b.type._context;I(mg,h._currentValue);h._currentValue=f;if(null!==g)if(h=g.value,f=He(h,f)?0:("function"===typeof d._calculateChangedBits?d._calculateChangedBits(h,f):1073741823)|0,0===f){if(g.children===e.children&&!N.current){b=hi(a,b,c);break a}}else for(h=b.child,null!==h&&(h.return=b);null!==h;){var k=h.dependencies;if(null!==k){g=h.child;for(var l=
k.firstContext;null!==l;){if(l.context===d&&0!==(l.observedBits&f)){1===h.tag&&(l=zg(-1,c&-c),l.tag=2,Ag(h,l));h.lanes|=c;l=h.alternate;null!==l&&(l.lanes|=c);sg(h.return,c);k.lanes|=c;break}l=l.next;}}else g=10===h.tag?h.type===b.type?null:h.child:h.child;if(null!==g)g.return=h;else for(g=h;null!==g;){if(g===b){g=null;break}h=g.sibling;if(null!==h){h.return=g.return;g=h;break}g=g.return;}h=g;}fi(a,b,e.children,c);b=b.child;}return b;case 9:return e=b.type,f=b.pendingProps,d=f.children,tg(b,c),e=vg(e,
f.unstable_observedBits),d=d(e),b.flags|=1,fi(a,b,d,c),b.child;case 14:return e=b.type,f=lg(e,b.pendingProps),f=lg(e.type,f),ii(a,b,e,f,d,c);case 15:return ki(a,b,b.type,b.pendingProps,d,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:lg(d,e),null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2),b.tag=1,Ff(d)?(a=!0,Jf(b)):a=!1,tg(b,c),Mg(b,d,e),Og(b,d,e,c),qi(null,b,d,!0,a,c);case 19:return Ai(a,b,c);case 23:return mi(a,b,c);case 24:return mi(a,b,c)}throw Error(y$1(156,b.tag));
};function ik(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.flags=0;this.lastEffect=this.firstEffect=this.nextEffect=null;this.childLanes=this.lanes=0;this.alternate=null;}function nh(a,b,c,d){return new ik(a,b,c,d)}function ji(a){a=a.prototype;return !(!a||!a.isReactComponent)}
function hk(a){if("function"===typeof a)return ji(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Aa)return 11;if(a===Da)return 14}return 2}
function Tg(a,b){var c=a.alternate;null===c?(c=nh(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.nextEffect=null,c.firstEffect=null,c.lastEffect=null);c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function Vg(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)ji(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ua:return Xg(c.children,e,f,b);case Ha:g=8;e|=16;break;case wa:g=8;e|=1;break;case xa:return a=nh(12,c,b,e|8),a.elementType=xa,a.type=xa,a.lanes=f,a;case Ba:return a=nh(13,c,b,e),a.type=Ba,a.elementType=Ba,a.lanes=f,a;case Ca:return a=nh(19,c,b,e),a.elementType=Ca,a.lanes=f,a;case Ia:return vi(c,e,f,b);case Ja:return a=nh(24,c,b,e),a.elementType=Ja,a.lanes=f,a;default:if("object"===
typeof a&&null!==a)switch(a.$$typeof){case ya:g=10;break a;case za:g=9;break a;case Aa:g=11;break a;case Da:g=14;break a;case Ea:g=16;d=null;break a;case Fa:g=22;break a}throw Error(y$1(130,null==a?a:typeof a,""));}b=nh(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Xg(a,b,c,d){a=nh(7,a,d,b);a.lanes=c;return a}function vi(a,b,c,d){a=nh(23,a,d,b);a.elementType=Ia;a.lanes=c;return a}function Ug(a,b,c){a=nh(6,a,null,b);a.lanes=c;return a}
function Wg(a,b,c){b=nh(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function jk(a,b,c){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.pendingContext=this.context=null;this.hydrate=c;this.callbackNode=null;this.callbackPriority=0;this.eventTimes=Zc(0);this.expirationTimes=Zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=Zc(0);this.mutableSourceEagerHydrationData=null;}
function kk(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return {$$typeof:ta,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function lk(a,b,c,d){var e=b.current,f=Hg(),g=Ig(e);a:if(c){c=c._reactInternals;b:{if(Zb(c)!==c||1!==c.tag)throw Error(y$1(170));var h=c;do{switch(h.tag){case 3:h=h.stateNode.context;break b;case 1:if(Ff(h.type)){h=h.stateNode.__reactInternalMemoizedMergedChildContext;break b}}h=h.return;}while(null!==h);throw Error(y$1(171));}if(1===c.tag){var k=c.type;if(Ff(k)){c=If(c,k,h);break a}}c=h;}else c=Cf;null===b.context?b.context=c:b.pendingContext=c;b=zg(f,g);b.payload={element:a};d=void 0===d?null:d;null!==
d&&(b.callback=d);Ag(e,b);Jg(e,g,f);return g}function mk(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function nk(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b;}}function ok(a,b){nk(a,b);(a=a.alternate)&&nk(a,b);}function pk(){return null}
function qk(a,b,c){var d=null!=c&&null!=c.hydrationOptions&&c.hydrationOptions.mutableSources||null;c=new jk(a,b,null!=c&&!0===c.hydrate);b=nh(3,null,null,2===b?7:1===b?3:0);c.current=b;b.stateNode=c;xg(b);a[ff]=c.current;cf(8===a.nodeType?a.parentNode:a);if(d)for(a=0;a<d.length;a++){b=d[a];var e=b._getVersion;e=e(b._source);null==c.mutableSourceEagerHydrationData?c.mutableSourceEagerHydrationData=[b,e]:c.mutableSourceEagerHydrationData.push(b,e);}this._internalRoot=c;}
qk.prototype.render=function(a){lk(a,this._internalRoot,null,null);};qk.prototype.unmount=function(){var a=this._internalRoot,b=a.containerInfo;lk(null,a,null,function(){b[ff]=null;});};function rk(a){return !(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}
function sk(a,b){b||(b=a?9===a.nodeType?a.documentElement:a.firstChild:null,b=!(!b||1!==b.nodeType||!b.hasAttribute("data-reactroot")));if(!b)for(var c;c=a.lastChild;)a.removeChild(c);return new qk(a,0,b?{hydrate:!0}:void 0)}
function tk(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f._internalRoot;if("function"===typeof e){var h=e;e=function(){var a=mk(g);h.call(a);};}lk(b,g,a,e);}else {f=c._reactRootContainer=sk(c,d);g=f._internalRoot;if("function"===typeof e){var k=e;e=function(){var a=mk(g);k.call(a);};}Xj(function(){lk(b,g,a,e);});}return mk(g)}ec=function(a){if(13===a.tag){var b=Hg();Jg(a,4,b);ok(a,4);}};fc=function(a){if(13===a.tag){var b=Hg();Jg(a,67108864,b);ok(a,67108864);}};
gc=function(a){if(13===a.tag){var b=Hg(),c=Ig(a);Jg(a,c,b);ok(a,c);}};hc=function(a,b){return b()};
yb=function(a,b,c){switch(b){case "input":ab(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(y$1(90));Wa(d);ab(d,e);}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,!1);}};Gb=Wj;
Hb=function(a,b,c,d,e){var f=X;X|=4;try{return gg(98,a.bind(null,b,c,d,e))}finally{X=f,0===X&&(wj(),ig());}};Ib=function(){0===(X&49)&&(Vj(),Oj());};Jb=function(a,b){var c=X;X|=2;try{return a(b)}finally{X=c,0===X&&(wj(),ig());}};function uk(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!rk(b))throw Error(y$1(200));return kk(a,b,null,c)}var vk={Events:[Cb,ue,Db,Eb,Fb,Oj,{current:!1}]},wk={findFiberByHostInstance:wc,bundleType:0,version:"17.0.1",rendererPackageName:"react-dom"};
var xk={bundleType:wk.bundleType,version:wk.version,rendererPackageName:wk.rendererPackageName,rendererConfig:wk.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ra.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=cc(a);return null===a?null:a.stateNode},findFiberByHostInstance:wk.findFiberByHostInstance||
pk,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var yk=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!yk.isDisabled&&yk.supportsFiber)try{Lf=yk.inject(xk),Mf=yk;}catch(a){}}var __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=vk;var createPortal=uk;
var findDOMNode=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(y$1(188));throw Error(y$1(268,Object.keys(a)));}a=cc(b);a=null===a?null:a.stateNode;return a};var flushSync=function(a,b){var c=X;if(0!==(c&48))return a(b);X|=1;try{if(a)return gg(99,a.bind(null,b))}finally{X=c,ig();}};var hydrate=function(a,b,c){if(!rk(b))throw Error(y$1(200));return tk(null,a,b,!0,c)};
var render=function(a,b,c){if(!rk(b))throw Error(y$1(200));return tk(null,a,b,!1,c)};var unmountComponentAtNode=function(a){if(!rk(a))throw Error(y$1(40));return a._reactRootContainer?(Xj(function(){tk(null,null,a,!1,function(){a._reactRootContainer=null;a[ff]=null;});}),!0):!1};var unstable_batchedUpdates=Wj;var unstable_createPortal=function(a,b){return uk(a,b,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)};
var unstable_renderSubtreeIntoContainer=function(a,b,c,d){if(!rk(c))throw Error(y$1(200));if(null==a||void 0===a._reactInternals)throw Error(y$1(38));return tk(a,b,c,!1,d)};var version$1="17.0.1";

var reactDom_production_min = {
	__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
	createPortal: createPortal,
	findDOMNode: findDOMNode,
	flushSync: flushSync,
	hydrate: hydrate,
	render: render,
	unmountComponentAtNode: unmountComponentAtNode,
	unstable_batchedUpdates: unstable_batchedUpdates,
	unstable_createPortal: unstable_createPortal,
	unstable_renderSubtreeIntoContainer: unstable_renderSubtreeIntoContainer,
	version: version$1
};

/** @license React v0.20.1
 * scheduler-tracing.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var b$1=0;var __interactionsRef=null;var __subscriberRef=null;var unstable_clear=function(a){return a()};var unstable_getCurrent=function(){return null};var unstable_getThreadID=function(){return ++b$1};var unstable_subscribe=function(){};var unstable_trace=function(a,d,c){return c()};var unstable_unsubscribe=function(){};var unstable_wrap=function(a){return a};

var schedulerTracing_production_min = {
	__interactionsRef: __interactionsRef,
	__subscriberRef: __subscriberRef,
	unstable_clear: unstable_clear,
	unstable_getCurrent: unstable_getCurrent,
	unstable_getThreadID: unstable_getThreadID,
	unstable_subscribe: unstable_subscribe,
	unstable_trace: unstable_trace,
	unstable_unsubscribe: unstable_unsubscribe,
	unstable_wrap: unstable_wrap
};

var schedulerTracing_development = createCommonjsModule(function (module, exports) {
});

var tracing = createCommonjsModule(function (module) {

{
  module.exports = schedulerTracing_production_min;
}
});

var reactDom_development = createCommonjsModule(function (module, exports) {
});

var reactDom = createCommonjsModule(function (module) {

function checkDCE() {
  /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
  if (
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === 'undefined' ||
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== 'function'
  ) {
    return;
  }
  try {
    // Verify that the code above has been dead code eliminated (DCE'd).
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    // DevTools shouldn't crash React, no matter what.
    // We should still report in case we break this code.
    console.error(err);
  }
}

{
  // DCE check should happen before ReactDOM bundle executes so that
  // DevTools can report bad minification during injection.
  checkDCE();
  module.exports = reactDom_production_min;
}
});

var _fails = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};

// Thank's IE8 for his funny defineProperty
var _descriptors = !_fails(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});

var _isObject = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};

var _anObject = function (it) {
  if (!_isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};

var _global = createCommonjsModule(function (module) {
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef
});

var document$1 = _global.document;
// typeof document.createElement is 'object' in old IE
var is = _isObject(document$1) && _isObject(document$1.createElement);
var _domCreate = function (it) {
  return is ? document$1.createElement(it) : {};
};

var _ie8DomDefine = !_descriptors && !_fails(function () {
  return Object.defineProperty(_domCreate('div'), 'a', { get: function () { return 7; } }).a != 7;
});

// 7.1.1 ToPrimitive(input [, PreferredType])

// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
var _toPrimitive = function (it, S) {
  if (!_isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !_isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !_isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !_isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};

var dP = Object.defineProperty;

var f$1 = _descriptors ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  _anObject(O);
  P = _toPrimitive(P, true);
  _anObject(Attributes);
  if (_ie8DomDefine) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

var _objectDp = {
	f: f$1
};

// 21.2.5.3 get RegExp.prototype.flags

var _flags = function () {
  var that = _anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};

// 21.2.5.3 get RegExp.prototype.flags()
if (_descriptors && /./g.flags != 'g') _objectDp.f(RegExp.prototype, 'flags', {
  configurable: true,
  get: _flags
});

var _propertyDesc = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

var _hide = _descriptors ? function (object, key, value) {
  return _objectDp.f(object, key, _propertyDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

var hasOwnProperty$2 = {}.hasOwnProperty;
var _has = function (it, key) {
  return hasOwnProperty$2.call(it, key);
};

var id$1 = 0;
var px = Math.random();
var _uid = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id$1 + px).toString(36));
};

var _core = createCommonjsModule(function (module) {
var core = module.exports = { version: '2.6.12' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef
});

var _shared = createCommonjsModule(function (module) {
var SHARED = '__core-js_shared__';
var store = _global[SHARED] || (_global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: _core.version,
  mode:  'global',
  copyright: '© 2020 Denis Pushkarev (zloirock.ru)'
});
});

var _functionToString = _shared('native-function-to-string', Function.toString);

var _redefine = createCommonjsModule(function (module) {
var SRC = _uid('src');

var TO_STRING = 'toString';
var TPL = ('' + _functionToString).split(TO_STRING);

_core.inspectSource = function (it) {
  return _functionToString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) _has(val, 'name') || _hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) _has(val, SRC) || _hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === _global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    _hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    _hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || _functionToString.call(this);
});
});

var TO_STRING = 'toString';
var $toString = /./[TO_STRING];

var define = function (fn) {
  _redefine(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (_fails(function () { return $toString.call({ source: 'a', flags: 'b' }) != '/a/b'; })) {
  define(function toString() {
    var R = _anObject(this);
    return '/'.concat(R.source, '/',
      'flags' in R ? R.flags : !_descriptors && R instanceof RegExp ? _flags.call(R) : undefined);
  });
// FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}

var toString = {}.toString;

var _cof = function (it) {
  return toString.call(it).slice(8, -1);
};

var _wks = createCommonjsModule(function (module) {
var store = _shared('wks');

var Symbol = _global.Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : _uid)('Symbol.' + name));
};

$exports.store = store;
});

// getting tag from 19.1.3.6 Object.prototype.toString()

var TAG = _wks('toStringTag');
// ES3 wrong here
var ARG = _cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

var _classof = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? _cof(O)
    // ES3 arguments fallback
    : (B = _cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};

// 19.1.3.6 Object.prototype.toString()

var test = {};
test[_wks('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  _redefine(Object.prototype, 'toString', function toString() {
    return '[object ' + _classof(this) + ']';
  }, true);
}

var _aFunction = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};

// optional / simple context binding

var _ctx = function (fn, that, length) {
  _aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};

var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? _global : IS_STATIC ? _global[name] || (_global[name] = {}) : (_global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? _core : _core[name] || (_core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? _ctx(out, _global) : IS_PROTO && typeof out == 'function' ? _ctx(Function.call, out) : out;
    // extend global
    if (target) _redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) _hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
_global.core = _core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
var _export = $export;

// fallback for non-array-like ES3 and non-enumerable old V8 strings

// eslint-disable-next-line no-prototype-builtins
var _iobject = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return _cof(it) == 'String' ? it.split('') : Object(it);
};

// 7.2.1 RequireObjectCoercible(argument)
var _defined = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};

// to indexed object, toObject with fallback for non-array-like ES3 strings


var _toIobject = function (it) {
  return _iobject(_defined(it));
};

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
var _toInteger = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};

// 7.1.15 ToLength

var min = Math.min;
var _toLength = function (it) {
  return it > 0 ? min(_toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};

var max = Math.max;
var min$1 = Math.min;
var _toAbsoluteIndex = function (index, length) {
  index = _toInteger(index);
  return index < 0 ? max(index + length, 0) : min$1(index, length);
};

// false -> Array#indexOf
// true  -> Array#includes



var _arrayIncludes = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = _toIobject($this);
    var length = _toLength(O.length);
    var index = _toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};

var shared = _shared('keys');

var _sharedKey = function (key) {
  return shared[key] || (shared[key] = _uid(key));
};

var arrayIndexOf = _arrayIncludes(false);
var IE_PROTO = _sharedKey('IE_PROTO');

var _objectKeysInternal = function (object, names) {
  var O = _toIobject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) _has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (_has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};

// IE 8- don't enum bug keys
var _enumBugKeys = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');

// 19.1.2.14 / 15.2.3.14 Object.keys(O)



var _objectKeys = Object.keys || function keys(O) {
  return _objectKeysInternal(O, _enumBugKeys);
};

var _objectDps = _descriptors ? Object.defineProperties : function defineProperties(O, Properties) {
  _anObject(O);
  var keys = _objectKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) _objectDp.f(O, P = keys[i++], Properties[P]);
  return O;
};

var document$2 = _global.document;
var _html = document$2 && document$2.documentElement;

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])



var IE_PROTO$1 = _sharedKey('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE$1 = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = _domCreate('iframe');
  var i = _enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  _html.appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE$1][_enumBugKeys[i]];
  return createDict();
};

var _objectCreate = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE$1] = _anObject(O);
    result = new Empty();
    Empty[PROTOTYPE$1] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO$1] = O;
  } else result = createDict();
  return Properties === undefined ? result : _objectDps(result, Properties);
};

// fast apply, http://jsperf.lnkit.com/fast-apply/5
var _invoke = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};

var arraySlice = [].slice;
var factories = {};

var construct = function (F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  } return factories[len](F, args);
};

var _bind = Function.bind || function bind(that /* , ...args */) {
  var fn = _aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var bound = function (/* args... */) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof bound ? construct(fn, args.length, args) : _invoke(fn, args, that);
  };
  if (_isObject(fn.prototype)) bound.prototype = fn.prototype;
  return bound;
};

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])







var rConstruct = (_global.Reflect || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = _fails(function () {
  function F() { /* empty */ }
  return !(rConstruct(function () { /* empty */ }, [], F) instanceof F);
});
var ARGS_BUG = !_fails(function () {
  rConstruct(function () { /* empty */ });
});

_export(_export.S + _export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    _aFunction(Target);
    _anObject(args);
    var newTarget = arguments.length < 3 ? Target : _aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0: return new Target();
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (_bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = _objectCreate(_isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return _isObject(result) ? result : instance;
  }
});

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = _wks('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) _hide(ArrayProto, UNSCOPABLES, {});
var _addToUnscopables = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};

// https://github.com/tc39/Array.prototype.includes

var $includes = _arrayIncludes(true);

_export(_export.P, 'Array', {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

_addToUnscopables('includes');

// 7.2.8 IsRegExp(argument)


var MATCH = _wks('match');
var _isRegexp = function (it) {
  var isRegExp;
  return _isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : _cof(it) == 'RegExp');
};

// helper for String#{startsWith, endsWith, includes}



var _stringContext = function (that, searchString, NAME) {
  if (_isRegexp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(_defined(that));
};

var MATCH$1 = _wks('match');
var _failsIsRegexp = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH$1] = false;
      return !'/./'[KEY](re);
    } catch (f) { /* empty */ }
  } return true;
};

var INCLUDES = 'includes';

_export(_export.P + _export.F * _failsIsRegexp(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~_stringContext(this, searchString, INCLUDES)
      .indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

// 7.1.13 ToObject(argument)

var _toObject = function (it) {
  return Object(_defined(it));
};

// 7.2.2 IsArray(argument)

var _isArray = Array.isArray || function isArray(arg) {
  return _cof(arg) == 'Array';
};

var SPECIES = _wks('species');

var _arraySpeciesConstructor = function (original) {
  var C;
  if (_isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || _isArray(C.prototype))) C = undefined;
    if (_isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)


var _arraySpeciesCreate = function (original, length) {
  return new (_arraySpeciesConstructor(original))(length);
};

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex





var _arrayMethods = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || _arraySpeciesCreate;
  return function ($this, callbackfn, that) {
    var O = _toObject($this);
    var self = _iobject(O);
    var f = _ctx(callbackfn, that, 3);
    var length = _toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};

// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)

var $find = _arrayMethods(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
_export(_export.P + _export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
_addToUnscopables(KEY);

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

var ReactPropTypesSecret_1 = ReactPropTypesSecret;

var has = Function.call.bind(Object.prototype.hasOwnProperty);

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



function emptyFunction() {}
function emptyFunctionWithReset() {}
emptyFunctionWithReset.resetWarningCache = emptyFunction;

var factoryWithThrowingShims = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret_1) {
      // It is still safe when called from React.
      return;
    }
    var err = new Error(
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
    err.name = 'Invariant Violation';
    throw err;
  }  shim.isRequired = shim;
  function getShim() {
    return shim;
  }  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,

    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };

  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};

var propTypes = createCommonjsModule(function (module) {
{
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = factoryWithThrowingShims();
}
});

/*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/

var classnames = createCommonjsModule(function (module) {
/* global define */

(function () {

	var hasOwn = {}.hasOwnProperty;

	function classNames () {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg) && arg.length) {
				var inner = classNames.apply(null, arg);
				if (inner) {
					classes.push(inner);
				}
			} else if (argType === 'object') {
				for (var key in arg) {
					if (hasOwn.call(arg, key) && arg[key]) {
						classes.push(key);
					}
				}
			}
		}

		return classes.join(' ');
	}

	if ( module.exports) {
		classNames.default = classNames;
		module.exports = classNames;
	} else {
		window.classNames = classNames;
	}
}());
});

// true  -> String#at
// false -> String#codePointAt
var _stringAt = function (TO_STRING) {
  return function (that, pos) {
    var s = String(_defined(that));
    var i = _toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};

var _iterators = {};

var def = _objectDp.f;

var TAG$1 = _wks('toStringTag');

var _setToStringTag = function (it, tag, stat) {
  if (it && !_has(it = stat ? it : it.prototype, TAG$1)) def(it, TAG$1, { configurable: true, value: tag });
};

var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
_hide(IteratorPrototype, _wks('iterator'), function () { return this; });

var _iterCreate = function (Constructor, NAME, next) {
  Constructor.prototype = _objectCreate(IteratorPrototype, { next: _propertyDesc(1, next) });
  _setToStringTag(Constructor, NAME + ' Iterator');
};

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)


var IE_PROTO$2 = _sharedKey('IE_PROTO');
var ObjectProto = Object.prototype;

var _objectGpo = Object.getPrototypeOf || function (O) {
  O = _toObject(O);
  if (_has(O, IE_PROTO$2)) return O[IE_PROTO$2];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};

var ITERATOR = _wks('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

var _iterDefine = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  _iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = _objectGpo($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      _setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if ( typeof IteratorPrototype[ITERATOR] != 'function') _hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ( (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    _hide(proto, ITERATOR, $default);
  }
  // Plug for library
  _iterators[NAME] = $default;
  _iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) _redefine(proto, key, methods[key]);
    } else _export(_export.P + _export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};

var $at = _stringAt(true);

// 21.1.3.27 String.prototype[@@iterator]()
_iterDefine(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});

// call something on iterator step with safe closing on error

var _iterCall = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(_anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) _anObject(ret.call(iterator));
    throw e;
  }
};

// check on default Array iterator

var ITERATOR$1 = _wks('iterator');
var ArrayProto$1 = Array.prototype;

var _isArrayIter = function (it) {
  return it !== undefined && (_iterators.Array === it || ArrayProto$1[ITERATOR$1] === it);
};

var _createProperty = function (object, index, value) {
  if (index in object) _objectDp.f(object, index, _propertyDesc(0, value));
  else object[index] = value;
};

var ITERATOR$2 = _wks('iterator');

var core_getIteratorMethod = _core.getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR$2]
    || it['@@iterator']
    || _iterators[_classof(it)];
};

var ITERATOR$3 = _wks('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR$3]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

var _iterDetect = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR$3]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR$3] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};

_export(_export.S + _export.F * !_iterDetect(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = _toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = core_getIteratorMethod(O);
    var length, result, step, iterator;
    if (mapping) mapfn = _ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && _isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        _createProperty(result, index, mapping ? _iterCall(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = _toLength(O.length);
      for (result = new C(length); length > index; index++) {
        _createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});

// 7.3.20 SpeciesConstructor(O, defaultConstructor)


var SPECIES$1 = _wks('species');
var _speciesConstructor = function (O, D) {
  var C = _anObject(O).constructor;
  var S;
  return C === undefined || (S = _anObject(C)[SPECIES$1]) == undefined ? D : _aFunction(S);
};

var at = _stringAt(true);

 // `AdvanceStringIndex` abstract operation
// https://tc39.github.io/ecma262/#sec-advancestringindex
var _advanceStringIndex = function (S, index, unicode) {
  return index + (unicode ? at(S, index).length : 1);
};

var builtinExec = RegExp.prototype.exec;

 // `RegExpExec` abstract operation
// https://tc39.github.io/ecma262/#sec-regexpexec
var _regexpExecAbstract = function (R, S) {
  var exec = R.exec;
  if (typeof exec === 'function') {
    var result = exec.call(R, S);
    if (typeof result !== 'object') {
      throw new TypeError('RegExp exec method returned something other than an Object or null');
    }
    return result;
  }
  if (_classof(R) !== 'RegExp') {
    throw new TypeError('RegExp#exec called on incompatible receiver');
  }
  return builtinExec.call(R, S);
};

var nativeExec = RegExp.prototype.exec;
// This always refers to the native implementation, because the
// String#replace polyfill uses ./fix-regexp-well-known-symbol-logic.js,
// which loads this file before patching the method.
var nativeReplace = String.prototype.replace;

var patchedExec = nativeExec;

var LAST_INDEX = 'lastIndex';

var UPDATES_LAST_INDEX_WRONG = (function () {
  var re1 = /a/,
      re2 = /b*/g;
  nativeExec.call(re1, 'a');
  nativeExec.call(re2, 'a');
  return re1[LAST_INDEX] !== 0 || re2[LAST_INDEX] !== 0;
})();

// nonparticipating capturing group, copied from es5-shim's String#split patch.
var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED;

if (PATCH) {
  patchedExec = function exec(str) {
    var re = this;
    var lastIndex, reCopy, match, i;

    if (NPCG_INCLUDED) {
      reCopy = new RegExp('^' + re.source + '$(?!\\s)', _flags.call(re));
    }
    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re[LAST_INDEX];

    match = nativeExec.call(re, str);

    if (UPDATES_LAST_INDEX_WRONG && match) {
      re[LAST_INDEX] = re.global ? match.index + match[0].length : lastIndex;
    }
    if (NPCG_INCLUDED && match && match.length > 1) {
      // Fix browsers whose `exec` methods don't consistently return `undefined`
      // for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
      // eslint-disable-next-line no-loop-func
      nativeReplace.call(match[0], reCopy, function () {
        for (i = 1; i < arguments.length - 2; i++) {
          if (arguments[i] === undefined) match[i] = undefined;
        }
      });
    }

    return match;
  };
}

var _regexpExec = patchedExec;

_export({
  target: 'RegExp',
  proto: true,
  forced: _regexpExec !== /./.exec
}, {
  exec: _regexpExec
});

var SPECIES$2 = _wks('species');

var REPLACE_SUPPORTS_NAMED_GROUPS = !_fails(function () {
  // #replace needs built-in support for named groups.
  // #match works fine because it just return the exec results, even if it has
  // a "grops" property.
  var re = /./;
  re.exec = function () {
    var result = [];
    result.groups = { a: '7' };
    return result;
  };
  return ''.replace(re, '$<a>') !== '7';
});

var SPLIT_WORKS_WITH_OVERWRITTEN_EXEC = (function () {
  // Chrome 51 has a buggy "split" implementation when RegExp#exec !== nativeExec
  var re = /(?:)/;
  var originalExec = re.exec;
  re.exec = function () { return originalExec.apply(this, arguments); };
  var result = 'ab'.split(re);
  return result.length === 2 && result[0] === 'a' && result[1] === 'b';
})();

var _fixReWks = function (KEY, length, exec) {
  var SYMBOL = _wks(KEY);

  var DELEGATES_TO_SYMBOL = !_fails(function () {
    // String methods call symbol-named RegEp methods
    var O = {};
    O[SYMBOL] = function () { return 7; };
    return ''[KEY](O) != 7;
  });

  var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL ? !_fails(function () {
    // Symbol-named RegExp methods call .exec
    var execCalled = false;
    var re = /a/;
    re.exec = function () { execCalled = true; return null; };
    if (KEY === 'split') {
      // RegExp[@@split] doesn't call the regex's exec method, but first creates
      // a new one. We need to return the patched regex when creating the new one.
      re.constructor = {};
      re.constructor[SPECIES$2] = function () { return re; };
    }
    re[SYMBOL]('');
    return !execCalled;
  }) : undefined;

  if (
    !DELEGATES_TO_SYMBOL ||
    !DELEGATES_TO_EXEC ||
    (KEY === 'replace' && !REPLACE_SUPPORTS_NAMED_GROUPS) ||
    (KEY === 'split' && !SPLIT_WORKS_WITH_OVERWRITTEN_EXEC)
  ) {
    var nativeRegExpMethod = /./[SYMBOL];
    var fns = exec(
      _defined,
      SYMBOL,
      ''[KEY],
      function maybeCallNative(nativeMethod, regexp, str, arg2, forceStringMethod) {
        if (regexp.exec === _regexpExec) {
          if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
            // The native String method already delegates to @@method (this
            // polyfilled function), leasing to infinite recursion.
            // We avoid it by directly calling the native @@method method.
            return { done: true, value: nativeRegExpMethod.call(regexp, str, arg2) };
          }
          return { done: true, value: nativeMethod.call(str, regexp, arg2) };
        }
        return { done: false };
      }
    );
    var strfn = fns[0];
    var rxfn = fns[1];

    _redefine(String.prototype, KEY, strfn);
    _hide(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function (string, arg) { return rxfn.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function (string) { return rxfn.call(string, this); }
    );
  }
};

var $min = Math.min;
var $push = [].push;
var $SPLIT = 'split';
var LENGTH = 'length';
var LAST_INDEX$1 = 'lastIndex';
var MAX_UINT32 = 0xffffffff;

// babel-minify transpiles RegExp('x', 'y') -> /x/y and it causes SyntaxError
var SUPPORTS_Y = !_fails(function () { RegExp(MAX_UINT32, 'y'); });

// @@split logic
_fixReWks('split', 2, function (defined, SPLIT, $split, maybeCallNative) {
  var internalSplit;
  if (
    'abbc'[$SPLIT](/(b)*/)[1] == 'c' ||
    'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 ||
    'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 ||
    '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 ||
    '.'[$SPLIT](/()()/)[LENGTH] > 1 ||
    ''[$SPLIT](/.?/)[LENGTH]
  ) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function (separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!_isRegexp(separator)) return $split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? MAX_UINT32 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = _regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy[LAST_INDEX$1];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX$1] === match.index) separatorCopy[LAST_INDEX$1]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
  // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    internalSplit = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : $split.call(this, separator, limit);
    };
  } else {
    internalSplit = $split;
  }

  return [
    // `String.prototype.split` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.split
    function split(separator, limit) {
      var O = defined(this);
      var splitter = separator == undefined ? undefined : separator[SPLIT];
      return splitter !== undefined
        ? splitter.call(separator, O, limit)
        : internalSplit.call(String(O), separator, limit);
    },
    // `RegExp.prototype[@@split]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@split
    //
    // NOTE: This cannot be properly polyfilled in engines that don't support
    // the 'y' flag.
    function (regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== $split);
      if (res.done) return res.value;

      var rx = _anObject(regexp);
      var S = String(this);
      var C = _speciesConstructor(rx, RegExp);

      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? 'i' : '') +
                  (rx.multiline ? 'm' : '') +
                  (rx.unicode ? 'u' : '') +
                  (SUPPORTS_Y ? 'y' : 'g');

      // ^(? + rx + ) is needed, in combination with some S slicing, to
      // simulate the 'y' flag.
      var splitter = new C(SUPPORTS_Y ? rx : '^(?:' + rx.source + ')', flags);
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (S.length === 0) return _regexpExecAbstract(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = SUPPORTS_Y ? q : 0;
        var z = _regexpExecAbstract(splitter, SUPPORTS_Y ? S : S.slice(q));
        var e;
        if (
          z === null ||
          (e = $min(_toLength(splitter.lastIndex + (SUPPORTS_Y ? 0 : q)), S.length)) === p
        ) {
          q = _advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim) return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim) return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
});

var max$1 = Math.max;
var min$2 = Math.min;
var floor$1 = Math.floor;
var SUBSTITUTION_SYMBOLS = /\$([$&`']|\d\d?|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&`']|\d\d?)/g;

var maybeToString = function (it) {
  return it === undefined ? it : String(it);
};

// @@replace logic
_fixReWks('replace', 2, function (defined, REPLACE, $replace, maybeCallNative) {
  return [
    // `String.prototype.replace` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.replace
    function replace(searchValue, replaceValue) {
      var O = defined(this);
      var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
      return fn !== undefined
        ? fn.call(searchValue, O, replaceValue)
        : $replace.call(String(O), searchValue, replaceValue);
    },
    // `RegExp.prototype[@@replace]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
    function (regexp, replaceValue) {
      var res = maybeCallNative($replace, regexp, this, replaceValue);
      if (res.done) return res.value;

      var rx = _anObject(regexp);
      var S = String(this);
      var functionalReplace = typeof replaceValue === 'function';
      if (!functionalReplace) replaceValue = String(replaceValue);
      var global = rx.global;
      if (global) {
        var fullUnicode = rx.unicode;
        rx.lastIndex = 0;
      }
      var results = [];
      while (true) {
        var result = _regexpExecAbstract(rx, S);
        if (result === null) break;
        results.push(result);
        if (!global) break;
        var matchStr = String(result[0]);
        if (matchStr === '') rx.lastIndex = _advanceStringIndex(S, _toLength(rx.lastIndex), fullUnicode);
      }
      var accumulatedResult = '';
      var nextSourcePosition = 0;
      for (var i = 0; i < results.length; i++) {
        result = results[i];
        var matched = String(result[0]);
        var position = max$1(min$2(_toInteger(result.index), S.length), 0);
        var captures = [];
        // NOTE: This is equivalent to
        //   captures = result.slice(1).map(maybeToString)
        // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
        // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
        // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
        for (var j = 1; j < result.length; j++) captures.push(maybeToString(result[j]));
        var namedCaptures = result.groups;
        if (functionalReplace) {
          var replacerArgs = [matched].concat(captures, position, S);
          if (namedCaptures !== undefined) replacerArgs.push(namedCaptures);
          var replacement = String(replaceValue.apply(undefined, replacerArgs));
        } else {
          replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
        }
        if (position >= nextSourcePosition) {
          accumulatedResult += S.slice(nextSourcePosition, position) + replacement;
          nextSourcePosition = position + matched.length;
        }
      }
      return accumulatedResult + S.slice(nextSourcePosition);
    }
  ];

    // https://tc39.github.io/ecma262/#sec-getsubstitution
  function getSubstitution(matched, str, position, captures, namedCaptures, replacement) {
    var tailPos = position + matched.length;
    var m = captures.length;
    var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
    if (namedCaptures !== undefined) {
      namedCaptures = _toObject(namedCaptures);
      symbols = SUBSTITUTION_SYMBOLS;
    }
    return $replace.call(replacement, symbols, function (match, ch) {
      var capture;
      switch (ch.charAt(0)) {
        case '$': return '$';
        case '&': return matched;
        case '`': return str.slice(0, position);
        case "'": return str.slice(tailPos);
        case '<':
          capture = namedCaptures[ch.slice(1, -1)];
          break;
        default: // \d\d?
          var n = +ch;
          if (n === 0) return match;
          if (n > m) {
            var f = floor$1(n / 10);
            if (f === 0) return match;
            if (f <= m) return captures[f - 1] === undefined ? ch.charAt(1) : captures[f - 1] + ch.charAt(1);
            return match;
          }
          capture = captures[n - 1];
      }
      return capture === undefined ? '' : capture;
    });
  }
});

// most Object methods by ES6 should accept primitives



var _objectSap = function (KEY, exec) {
  var fn = (_core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  _export(_export.S + _export.F * _fails(function () { fn(1); }), 'Object', exp);
};

// 19.1.2.14 Object.keys(O)



_objectSap('keys', function () {
  return function keys(it) {
    return _objectKeys(_toObject(it));
  };
});

// 19.1.2.12 Object.isFrozen(O)


_objectSap('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return _isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _arrayWithHoles$1(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit$1(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _arrayLikeToArray$1(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _unsupportedIterableToArray$1(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray$1(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$1(o, minLen);
}

function _nonIterableRest$1() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray$1(arr, i) {
  return _arrayWithHoles$1(arr) || _iterableToArrayLimit$1(arr, i) || _unsupportedIterableToArray$1(arr, i) || _nonIterableRest$1();
}

var _iterStep = function (done, value) {
  return { value: value, done: !!done };
};

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
var es6_array_iterator = _iterDefine(Array, 'Array', function (iterated, kind) {
  this._t = _toIobject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return _iterStep(1);
  }
  if (kind == 'keys') return _iterStep(0, index);
  if (kind == 'values') return _iterStep(0, O[index]);
  return _iterStep(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
_iterators.Arguments = _iterators.Array;

_addToUnscopables('keys');
_addToUnscopables('values');
_addToUnscopables('entries');

var ITERATOR$4 = _wks('iterator');
var TO_STRING_TAG = _wks('toStringTag');
var ArrayValues = _iterators.Array;

var DOMIterables = {
  CSSRuleList: true, // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true, // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true, // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};

for (var collections = _objectKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = _global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR$4]) _hide(proto, ITERATOR$4, ArrayValues);
    if (!proto[TO_STRING_TAG]) _hide(proto, TO_STRING_TAG, NAME);
    _iterators[NAME] = ArrayValues;
    if (explicit) for (key in es6_array_iterator) if (!proto[key]) _redefine(proto, key, es6_array_iterator[key], true);
  }
}

var f$2 = {}.propertyIsEnumerable;

var _objectPie = {
	f: f$2
};

var isEnum = _objectPie.f;
var _objectToArray = function (isEntries) {
  return function (it) {
    var O = _toIobject(it);
    var keys = _objectKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) {
      key = keys[i++];
      if (!_descriptors || isEnum.call(O, key)) {
        result.push(isEntries ? [key, O[key]] : O[key]);
      }
    }
    return result;
  };
};

// https://github.com/tc39/proposal-object-values-entries

var $entries = _objectToArray(true);

_export(_export.S, 'Object', {
  entries: function entries(it) {
    return $entries(it);
  }
});

var gOPD = Object.getOwnPropertyDescriptor;

var f$3 = _descriptors ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = _toIobject(O);
  P = _toPrimitive(P, true);
  if (_ie8DomDefine) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (_has(O, P)) return _propertyDesc(!_objectPie.f.call(O, P), O[P]);
};

var _objectGopd = {
	f: f$3
};

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */


var check = function (O, proto) {
  _anObject(O);
  if (!_isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
var _setProto = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = _ctx(Function.call, _objectGopd.f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};

var setPrototypeOf = _setProto.set;
var _inheritIfRequired = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && _isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  } return that;
};

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)

var hiddenKeys = _enumBugKeys.concat('length', 'prototype');

var f$4 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return _objectKeysInternal(O, hiddenKeys);
};

var _objectGopn = {
	f: f$4
};

var SPECIES$3 = _wks('species');

var _setSpecies = function (KEY) {
  var C = _global[KEY];
  if (_descriptors && C && !C[SPECIES$3]) _objectDp.f(C, SPECIES$3, {
    configurable: true,
    get: function () { return this; }
  });
};

var dP$1 = _objectDp.f;
var gOPN = _objectGopn.f;


var $RegExp = _global.RegExp;
var Base = $RegExp;
var proto$1 = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;

if (_descriptors && (!CORRECT_NEW || _fails(function () {
  re2[_wks('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = _isRegexp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p
      : _inheritIfRequired(CORRECT_NEW
        ? new Base(piRE && !fiU ? p.source : p, f)
        : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? _flags.call(p) : f)
      , tiRE ? this : proto$1, $RegExp);
  };
  var proxy = function (key) {
    key in $RegExp || dP$1($RegExp, key, {
      configurable: true,
      get: function () { return Base[key]; },
      set: function (it) { Base[key] = it; }
    });
  };
  for (var keys = gOPN(Base), i$1 = 0; keys.length > i$1;) proxy(keys[i$1++]);
  proto$1.constructor = $RegExp;
  $RegExp.prototype = proto$1;
  _redefine(_global, 'RegExp', $RegExp);
}

_setSpecies('RegExp');

// @@match logic
_fixReWks('match', 1, function (defined, MATCH, $match, maybeCallNative) {
  return [
    // `String.prototype.match` method
    // https://tc39.github.io/ecma262/#sec-string.prototype.match
    function match(regexp) {
      var O = defined(this);
      var fn = regexp == undefined ? undefined : regexp[MATCH];
      return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
    },
    // `RegExp.prototype[@@match]` method
    // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@match
    function (regexp) {
      var res = maybeCallNative($match, regexp, this);
      if (res.done) return res.value;
      var rx = _anObject(regexp);
      var S = String(this);
      if (!rx.global) return _regexpExecAbstract(rx, S);
      var fullUnicode = rx.unicode;
      rx.lastIndex = 0;
      var A = [];
      var n = 0;
      var result;
      while ((result = _regexpExecAbstract(rx, S)) !== null) {
        var matchStr = String(result[0]);
        A[n] = matchStr;
        if (matchStr === '') rx.lastIndex = _advanceStringIndex(S, _toLength(rx.lastIndex), fullUnicode);
        n++;
      }
      return n === 0 ? null : A;
    }
  ];
});

var keycode = createCommonjsModule(function (module, exports) {
// Source: http://jsfiddle.net/vWx8V/
// http://stackoverflow.com/questions/5603195/full-list-of-javascript-keycodes

/**
 * Conenience method returns corresponding value for given keyName or keyCode.
 *
 * @param {Mixed} keyCode {Number} or keyName {String}
 * @return {Mixed}
 * @api public
 */

function keyCode(searchInput) {
  // Keyboard Events
  if (searchInput && 'object' === typeof searchInput) {
    var hasKeyCode = searchInput.which || searchInput.keyCode || searchInput.charCode;
    if (hasKeyCode) searchInput = hasKeyCode;
  }

  // Numbers
  if ('number' === typeof searchInput) return names[searchInput]

  // Everything else (cast to string)
  var search = String(searchInput);

  // check codes
  var foundNamedKey = codes[search.toLowerCase()];
  if (foundNamedKey) return foundNamedKey

  // check aliases
  var foundNamedKey = aliases[search.toLowerCase()];
  if (foundNamedKey) return foundNamedKey

  // weird character?
  if (search.length === 1) return search.charCodeAt(0)

  return undefined
}

/**
 * Compares a keyboard event with a given keyCode or keyName.
 *
 * @param {Event} event Keyboard event that should be tested
 * @param {Mixed} keyCode {Number} or keyName {String}
 * @return {Boolean}
 * @api public
 */
keyCode.isEventKey = function isEventKey(event, nameOrCode) {
  if (event && 'object' === typeof event) {
    var keyCode = event.which || event.keyCode || event.charCode;
    if (keyCode === null || keyCode === undefined) { return false; }
    if (typeof nameOrCode === 'string') {
      // check codes
      var foundNamedKey = codes[nameOrCode.toLowerCase()];
      if (foundNamedKey) { return foundNamedKey === keyCode; }
    
      // check aliases
      var foundNamedKey = aliases[nameOrCode.toLowerCase()];
      if (foundNamedKey) { return foundNamedKey === keyCode; }
    } else if (typeof nameOrCode === 'number') {
      return nameOrCode === keyCode;
    }
    return false;
  }
};

exports = module.exports = keyCode;

/**
 * Get by name
 *
 *   exports.code['enter'] // => 13
 */

var codes = exports.code = exports.codes = {
  'backspace': 8,
  'tab': 9,
  'enter': 13,
  'shift': 16,
  'ctrl': 17,
  'alt': 18,
  'pause/break': 19,
  'caps lock': 20,
  'esc': 27,
  'space': 32,
  'page up': 33,
  'page down': 34,
  'end': 35,
  'home': 36,
  'left': 37,
  'up': 38,
  'right': 39,
  'down': 40,
  'insert': 45,
  'delete': 46,
  'command': 91,
  'left command': 91,
  'right command': 93,
  'numpad *': 106,
  'numpad +': 107,
  'numpad -': 109,
  'numpad .': 110,
  'numpad /': 111,
  'num lock': 144,
  'scroll lock': 145,
  'my computer': 182,
  'my calculator': 183,
  ';': 186,
  '=': 187,
  ',': 188,
  '-': 189,
  '.': 190,
  '/': 191,
  '`': 192,
  '[': 219,
  '\\': 220,
  ']': 221,
  "'": 222
};

// Helper aliases

var aliases = exports.aliases = {
  'windows': 91,
  '⇧': 16,
  '⌥': 18,
  '⌃': 17,
  '⌘': 91,
  'ctl': 17,
  'control': 17,
  'option': 18,
  'pause': 19,
  'break': 19,
  'caps': 20,
  'return': 13,
  'escape': 27,
  'spc': 32,
  'spacebar': 32,
  'pgup': 33,
  'pgdn': 34,
  'ins': 45,
  'del': 46,
  'cmd': 91
};

/*!
 * Programatically add the following
 */

// lower case chars
for (i = 97; i < 123; i++) codes[String.fromCharCode(i)] = i - 32;

// numbers
for (var i = 48; i < 58; i++) codes[i - 48] = i;

// function keys
for (i = 1; i < 13; i++) codes['f'+i] = i + 111;

// numpad keys
for (i = 0; i < 10; i++) codes['numpad '+i] = i + 96;

/**
 * Get by code
 *
 *   exports.name[13] // => 'Enter'
 */

var names = exports.names = exports.title = {}; // title for backward compat

// Create reverse mapping
for (i in codes) names[codes[i]] = i;

// Add aliases
for (var alias in aliases) {
  codes[alias] = aliases[alias];
}
});

/**
 * what-input - A global utility for tracking the current input method (mouse, keyboard or touch).
 * @version v5.2.10
 * @link https://github.com/ten1seven/what-input
 * @license MIT
 */

var whatInput = createCommonjsModule(function (module, exports) {
(function webpackUniversalModuleDefinition(root, factory) {
	module.exports = factory();
})(commonjsGlobal, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

	module.exports = function () {
	  /*
	   * bail out if there is no document or window
	   * (i.e. in a node/non-DOM environment)
	   *
	   * Return a stubbed API instead
	   */
	  if (typeof document === 'undefined' || typeof window === 'undefined') {
	    return {
	      // always return "initial" because no interaction will ever be detected
	      ask: function ask() {
	        return 'initial';
	      },

	      // always return null
	      element: function element() {
	        return null;
	      },

	      // no-op
	      ignoreKeys: function ignoreKeys() {},

	      // no-op
	      specificKeys: function specificKeys() {},

	      // no-op
	      registerOnChange: function registerOnChange() {},

	      // no-op
	      unRegisterOnChange: function unRegisterOnChange() {}
	    };
	  }

	  /*
	   * variables
	   */

	  // cache document.documentElement
	  var docElem = document.documentElement;

	  // currently focused dom element
	  var currentElement = null;

	  // last used input type
	  var currentInput = 'initial';

	  // last used input intent
	  var currentIntent = currentInput;

	  // UNIX timestamp of current event
	  var currentTimestamp = Date.now();

	  // check for a `data-whatpersist` attribute on either the `html` or `body` elements, defaults to `true`
	  var shouldPersist = 'false';

	  // form input types
	  var formInputs = ['button', 'input', 'select', 'textarea'];

	  // empty array for holding callback functions
	  var functionList = [];

	  // list of modifier keys commonly used with the mouse and
	  // can be safely ignored to prevent false keyboard detection
	  var ignoreMap = [16, // shift
	  17, // control
	  18, // alt
	  91, // Windows key / left Apple cmd
	  93 // Windows menu / right Apple cmd
	  ];

	  var specificMap = [];

	  // mapping of events to input types
	  var inputMap = {
	    keydown: 'keyboard',
	    keyup: 'keyboard',
	    mousedown: 'mouse',
	    mousemove: 'mouse',
	    MSPointerDown: 'pointer',
	    MSPointerMove: 'pointer',
	    pointerdown: 'pointer',
	    pointermove: 'pointer',
	    touchstart: 'touch',
	    touchend: 'touch'

	    // boolean: true if the page is being scrolled
	  };var isScrolling = false;

	  // store current mouse position
	  var mousePos = {
	    x: null,
	    y: null

	    // map of IE 10 pointer events
	  };var pointerMap = {
	    2: 'touch',
	    3: 'touch', // treat pen like touch
	    4: 'mouse'

	    // check support for passive event listeners
	  };var supportsPassive = false;

	  try {
	    var opts = Object.defineProperty({}, 'passive', {
	      get: function get() {
	        supportsPassive = true;
	      }
	    });

	    window.addEventListener('test', null, opts);
	  } catch (e) {}
	  // fail silently


	  /*
	   * set up
	   */

	  var setUp = function setUp() {
	    // add correct mouse wheel event mapping to `inputMap`
	    inputMap[detectWheel()] = 'mouse';

	    addListeners();
	  };

	  /*
	   * events
	   */

	  var addListeners = function addListeners() {
	    // `pointermove`, `MSPointerMove`, `mousemove` and mouse wheel event binding
	    // can only demonstrate potential, but not actual, interaction
	    // and are treated separately
	    var options = supportsPassive ? { passive: true } : false;

	    document.addEventListener('DOMContentLoaded', setPersist);

	    // pointer events (mouse, pen, touch)
	    if (window.PointerEvent) {
	      window.addEventListener('pointerdown', setInput);
	      window.addEventListener('pointermove', setIntent);
	    } else if (window.MSPointerEvent) {
	      window.addEventListener('MSPointerDown', setInput);
	      window.addEventListener('MSPointerMove', setIntent);
	    } else {
	      // mouse events
	      window.addEventListener('mousedown', setInput);
	      window.addEventListener('mousemove', setIntent);

	      // touch events
	      if ('ontouchstart' in window) {
	        window.addEventListener('touchstart', setInput, options);
	        window.addEventListener('touchend', setInput);
	      }
	    }

	    // mouse wheel
	    window.addEventListener(detectWheel(), setIntent, options);

	    // keyboard events
	    window.addEventListener('keydown', setInput);
	    window.addEventListener('keyup', setInput);

	    // focus events
	    window.addEventListener('focusin', setElement);
	    window.addEventListener('focusout', clearElement);
	  };

	  // checks if input persistence should happen and
	  // get saved state from session storage if true (defaults to `false`)
	  var setPersist = function setPersist() {
	    shouldPersist = !(docElem.getAttribute('data-whatpersist') || document.body.getAttribute('data-whatpersist') === 'false');

	    if (shouldPersist) {
	      // check for session variables and use if available
	      try {
	        if (window.sessionStorage.getItem('what-input')) {
	          currentInput = window.sessionStorage.getItem('what-input');
	        }

	        if (window.sessionStorage.getItem('what-intent')) {
	          currentIntent = window.sessionStorage.getItem('what-intent');
	        }
	      } catch (e) {
	        // fail silently
	      }
	    }

	    // always run these so at least `initial` state is set
	    doUpdate('input');
	    doUpdate('intent');
	  };

	  // checks conditions before updating new input
	  var setInput = function setInput(event) {
	    var eventKey = event.which;
	    var value = inputMap[event.type];

	    if (value === 'pointer') {
	      value = pointerType(event);
	    }

	    var ignoreMatch = !specificMap.length && ignoreMap.indexOf(eventKey) === -1;

	    var specificMatch = specificMap.length && specificMap.indexOf(eventKey) !== -1;

	    var shouldUpdate = value === 'keyboard' && eventKey && (ignoreMatch || specificMatch) || value === 'mouse' || value === 'touch';

	    // prevent touch detection from being overridden by event execution order
	    if (validateTouch(value)) {
	      shouldUpdate = false;
	    }

	    if (shouldUpdate && currentInput !== value) {
	      currentInput = value;

	      persistInput('input', currentInput);
	      doUpdate('input');
	    }

	    if (shouldUpdate && currentIntent !== value) {
	      // preserve intent for keyboard interaction with form fields
	      var activeElem = document.activeElement;
	      var notFormInput = activeElem && activeElem.nodeName && (formInputs.indexOf(activeElem.nodeName.toLowerCase()) === -1 || activeElem.nodeName.toLowerCase() === 'button' && !checkClosest(activeElem, 'form'));

	      if (notFormInput) {
	        currentIntent = value;

	        persistInput('intent', currentIntent);
	        doUpdate('intent');
	      }
	    }
	  };

	  // updates the doc and `inputTypes` array with new input
	  var doUpdate = function doUpdate(which) {
	    docElem.setAttribute('data-what' + which, which === 'input' ? currentInput : currentIntent);

	    fireFunctions(which);
	  };

	  // updates input intent for `mousemove` and `pointermove`
	  var setIntent = function setIntent(event) {
	    var value = inputMap[event.type];

	    if (value === 'pointer') {
	      value = pointerType(event);
	    }

	    // test to see if `mousemove` happened relative to the screen to detect scrolling versus mousemove
	    detectScrolling(event);

	    // only execute if scrolling isn't happening
	    if ((!isScrolling && !validateTouch(value) || isScrolling && event.type === 'wheel' || event.type === 'mousewheel' || event.type === 'DOMMouseScroll') && currentIntent !== value) {
	      currentIntent = value;

	      persistInput('intent', currentIntent);
	      doUpdate('intent');
	    }
	  };

	  var setElement = function setElement(event) {
	    if (!event.target.nodeName) {
	      // If nodeName is undefined, clear the element
	      // This can happen if click inside an <svg> element.
	      clearElement();
	      return;
	    }

	    currentElement = event.target.nodeName.toLowerCase();
	    docElem.setAttribute('data-whatelement', currentElement);

	    if (event.target.classList && event.target.classList.length) {
	      docElem.setAttribute('data-whatclasses', event.target.classList.toString().replace(' ', ','));
	    }
	  };

	  var clearElement = function clearElement() {
	    currentElement = null;

	    docElem.removeAttribute('data-whatelement');
	    docElem.removeAttribute('data-whatclasses');
	  };

	  var persistInput = function persistInput(which, value) {
	    if (shouldPersist) {
	      try {
	        window.sessionStorage.setItem('what-' + which, value);
	      } catch (e) {
	        // fail silently
	      }
	    }
	  };

	  /*
	   * utilities
	   */

	  var pointerType = function pointerType(event) {
	    if (typeof event.pointerType === 'number') {
	      return pointerMap[event.pointerType];
	    } else {
	      // treat pen like touch
	      return event.pointerType === 'pen' ? 'touch' : event.pointerType;
	    }
	  };

	  // prevent touch detection from being overridden by event execution order
	  var validateTouch = function validateTouch(value) {
	    var timestamp = Date.now();

	    var touchIsValid = value === 'mouse' && currentInput === 'touch' && timestamp - currentTimestamp < 200;

	    currentTimestamp = timestamp;

	    return touchIsValid;
	  };

	  // detect version of mouse wheel event to use
	  // via https://developer.mozilla.org/en-US/docs/Web/API/Element/wheel_event
	  var detectWheel = function detectWheel() {
	    var wheelType = null;

	    // Modern browsers support "wheel"
	    if ('onwheel' in document.createElement('div')) {
	      wheelType = 'wheel';
	    } else {
	      // Webkit and IE support at least "mousewheel"
	      // or assume that remaining browsers are older Firefox
	      wheelType = document.onmousewheel !== undefined ? 'mousewheel' : 'DOMMouseScroll';
	    }

	    return wheelType;
	  };

	  // runs callback functions
	  var fireFunctions = function fireFunctions(type) {
	    for (var i = 0, len = functionList.length; i < len; i++) {
	      if (functionList[i].type === type) {
	        functionList[i].fn.call(undefined, type === 'input' ? currentInput : currentIntent);
	      }
	    }
	  };

	  // finds matching element in an object
	  var objPos = function objPos(match) {
	    for (var i = 0, len = functionList.length; i < len; i++) {
	      if (functionList[i].fn === match) {
	        return i;
	      }
	    }
	  };

	  var detectScrolling = function detectScrolling(event) {
	    if (mousePos.x !== event.screenX || mousePos.y !== event.screenY) {
	      isScrolling = false;

	      mousePos.x = event.screenX;
	      mousePos.y = event.screenY;
	    } else {
	      isScrolling = true;
	    }
	  };

	  // manual version of `closest()`
	  var checkClosest = function checkClosest(elem, tag) {
	    var ElementPrototype = window.Element.prototype;

	    if (!ElementPrototype.matches) {
	      ElementPrototype.matches = ElementPrototype.msMatchesSelector || ElementPrototype.webkitMatchesSelector;
	    }

	    if (!ElementPrototype.closest) {
	      do {
	        if (elem.matches(tag)) {
	          return elem;
	        }

	        elem = elem.parentElement || elem.parentNode;
	      } while (elem !== null && elem.nodeType === 1);

	      return null;
	    } else {
	      return elem.closest(tag);
	    }
	  };

	  /*
	   * init
	   */

	  // don't start script unless browser cuts the mustard
	  // (also passes if polyfills are used)
	  if ('addEventListener' in window && Array.prototype.indexOf) {
	    setUp();
	  }

	  /*
	   * api
	   */

	  return {
	    // returns string: the current input type
	    // opt: 'intent'|'input'
	    // 'input' (default): returns the same value as the `data-whatinput` attribute
	    // 'intent': includes `data-whatintent` value if it's different than `data-whatinput`
	    ask: function ask(opt) {
	      return opt === 'intent' ? currentIntent : currentInput;
	    },

	    // returns string: the currently focused element or null
	    element: function element() {
	      return currentElement;
	    },

	    // overwrites ignored keys with provided array
	    ignoreKeys: function ignoreKeys(arr) {
	      ignoreMap = arr;
	    },

	    // overwrites specific char keys to update on
	    specificKeys: function specificKeys(arr) {
	      specificMap = arr;
	    },

	    // attach functions to input and intent "events"
	    // funct: function to fire on change
	    // eventType: 'input'|'intent'
	    registerOnChange: function registerOnChange(fn, eventType) {
	      functionList.push({
	        fn: fn,
	        type: eventType || 'input'
	      });
	    },

	    unRegisterOnChange: function unRegisterOnChange(fn) {
	      var position = objPos(fn);

	      if (position || position === 0) {
	        functionList.splice(position, 1);
	      }
	    },

	    clearStorage: function clearStorage() {
	      window.sessionStorage.clear();
	    }
	  };
	}();

/***/ })
/******/ ])
});
});

var _stringWs = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

var space = '[' + _stringWs + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = _fails(function () {
    return !!_stringWs[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim$1) : _stringWs[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  _export(_export.P + _export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim$1 = exporter.trim = function (string, TYPE) {
  string = String(_defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

var _stringTrim = exporter;

var gOPN$1 = _objectGopn.f;
var gOPD$1 = _objectGopd.f;
var dP$2 = _objectDp.f;
var $trim = _stringTrim.trim;
var NUMBER = 'Number';
var $Number = _global[NUMBER];
var Base$1 = $Number;
var proto$2 = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = _cof(_objectCreate(proto$2)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function (argument) {
  var it = _toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66: case 98: radix = 2; maxCode = 49; break; // fast equal /^0b[01]+$/i
        case 79: case 111: radix = 8; maxCode = 55; break; // fast equal /^0o[0-7]+$/i
        default: return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      } return parseInt(digits, radix);
    }
  } return +it;
};

if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? _fails(function () { proto$2.valueOf.call(that); }) : _cof(that) != NUMBER)
        ? _inheritIfRequired(new Base$1(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys$1 = _descriptors ? gOPN$1(Base$1) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
    'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
  ).split(','), j = 0, key$1; keys$1.length > j; j++) {
    if (_has(Base$1, key$1 = keys$1[j]) && !_has($Number, key$1)) {
      dP$2($Number, key$1, gOPD$1(Base$1, key$1));
    }
  }
  $Number.prototype = proto$2;
  proto$2.constructor = $Number;
  _redefine(_global, NUMBER, $Number);
}

function _arrayWithoutHoles$1(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray$1(arr);
}

function _iterableToArray$1(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _nonIterableSpread$1() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toConsumableArray$1(arr) {
  return _arrayWithoutHoles$1(arr) || _iterableToArray$1(arr) || _unsupportedIterableToArray$1(arr) || _nonIterableSpread$1();
}

function _isNativeFunction(fn) {
  return Function.toString.call(fn).indexOf("[native code]") !== -1;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _construct(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct(Parent, args, Class) {
      var a = [null];
      a.push.apply(a, args);
      var Constructor = Function.bind.apply(Parent, a);
      var instance = new Constructor();
      if (Class) _setPrototypeOf(instance, Class.prototype);
      return instance;
    };
  }

  return _construct.apply(null, arguments);
}

function _wrapNativeSuper(Class) {
  var _cache = typeof Map === "function" ? new Map() : undefined;

  _wrapNativeSuper = function _wrapNativeSuper(Class) {
    if (Class === null || !_isNativeFunction(Class)) return Class;

    if (typeof Class !== "function") {
      throw new TypeError("Super expression must either be null or a function");
    }

    if (typeof _cache !== "undefined") {
      if (_cache.has(Class)) return _cache.get(Class);

      _cache.set(Class, Wrapper);
    }

    function Wrapper() {
      return _construct(Class, arguments, _getPrototypeOf(this).constructor);
    }

    Wrapper.prototype = Object.create(Class.prototype, {
      constructor: {
        value: Wrapper,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    return _setPrototypeOf(Wrapper, Class);
  };

  return _wrapNativeSuper(Class);
}

var dP$3 = _objectDp.f;
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME$1 = 'name';

// 19.2.4.2 name
NAME$1 in FProto || _descriptors && dP$3(FProto, NAME$1, {
  configurable: true,
  get: function () {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});

var ERROR_HARMLESS = 100;
var ERROR_FATAL = 500;
function ErrorHandler(error) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
    message: null
  },
      message = _ref.message;

  var code = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : ERROR_HARMLESS;

  if (_typeof(error) === 'object') {
    message = error.message;
  }

  this.err = new Error("".concat(error, "\n\n").concat(message));

  if (code === ERROR_FATAL) {
    throw this.err;
  } else {
    console.log(this.err);
  }
}

function installCustomElements(window, polyfill) {

  var document = window.document,
      Object = window.Object;

  var htmlClass = function (info) {
    var catchClass = /^[A-Z]+[a-z]/,
        filterBy = function filterBy(re) {
      var arr = [],
          tag;

      for (tag in register) {
        if (re.test(tag)) arr.push(tag);
      }

      return arr;
    },
        add = function add(Class, tag) {
      tag = tag.toLowerCase();

      if (!(tag in register)) {
        register[Class] = (register[Class] || []).concat(tag);
        register[tag] = register[tag.toUpperCase()] = Class;
      }
    },
        register = (Object.create || Object)(null),
        htmlClass = {},
        i,
        section,
        tags,
        Class;

    for (section in info) {
      for (Class in info[section]) {
        tags = info[section][Class];
        register[Class] = tags;

        for (i = 0; i < tags.length; i++) {
          register[tags[i].toLowerCase()] = register[tags[i].toUpperCase()] = Class;
        }
      }
    }

    htmlClass.get = function get(tagOrClass) {
      return typeof tagOrClass === 'string' ? register[tagOrClass] || (catchClass.test(tagOrClass) ? [] : '') : filterBy(tagOrClass);
    };

    htmlClass.set = function set(tag, Class) {
      return catchClass.test(tag) ? add(tag, Class) : add(Class, tag), htmlClass;
    };

    return htmlClass;
  }({
    collections: {
      HTMLAllCollection: ['all'],
      HTMLCollection: ['forms'],
      HTMLFormControlsCollection: ['elements'],
      HTMLOptionsCollection: ['options']
    },
    elements: {
      Element: ['element'],
      HTMLAnchorElement: ['a'],
      HTMLAppletElement: ['applet'],
      HTMLAreaElement: ['area'],
      HTMLAttachmentElement: ['attachment'],
      HTMLAudioElement: ['audio'],
      HTMLBRElement: ['br'],
      HTMLBaseElement: ['base'],
      HTMLBodyElement: ['body'],
      HTMLButtonElement: ['button'],
      HTMLCanvasElement: ['canvas'],
      HTMLContentElement: ['content'],
      HTMLDListElement: ['dl'],
      HTMLDataElement: ['data'],
      HTMLDataListElement: ['datalist'],
      HTMLDetailsElement: ['details'],
      HTMLDialogElement: ['dialog'],
      HTMLDirectoryElement: ['dir'],
      HTMLDivElement: ['div'],
      HTMLDocument: ['document'],
      HTMLElement: ['element', 'abbr', 'address', 'article', 'aside', 'b', 'bdi', 'bdo', 'cite', 'code', 'command', 'dd', 'dfn', 'dt', 'em', 'figcaption', 'figure', 'footer', 'header', 'i', 'kbd', 'mark', 'nav', 'noscript', 'rp', 'rt', 'ruby', 's', 'samp', 'section', 'small', 'strong', 'sub', 'summary', 'sup', 'u', 'var', 'wbr'],
      HTMLEmbedElement: ['embed'],
      HTMLFieldSetElement: ['fieldset'],
      HTMLFontElement: ['font'],
      HTMLFormElement: ['form'],
      HTMLFrameElement: ['frame'],
      HTMLFrameSetElement: ['frameset'],
      HTMLHRElement: ['hr'],
      HTMLHeadElement: ['head'],
      HTMLHeadingElement: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
      HTMLHtmlElement: ['html'],
      HTMLIFrameElement: ['iframe'],
      HTMLImageElement: ['img'],
      HTMLInputElement: ['input'],
      HTMLKeygenElement: ['keygen'],
      HTMLLIElement: ['li'],
      HTMLLabelElement: ['label'],
      HTMLLegendElement: ['legend'],
      HTMLLinkElement: ['link'],
      HTMLMapElement: ['map'],
      HTMLMarqueeElement: ['marquee'],
      HTMLMediaElement: ['media'],
      HTMLMenuElement: ['menu'],
      HTMLMenuItemElement: ['menuitem'],
      HTMLMetaElement: ['meta'],
      HTMLMeterElement: ['meter'],
      HTMLModElement: ['del', 'ins'],
      HTMLOListElement: ['ol'],
      HTMLObjectElement: ['object'],
      HTMLOptGroupElement: ['optgroup'],
      HTMLOptionElement: ['option'],
      HTMLOutputElement: ['output'],
      HTMLParagraphElement: ['p'],
      HTMLParamElement: ['param'],
      HTMLPictureElement: ['picture'],
      HTMLPreElement: ['pre'],
      HTMLProgressElement: ['progress'],
      HTMLQuoteElement: ['blockquote', 'q', 'quote'],
      HTMLScriptElement: ['script'],
      HTMLSelectElement: ['select'],
      HTMLShadowElement: ['shadow'],
      HTMLSlotElement: ['slot'],
      HTMLSourceElement: ['source'],
      HTMLSpanElement: ['span'],
      HTMLStyleElement: ['style'],
      HTMLTableCaptionElement: ['caption'],
      HTMLTableCellElement: ['td', 'th'],
      HTMLTableColElement: ['col', 'colgroup'],
      HTMLTableElement: ['table'],
      HTMLTableRowElement: ['tr'],
      HTMLTableSectionElement: ['thead', 'tbody', 'tfoot'],
      HTMLTemplateElement: ['template'],
      HTMLTextAreaElement: ['textarea'],
      HTMLTimeElement: ['time'],
      HTMLTitleElement: ['title'],
      HTMLTrackElement: ['track'],
      HTMLUListElement: ['ul'],
      HTMLUnknownElement: ['unknown', 'vhgroupv', 'vkeygen'],
      HTMLVideoElement: ['video']
    },
    nodes: {
      Attr: ['node'],
      Audio: ['audio'],
      CDATASection: ['node'],
      CharacterData: ['node'],
      Comment: ['#comment'],
      Document: ['#document'],
      DocumentFragment: ['#document-fragment'],
      DocumentType: ['node'],
      HTMLDocument: ['#document'],
      Image: ['img'],
      Option: ['option'],
      ProcessingInstruction: ['node'],
      ShadowRoot: ['#shadow-root'],
      Text: ['#text'],
      XMLDocument: ['xml']
    }
  });

  if (_typeof(polyfill) !== 'object') polyfill = {
    type: polyfill || 'auto'
  };

  var REGISTER_ELEMENT = 'registerElement',
      EXPANDO_UID = '__' + REGISTER_ELEMENT + (window.Math.random() * 10e4 >> 0),
      ADD_EVENT_LISTENER = 'addEventListener',
      ATTACHED = 'attached',
      CALLBACK = 'Callback',
      DETACHED = 'detached',
      EXTENDS = 'extends',
      ATTRIBUTE_CHANGED_CALLBACK = 'attributeChanged' + CALLBACK,
      ATTACHED_CALLBACK = ATTACHED + CALLBACK,
      CONNECTED_CALLBACK = 'connected' + CALLBACK,
      DISCONNECTED_CALLBACK = 'disconnected' + CALLBACK,
      CREATED_CALLBACK = 'created' + CALLBACK,
      DETACHED_CALLBACK = DETACHED + CALLBACK,
      ADDITION = 'ADDITION',
      MODIFICATION = 'MODIFICATION',
      REMOVAL = 'REMOVAL',
      DOM_ATTR_MODIFIED = 'DOMAttrModified',
      DOM_CONTENT_LOADED = 'DOMContentLoaded',
      DOM_SUBTREE_MODIFIED = 'DOMSubtreeModified',
      PREFIX_TAG = '<',
      PREFIX_IS = '=',
      validName = /^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$/,
      invalidNames = ['ANNOTATION-XML', 'COLOR-PROFILE', 'FONT-FACE', 'FONT-FACE-SRC', 'FONT-FACE-URI', 'FONT-FACE-FORMAT', 'FONT-FACE-NAME', 'MISSING-GLYPH'],
      types = [],
      protos = [],
      query = '',
      documentElement = document.documentElement,
      indexOf = types.indexOf || function (v) {
    for (var i = this.length; i-- && this[i] !== v;) {}

    return i;
  },
      OP = Object.prototype,
      hOP = OP.hasOwnProperty,
      iPO = OP.isPrototypeOf,
      defineProperty = Object.defineProperty,
      empty = [],
      gOPD = Object.getOwnPropertyDescriptor,
      gOPN = Object.getOwnPropertyNames,
      gPO = Object.getPrototypeOf,
      sPO = Object.setPrototypeOf,
      hasProto = !!Object.__proto__,
      DRECEV1 = '__dreCEv1',
      customElements = window.customElements,
      usableCustomElements = !/^force/.test(polyfill.type) && !!(customElements && customElements.define && customElements.get && customElements.whenDefined),
      Dict = Object.create || Object,
      Map = window.Map || function Map() {
    var K = [],
        V = [],
        i;
    return {
      get: function get(k) {
        return V[indexOf.call(K, k)];
      },
      set: function set(k, v) {
        i = indexOf.call(K, k);
        if (i < 0) V[K.push(k) - 1] = v;else V[i] = v;
      }
    };
  },
      Promise = window.Promise || function (fn) {
    var notify = [],
        done = false,
        p = {
      catch: function _catch() {
        return p;
      },
      then: function then(cb) {
        notify.push(cb);
        if (done) setTimeout(resolve, 1);
        return p;
      }
    };

    function resolve(value) {
      done = true;

      while (notify.length) {
        notify.shift()(value);
      }
    }

    fn(resolve);
    return p;
  },
      justCreated = false,
      constructors = Dict(null),
      waitingList = Dict(null),
      nodeNames = new Map(),
      secondArgument = function secondArgument(is) {
    return is.toLowerCase();
  },
      create = Object.create || function Bridge(proto) {
    return proto ? (Bridge.prototype = proto, new Bridge()) : this;
  },
      setPrototype = sPO || (hasProto ? function (o, p) {
    o.__proto__ = p;
    return o;
  } : gOPN && gOPD ? function () {
    function setProperties(o, p) {
      for (var key, names = gOPN(p), i = 0, length = names.length; i < length; i++) {
        key = names[i];

        if (!hOP.call(o, key)) {
          defineProperty(o, key, gOPD(p, key));
        }
      }
    }

    return function (o, p) {
      do {
        setProperties(o, p);
      } while ((p = gPO(p)) && !iPO.call(p, o));

      return o;
    };
  }() : function (o, p) {
    for (var key in p) {
      o[key] = p[key];
    }

    return o;
  }),
      MutationObserver = window.MutationObserver || window.WebKitMutationObserver,
      HTMLElementPrototype = (window.HTMLElement || window.Element || window.Node).prototype,
      IE8 = !iPO.call(HTMLElementPrototype, documentElement),
      safeProperty = IE8 ? function (o, k, d) {
    o[k] = d.value;
    return o;
  } : defineProperty,
      isValidNode = IE8 ? function (node) {
    return node.nodeType === 1;
  } : function (node) {
    return iPO.call(HTMLElementPrototype, node);
  },
      targets = IE8 && [],
      attachShadow = HTMLElementPrototype.attachShadow,
      cloneNode = HTMLElementPrototype.cloneNode,
      dispatchEvent = HTMLElementPrototype.dispatchEvent,
      getAttribute = HTMLElementPrototype.getAttribute,
      hasAttribute = HTMLElementPrototype.hasAttribute,
      removeAttribute = HTMLElementPrototype.removeAttribute,
      setAttribute = HTMLElementPrototype.setAttribute,
      createElement = document.createElement,
      patchedCreateElement = createElement,
      attributesObserver = MutationObserver && {
    attributes: true,
    characterData: true,
    attributeOldValue: true
  },
      DOMAttrModified = MutationObserver || function (e) {
    doesNotSupportDOMAttrModified = false;
    documentElement.removeEventListener(DOM_ATTR_MODIFIED, DOMAttrModified);
  },
      asapQueue,
      asapTimer = 0,
      V0 = REGISTER_ELEMENT in document && !/^force-all/.test(polyfill.type),
      setListener = true,
      justSetup = false,
      doesNotSupportDOMAttrModified = true,
      dropDomContentLoaded = true,
      notFromInnerHTMLHelper = true,
      onSubtreeModified,
      callDOMAttrModified,
      getAttributesMirror,
      observer,
      observe,
      patchIfNotAlready,
      patch,
      tmp;

  if (MutationObserver) {
    tmp = document.createElement('div');
    tmp.innerHTML = '<div><div></div></div>';
    new MutationObserver(function (mutations, observer) {
      if (mutations[0] && mutations[0].type == 'childList' && !mutations[0].removedNodes[0].childNodes.length) {
        tmp = gOPD(HTMLElementPrototype, 'innerHTML');

        var _set = tmp && tmp.set;

        if (_set) defineProperty(HTMLElementPrototype, 'innerHTML', {
          set: function set(value) {
            while (this.lastChild) {
              this.removeChild(this.lastChild);
            }

            _set.call(this, value);
          }
        });
      }

      observer.disconnect();
      tmp = null;
    }).observe(tmp, {
      childList: true,
      subtree: true
    });
    tmp.innerHTML = '';
  }

  if (!V0) {
    if (sPO || hasProto) {
      patchIfNotAlready = function patchIfNotAlready(node, proto) {
        if (!iPO.call(proto, node)) {
          setupNode(node, proto);
        }
      };

      patch = setupNode;
    } else {
      patchIfNotAlready = function patchIfNotAlready(node, proto) {
        if (!node[EXPANDO_UID]) {
          node[EXPANDO_UID] = Object(true);
          setupNode(node, proto);
        }
      };

      patch = patchIfNotAlready;
    }

    if (IE8) {
      doesNotSupportDOMAttrModified = false;

      (function () {
        var descriptor = gOPD(HTMLElementPrototype, ADD_EVENT_LISTENER),
            addEventListener = descriptor.value,
            patchedRemoveAttribute = function patchedRemoveAttribute(name) {
          var e = new CustomEvent(DOM_ATTR_MODIFIED, {
            bubbles: true
          });
          e.attrName = name;
          e.prevValue = getAttribute.call(this, name);
          e.newValue = null;
          e[REMOVAL] = e.attrChange = 2;
          removeAttribute.call(this, name);
          dispatchEvent.call(this, e);
        },
            patchedSetAttribute = function patchedSetAttribute(name, value) {
          var had = hasAttribute.call(this, name),
              old = had && getAttribute.call(this, name),
              e = new CustomEvent(DOM_ATTR_MODIFIED, {
            bubbles: true
          });
          setAttribute.call(this, name, value);
          e.attrName = name;
          e.prevValue = had ? old : null;
          e.newValue = value;

          if (had) {
            e[MODIFICATION] = e.attrChange = 1;
          } else {
            e[ADDITION] = e.attrChange = 0;
          }

          dispatchEvent.call(this, e);
        },
            onPropertyChange = function onPropertyChange(e) {
          var node = e.currentTarget,
              superSecret = node[EXPANDO_UID],
              propertyName = e.propertyName,
              event;

          if (superSecret.hasOwnProperty(propertyName)) {
            superSecret = superSecret[propertyName];
            event = new CustomEvent(DOM_ATTR_MODIFIED, {
              bubbles: true
            });
            event.attrName = superSecret.name;
            event.prevValue = superSecret.value || null;
            event.newValue = superSecret.value = node[propertyName] || null;

            if (event.prevValue == null) {
              event[ADDITION] = event.attrChange = 0;
            } else {
              event[MODIFICATION] = event.attrChange = 1;
            }

            dispatchEvent.call(node, event);
          }
        };

        descriptor.value = function (type, handler, capture) {
          if (type === DOM_ATTR_MODIFIED && this[ATTRIBUTE_CHANGED_CALLBACK] && this.setAttribute !== patchedSetAttribute) {
            this[EXPANDO_UID] = {
              className: {
                name: 'class',
                value: this.className
              }
            };
            this.setAttribute = patchedSetAttribute;
            this.removeAttribute = patchedRemoveAttribute;
            addEventListener.call(this, 'propertychange', onPropertyChange);
          }

          addEventListener.call(this, type, handler, capture);
        };

        defineProperty(HTMLElementPrototype, ADD_EVENT_LISTENER, descriptor);
      })();
    } else if (!MutationObserver) {
      documentElement[ADD_EVENT_LISTENER](DOM_ATTR_MODIFIED, DOMAttrModified);
      documentElement.setAttribute(EXPANDO_UID, 1);
      documentElement.removeAttribute(EXPANDO_UID);

      if (doesNotSupportDOMAttrModified) {
        onSubtreeModified = function onSubtreeModified(e) {
          var node = this,
              oldAttributes,
              newAttributes,
              key;

          if (node === e.target) {
            oldAttributes = node[EXPANDO_UID];
            node[EXPANDO_UID] = newAttributes = getAttributesMirror(node);

            for (key in newAttributes) {
              if (!(key in oldAttributes)) {
                return callDOMAttrModified(0, node, key, oldAttributes[key], newAttributes[key], ADDITION);
              } else if (newAttributes[key] !== oldAttributes[key]) {
                return callDOMAttrModified(1, node, key, oldAttributes[key], newAttributes[key], MODIFICATION);
              }
            }

            for (key in oldAttributes) {
              if (!(key in newAttributes)) {
                return callDOMAttrModified(2, node, key, oldAttributes[key], newAttributes[key], REMOVAL);
              }
            }
          }
        };

        callDOMAttrModified = function callDOMAttrModified(attrChange, currentTarget, attrName, prevValue, newValue, action) {
          var e = {
            attrChange: attrChange,
            currentTarget: currentTarget,
            attrName: attrName,
            prevValue: prevValue,
            newValue: newValue
          };
          e[action] = attrChange;
          onDOMAttrModified(e);
        };

        getAttributesMirror = function getAttributesMirror(node) {
          for (var attr, name, result = {}, attributes = node.attributes, i = 0, length = attributes.length; i < length; i++) {
            attr = attributes[i];
            name = attr.name;

            if (name !== 'setAttribute') {
              result[name] = attr.value;
            }
          }

          return result;
        };
      }
    }

    document[REGISTER_ELEMENT] = function registerElement(type, options) {
      upperType = type.toUpperCase();

      if (setListener) {
        setListener = false;

        if (MutationObserver) {
          observer = function (attached, detached) {
            function checkEmAll(list, callback) {
              for (var i = 0, length = list.length; i < length; callback(list[i++])) {}
            }

            return new MutationObserver(function (records) {
              for (var current, node, newValue, i = 0, length = records.length; i < length; i++) {
                current = records[i];

                if (current.type === 'childList') {
                  checkEmAll(current.addedNodes, attached);
                  checkEmAll(current.removedNodes, detached);
                } else {
                  node = current.target;

                  if (notFromInnerHTMLHelper && node[ATTRIBUTE_CHANGED_CALLBACK] && current.attributeName !== 'style') {
                    newValue = getAttribute.call(node, current.attributeName);

                    if (newValue !== current.oldValue) {
                      node[ATTRIBUTE_CHANGED_CALLBACK](current.attributeName, current.oldValue, newValue);
                    }
                  }
                }
              }
            });
          }(executeAction(ATTACHED), executeAction(DETACHED));

          observe = function observe(node) {
            observer.observe(node, {
              childList: true,
              subtree: true
            });
            return node;
          };

          observe(document);

          if (attachShadow) {
            HTMLElementPrototype.attachShadow = function () {
              return observe(attachShadow.apply(this, arguments));
            };
          }
        } else {
          asapQueue = [];
          document[ADD_EVENT_LISTENER]('DOMNodeInserted', onDOMNode(ATTACHED));
          document[ADD_EVENT_LISTENER]('DOMNodeRemoved', onDOMNode(DETACHED));
        }

        document[ADD_EVENT_LISTENER](DOM_CONTENT_LOADED, onReadyStateChange);
        document[ADD_EVENT_LISTENER]('readystatechange', onReadyStateChange);

        HTMLElementPrototype.cloneNode = function (deep) {
          var node = cloneNode.call(this, !!deep),
              i = getTypeIndex(node);
          if (-1 < i) patch(node, protos[i]);
          if (deep && query.length) loopAndSetup(node.querySelectorAll(query));
          return node;
        };
      }

      if (justSetup) return justSetup = false;

      if (-2 < indexOf.call(types, PREFIX_IS + upperType) + indexOf.call(types, PREFIX_TAG + upperType)) {
        throwTypeError(type);
      }

      if (!validName.test(upperType) || -1 < indexOf.call(invalidNames, upperType)) {
        throw new Error('The type ' + type + ' is invalid');
      }

      var constructor = function constructor() {
        return extending ? document.createElement(nodeName, upperType) : document.createElement(nodeName);
      },
          opt = options || OP,
          extending = hOP.call(opt, EXTENDS),
          nodeName = extending ? options[EXTENDS].toUpperCase() : upperType,
          upperType,
          i;

      if (extending && -1 < indexOf.call(types, PREFIX_TAG + nodeName)) {
        throwTypeError(nodeName);
      }

      i = types.push((extending ? PREFIX_IS : PREFIX_TAG) + upperType) - 1;
      query = query.concat(query.length ? ',' : '', extending ? nodeName + '[is="' + type.toLowerCase() + '"]' : nodeName);
      constructor.prototype = protos[i] = hOP.call(opt, 'prototype') ? opt.prototype : create(HTMLElementPrototype);
      if (query.length) loopAndVerify(document.querySelectorAll(query), ATTACHED);
      return constructor;
    };

    document.createElement = patchedCreateElement = function patchedCreateElement(localName, typeExtension) {
      var is = getIs(typeExtension),
          node = is ? createElement.call(document, localName, secondArgument(is)) : createElement.call(document, localName),
          name = '' + localName,
          i = indexOf.call(types, (is ? PREFIX_IS : PREFIX_TAG) + (is || name).toUpperCase()),
          setup = -1 < i;

      if (is) {
        node.setAttribute('is', is = is.toLowerCase());

        if (setup) {
          setup = isInQSA(name.toUpperCase(), is);
        }
      }

      notFromInnerHTMLHelper = !document.createElement.innerHTMLHelper;
      if (setup) patch(node, protos[i]);
      return node;
    };
  }

  function ASAP() {
    var queue = asapQueue.splice(0, asapQueue.length);
    asapTimer = 0;

    while (queue.length) {
      queue.shift().call(null, queue.shift());
    }
  }

  function loopAndVerify(list, action) {
    for (var i = 0, length = list.length; i < length; i++) {
      verifyAndSetupAndAction(list[i], action);
    }
  }

  function loopAndSetup(list) {
    for (var i = 0, length = list.length, node; i < length; i++) {
      node = list[i];
      patch(node, protos[getTypeIndex(node)]);
    }
  }

  function executeAction(action) {
    return function (node) {
      if (isValidNode(node)) {
        verifyAndSetupAndAction(node, action);
        if (query.length) loopAndVerify(node.querySelectorAll(query), action);
      }
    };
  }

  function getTypeIndex(target) {
    var is = getAttribute.call(target, 'is'),
        nodeName = target.nodeName.toUpperCase(),
        i = indexOf.call(types, is ? PREFIX_IS + is.toUpperCase() : PREFIX_TAG + nodeName);
    return is && -1 < i && !isInQSA(nodeName, is) ? -1 : i;
  }

  function isInQSA(name, type) {
    return -1 < query.indexOf(name + '[is="' + type + '"]');
  }

  function onDOMAttrModified(e) {
    var node = e.currentTarget,
        attrChange = e.attrChange,
        attrName = e.attrName,
        target = e.target,
        addition = e[ADDITION] || 2,
        removal = e[REMOVAL] || 3;

    if (notFromInnerHTMLHelper && (!target || target === node) && node[ATTRIBUTE_CHANGED_CALLBACK] && attrName !== 'style' && (e.prevValue !== e.newValue || e.newValue === '' && (attrChange === addition || attrChange === removal))) {
      node[ATTRIBUTE_CHANGED_CALLBACK](attrName, attrChange === addition ? null : e.prevValue, attrChange === removal ? null : e.newValue);
    }
  }

  function onDOMNode(action) {
    var executor = executeAction(action);
    return function (e) {
      asapQueue.push(executor, e.target);
      if (asapTimer) clearTimeout(asapTimer);
      asapTimer = setTimeout(ASAP, 1);
    };
  }

  function onReadyStateChange(e) {
    if (dropDomContentLoaded) {
      dropDomContentLoaded = false;
      e.currentTarget.removeEventListener(DOM_CONTENT_LOADED, onReadyStateChange);
    }

    if (query.length) loopAndVerify((e.target || document).querySelectorAll(query), e.detail === DETACHED ? DETACHED : ATTACHED);
    if (IE8) purge();
  }

  function patchedSetAttribute(name, value) {
    var self = this;
    setAttribute.call(self, name, value);
    onSubtreeModified.call(self, {
      target: self
    });
  }

  function setupNode(node, proto) {
    setPrototype(node, proto);

    if (observer) {
      observer.observe(node, attributesObserver);
    } else {
      if (doesNotSupportDOMAttrModified) {
        node.setAttribute = patchedSetAttribute;
        node[EXPANDO_UID] = getAttributesMirror(node);
        node[ADD_EVENT_LISTENER](DOM_SUBTREE_MODIFIED, onSubtreeModified);
      }

      node[ADD_EVENT_LISTENER](DOM_ATTR_MODIFIED, onDOMAttrModified);
    }

    if (node[CREATED_CALLBACK] && notFromInnerHTMLHelper) {
      node.created = true;
      node[CREATED_CALLBACK]();
      node.created = false;
    }
  }

  function purge() {
    for (var node, i = 0, length = targets.length; i < length; i++) {
      node = targets[i];

      if (!documentElement.contains(node)) {
        length--;
        targets.splice(i--, 1);
        verifyAndSetupAndAction(node, DETACHED);
      }
    }
  }

  function throwTypeError(type) {
    throw new Error('A ' + type + ' type is already registered');
  }

  function verifyAndSetupAndAction(node, action) {
    var fn,
        i = getTypeIndex(node),
        counterAction;

    if (-1 < i) {
      patchIfNotAlready(node, protos[i]);
      i = 0;

      if (action === ATTACHED && !node[ATTACHED]) {
        node[DETACHED] = false;
        node[ATTACHED] = true;
        counterAction = 'connected';
        i = 1;

        if (IE8 && indexOf.call(targets, node) < 0) {
          targets.push(node);
        }
      } else if (action === DETACHED && !node[DETACHED]) {
        node[ATTACHED] = false;
        node[DETACHED] = true;
        counterAction = 'disconnected';
        i = 1;
      }

      if (i && (fn = node[action + CALLBACK] || node[counterAction + CALLBACK])) fn.call(node);
    }
  }

  function CustomElementRegistry() {}

  CustomElementRegistry.prototype = {
    constructor: CustomElementRegistry,
    define: usableCustomElements ? function (name, Class, options) {
      if (options) {
        CERDefine(name, Class, options);
      } else {
        var NAME = name.toUpperCase();
        constructors[NAME] = {
          constructor: Class,
          create: [NAME]
        };
        nodeNames.set(Class, NAME);
        customElements.define(name, Class);
      }
    } : CERDefine,
    get: usableCustomElements ? function (name) {
      return customElements.get(name) || get(name);
    } : get,
    whenDefined: usableCustomElements ? function (name) {
      return Promise.race([customElements.whenDefined(name), whenDefined(name)]);
    } : whenDefined
  };

  function CERDefine(name, Class, options) {
    var is = options && options[EXTENDS] || '',
        CProto = Class.prototype,
        proto = create(CProto),
        attributes = Class.observedAttributes || empty,
        definition = {
      prototype: proto
    };
    safeProperty(proto, CREATED_CALLBACK, {
      value: function value() {
        if (justCreated) justCreated = false;else if (!this[DRECEV1]) {
          this[DRECEV1] = true;
          new Class(this);
          if (CProto[CREATED_CALLBACK]) CProto[CREATED_CALLBACK].call(this);
          var info = constructors[nodeNames.get(Class)];

          if (!usableCustomElements || info.create.length > 1) {
            notifyAttributes(this);
          }
        }
      }
    });
    safeProperty(proto, ATTRIBUTE_CHANGED_CALLBACK, {
      value: function value(name) {
        if (-1 < indexOf.call(attributes, name)) CProto[ATTRIBUTE_CHANGED_CALLBACK].apply(this, arguments);
      }
    });

    if (CProto[CONNECTED_CALLBACK]) {
      safeProperty(proto, ATTACHED_CALLBACK, {
        value: CProto[CONNECTED_CALLBACK]
      });
    }

    if (CProto[DISCONNECTED_CALLBACK]) {
      safeProperty(proto, DETACHED_CALLBACK, {
        value: CProto[DISCONNECTED_CALLBACK]
      });
    }

    if (is) definition[EXTENDS] = is;
    name = name.toUpperCase();
    constructors[name] = {
      constructor: Class,
      create: is ? [is, secondArgument(name)] : [name]
    };
    nodeNames.set(Class, name);
    document[REGISTER_ELEMENT](name.toLowerCase(), definition);
    whenDefined(name);
    waitingList[name].r();
  }

  function get(name) {
    var info = constructors[name.toUpperCase()];
    return info && info.constructor;
  }

  function getIs(options) {
    return typeof options === 'string' ? options : options && options.is || '';
  }

  function notifyAttributes(self) {
    var callback = self[ATTRIBUTE_CHANGED_CALLBACK],
        attributes = callback ? self.attributes : empty,
        i = attributes.length,
        attribute;

    while (i--) {
      attribute = attributes[i];
      callback.call(self, attribute.name || attribute.nodeName, null, attribute.value || attribute.nodeValue);
    }
  }

  function whenDefined(name) {
    name = name.toUpperCase();

    if (!(name in waitingList)) {
      waitingList[name] = {};
      waitingList[name].p = new Promise(function (resolve) {
        waitingList[name].r = resolve;
      });
    }

    return waitingList[name].p;
  }

  function polyfillV1() {
    if (customElements) delete window.customElements;
    defineProperty(window, 'customElements', {
      configurable: true,
      value: new CustomElementRegistry()
    });
    defineProperty(window, 'CustomElementRegistry', {
      configurable: true,
      value: CustomElementRegistry
    });

    for (var patchClass = function patchClass(name) {
      var Class = window[name];

      if (Class) {
        window[name] = function CustomElementsV1(self) {
          var info, isNative;
          if (!self) self = this;

          if (!self[DRECEV1]) {
            justCreated = true;
            info = constructors[nodeNames.get(self.constructor)];
            isNative = usableCustomElements && info.create.length === 1;
            self = isNative ? Reflect.construct(Class, empty, info.constructor) : document.createElement.apply(document, info.create);
            self[DRECEV1] = true;
            justCreated = false;
            if (!isNative) notifyAttributes(self);
          }

          return self;
        };

        window[name].prototype = Class.prototype;

        try {
          Class.prototype.constructor = window[name];
        } catch (WebKit) {
          defineProperty(Class, DRECEV1, {
            value: window[name]
          });
        }
      }
    }, Classes = htmlClass.get(/^HTML[A-Z]*[a-z]/), i = Classes.length; i--; patchClass(Classes[i])) {}

    document.createElement = function (name, options) {
      var is = getIs(options);
      return is ? patchedCreateElement.call(this, name, secondArgument(is)) : patchedCreateElement.call(this, name);
    };

    if (!V0) {
      justSetup = true;
      document[REGISTER_ELEMENT]('');
    }
  }

  if (!customElements || /^force/.test(polyfill.type)) polyfillV1();else if (!polyfill.noBuiltIn) {
    try {
      ;

      (function (DRE, options, name) {
        options[EXTENDS] = 'a';
        DRE.prototype = create(HTMLAnchorElement.prototype);
        DRE.prototype.constructor = DRE;
        window.customElements.define(name, DRE, options);

        if (getAttribute.call(document.createElement('a', {
          is: name
        }), 'is') !== name || usableCustomElements && getAttribute.call(new DRE(), 'is') !== name) {
          throw options;
        }
      })(function DRE() {
        return Reflect.construct(HTMLAnchorElement, [], DRE);
      }, {}, 'document-register-element-a');
    } catch (o_O) {
      polyfillV1();
    }
  }

  if (!polyfill.noBuiltIn) {
    try {
      createElement.call(document, 'a', 'a');
    } catch (FireFox) {
      secondArgument = function secondArgument(is) {
        return {
          is: is.toLowerCase()
        };
      };
    }
  }
}

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$1(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$1() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var isTest = "production" === 'test';
var hasPolyfill = isTest;
var registeredElements = typeof window !== 'undefined' && (window.registeredElements = window.registeredElements || []) || [];
var registerElement = function registerElement(tagName, ReactComponent) {
  var propNames = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

  var _ref = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {},
      _ref$attributesExclud = _ref.attributesExcludelist,
      attributesExcludelist = _ref$attributesExclud === void 0 ? ['id'] : _ref$attributesExclud;

  if (!tagName) tagName = ReactComponent.displayName || ReactComponent.name;
  if (registeredElements.indexOf(tagName) !== -1) return;
  registeredElements.push(tagName);

  if (typeof document === 'undefined' || typeof window === 'undefined') {
    return null;
  }

  if (!hasPolyfill) {
    hasPolyfill = true;
    installCustomElements(window);
  }

  if (propNames) {
    propNames = prepareDefaultProps(propNames);
  }

  var HtmlClass = function (_HTMLElement) {
    _inherits(HtmlClass, _HTMLElement);

    var _super = _createSuper(HtmlClass);

    _createClass(HtmlClass, null, [{
      key: "observedAttributes",
      get: function get() {
        return propNames || [];
      }
    }]);

    function HtmlClass(props) {
      var _this;

      _classCallCheck(this, HtmlClass);

      _this = _super.call(this, props);
      _this._elementRef = react.createRef();
      _this._customMethodes = {};
      _this._customEvents = [];
      _this._isConnected = false;
      _this._props = {};
      return _this;
    }

    _createClass(HtmlClass, [{
      key: "connectedCallback",
      value: function connectedCallback() {
        this.updateChildren();
        this.renderElement();
        this._isConnected = true;
      }
    }, {
      key: "attributeChangedCallback",
      value: function attributeChangedCallback(attrName, oldAttr, newAttr) {
        if (!this._isConnected || oldAttr === newAttr) {
          return false;
        }

        this.renderElement();
        return newAttr;
      }
    }, {
      key: "disconnectedCallback",
      value: function disconnectedCallback() {
        {
          reactDom.unmountComponentAtNode(this);
        }

        if (this._children) delete this._children;
        if (this._isConnected) delete this._isConnected;
        if (this._elementRef) delete this._elementRef;
        if (this._customMethodes) delete this._customMethodes;
        if (this._customEvents) delete this._customEvents;
        this._props = null;
        this._ref = null;
      }
    }, {
      key: "updateChildren",
      value: function updateChildren() {
        this._children = [];
        var i,
            cn = this.childNodes,
            v;

        for (i = cn.length; i--;) {
          v = toVdom(cn[i]);

          if (v) {
            this._children.push(v);
          }
        }
      }
    }, {
      key: "connectEvents",
      value: function connectEvents() {
        var props = {};

        for (var i = this.attributes.length; i--;) {
          props[this.attributes[i].name] = this.attributes[i].value;
        }

        if (props.events) {
          props.event = props.events;
          delete props.events;
        }

        var events = [].concat(_toConsumableArray$1(props.event ? props.event.split(',') : []), _toConsumableArray$1(Object.entries(props).map(function (_ref2) {
          var _ref3 = _slicedToArray$1(_ref2, 2),
              key = _ref3[0],
              value = _ref3[1];

          if (key && /^(on_|on[A-Z]|render_)/.test(key)) {
            return key + '=' + value;
          }

          return null;
        }).filter(Boolean)));

        if (events.length > 0) {
          events.forEach(function (eventDef) {
            var _eventDef$split = eventDef.split('='),
                _eventDef$split2 = _slicedToArray$1(_eventDef$split, 2),
                type = _eventDef$split2[0],
                func = _eventDef$split2[1];

            type = EVENT_TRANSLATIONS[type] || type;

            props[type] = function () {
              try {
                var _func$split = func.split('.'),
                    _func$split2 = _slicedToArray$1(_func$split, 2),
                    scope = _func$split2[0],
                    fn = _func$split2[1];

                fn = fn ? window[scope][fn] : window[scope];

                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                  args[_key] = arguments[_key];
                }

                var component = fn.apply(scope, [].concat(args));

                if (component instanceof HTMLElement) {
                  var children = [],
                      cn = component.childNodes,
                      a = component.attributes,
                      _props = {};

                  for (var _i = cn.length; _i--;) {
                    children.push(toVdom(cn[_i]));
                  }

                  for (var _i2 = a.length; _i2--;) {
                    _props[PROP_TRANSLATIONS[a[_i2].name] || a[_i2].name] = a[_i2].value;
                  }

                  var nodeName = component.nodeName.toLowerCase();
                  component.remove();
                  return react.createElement(nodeName, _props, children);
                }

                return component;
              } catch (error) {
                new ErrorHandler("The '".concat(type, "' event has failed. '").concat(func, "' has to exist on a 'window' scope!"), error);
              }
            };
          });
          delete props.event;
        }

        return props;
      }
    }, {
      key: "setProps",
      value: function setProps(props, value) {
        if (typeof props === 'string') {
          props = _defineProperty({}, props, value);
        }

        return this.renderElement(props);
      }
    }, {
      key: "getRef",
      value: function getRef() {
        return this._ref;
      }
    }, {
      key: "addEvent",
      value: function addEvent(eventName, eventCallback) {
        var _this2 = this,
            _this$_customEvents;

        var eventWrapper = function eventWrapper(event) {
          return eventCallback.apply(_this2, [event]);
        };

        (_this$_customEvents = this._customEvents) === null || _this$_customEvents === void 0 ? void 0 : _this$_customEvents.push({
          eventName: eventName,
          eventCallback: eventCallback,
          eventWrapper: eventWrapper
        });
        return eventWrapper;
      }
    }, {
      key: "removeEvent",
      value: function removeEvent(eventId) {
        var removeCallback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
        this._customEvents = this._customEvents.reduce(function (accumulator, current) {
          if (removeCallback) {
            var eventWrapper = current.eventCallback;

            if (eventWrapper !== removeCallback) {
              accumulator.push(current);
            }
          } else {
            var _eventWrapper = current.eventWrapper;

            if (_eventWrapper !== eventId) {
              accumulator.push(current);
            }
          }

          return accumulator;
        }, []);
      }
    }, {
      key: "fireEvent",
      value: function fireEvent(eventName) {
        var _this3 = this;

        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }

        this._customEvents.forEach(function (_ref4) {
          var name = _ref4.eventName,
              eventCallback = _ref4.eventCallback;

          if (name === eventName && typeof eventCallback === 'function') {
            eventCallback.apply(_this3, [].concat(args));
          }
        });
      }
    }, {
      key: "renderElement",
      value: function renderElement() {
        var _this4 = this;

        var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        props = _extends({}, this._props, this.connectEvents(), props);

        for (var p in props) {
          if (props[p] === 'true') {
            props[p] = true;
          } else if (props[p] === 'false') {
            props[p] = false;
          } else if (typeof props[p] !== 'undefined' && props[p] !== null && !isNaN(Number(props[p]))) {
            props[p] = Number(props[p]);
          }
        }

        for (var i = attributesExcludelist.length; i--;) {
          if (props[attributesExcludelist[i]]) {
            this.removeAttribute(attributesExcludelist[i]);
          }
        }

        if (this._children && this._children.length > 0) {
          props.children = this._children;
        }

        if (this._elementRef) {
          props.ref = this._elementRef;
        }

        if (!props.custom_element) {
          props.custom_element = this;
        }

        if (!props.custom_method) {
          props.custom_method = function (methodName, methodFunc) {
            _this4[methodName] = _this4._customMethodes[methodName] = methodFunc;
          };
        }

        this._props = props;
        this._ref = react.createElement(ReactComponent, props);
        reactDom.render(this._ref, this);
        return this;
      }
    }]);

    return HtmlClass;
  }(_wrapNativeSuper(HTMLElement));

  return window.customElements.define(tagName, HtmlClass);
};

var filterProps = function filterProps(key) {
  return key && !/[A-Z]/.test(key) && !/children/.test(key);
};

var prepareDefaultProps = function prepareDefaultProps(defaultProps) {
  return Array.isArray(defaultProps) ? defaultProps.filter(filterProps) : Object.entries(defaultProps || {}).reduce(function (props, _ref5) {
    var _ref6 = _slicedToArray$1(_ref5, 1),
        key = _ref6[0];

    props.push(key);
    return props;
  }, []).filter(filterProps);
};

var toVdom = function toVdom(elem) {
  var name = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  if (elem.nodeType === 3) return elem.nodeValue;
  if (elem.nodeType !== 1) return null;
  var children = [],
      props = {},
      i = 0,
      a = elem.attributes,
      cn = elem.childNodes;

  for (i = a.length; i--;) {
    props[a[i].name] = a[i].value;
  }

  for (i = cn.length; i--;) {
    children[i] = toVdom(cn[i]);
  }

  props.key = "key".concat(Math.random() * 1000);
  return react.createElement(name || elem.nodeName.toLowerCase(), props, children);
};

var PROP_TRANSLATIONS = {
  class: 'className',
  for: 'htmlFor'
};
var EVENT_TRANSLATIONS = {
  onclick: 'onClick'
};

var PLATFORM_MAC = 'Mac|iPad|iPhone|iPod';
var PLATFORM_WIN = 'Win';
var PLATFORM_LINUX = 'Linux';
var PLATFORM_IOS = 'iOS|iPhone|iPad|iPod';

if (typeof process !== 'undefined' && "production" === 'test' && typeof window !== 'undefined') {
  window.IS_TEST = true;
}

whatInput.specificKeys([9]);
defineNavigator();
function defineNavigator() {
  var handleNavigator = function handleNavigator() {
    if (typeof document === 'undefined' || typeof window === 'undefined' || typeof navigator === 'undefined') {
      return;
    }

    try {
      if (!(typeof window !== 'undefined' && window.IS_TEST)) {
        if (navigator.platform.match(new RegExp(PLATFORM_MAC)) !== null) {
          document.documentElement.setAttribute('data-os', 'mac');
        } else if (navigator.platform.match(new RegExp(PLATFORM_WIN)) !== null) {
          document.documentElement.setAttribute('data-os', 'win');
        } else if (navigator.platform.match(new RegExp(PLATFORM_LINUX)) !== null) {
          document.documentElement.setAttribute('data-os', 'linux');
        }
      } else {
        document.documentElement.setAttribute('data-os', 'other');
      }
    } catch (e) {
      warn(e);
    }

    document.removeEventListener('DOMContentLoaded', handleNavigator);
  };

  if (typeof document !== 'undefined' && document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', handleNavigator);
  } else {
    handleNavigator();
  }
}
var validateDOMAttributes = function validateDOMAttributes(props, params) {
  if (props && props.attributes) {
    var attr = props.attributes;

    if (attr) {
      if (attr[0] === '{') attr = JSON.parse(attr);

      if (attr && _typeof(attr) === 'object') {
        Object.entries(attr).forEach(function (_ref) {
          var _ref2 = _slicedToArray$1(_ref, 2),
              key = _ref2[0],
              value = _ref2[1];

          _extends(params, _defineProperty({}, key, value));
        });
      }
    }
  }

  if (params.disabled === null || params.disabled === 'false') {
    delete params.disabled;
  }

  if (typeof params.space !== 'undefined') {
    delete params.space;
  }

  if (typeof params.top !== 'undefined') {
    delete params.top;
  }

  if (typeof params.right !== 'undefined') {
    delete params.right;
  }

  if (typeof params.bottom !== 'undefined') {
    delete params.bottom;
  }

  if (typeof params.left !== 'undefined') {
    delete params.left;
  }

  if (typeof params.no_collapse !== 'undefined') {
    delete params.no_collapse;
  } else if (params.disabled === 'true') {
      params.disabled = true;
    }

  if (params.disabled === true) {
    params['aria-disabled'] = true;
  }

  if (props && props.tabindex) {
    var tabIndex = props.tabindex;

    if (tabIndex === 'off') {
      tabIndex = '-1';
    }

    params['tabIndex'] = tabIndex;
  }

  if (params && _typeof(params) === 'object') {
    for (var i in params) {
      if (typeof params[i] === 'function' && !/(^[a-z]{1,}[A-Z]{1})/.test(i)) {
        delete params[i];
      } else if (params[i] === null || /[^a-z-]/i.test(i)) {
          delete params[i];
        }
    }
  }

  return params;
};
var processChildren = function processChildren(props) {
  if (!props) {
    return null;
  }

  if (typeof global$1 !== 'undefined' && Array.isArray(global$1.registeredElements) && global$1.registeredElements.length > 0) {
    var cache = null;
    Object.entries(props).reverse().map(function (_ref3) {
      var _ref4 = _slicedToArray$1(_ref3, 2),
          key = _ref4[0],
          cb = _ref4[1];

      if (key.includes('render_') && /^render_/.test(key)) {
        if (typeof cb === 'function') {
          if (cache) {
            if (Object.isFrozen(props)) {
              props = _extends({}, props);
            }

            props.children = cache;
          }

          return cache = react.createElement(react.Fragment, {
            key: key
          }, cb(props));
        }
      }

      return null;
    }).filter(Boolean);

    if (cache) {
      return cache;
    }
  }

  var res = typeof props.children === 'function' ? props.children(props) : props.children;

  if (Array.isArray(res)) {
    var onlyTexts = res.reduce(function (pV, cV) {
      if (typeof cV === 'string' || typeof cV === 'number') {
        pV.push(cV);
      }

      return pV;
    }, []);

    if (onlyTexts.length === res.length && onlyTexts.length > 0) {
      return onlyTexts.join('');
    }
  }

  return res;
};
var extend = function extend() {
  var first = {};

  for (var _len = arguments.length, objects = new Array(_len), _key = 0; _key < _len; _key++) {
    objects[_key] = arguments[_key];
  }

  var keepRef = objects[0];

  if (keepRef === true || keepRef === false) {
    objects.shift();

    if (keepRef) {
      first = objects.shift();
    }
  }

  return objects.reduce(function (acc1, object) {
    if (object) {
      acc1 = _extends(acc1, Object.entries(object).reduce(function (acc2, _ref5) {
        var _ref6 = _slicedToArray$1(_ref5, 2),
            key = _ref6[0],
            value = _ref6[1];

        if (value !== null) {
          if (_typeof(value) === 'object') {
            value = extend(acc1[key] || {}, value);

            if (Object.keys(value).length > 0) {
              acc2[key] = value;
            }
          } else {
            acc2[key] = value;
          }
        }

        return acc2;
      }, {}));
    }

    return acc1;
  }, first);
};
var extendPropsWithContext = function extendPropsWithContext(props) {
  var defaults = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  for (var _len2 = arguments.length, contexts = new Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
    contexts[_key2 - 2] = arguments[_key2];
  }

  var context = contexts.reduce(function (acc, cur) {
    if (cur) {
      acc = _extends({}, acc, cur);
    }

    return acc;
  }, {});
  return _extends({}, props, Object.entries(context).reduce(function (acc, _ref7) {
    var _ref8 = _slicedToArray$1(_ref7, 2),
        key = _ref8[0],
        value = _ref8[1];

    if (typeof props[key] !== 'undefined' && props[key] === defaults[key]) {
      acc[key] = value;
    }

    return acc;
  }, {}));
};
var isTrue = function isTrue(value) {
  if (value !== null && typeof value !== 'undefined' && (String(value) === 'true' || String(value) === '1')) {
    return true;
  }

  return false;
};
var dispatchCustomElementEvent = function dispatchCustomElementEvent(src, eventName, eventObjectOrig) {
  var ret = undefined;

  var eventObject = _extends({}, eventObjectOrig.event || {}, eventObjectOrig);

  if (eventObject && eventObject.attributes && eventObject.event) {
    var currentTarget = eventObject.event.currentTarget;

    if (currentTarget) {
      try {
        var dataset = _extends({}, currentTarget.dataset || {});

        var attributes = _extends({}, eventObject.attributes);

        for (var i in attributes) {
          if (/^data-/.test(i)) {
            dataset[String(i).replace(/^data-/, '')] = attributes[i];
          }
        }

        for (var _i in dataset) {
          if (eventObject.event.currentTarget.dataset) {
            eventObject.event.currentTarget.dataset[_i] = dataset[_i];
          }

          if (eventObject.event.target && eventObject.event.target.dataset) {
            eventObject.event.target.dataset[_i] = dataset[_i];
          }
        }
      } catch (e) {
        warn('Error on handling dataset:', e);
      }
    }
  }

  var props = src && src.props || src;

  if (props.custom_element) {
    if (typeof props.custom_element.fireEvent === 'function') {
      ret = props.custom_element.fireEvent(eventName, eventObject);
    }
  }

  if (eventName.includes('_')) {
    if (typeof props[eventName] === 'function') {
      var r = props[eventName].apply(src, [eventObject]);

      if (typeof r !== 'undefined') {
        ret = r;
      }
    }

    eventName = toCamelCase(eventName);

    if (typeof props[eventName] === 'function') {
      var _r = props[eventName].apply(src, [eventObject]);

      if (typeof _r !== 'undefined') {
        ret = _r;
      }
    }
  } else {
    if (typeof props[eventName] === 'function') {
      var _r2 = props[eventName].apply(src, [eventObject]);

      if (typeof _r2 !== 'undefined') {
        ret = _r2;
      }
    }

    eventName = toSnakeCase(eventName);

    if (typeof props[eventName] === 'function') {
      var _r3 = props[eventName].apply(src, [eventObject]);

      if (typeof _r3 !== 'undefined') {
        ret = _r3;
      }
    }
  }

  return ret;
};
var toCamelCase = function toCamelCase(s) {
  return s.split(/_/g).reduce(function (acc, cur, i) {
    return acc + (i === 0 ? cur : cur.replace(/(\w)(\w*)/g, function (g0, g1, g2) {
      return g1.toUpperCase() + g2.toLowerCase();
    }));
  }, '');
};
var toSnakeCase = function toSnakeCase(str) {
  return str.replace(/\B[A-Z]/g, function (letter) {
    return "_".concat(letter);
  }).toLowerCase();
};
var detectOutsideClick = function detectOutsideClick(ignoreElements, onSuccess, options) {
  return new DetectOutsideClickClass(ignoreElements, onSuccess, options);
};
var DetectOutsideClickClass = function () {
  function DetectOutsideClickClass(_ignoreElements, _onSuccess) {
    var _this = this;

    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    _classCallCheck(this, DetectOutsideClickClass);

    this.checkOutsideClick = function (_ref9) {
      var currentElement = _ref9.currentElement,
          ignoreElements = _ref9.ignoreElements;
      var onSuccess = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      try {
        if (typeof currentElement.tagName === 'undefined' || /html/i.test(currentElement.tagName)) {
            return;
          }

        if (checkIfHasScrollbar(currentElement)) {
          return;
        }

        for (var i = 0, elem, l = ignoreElements.length; i < l; ++i) {
          elem = currentElement;

          if (!ignoreElements[i]) {
            continue;
          }

          do {
            if (elem === ignoreElements[i]) {
              return;
            }

            elem = elem && elem.parentNode;
          } while (elem);
        }

        if (typeof onSuccess === 'function') {
          onSuccess();
        }
      } catch (e) {
        warn(e);
      }
    };

    if (!this.handleClickOutside && typeof document !== 'undefined' && typeof window !== 'undefined') {
      if (!Array.isArray(_ignoreElements)) {
        _ignoreElements = [_ignoreElements];
      }

      this.handleClickOutside = function (event) {
        _this.checkOutsideClick({
          currentElement: event.target,
          ignoreElements: _ignoreElements
        }, function () {
          return typeof _onSuccess === 'function' && _onSuccess({
            event: event
          });
        });
      };

      document.addEventListener('mousedown', this.handleClickOutside);

      this.keydownCallback = function (event) {
        var keyCode = keycode(event);

        if (keyCode === 'esc') {
          window.removeEventListener('keydown', _this.keydownCallback);

          if (typeof _onSuccess === 'function') {
            _onSuccess({
              event: event
            });
          }
        }
      };

      window.addEventListener('keydown', this.keydownCallback);

      if (options.includedKeys) {
        this.keyupCallback = function (event) {
          var keyCode = keycode(event);

          if (options.includedKeys.includes(keyCode) && typeof _this.handleClickOutside === 'function') {
            _this.handleClickOutside(event, function () {
              if (_this.keyupCallback) window.removeEventListener('keyup', _this.keyupCallback);
            });
          }
        };

        window.addEventListener('keyup', this.keyupCallback);
      }
    }
  }

  _createClass(DetectOutsideClickClass, [{
    key: "remove",
    value: function remove() {
      if (this.handleClickOutside && typeof document !== 'undefined') {
        document.removeEventListener('mousedown', this.handleClickOutside);
        this.handleClickOutside = null;
      }

      if (this.keydownCallback && typeof window !== 'undefined') {
        window.removeEventListener('keydown', this.keydownCallback);
        this.keydownCallback = null;
      }

      if (this.keyupCallback && typeof window !== 'undefined') {
        window.removeEventListener('keyup', this.keyupCallback);
        this.keyupCallback = null;
      }
    }
  }]);

  return DetectOutsideClickClass;
}();
var checkIfHasScrollbar = function checkIfHasScrollbar(elem) {
  return elem && (elem.scrollHeight > elem.offsetHeight || elem.scrollWidth > elem.offsetWidth) && overflowIsScrollable(elem);
};

var overflowIsScrollable = function overflowIsScrollable(elem) {
  var style = window.getComputedStyle(elem);
  return /scroll|auto/i.test(style.overflow + (style.overflowX || '') + (style.overflowY || ''));
};
var makeUniqueId = function makeUniqueId() {
  var prefix = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var length = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 8;
  return prefix + String(Math.random().toString(36).substr(2, length) + idIncrement++).slice(-length);
};
var idIncrement = 0;
var getPreviousSibling = function getPreviousSibling(className, element) {
  try {
    var contains = function contains(element) {
      return element && element.classList.contains(className);
    };

    if (contains(element)) {
      return element;
    }

    while ((element = element && element.parentElement) && !contains(element)) {
      ;
    }
  } catch (e) {
    warn(e);
  }

  return element;
};
var isChildOfElement = function isChildOfElement(element, target) {
  var cb = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

  try {
    var contains = function contains(element) {
      if (cb) {
        var res = cb(element);

        if (typeof res === 'boolean') {
          return res;
        }
      }

      return element && element === target;
    };

    if (contains(element)) {
      return element;
    }

    while ((element = element && element.parentElement) && !contains(element)) {
      ;
    }
  } catch (e) {}

  return element;
};
var roundToNearest = function roundToNearest(num, target) {
  var diff = num % target;
  return diff > target / 2 ? num - diff + target : num - diff;
};
var isInsideScrollView = function isInsideScrollView(currentElement) {
  var returnElement = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var elem = getPreviousSibling('dnb-scroll-view', currentElement);

  if (returnElement) {
    return elem == window ? null : elem;
  }

  return elem == window ? false : Boolean(elem);
};
var warn = function warn() {
  if (typeof process !== 'undefined' && typeof console !== 'undefined' && "production" !== 'production' && typeof console.log === 'function') {
    var _console;

    for (var _len3 = arguments.length, e = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      e[_key3] = arguments[_key3];
    }

    (_console = console).log.apply(_console, ['Eufemia:'].concat(e));
  }
};
var convertJsxToString = function convertJsxToString(elements) {
  var separator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : undefined;

  if (!Array.isArray(elements)) {
    elements = [elements];
  }

  var process = function process(word) {
    if (react.isValidElement(word)) {
      if (typeof word.props.children === 'string') {
        word = word.props.children;
      } else if (Array.isArray(word.props.children)) {
        word = word.props.children.reduce(function (acc, word) {
          if (typeof word !== 'string') {
            word = process(word);
          }

          if (typeof word === 'string') {
            acc = acc + word;
          }

          return acc;
        }, '');
      } else {
        return null;
      }
    }

    return word;
  };

  return elements.map(function (word) {
    return process(word);
  }).filter(Boolean).join(separator);
};
var InteractionInvalidation = function () {
  function InteractionInvalidation() {
    _classCallCheck(this, InteractionInvalidation);

    this.bypassElement = null;
    this.bypassSelectors = [];
    return this;
  }

  _createClass(InteractionInvalidation, [{
    key: "setBypassElement",
    value: function setBypassElement(bypassElement) {
      if (bypassElement instanceof HTMLElement) {
        this.bypassElement = bypassElement;
      }

      return this;
    }
  }, {
    key: "setBypassSelector",
    value: function setBypassSelector(bypassSelector) {
      if (!Array.isArray(bypassSelector)) {
        bypassSelector = [bypassSelector];
      }

      this.bypassSelectors = bypassSelector;
      return this;
    }
  }, {
    key: "activate",
    value: function activate() {
      var targetElement = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (!this.nodesToInvalidate) {
        this._runInvalidaiton(targetElement);
      }
    }
  }, {
    key: "revert",
    value: function revert() {
      this._revertInvalidation();

      this.nodesToInvalidate = null;
    }
  }, {
    key: "_runInvalidaiton",
    value: function _runInvalidaiton(targetElement) {
      if (typeof document === 'undefined') {
          return;
        }

      this._setNodesToInvalidate(targetElement);

      if (Array.isArray(this.nodesToInvalidate)) {
        this.nodesToInvalidate.forEach(function (node) {
          try {
            if (node && typeof node._orig_tabindex === 'undefined' && node.hasAttribute('tabindex')) {
              node._orig_tabindex = node.getAttribute('tabindex');
            }

            if (node && typeof node._orig_ariahidden === 'undefined' && node.hasAttribute('aria-hidden')) {
              node._orig_ariahidden = node.getAttribute('aria-hidden');
            }

            node.setAttribute('tabindex', '-1');
            node.setAttribute('aria-hidden', 'true');
          } catch (e) {}
        });
      }
    }
  }, {
    key: "_revertInvalidation",
    value: function _revertInvalidation() {
      if (!this.nodesToInvalidate) {
        return;
      }

      this.nodesToInvalidate.forEach(function (node) {
        try {
          if (node && typeof node._orig_tabindex !== 'undefined') {
            node.setAttribute('tabindex', node._orig_tabindex);
            node._orig_tabindex = null;
            delete node._orig_tabindex;
          } else {
            node.removeAttribute('tabindex');
          }

          if (node && typeof node._orig_ariahidden !== 'undefined') {
            node.setAttribute('aria-hidden', node._orig_ariahidden);
            node._orig_ariahidden = null;
            delete node._orig_ariahidden;
          } else {
            node.removeAttribute('aria-hidden');
          }
        } catch (e) {}
      });
    }
  }, {
    key: "_setNodesToInvalidate",
    value: function _setNodesToInvalidate() {
      var targetElement = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (typeof document === 'undefined') {
        return;
      }

      if (typeof targetElement === 'string') {
        targetElement = document.querySelector(targetElement);
      }

      var skipTheseNodes = this.bypassSelectors && this.bypassSelectors.length > 0 ? Array.from((this.bypassElement || document).querySelectorAll(this.bypassSelectors ? this.bypassSelectors.map(function (s) {
        return "".concat(s, " *");
      }).join(', ') : '*')) : [];
      this.nodesToInvalidate = Array.from((targetElement || document).querySelectorAll("body *".concat(this.bypassSelectors.map(function (s) {
        return ":not(".concat(s, ")");
      }).join(''), ":not(script):not(style):not(path)"))).filter(function (node) {
        return !skipTheseNodes.includes(node);
      });
    }
  }]);

  return InteractionInvalidation;
}();
var AnimateHeight = function () {
  function AnimateHeight() {
    var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, AnimateHeight);

    this.state = 'init';
    this.onStartStack = [];
    this.onEndStack = [];
    this.opts = opts;
  }

  _createClass(AnimateHeight, [{
    key: "setElem",
    value: function setElem(elem) {
      var _this$elem,
          _this2 = this;

      var container = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      this.elem = elem || typeof document !== 'undefined' && document.createElement('div');

      if (String((_this$elem = this.elem) === null || _this$elem === void 0 ? void 0 : _this$elem.nodeName).toLowerCase() === 'td') {
        this.elem = this.elem.parentElement;
      }

      this.container = container;

      if (this.container) {
        this.onResize = function () {
          clearTimeout(_this2.resizeTimeout);
          _this2.resizeTimeout = setTimeout(function () {
            return _this2.setContainerHeight();
          }, 300);
        };

        window.addEventListener('resize', this.onResize);
      }
    }
  }, {
    key: "removeEndEvents",
    value: function removeEndEvents() {
      if (this.onOpenEnd) {
        this.elem.removeEventListener('transitionend', this.onOpenEnd);
        this.onOpenEnd = null;
      }

      if (this.onAdjustEnd) {
        this.elem.removeEventListener('transitionend', this.onAdjustEnd);
        this.onAdjustEnd = null;
      }

      if (this.onCloseEnd) {
        this.elem.removeEventListener('transitionend', this.onCloseEnd);
        this.onCloseEnd = null;
      }
    }
  }, {
    key: "remove",
    value: function remove() {
      this.removeEndEvents();
      this.isAnimating = false;
      this.onStartStack = null;
      this.onEndStack = null;
      this.stop();
      this.elem = null;
      this.state = 'init';

      if (this.onResize) {
        clearTimeout(this.resizeTimeout);
        window.removeEventListener('resize', this.onResize);
      }
    }
  }, {
    key: "getCloseHeight",
    value: function getCloseHeight() {
      return parseFloat(this.elem.clientHeight);
    }
  }, {
    key: "getOpenHeight",
    value: function getOpenHeight(state) {
      var currentHeight = window.getComputedStyle(this.elem).height;
      this.elem.parentElement.style.position = 'relative';
      this.elem.style.position = 'absolute';
      this.elem.style.visibility = 'hidden';
      this.elem.style.height = 'auto';
      var height = parseFloat(this.elem.clientHeight);
      this.elem.parentElement.style.position = '';
      this.elem.style.position = '';
      this.elem.style.visibility = '';

      switch (state) {
        case 'open':
          this.elem.style.height = this.state === 'init' ? '0' : currentHeight;
          break;
      }

      return height;
    }
  }, {
    key: "onStart",
    value: function onStart(fn) {
      this.onStartStack.push(fn);
    }
  }, {
    key: "onEnd",
    value: function onEnd(fn) {
      this.onEndStack.push(fn);
    }
  }, {
    key: "callOnStart",
    value: function callOnStart() {
      var _this3 = this;

      this.onStartStack.forEach(function (fn) {
        if (typeof fn === 'function') {
          fn(_this3.state);
        }
      });
    }
  }, {
    key: "callOnEnd",
    value: function callOnEnd() {
      var _this4 = this;

      this.isAnimating = false;
      this.removeEndEvents();
      this.resetSuppressAnimation();
      this.onEndStack.forEach(function (fn) {
        if (typeof fn === 'function') {
          fn(_this4.state);
        }
      });
    }
  }, {
    key: "start",
    value: function start(fromHeight, toHeight, _ref12) {
      var _this$opts,
          _this5 = this;

      var animate = _ref12.animate;

      if (animate === false || ((_this$opts = this.opts) === null || _this$opts === void 0 ? void 0 : _this$opts.animate) === false) {
        this.elem.style.height = "".concat(toHeight, "px");
        this.callOnStart();

        try {
          var event = new CustomEvent('transitionend');
          this.elem.dispatchEvent(event);
        } catch (e) {
          warn(e);
        }

        return;
      }

      if (typeof window !== 'undefined' && window.requestAnimationFrame) {
        this.stop();
        this.isAnimating = true;

        if (animate === false) {
          this.suppressAnimation();
        }

        this.callOnStart();
        this.reqId1 = window.requestAnimationFrame(function () {
          _this5.elem.style.height = "".concat(fromHeight, "px");

          if (_this5.container) {
            _this5.container.style.minHeight = "".concat(fromHeight, "px");
          }

          _this5.reqId2 = window.requestAnimationFrame(function () {
            _this5.elem.style.height = "".concat(toHeight, "px");

            _this5.setContainerHeight();
          });
        });
      }
    }
  }, {
    key: "setContainerHeight",
    value: function setContainerHeight() {
      if (this.container) {
        var contentElem = this.elem;

        if (contentElem.offsetHeight > 0) {
          this.container.style.minHeight = "".concat(contentElem.offsetHeight + contentElem.offsetTop, "px");
        }
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      if (typeof window !== 'undefined' && window.requestAnimationFrame) {
        window.cancelAnimationFrame(this.reqId1);
        window.cancelAnimationFrame(this.reqId2);
      }
    }
  }, {
    key: "suppressAnimation",
    value: function suppressAnimation() {
      this.transitionDuration = window.getComputedStyle(this.elem).transitionDuration;
      this.elem.style.transitionDuration = '1ms';
    }
  }, {
    key: "resetSuppressAnimation",
    value: function resetSuppressAnimation() {
      if (this.transitionDuration) {
        this.elem.style.transitionDuration = this.transitionDuration;
        this.transitionDuration = null;
      }
    }
  }, {
    key: "adjustFrom",
    value: function adjustFrom() {
      var height = this.getCloseHeight();
      this.elem.style.height = "".concat(height, "px");
      return height;
    }
  }, {
    key: "adjustTo",
    value: function adjustTo(fromHeight) {
      var _this6 = this;

      var _ref13 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref13$animate = _ref13.animate,
          animate = _ref13$animate === void 0 ? true : _ref13$animate;

      var toHeight = this.getOpenHeight('open');
      this.state = 'adjusting';
      this.removeEndEvents();

      if (!this.onAdjustEnd) {
        this.elem.addEventListener('transitionend', this.onAdjustEnd = function () {
          if (_this6.elem) {
            _this6.elem.style.height = 'auto';
          }

          _this6.state = 'adjusted';

          _this6.callOnEnd();

          _this6.setContainerHeight();
        });
      }

      this.start(fromHeight, toHeight, {
        animate: animate
      });
    }
  }, {
    key: "open",
    value: function open() {
      var _this7 = this;

      var _ref14 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          _ref14$animate = _ref14.animate,
          animate = _ref14$animate === void 0 ? true : _ref14$animate;

      if (this.state === 'opened' || this.state === 'opening') {
        return;
      }

      var height = this.getOpenHeight('open');
      this.state = 'opening';
      this.removeEndEvents();

      if (!this.onOpenEnd) {
        this.elem.addEventListener('transitionend', this.onOpenEnd = function () {
          if (_this7.elem) {
            _this7.elem.style.height = 'auto';
          }

          _this7.state = 'opened';

          _this7.callOnEnd();

          _this7.setContainerHeight();
        });
      }

      this.start(0, height, {
        animate: animate
      });
    }
  }, {
    key: "close",
    value: function close() {
      var _this8 = this;

      var _ref15 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          _ref15$animate = _ref15.animate,
          animate = _ref15$animate === void 0 ? true : _ref15$animate;

      if (this.state === 'closed' || this.state === 'closing') {
        return;
      }

      var height = this.getCloseHeight();

      if (this.state === 'init') {
        height = this.getOpenHeight();
      }

      this.state = 'closing';
      this.removeEndEvents();

      if (!this.onCloseEnd) {
        this.elem.addEventListener('transitionend', this.onCloseEnd = function () {
          if (_this8.elem) {
            _this8.elem.style.visibility = 'hidden';
          }

          _this8.state = 'closed';

          _this8.callOnEnd();
        });
      }

      this.start(height, 0, {
        animate: animate
      });
    }
  }]);

  return AnimateHeight;
}();
function getStatusState(status) {
  return status && status !== 'error' && status !== 'warn' && status !== 'info';
}
function combineDescribedBy() {
  for (var _len5 = arguments.length, params = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    params[_key5] = arguments[_key5];
  }

  return combineAriaBy('aria-describedby', params);
}

function combineAriaBy(type, params) {
  params = params.map(function (cur) {
    if (cur && typeof cur[type] !== 'undefined') {
      cur = cur[type];
    }

    if (typeof cur !== 'string') {
      cur = null;
    }

    return cur;
  });
  params = params.filter(Boolean).join(' ');

  if (params === '') {
    params = undefined;
  }

  return params;
}

// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)

var $find$1 = _arrayMethods(5);
var KEY$1 = 'find';
var forced$1 = true;
// Shouldn't skip holes
if (KEY$1 in []) Array(1)[KEY$1](function () { forced$1 = false; });
_export(_export.P + _export.F * forced$1, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find$1(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
_addToUnscopables(KEY$1);

var spacingPropTypes = {
  space: propTypes.shape({
    top: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
    right: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
    bottom: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
    left: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool])
  }),
  top: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
  right: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
  bottom: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool]),
  left: propTypes.oneOfType([propTypes.string, propTypes.number, propTypes.bool])
};
var spacingDefaultProps = {
  space: null,
  top: null,
  right: null,
  bottom: null,
  left: null
};
var spacePatterns = {
  'xx-small': 0.25,
  'x-small': 0.5,
  small: 1,
  medium: 1.5,
  large: 2,
  'x-large': 3,
  'xx-large': 3.5,
  'xx-large-x2': 7
};
var translateSpace = function translateSpace(type) {
  if (/-x2$/.test(type)) {
    return spacePatterns[type.replace(/-x2$/, '')] * 2;
  }

  return spacePatterns[type] || 0;
};
var splitTypes = function splitTypes(types) {
  if (typeof types === 'string') {
    types = types.split(/ /g);
  } else if (typeof types === 'boolean') {
    return ['small'];
  } else if (typeof types === 'number') {
    return [types];
  }

  return types ? types.filter(function (r) {
    return r && r.length > 0;
  }) : null;
};
var sumTypes = function sumTypes(types) {
  return splitTypes(types).map(function (type) {
    return translateSpace(type);
  }).reduce(function (acc, cur) {
    if (cur > 0) {
      acc += cur;
    } else if (cur < 0) {
      acc -= cur;
    }

    return acc;
  }, 0);
};
var createTypeModifyers = function createTypeModifyers(types) {
  if (typeof types === 'number') {
    types = String(types);
  }

  return (splitTypes(types) || []).reduce(function (acc, type) {
    if (type) {
      var firstLetter = type[0];

      if (parseFloat(firstLetter) > -1) {
        var num = parseFloat(type);

        if (num >= 8 && /[0-9]px/.test(type)) {
          num = num / 16;
        }

        var foundType = findType(num);

        if (foundType) {
          type = foundType;
        } else {
          findNearestTypes(num).forEach(function (type) {
            if (type) {
              acc.push(type);
            }
          });
        }
      }

      if (!(parseFloat(type) > 0)) {
        acc.push(type);
      }
    }

    return acc;
  }, []);
};
var findType = function findType(num) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$returnObject = _ref.returnObject,
      returnObject = _ref$returnObject === void 0 ? false : _ref$returnObject;

  var found = Object.entries(spacePatterns).find(function (_ref2) {
    var _ref3 = _slicedToArray$1(_ref2, 2),
        k = _ref3[0],
        v = _ref3[1];

    return k && v === num;
  }) || null;

  if (returnObject) {
    return found;
  }

  if (found) {
    return found[0];
  }

  return found;
};
var findNearestTypes = function findNearestTypes(num) {
  var res = [];
  var near = Object.entries(spacePatterns).reverse().find(function (_ref4) {
    var _ref5 = _slicedToArray$1(_ref4, 2),
        k = _ref5[0],
        v = _ref5[1];

    return k && num >= v;
  });
  var nearNum = near && near[1] || num;
  var typeObject = findType(nearNum, {
    returnObject: true
  });

  if (typeObject) {
    var nearType = typeObject[0];
    res.push(nearType);
    var leftOver = num - parseFloat(typeObject[1]);
    var foundMoreTypes = findNearestTypes(leftOver);
    foundMoreTypes.forEach(function (type) {
      var index = res.indexOf(type);

      if (index !== -1) {
        res[index] = "".concat(type, "-x2");
      }
    });
    res = [].concat(_toConsumableArray$1(res), _toConsumableArray$1(foundMoreTypes));
  }

  return res;
};
var isValidSpaceProp = function isValidSpaceProp(prop) {
  return prop && ['top', 'right', 'bottom', 'left'].includes(prop);
};
var createSpacingClasses = function createSpacingClasses(props) {
  var Element = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

  if (typeof props.space !== 'undefined') {
    for (var i in props.space) {
      if (!props[i] && isValidSpaceProp(i)) {
        props[i] = props.space[i];
      }

      delete props.space;
    }
  }

  return Object.entries(props).reduce(function (acc, _ref7) {
    var _ref8 = _slicedToArray$1(_ref7, 2),
        direction = _ref8[0],
        cur = _ref8[1];

    if (isValidSpaceProp(direction)) {
      if (String(cur) === '0' || String(cur) === 'false') {
        acc.push("dnb-space__".concat(direction, "--zero"));
      } else if (cur) {
        var typeModifyers = createTypeModifyers(cur);
        var sum = sumTypes(typeModifyers);

        if (sum > 10) {
          warn("Spacing of more than 10rem is not supported! You used ".concat(sum, " / (").concat(typeModifyers.join(','), ")"));
        } else {
          var nearestTypes = findNearestTypes(sum);
          acc = [].concat(_toConsumableArray$1(acc), _toConsumableArray$1(nearestTypes.map(function (type) {
            return "dnb-space__".concat(direction, "--").concat(type);
          })));
        }
      }
    } else if (direction === 'no_collapse') {
      acc.push('dnb-space--no-collapse');

      if (Element && isInline(Element)) {
        acc.push('dnb-space--inline');
      }
    }

    return acc;
  }, []);
};
var isInline = function isInline(Element) {
  var inline = false;

  switch (Element) {
    case 'h1':
    case 'h2':
    case 'h3':
    case 'h4':
    case 'h5':
    case 'h6':
    case 'p':
      inline = true;
      break;
  }

  return inline;
};

var LOCALE = 'nb-NO';
var CURRENCY = 'NOK';
var CURRENCY_DISPLAY = 'symbol';

var nbNO = {
  'nb-NO': {
    DatePicker: {
      day: 'dag',
      month: 'måned',
      year: 'år',
      start: 'fra',
      end: 'til',
      selected_date: 'Valgt dato: %s',
      selected_month: 'Valgt måned %s',
      selected_year: 'Valgt år %s',
      next_month: 'Neste måned %s',
      prev_month: 'Forrige måned %s',
      next_year: 'Neste år %s',
      prev_year: 'Forrige år %s',
      open_picker_text: 'åpne datovelger',
      mask_order: 'dd/mm/yyyy',
      mask_placeholder: 'dd.mm.åååå',
      date_format: 'yyyy-MM-dd',
      return_format: 'yyyy-MM-dd',
      submit_button_text: 'Ok',
      cancel_button_text: 'Avbryt',
      reset_button_text: 'Tilbakestill'
    },
    GlobalStatus: {
      default_title: 'En feil har skjedd',
      close_text: 'Lukk',
      status_anchor_text: 'Gå til %s'
    },
    GlobalError: {
      404: {
        title: 'Oisann! Vi finner ikke siden du leter etter …',
        text: 'Sikker på at du har skrevet riktig adresse? Eller har vi rotet med lenkene? Prøv på nytt, eller [gå tilbake der du kom fra](/back).',
        alt: 'Dame søker i tom eske'
      },
      500: {
        title: 'Oops, her ble det en teknisk feil!',
        text: 'Tjenesten fungerer ikke slik den skal for øyeblikket, men prøv igjen senere.',
        alt: 'Mann leter etter spor'
      }
    },
    ProgressIndicator: {
      indicator_label: 'Vennligst vent ...'
    },
    Dropdown: {
      title: 'Valgmeny'
    },
    Autocomplete: {
      title: 'Skriv og velg',
      submit_button_title: 'Vis alternativer',
      no_options: 'Ingen alternativer',
      show_all: 'Vis alt',
      aria_live_options: '%s alternativer',
      indicator_label: 'Henter data ...'
    },
    Modal: {
      close_title: 'Lukk'
    },
    HelpButton: {
      title: 'Hjelpetekst',
      aria_role: 'Hjelp-knapp'
    },
    Input: {
      submit_button_title: 'Send knapp',
      show_password: 'Vis passord',
      hide_password: 'Skjul passord'
    },
    Pagination: {
      button_title: 'Side %s',
      next_title: 'Neste side',
      prev_title: 'Forrige side',
      more_pages: '%s flere sider',
      is_loading_text: 'Laster nytt innhold',
      load_button_text: 'Vis mer innhold'
    },
    Skeleton: {
      aria_bussy: 'Behandler data ...',
      aria_ready: 'Klar til å samhandle'
    },
    StepIndicator: {
      step_title: 'Steg %step av %count'
    },
    Slider: {
      add_title: 'Øk (%s)',
      subtract_title: 'Reduser (%s)'
    },
    PaymentCard: {
      text_card_number: 'Kortnummer',
      text_expired: 'Utgått',
      text_blocked: 'Sperret'
    },
    Logo: {
      alt: 'DNB Logo'
    }
  }
};

var enGB = {
  'en-GB': {
    DatePicker: {
      day: 'Day',
      month: 'Month',
      year: 'Year',
      start: 'from',
      end: 'to',
      selected_date: 'Selected date: %s',
      selected_month: 'Selected month %s',
      selected_year: 'Selected year %s',
      next_month: 'Next month %s',
      prev_month: 'Previous month %s',
      next_year: 'Next year %s',
      prev_year: 'Previous year %s',
      open_picker_text: 'Open date picker',
      mask_order: 'dd/mm/yyyy',
      mask_placeholder: 'dd/mm/yyyy',
      date_format: 'yyyy-MM-dd',
      return_format: 'yyyy-MM-dd',
      submit_button_text: 'OK',
      cancel_button_text: 'Cancel',
      reset_button_text: 'Reset'
    },
    GlobalStatus: {
      default_title: 'An error has occurred',
      close_text: 'Close',
      status_anchor_text: 'Go to %s'
    },
    GlobalError: {
      404: {
        title: "Oops! We can't find the page you're looking for …",
        text: 'Did we messed with the links? Try again, or [go back where you came from](/back).',
        alt: 'Lady searching in empty box'
      },
      500: {
        title: 'Ohh, a technical error happened!',
        text: 'The service is not working properly at the moment, but try again later.',
        alt: 'Man looking for clues'
      }
    },
    ProgressIndicator: {
      indicator_label: 'Please wait ...'
    },
    Dropdown: {
      title: 'Option Menu'
    },
    Autocomplete: {
      title: 'Type and select',
      submit_button_title: 'Show options',
      no_options: 'No option',
      show_all: 'Show everything',
      aria_live_options: '%s options',
      indicator_label: 'Getting data ...'
    },
    Modal: {
      close_title: 'Close'
    },
    HelpButton: {
      title: 'Help text',
      aria_role: 'Help button'
    },
    Skeleton: {
      aria_bussy: 'In progress ...',
      aria_ready: 'Ready to interact'
    },
    Input: {
      submit_button_title: 'Submit button',
      show_password: 'Show password',
      hide_password: 'Hide password'
    },
    Pagination: {
      button_title: 'Page %s',
      next_title: 'Next page',
      prev_title: 'Previous page',
      more_pages: '%s more pages',
      is_loading_text: 'Loading new content',
      load_button_text: 'Show more content'
    },
    StepIndicator: {
      step_title: 'Step %step of %count'
    },
    Slider: {
      add_title: 'Increase (%s)',
      subtract_title: 'Decrease (%s)'
    },
    PaymentCard: {
      text_card_number: 'Card number',
      text_expired: 'Expired',
      text_blocked: 'Blocked'
    },
    Logo: {
      alt: 'DNB Logo'
    }
  }
};

var defaultLocales = _extends({}, nbNO, enGB);

var prepareContext = function prepareContext() {
  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var locales = props.locales ? extend(defaultLocales, props.locales) : defaultLocales;

  if (props.__newContext) {
    _extends(props, props.__newContext);

    delete props.__newContext;
  }

  var key = handleLocaleFallbacks(props.locale || LOCALE, locales);
  var translation = locales[key] || defaultLocales[LOCALE] || {};

  if (locales[key]) {
    locales[key] = destruct(locales[key], translation);
  }

  var context = _extends({
    updateTranslation: function updateTranslation(locale, translation) {
      context.translation = context.locales[locale] = translation;
    },
    getTranslation: function getTranslation(props) {
      if (props) {
        var lang = props.lang || props.locale;

        if (lang && context.locales[lang] && lang !== key) {
          return context.locales[lang];
        }
      }

      return context.translation;
    },
    locales: locales
  }, props, {
    translation: translation
  });

  return context;
};

function handleLocaleFallbacks(locale, locales) {
  if (!locales[locale]) {
    if (locale === 'en' || locale.split('-')[0] === 'en') {
      return 'en-GB';
    }
  }

  return locale;
}

var Context = react.createContext(prepareContext({
  locale: LOCALE,
  currency: CURRENCY,
  currency_display: CURRENCY_DISPLAY
}));

function destruct(source, validKeys) {
  for (var k in source) {
    if (String(k).includes('.')) {
      var list = k.split('.');

      if (validKeys[list[0]]) {
        (function () {
          var val = source[k];
          var last = list.length - 1;
          list.forEach(function (k, i) {
            source[k] = i === last ? val : source[k];
            source = source[k] || {};
          });
        })();
      }
    }
  }

  return source;
}

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime_1 = createCommonjsModule(function (module) {
var runtime = (function (exports) {

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined$1; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined$1) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined$1;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined$1;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined$1;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined$1, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined$1;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined$1;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined$1;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined$1;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined$1;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   module.exports 
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}
});

var regenerator = runtime_1;

var IS_IE11 = false;
var isMac = function isMac() {
  var _navigator;

  return typeof navigator !== 'undefined' && new RegExp(PLATFORM_MAC, 'i').test((_navigator = navigator) === null || _navigator === void 0 ? void 0 : _navigator.platform);
};
var isWin = function isWin() {
  var _navigator2;

  return typeof navigator !== 'undefined' && new RegExp(PLATFORM_WIN, 'i').test((_navigator2 = navigator) === null || _navigator2 === void 0 ? void 0 : _navigator2.platform);
};
var isLinux = function isLinux() {
  var _navigator3;

  return typeof navigator !== 'undefined' && new RegExp(PLATFORM_LINUX, 'i').test((_navigator3 = navigator) === null || _navigator3 === void 0 ? void 0 : _navigator3.platform);
};
var isiOS = function isiOS() {
  var _navigator4;

  return typeof navigator !== 'undefined' && new RegExp(PLATFORM_IOS, 'i').test((_navigator4 = navigator) === null || _navigator4 === void 0 ? void 0 : _navigator4.platform);
};
var isSafari = function isSafari() {
  var _navigator5, _navigator6;

  return typeof navigator !== 'undefined' && /safari/i.test((_navigator5 = navigator) === null || _navigator5 === void 0 ? void 0 : _navigator5.userAgent) && !/chrome/i.test((_navigator6 = navigator) === null || _navigator6 === void 0 ? void 0 : _navigator6.userAgent);
};
var isIE11 = function isIE11() {
  return IS_IE11 = typeof window !== 'undefined' && typeof document !== 'undefined' ? !!window.MSInputMethodContext && !!document.documentMode : false;
};
var isEdge = function isEdge() {
  var _navigator7;

  return typeof navigator !== 'undefined' && /edge/i.test((_navigator7 = navigator) === null || _navigator7 === void 0 ? void 0 : _navigator7.userAgent);
};
isIE11();
isEdge();
isiOS();
isSafari();
isWin();
isMac();
isLinux();
function getOffsetTop(elem) {
  var offsetTop = 0;

  do {
    if (!isNaN(elem.offsetTop)) {
      offsetTop += elem.offsetTop;
    }
  } while (elem = elem.offsetParent);

  return offsetTop;
}
function getOffsetLeft(elem) {
  var offsetLeft = 0;

  do {
    if (!isNaN(elem.offsetLeft)) {
      offsetLeft += elem.offsetLeft;
    }
  } while (elem = elem.offsetParent);

  return offsetLeft;
}
function getSelectedText() {
  try {
    return window.getSelection().toString();
  } catch (e) {}

  return '';
}
function hasSelectedText() {
  return getSelectedText().length > 0;
}

function _createSuper$1(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$2(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$2() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var skeletonDOMAttributes = function skeletonDOMAttributes(params, skeleton, context) {
  if (isTrue(skeleton) || context !== null && context !== void 0 && context.skeleton) {
    var _context$translation, _context$translation$;

    params.disabled = true;
    params['aria-disabled'] = true;
    params['aria-label'] = context === null || context === void 0 ? void 0 : (_context$translation = context.translation) === null || _context$translation === void 0 ? void 0 : (_context$translation$ = _context$translation.Skeleton) === null || _context$translation$ === void 0 ? void 0 : _context$translation$.aria_bussy;
  }

  return params;
};
var createSkeletonClass = function createSkeletonClass(method, skeleton) {
  var context = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

  if (isTrue(skeleton) || context !== null && context !== void 0 && context.skeleton) {
    return 'dnb-skeleton' + (method ? " dnb-skeleton--".concat(method) : "");
  }

  return null;
};
var AutoSize = function (_React$PureComponent) {
  _inherits(AutoSize, _React$PureComponent);

  var _super = _createSuper$1(AutoSize);

  function AutoSize() {
    _classCallCheck(this, AutoSize);

    return _super.apply(this, arguments);
  }

  _createClass(AutoSize, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          children = _this$props.children,
          Comp = _this$props.__element,
          style = _this$props.style,
          props = _objectWithoutProperties(_this$props, ["className", "children", "__element", "style"]);

      var string = convertJsxToString(children);

      if (typeof string === 'string') {
        var countChars = string.trim().length;

        if (countChars > 0) {
          return react.createElement(Comp, _extends({
            className: classnames("dnb-skeleton dnb-skeleton--font", className),
            'data-skeleton-chars': String(countChars),
            style: _extends({}, style || {}, _defineProperty({}, IS_IE11 ? 'maxWidth' : '--skeleton-chars', "".concat(countChars, "ch")))
          }, props), children);
        }
      }

      return react.createElement(Comp, _extends({}, props, {
        className: className,
        style: style
      }));
    }
  }]);

  return AutoSize;
}(react.PureComponent);
AutoSize.defaultProps = {
  __element: null,
  children: null,
  className: null,
  style: null
};

function _createSuper$2(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$3(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$3() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var DefaultIconSize = 16;
var DefaultIconSizes = {
  default: 16,
  medium: 24
};
var ListDefaultIconSizes = [['default', 16], ['medium', 24]];
var ValidIconSizes = ['small', 'default', 'medium', 'large', 'x-large', 'xx-large'];

var Icon = function (_React$PureComponent) {
  _inherits(Icon, _React$PureComponent);

  var _super = _createSuper$2(Icon);

  function Icon() {
    _classCallCheck(this, Icon);

    return _super.apply(this, arguments);
  }

  _createClass(Icon, [{
    key: "render",
    value: function render() {
      var _this$context;

      var props = extendPropsWithContext(this.props, Icon.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.formRow);

      var _prepareIcon = prepareIcon(props, this.context),
          icon = _prepareIcon.icon,
          size = _prepareIcon.size,
          wrapperParams = _prepareIcon.wrapperParams,
          iconParams = _prepareIcon.iconParams,
          alt = _prepareIcon.alt;

      var IconContainer = prerenderIcon({
        icon: icon,
        size: size,
        alt: alt
      });
      if (!IconContainer) return react.createElement(react.Fragment, null);
      return react.createElement("span", wrapperParams, react.createElement(IconContainer, iconParams));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      var tag = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Icon.tagName;
      var inst = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Icon;
      var props = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Icon.defaultProps;
      registerElement(tag, inst, props);
    }
  }, {
    key: "getIcon",
    value: function getIcon(props) {
      if (props.icon) {
        return props.icon;
      }

      return processChildren(props);
    }
  }]);

  return Icon;
}(react.PureComponent);

Icon.tagName = 'dnb-icon';
Icon.contextType = Context;
Icon.defaultProps = {
  icon: null,
  modifier: null,
  size: null,
  width: null,
  height: null,
  border: null,
  color: null,
  inherit_color: true,
  alt: null,
  title: null,
  skeleton: null,
  attributes: null,
  className: null,
  children: null
};
var getIconNameFromComponent = function getIconNameFromComponent(icon) {
  var name = typeof icon === 'string' ? icon : icon && (icon.displayName || icon.name);

  if (/^data:image\//.test(name)) {
    return null;
  }

  return name;
};
var calcSize = function calcSize(props) {
  var icon = props.icon,
      size = props.size,
      width = props.width,
      height = props.height;
  var sizeAsInt = -1;
  var sizeAsString = null;

  if (!size || size === DefaultIconSize) {
    var name = getIconNameFromComponent(icon);
    var nameParts = String(name || '').split('_');

    if (nameParts.length > 1) {
      var lastPartOfIconName = nameParts.reverse()[0];
      var potentialSize = ListDefaultIconSizes.filter(function (_ref) {
        var _ref2 = _slicedToArray$1(_ref, 1),
            key = _ref2[0];

        return key === lastPartOfIconName;
      }).reduce(function (acc, _ref3) {
        var _ref4 = _slicedToArray$1(_ref3, 2),
            key = _ref4[0],
            value = _ref4[1];

        return key && value;
      }, null);

      if (potentialSize) {
        sizeAsInt = potentialSize;
      }

      if (ValidIconSizes.includes(lastPartOfIconName)) {
        sizeAsString = lastPartOfIconName;
      }
    } else {
      if (typeof icon === 'function') {
        var elem = icon();

        if (elem.props) {
          var _potentialSize = -1;

          if (elem.props.width) {
            _potentialSize = elem.props.width;
          }

          if (!_potentialSize && elem.props.viewBox) {
            _potentialSize = /[0-9]+ [0-9]+ ([0-9]+)/.exec(elem.props.viewBox)[1];
          }

          if (_potentialSize) {
            sizeAsInt = _potentialSize;
          }
        }
      }
    }
  } else if (typeof size === 'string' && !(parseFloat(size) > 0)) {
      sizeAsInt = ListDefaultIconSizes.filter(function (_ref5) {
        var _ref6 = _slicedToArray$1(_ref5, 1),
            key = _ref6[0];

        return key === size;
      }).reduce(function (acc, _ref7) {
        var _ref8 = _slicedToArray$1(_ref7, 2),
            key = _ref8[0],
            value = _ref8[1];

        return key && value;
      }, -1);

      if (ValidIconSizes.includes(size)) {
        sizeAsString = size;
      }
    } else if (parseFloat(size) > 0) {
        sizeAsInt = ListDefaultIconSizes.filter(function (_ref9) {
          var _ref10 = _slicedToArray$1(_ref9, 2),
              key = _ref10[0],
              value = _ref10[1];

          return key && value === parseFloat(size);
        }).reduce(function (acc, _ref11) {
          var _ref12 = _slicedToArray$1(_ref11, 2),
              key = _ref12[0],
              value = _ref12[1];

          if (key && value) return value;
          return acc;
        }, -1);

        if (sizeAsInt === -1) {
          sizeAsInt = parseFloat(size);
          sizeAsString = 'custom-size';
        }
      }

  if (!sizeAsString && sizeAsInt > 0) {
    var potentialSizeAsString = ListDefaultIconSizes.reduce(function (acc, _ref13) {
      var _ref14 = _slicedToArray$1(_ref13, 2),
          key = _ref14[0],
          value = _ref14[1];

      if (key && value === sizeAsInt) {
        return key;
      }

      return acc;
    }, null);

    if (potentialSizeAsString) {
      sizeAsString = potentialSizeAsString;
    }
  }

  var _prepareIconParams = prepareIconParams({
    sizeAsString: sizeAsString,
    sizeAsInt: sizeAsInt,
    size: size,
    width: width,
    height: height
  }),
      isCustomSize = _prepareIconParams.sizeAsString,
      iconParams = _prepareIconParams.params;

  if (isCustomSize) {
    sizeAsString = isCustomSize;
  }

  if (!(sizeAsInt > 0)) {
    sizeAsInt = DefaultIconSize;
  }

  if (size === 'auto') {
    iconParams.width = '100%';
    iconParams.height = '100%';
    sizeAsString = 'auto';
  }

  return {
    iconParams: iconParams,
    sizeAsInt: sizeAsInt,
    sizeAsString: sizeAsString
  };
};

var prepareIconParams = function prepareIconParams(_ref15) {
  var sizeAsString = _ref15.sizeAsString,
      rest = _objectWithoutProperties(_ref15, ["sizeAsString"]);

  var size = rest.size,
      width = rest.width,
      height = rest.height,
      sizeAsInt = rest.sizeAsInt;
  var params = {};

  if (!sizeAsString && !(sizeAsInt > 0) && parseFloat(size) > -1) {
    params.width = params.height = parseFloat(size);
  } else if (sizeAsString === 'custom-size') {
    params.width = params.height = parseFloat(sizeAsInt);
  }

  if (parseFloat(width) > -1) {
    sizeAsString = 'custom-size';
    params.width = parseFloat(width);
  }

  if (parseFloat(height) > -1) {
    sizeAsString = 'custom-size';
    params.height = parseFloat(height);
  }

  validateDOMAttributes({}, params);
  return {
    params: params,
    sizeAsString: sizeAsString
  };
};

var prepareIcon = function prepareIcon(props, context) {
  var icon = props.icon,
      size = props.size,
      width = props.width,
      height = props.height,
      border = props.border,
      color = props.color,
      inherit_color = props.inherit_color,
      modifier = props.modifier,
      alt = props.alt,
      title = props.title,
      skeleton = props.skeleton,
      _className = props.class,
      className = props.className,
      attributes = _objectWithoutProperties(props, ["icon", "size", "width", "height", "border", "color", "inherit_color", "modifier", "alt", "title", "skeleton", "class", "className"]);

  var _calcSize = calcSize({
    icon: icon,
    size: size,
    width: width,
    height: height
  }),
      sizeAsString = _calcSize.sizeAsString,
      iconParams = _calcSize.iconParams;

  if (color) {
    iconParams.color = color;
  }

  var label = icon ? getIconNameFromComponent(icon) : null;
  var wrapperParams = validateDOMAttributes(props, _extends({
    role: alt ? 'img' : 'presentation',
    alt: alt,
    'aria-label': label ? label.replace(/_/g, ' ') + ' icon' : null,
    title: title
  }, attributes));

  if (!alt && typeof wrapperParams['aria-hidden'] === 'undefined') {
    wrapperParams['aria-hidden'] = true;
  }

  wrapperParams.className = classnames('dnb-icon', sizeAsString ? "dnb-icon--".concat(sizeAsString) : "dnb-icon--default", createSkeletonClass(null, skeleton, context), createSpacingClasses(props), _className, className, modifier && "dnb-icon--".concat(modifier), isTrue(border) && 'dnb-icon--border', isTrue(inherit_color) && 'dnb-icon--inherit-color');
  var iconToRender = Icon.getIcon(props);

  if (typeof iconToRender.defaultProps !== 'undefined') {
    iconToRender = react.createElement(iconToRender, validateDOMAttributes({}, {
      color: color,
      icon: icon,
      size: size,
      width: width,
      height: height
    }));
  }

  return _extends({}, props, {
    icon: iconToRender,
    alt: alt,
    iconParams: iconParams,
    wrapperParams: wrapperParams
  });
};
var prerenderIcon = function prerenderIcon() {
  var _ref16 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      icon = _ref16.icon,
      _ref16$size = _ref16.size,
      size = _ref16$size === void 0 ? null : _ref16$size,
      _ref16$listOfIcons = _ref16.listOfIcons,
      listOfIcons = _ref16$listOfIcons === void 0 ? null : _ref16$listOfIcons,
      _ref16$alt = _ref16.alt,
      alt = _ref16$alt === void 0 ? null : _ref16$alt;

  if (typeof icon === 'string' && /^data:image\//.test(icon)) {
    return function () {
      return react.createElement("img", {
        src: icon,
        alt: alt || 'no-alt'
      });
    };
  }

  if (typeof icon === 'function') {
    var elem = icon();

    if (react.isValidElement(elem)) {
      return icon;
    }

    return elem;
  }

  if (react.isValidElement(icon) || Array.isArray(icon)) {
    return function () {
      return icon;
    };
  }

  try {
    icon = iconCase(icon);

    if (size && DefaultIconSizes[size] && size !== 'default' && !(parseFloat(size) > 0) && !icon.includes(size)) {
      icon = "".concat(icon, "_").concat(size);
    }

    var mod = (listOfIcons.dnbIcons ? listOfIcons.dnbIcons : listOfIcons)[icon];
    return mod && mod.default ? mod.default : mod;
  } catch (e) {
    new ErrorHandler("Icon '".concat(icon, "' did not exist!"));
    return null;
  }
};
var iconCase = function iconCase(name) {
  return name.replace(/((?!^)[A-Z])/g, '_$1').toLowerCase().replace(/^[0-9]/g, '$1').replace(/[^a-z0-9_]/gi, '_');
};

var _ref = react.createElement("path", {
  d: "M7.25 14a.75.75 0 001.5 0h-1.5zm1.5-12a.75.75 0 00-1.5 0h1.5zM14 8.75a.75.75 0 000-1.5v1.5zM2 7.25a.75.75 0 000 1.5v-1.5zM8.75 14V2h-1.5v12h1.5zM14 7.25H2v1.5h12v-1.5z",
  fill: "#000"
});

function add(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref);
}

var _ref$1 = react.createElement("path", {
  d: "M3.53 9.22a.75.75 0 00-1.06 1.06l1.06-1.06zM8 14.75l-.53.53a.75.75 0 001.06 0L8 14.75zm5.53-4.47a.75.75 0 10-1.06-1.06l1.06 1.06zM8.75 1.25a.75.75 0 00-1.5 0h1.5zm-6.28 9.03l5 5 1.06-1.06-5-5-1.06 1.06zm6.06 5l5-5-1.06-1.06-5 5 1.06 1.06zM7.25 1.25v13.5h1.5V1.25h-1.5z",
  fill: "#000"
});

function arrow_down(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$1);
}

var _ref$2 = react.createElement("path", {
  d: "M14.5 8H1m5-5L1 8m0 0l5 5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function arrow_left(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$2);
}

var _ref$3 = react.createElement("path", {
  d: "M1.5 8H15m-5 5l5-5m0 0l-5-5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function arrow_right(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$3);
}

var _ref$4 = react.createElement("path", {
  d: "M2.47 5.72a.75.75 0 001.06 1.06L2.47 5.72zM8 1.25l.53-.53a.75.75 0 00-1.06 0l.53.53zm4.47 5.53a.75.75 0 101.06-1.06l-1.06 1.06zm-5.22 7.97a.75.75 0 001.5 0h-1.5zM3.53 6.78l5-5L7.47.72l-5 5 1.06 1.06zm3.94-5l5 5 1.06-1.06-5-5-1.06 1.06zm1.28 12.97V1.25h-1.5v13.5h1.5z",
  fill: "#000"
});

function arrow_up(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$4);
}

var _ref$5 = react.createElement("path", {
  d: "M6.756 14.067a1.299 1.299 0 002.492 0M8 2.4a4.667 4.667 0 014.667 4.667c0 4.384.933 5.133.933 5.133H2.4s.933-1.192.933-5.133A4.667 4.667 0 018 2.4zm0 0V1",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function bell(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$5);
}

var _ref$6 = react.createElement("path", {
  d: "M6.006 1a.75.75 0 10-1.5 0h1.5zm-1.5 3.256a.75.75 0 101.5 0h-1.5zM11.5 1A.75.75 0 0010 1h1.5zM10 4.256a.75.75 0 001.5 0H10zM2 15.75h12v-1.5H2v1.5zM4.506 1v3.256h1.5V1h-1.5zM10 1v3.256h1.5V1H10zm4 .878H2v1.5h12v-1.5zM.25 3.628V7.5h1.5V3.628H.25zm0 3.872V14h1.5V7.5H.25zm15.5 6.5V7.5h-1.5V14h1.5zm0-6.5V3.628h-1.5V7.5h1.5zM1 8.25h14v-1.5H1v1.5zm13-4.872a.25.25 0 01.25.25h1.5A1.75 1.75 0 0014 1.878v1.5zm0 12.372A1.75 1.75 0 0015.75 14h-1.5a.25.25 0 01-.25.25v1.5zm-12-1.5a.25.25 0 01-.25-.25H.25c0 .966.784 1.75 1.75 1.75v-1.5zM2 1.878a1.75 1.75 0 00-1.75 1.75h1.5a.25.25 0 01.25-.25v-1.5z",
  fill: "#000"
});

function calendar(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$6);
}

var _ref$7 = react.createElement("path", {
  d: "M1 10l4 4L15 2",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function check$1(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$7);
}

var _ref$8 = react.createElement("path", {
  d: "M13 5.5l-5 5-5-5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_down(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$8);
}

var _ref$9 = react.createElement("path", {
  d: "M10 3L5 8l5 5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_left(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$9);
}

var _ref$a = react.createElement("path", {
  d: "M6 13l5-5-5-5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_right(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$a);
}

var _ref$b = react.createElement("path", {
  d: "M3 10.5l5-5 5 5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_up(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$b);
}

var _ref$c = react.createElement("path", {
  d: "M3 13L13 3m0 10L3 3",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function close(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$c);
}

var _ref$d = react.createElement("path", {
  d: "M5.874 8.75a.75.75 0 00-1.06 1.062l1.06-1.061zM8 11.939l-.53.53a.75.75 0 001.06 0l-.53-.53zm3.187-2.126a.75.75 0 10-1.061-1.061l1.06 1.06zM8.75 3.5a.75.75 0 00-1.5 0h1.5zM3 14.25a.75.75 0 000 1.5v-1.5zm10 1.5a.75.75 0 000-1.5v1.5zM4.813 9.812l2.657 2.656 1.06-1.06L5.874 8.75l-1.06 1.06zm3.717 2.656l2.657-2.656-1.061-1.061-2.656 2.656 1.06 1.06zM7.25 3.5v8.438h1.5V3.5h-1.5zM3 15.75h10v-1.5H3v1.5z",
  fill: "#000"
});

function download(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$d);
}

var _ref$e = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M8.75 2a.75.75 0 00-1.5 0v8.412a.75.75 0 001.5 0V2zM7.444 12.668a1 1 0 111.111 1.663 1 1 0 01-1.11-1.662z",
  fill: "#000"
});

function exclamation(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$e);
}

var _ref$f = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M7.166 3.665a1 1 0 100-1.998 1 1 0 000 1.998zm-1 1.749a.75.75 0 100 1.5h.75V12a2.25 2.25 0 002.249 2.249h.75a.75.75 0 000-1.5h-.75a.75.75 0 01-.75-.75V6.914a1.5 1.5 0 00-1.499-1.5h-.75z",
  fill: "#000"
});

function information(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$f);
}

var _ref$g = react.createElement("path", {
  d: "M12.03 10.97a.75.75 0 10-1.06 1.06l1.06-1.06zm2.44 4.56a.75.75 0 101.06-1.06l-1.06 1.06zm-3.5-3.5l3.5 3.5 1.06-1.06-3.5-3.5-1.06 1.06zm.098-5.62a4.66 4.66 0 01-4.659 4.658v1.5a6.16 6.16 0 006.16-6.159h-1.5zM6.41 11.067A4.66 4.66 0 011.75 6.41H.25a6.16 6.16 0 006.16 6.16v-1.5zM1.75 6.41a4.66 4.66 0 014.66-4.66V.25A6.16 6.16 0 00.25 6.41h1.5zm4.66-4.66a4.66 4.66 0 014.658 4.66h1.5A6.16 6.16 0 006.41.25v1.5z",
  fill: "#000"
});

function loupe(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$g);
}

var _ref$h = react.createElement("path", {
  d: "M4.5 8A1.25 1.25 0 112 8a1.25 1.25 0 012.5 0zM8 9.25a1.25 1.25 0 100-2.5 1.25 1.25 0 000 2.5zm4.75 0a1.25 1.25 0 100-2.5 1.25 1.25 0 000 2.5z",
  fill: "#000"
});

function more(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$h);
}

var _ref$i = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M6.142 4.876c0-1.205 1.081-2.203 2.272-2.12 1.202.082 2.123 1.23 1.96 2.412A2.174 2.174 0 018.975 6.88c-.961.34-1.313 1.123-1.426 1.826a5.62 5.62 0 00-.053.985c.002.154.007.28.011.396.005.143.01.27.01.413a.75.75 0 001.5 0c0-.15-.006-.338-.012-.516l-.01-.32a4.196 4.196 0 01.036-.72c.062-.393.19-.56.444-.65a3.673 3.673 0 002.383-2.92c.283-2.038-1.267-3.972-3.341-4.115-2.053-.142-3.876 1.537-3.876 3.616a.75.75 0 101.5 0zM8.25 14.5a1 1 0 100-2 1 1 0 000 2z",
  fill: "#000"
});

function question(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$i);
}

var _ref$j = react.createElement("path", {
  d: "M5.333 14.474l.634-.401-.128-.202-.22-.09-.286.693zm1.084-3.807a.75.75 0 00-1.5 0h1.5zM5.667 15v.75a.75.75 0 00.75-.75h-.75zm-4.334-.75a.75.75 0 000 1.5v-1.5zm8.007-.144a.75.75 0 10.32 1.466l-.32-1.466zM1.75 8A6.25 6.25 0 018 1.75V.25A7.75 7.75 0 00.25 8h1.5zM8 1.75A6.25 6.25 0 0114.25 8h1.5A7.75 7.75 0 008 .25v1.5zM5.62 13.78A6.252 6.252 0 011.75 8H.25a7.752 7.752 0 004.797 7.168l.572-1.387zm-.703-3.113V15h1.5v-4.333h-1.5zm.75 3.583H1.333v1.5h4.334v-1.5zm-.967.626l.333.526 1.267-.803-.333-.526-1.267.803zM14.25 8a6.253 6.253 0 01-4.91 6.106l.32 1.466A7.753 7.753 0 0015.75 8h-1.5z",
  fill: "#000"
});

function reset(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$j);
}

var _ref$k = react.createElement("path", {
  d: "M6.133 5.2L8 7.067m0 0L9.867 5.2M8 7.067V1m.5 11.5H4m8.044 0h-.622M1.933 15h12.134a.933.933 0 00.933-.933v-3.734a.933.933 0 00-.933-.933H1.933a.933.933 0 00-.933.933v3.734c0 .515.418.933.933.933z",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function save(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$k);
}

var _ref$l = react.createElement("path", {
  d: "M14 8.75a.75.75 0 000-1.5v1.5zM2 7.25a.75.75 0 000 1.5v-1.5zm12 0H2v1.5h12v-1.5z",
  fill: "#000"
});

function subtract(props) {
  return react.createElement("svg", _extends({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$l);
}

var primary_icons = /*#__PURE__*/Object.freeze({
            __proto__: null,
            add: add,
            arrow_down: arrow_down,
            arrow_left: arrow_left,
            arrow_right: arrow_right,
            arrow_up: arrow_up,
            bell: bell,
            calendar: calendar,
            check: check$1,
            chevron_down: chevron_down,
            chevron_left: chevron_left,
            chevron_right: chevron_right,
            chevron_up: chevron_up,
            close: close,
            download: download,
            exclamation: exclamation,
            information: information,
            loupe: loupe,
            more: more,
            question: question,
            reset: reset,
            save: save,
            subtract: subtract
});

var _ref$m = react.createElement("path", {
  d: "M11.25 21a.75.75 0 001.5 0h-1.5zm1.5-18a.75.75 0 00-1.5 0h1.5zM21 12.75a.75.75 0 000-1.5v1.5zm-18-1.5a.75.75 0 000 1.5v-1.5zM12.75 21V3h-1.5v18h1.5zM21 11.25H3v1.5h18v-1.5z",
  fill: "#000"
});

function add_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$m);
}

var _ref$n = react.createElement("path", {
  d: "M5.03 14.095a.75.75 0 00-1.06 1.06l1.06-1.06zm6.97 8.03l-.53.53a.75.75 0 001.06 0l-.53-.53zm8.03-6.97a.75.75 0 10-1.06-1.06l1.06 1.06zm-7.28-13.28a.75.75 0 00-1.5 0h1.5zm-8.78 13.28l7.5 7.5 1.06-1.06-7.5-7.5-1.06 1.06zm8.56 7.5l7.5-7.5-1.06-1.06-7.5 7.5 1.06 1.06zm-1.28-20.78v20.25h1.5V1.875h-1.5z",
  fill: "#000"
});

function arrow_down_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$n);
}

var _ref$o = react.createElement("path", {
  d: "M22.25 11.5H2M9.5 4L2 11.5m0 0L9.5 19",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function arrow_left_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$o);
}

var _ref$p = react.createElement("path", {
  d: "M2.25 12H22.5M15 19.5l7.5-7.5m0 0L15 4.5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function arrow_right_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$p);
}

var _ref$q = react.createElement("path", {
  d: "M3.97 8.845a.75.75 0 001.06 1.06l-1.06-1.06zM12 1.875l.53-.53a.75.75 0 00-1.06 0l.53.53zm6.97 8.03a.75.75 0 101.06-1.06l-1.06 1.06zm-7.72 12.22a.75.75 0 001.5 0h-1.5zM5.03 9.905l7.5-7.5-1.06-1.06-7.5 7.5 1.06 1.06zm6.44-7.5l7.5 7.5 1.06-1.06-7.5-7.5-1.06 1.06zm1.28 19.72V1.875h-1.5v20.25h1.5z",
  fill: "#000"
});

function arrow_up_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$q);
}

var _ref$r = react.createElement("path", {
  d: "M10 21.75a2.087 2.087 0 004.005 0M12 3a7.5 7.5 0 017.5 7.5c0 7.046 1.5 8.25 1.5 8.25H3s1.5-1.916 1.5-8.25A7.5 7.5 0 0112 3zm0 0V.75",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function bell_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$r);
}

var _ref$s = react.createElement("path", {
  d: "M7.25 1a.75.75 0 00-1.5 0h1.5zm-1.5 5a.75.75 0 001.5 0h-1.5zm12.5-5a.75.75 0 00-1.5 0h1.5zm-1.5 5a.75.75 0 001.5 0h-1.5zM2.5 23.25h19v-1.5h-19v1.5zM5.75 1v5h1.5V1h-1.5zm11 0v5h1.5V1h-1.5zm4.75 1.75h-19v1.5h19v-1.5zM.75 4.5v5h1.5v-5H.75zm0 5v12h1.5v-12H.75zm22.5 12v-12h-1.5v12h1.5zm0-12v-5h-1.5v5h1.5zm-.75-.75h-21v1.5h21v-1.5zm-1-4.5a.25.25 0 01.25.25h1.5a1.75 1.75 0 00-1.75-1.75v1.5zm0 19a1.75 1.75 0 001.75-1.75h-1.5a.25.25 0 01-.25.25v1.5zm-19-1.5a.25.25 0 01-.25-.25H.75c0 .966.784 1.75 1.75 1.75v-1.5zm0-19A1.75 1.75 0 00.75 4.5h1.5a.25.25 0 01.25-.25v-1.5z",
  fill: "#000"
});

function calendar_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$s);
}

var _ref$t = react.createElement("path", {
  d: "M1.5 15l6 6 15-18",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function check_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$t);
}

var _ref$u = react.createElement("path", {
  d: "M19 8.5l-7 7-7-7",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_down_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$u);
}

var _ref$v = react.createElement("path", {
  d: "M15 5l-7 7 7 7",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_left_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$v);
}

var _ref$w = react.createElement("path", {
  d: "M9 19l7-7-7-7",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_right_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$w);
}

var _ref$x = react.createElement("path", {
  d: "M5 15.5l7-7 7 7",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function chevron_up_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$x);
}

var _ref$y = react.createElement("path", {
  d: "M5 19L19 5m0 14L5 5",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function close_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$y);
}

var _ref$z = react.createElement("path", {
  d: "M8.28 13.47a.75.75 0 00-1.06 1.06l1.06-1.06zM12 18.25l-.53.53a.75.75 0 001.06 0l-.53-.53zm4.78-3.72a.75.75 0 10-1.06-1.06l1.06 1.06zm-4.03-9.78a.75.75 0 00-1.5 0h1.5zM4 22.25a.75.75 0 000 1.5v-1.5zm16 1.5a.75.75 0 000-1.5v1.5zM7.22 14.53l4.25 4.25 1.06-1.06-4.25-4.25-1.06 1.06zm5.31 4.25l4.25-4.25-1.06-1.06-4.25 4.25 1.06 1.06zM11.25 4.75v13.5h1.5V4.75h-1.5zM4 23.75h16v-1.5H4v1.5z",
  fill: "#000"
});

function download_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$z);
}

var _ref$A = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M12.75 3.25a.75.75 0 00-1.5 0v11.868a.75.75 0 001.5 0V3.25zm-1.583 15.503a1.5 1.5 0 111.667 2.495 1.5 1.5 0 01-1.667-2.495z",
  fill: "#000"
});

function exclamation_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$A);
}

var _ref$B = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M10.75 5.998a1.5 1.5 0 100-2.998 1.5 1.5 0 000 2.998zm-1.5 2.998a.75.75 0 100 1.5h1.124c.207 0 .375.168.375.374v7.622a2.999 2.999 0 002.998 2.999h1.125a.75.75 0 000-1.5h-1.125a1.499 1.499 0 01-1.498-1.499V10.87c0-1.035-.84-1.874-1.875-1.874H9.25z",
  fill: "#000"
});

function information_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$B);
}

var _ref$C = react.createElement("path", {
  d: "M18.03 16.97a.75.75 0 10-1.06 1.06l1.06-1.06zm4.44 6.56a.75.75 0 101.06-1.06l-1.06 1.06zm-5.5-5.5l5.5 5.5 1.06-1.06-5.5-5.5-1.06 1.06zm.28-8.53a7.75 7.75 0 01-7.75 7.75v1.5a9.25 9.25 0 009.25-9.25h-1.5zM9.5 17.25A7.75 7.75 0 011.75 9.5H.25a9.25 9.25 0 009.25 9.25v-1.5zM1.75 9.5A7.75 7.75 0 019.5 1.75V.25A9.25 9.25 0 00.25 9.5h1.5zM9.5 1.75a7.75 7.75 0 017.75 7.75h1.5A9.25 9.25 0 009.5.25v1.5z",
  fill: "#000"
});

function loupe_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$C);
}

var _ref$D = react.createElement("path", {
  d: "M8 12a2 2 0 11-4 0 2 2 0 014 0zm4 2a2 2 0 100-4 2 2 0 000 4zm6 0a2 2 0 100-4 2 2 0 000 4z",
  fill: "#000"
});

function more_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$D);
}

var _ref$E = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M8.5 7.428c0-1.951 1.735-3.553 3.665-3.42 1.948.135 3.426 1.975 3.16 3.892a3.465 3.465 0 01-2.253 2.762 2.642 2.642 0 00-1.317.976c-.297.423-.446.9-.523 1.356a7.52 7.52 0 00-.08 1.342c.003.217.009.4.014.572.007.201.013.387.013.592a.75.75 0 001.5 0c0-.201-.008-.45-.015-.69l-.013-.495a6.078 6.078 0 01.06-1.072c.054-.318.144-.561.272-.742.12-.17.295-.32.589-.425a4.964 4.964 0 003.24-3.97c.384-2.772-1.724-5.4-4.543-5.594C9.476 2.319 7.001 4.602 7 7.428a.75.75 0 101.5 0zM12 21.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z",
  fill: "#000"
});

function question_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$E);
}

var _ref$F = react.createElement("path", {
  d: "M13.628 21.615a.75.75 0 10.248 1.48l-.248-1.48zM8 21.71l.633-.401-.127-.201-.22-.091L8 21.71zM9.25 16a.75.75 0 00-1.5 0h1.5zm-.75 6.5v.75a.75.75 0 00.75-.75H8.5zM2 21.75a.75.75 0 000 1.5v-1.5zM2.25 12A9.75 9.75 0 0112 2.25V.75C5.787.75.75 5.787.75 12h1.5zM12 2.25A9.75 9.75 0 0121.75 12h1.5C23.25 5.787 18.213.75 12 .75v1.5zM21.75 12c0 4.83-3.512 8.84-8.122 9.615l.248 1.48c5.32-.894 9.374-5.52 9.374-11.095h-1.5zM8.286 21.018A9.753 9.753 0 012.25 12H.75c0 4.697 2.878 8.72 6.964 10.405l.572-1.387zM7.75 16v6.5h1.5V16h-1.5zm.75 5.75H2v1.5h6.5v-1.5zm-1.133.363l.5.788 1.266-.802-.5-.79-1.266.804z",
  fill: "#000"
});

function reset_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$F);
}

var _ref$G = react.createElement("path", {
  d: "M9 7.5l3 3m0 0l3-3m-3 3V.75m7.5 19.5h-15m14-3h-1m-15.25 6h19.5a1.5 1.5 0 001.5-1.5v-6a1.5 1.5 0 00-1.5-1.5H2.25a1.5 1.5 0 00-1.5 1.5v6a1.5 1.5 0 001.5 1.5z",
  stroke: "#000",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

function save_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$G);
}

var _ref$H = react.createElement("path", {
  d: "M21 12.75a.75.75 0 000-1.5v1.5zm-18-1.5a.75.75 0 000 1.5v-1.5zm18 0H3v1.5h18v-1.5z",
  fill: "#000"
});

function subtract_medium(props) {
  return react.createElement("svg", _extends({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _ref$H);
}

var primary_icons_medium = /*#__PURE__*/Object.freeze({
            __proto__: null,
            add_medium: add_medium,
            arrow_down_medium: arrow_down_medium,
            arrow_left_medium: arrow_left_medium,
            arrow_right_medium: arrow_right_medium,
            arrow_up_medium: arrow_up_medium,
            bell_medium: bell_medium,
            calendar_medium: calendar_medium,
            check_medium: check_medium,
            chevron_down_medium: chevron_down_medium,
            chevron_left_medium: chevron_left_medium,
            chevron_right_medium: chevron_right_medium,
            chevron_up_medium: chevron_up_medium,
            close_medium: close_medium,
            download_medium: download_medium,
            exclamation_medium: exclamation_medium,
            information_medium: information_medium,
            loupe_medium: loupe_medium,
            more_medium: more_medium,
            question_medium: question_medium,
            reset_medium: reset_medium,
            save_medium: save_medium,
            subtract_medium: subtract_medium
});

function _createSuper$3(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$4(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$4() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var icons = _extends({}, primary_icons, primary_icons_medium);

var IconPrimary = function (_React$PureComponent) {
  _inherits(IconPrimary, _React$PureComponent);

  var _super = _createSuper$3(IconPrimary);

  function IconPrimary() {
    _classCallCheck(this, IconPrimary);

    return _super.apply(this, arguments);
  }

  _createClass(IconPrimary, [{
    key: "render",
    value: function render() {
      var _this$context;

      var props = extendPropsWithContext(this.props, IconPrimary.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.formRow);

      var _prepareIcon = prepareIcon(props, this.context),
          icon = _prepareIcon.icon,
          size = _prepareIcon.size,
          wrapperParams = _prepareIcon.wrapperParams,
          iconParams = _prepareIcon.iconParams,
          alt = _prepareIcon.alt;

      var IconContainer = prerenderIcon({
        icon: icon,
        size: size,
        alt: alt,
        listOfIcons: icons
      });
      if (!IconContainer) return react.createElement(react.Fragment, null);
      return react.createElement("span", wrapperParams, react.createElement(IconContainer, iconParams));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      Icon.enableWebComponent(IconPrimary.tagName, IconPrimary);
    }
  }, {
    key: "getIcon",
    value: function getIcon(props) {
      return Icon.getIcon(props);
    }
  }]);

  return IconPrimary;
}(react.PureComponent);

IconPrimary.tagName = 'dnb-icon-primary';
IconPrimary.contextType = Context;
IconPrimary.defaultProps = _extends({}, Icon.defaultProps);

var _strictMethod = function (method, arg) {
  return !!method && _fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};

var $sort = [].sort;
var test$1 = [1, 2, 3];

_export(_export.P + _export.F * (_fails(function () {
  // IE8-
  test$1.sort(undefined);
}) || !_fails(function () {
  // V8 bug
  test$1.sort(null);
  // Old WebKit
}) || !_strictMethod($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined
      ? $sort.call(_toObject(this))
      : $sort.call(_toObject(this), _aFunction(comparefn));
  }
});

function AlignmentHelper(_ref) {
  var className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, ["className", "children"]);

  return react.createElement("span", _extends({
    className: classnames('dnb-alignment-helper', className),
    "aria-hidden": true
  }, props), children);
}
AlignmentHelper.defaultProps = {
  children: null,
  className: null
};

var SuffixContext = react.createContext();

var Suffix = function Suffix(props) {
  if (!(props && props.suffix)) {
    return null;
  }

  if (typeof props.children !== 'string') {
    return react.createElement(SuffixContext.Provider, {
      value: props
    }, props.children);
  }

  return props.children;
};

function _createSuper$4(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$5(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$5() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var FormLabel = function (_React$PureComponent) {
  _inherits(FormLabel, _React$PureComponent);

  var _super = _createSuper$4(FormLabel);

  function FormLabel() {
    _classCallCheck(this, FormLabel);

    return _super.apply(this, arguments);
  }

  _createClass(FormLabel, [{
    key: "render",
    value: function render() {
      var _this$context;

      var props = extendPropsWithContext(this.props, FormLabel.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.formRow);

      var for_id = props.for_id,
          element = props.element,
          title = props.title,
          className = props.className,
          id = props.id,
          disabled = props.disabled,
          skeleton = props.skeleton,
          label_direction = props.label_direction,
          vertical = props.vertical,
          sr_only = props.sr_only,
          _className = props.class,
          _text = props.text,
          attributes = _objectWithoutProperties(props, ["for_id", "element", "title", "className", "id", "disabled", "skeleton", "label_direction", "vertical", "sr_only", "class", "text"]);

      var content = FormLabel.getContent(this.props);

      var params = _extends({
        className: classnames('dnb-form-label', (isTrue(vertical) || label_direction === 'vertical') && "dnb-form-label--vertical", createSkeletonClass('font', skeleton, this.context), createSpacingClasses(props), className, _className, isTrue(sr_only) && 'dnb-form-label--sr-only'),
        htmlFor: for_id,
        id: id,
        title: title,
        disabled: isTrue(disabled)
      }, attributes);

      if (disabled) {
        params.disabled = true;
      }

      skeletonDOMAttributes(params, skeleton, this.context);
      validateDOMAttributes(this.props, params);
      params.children = content;
      var Element = element;
      return react.createElement(Element, params);
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(FormLabel.tagName, FormLabel, FormLabel.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      if (props.text) return props.text;
      return processChildren(props);
    }
  }]);

  return FormLabel;
}(react.PureComponent);

FormLabel.tagName = 'dnb-form-label';
FormLabel.contextType = Context;
FormLabel.defaultProps = {
  for_id: null,
  element: 'label',
  title: null,
  text: null,
  id: null,
  class: null,
  disabled: null,
  skeleton: null,
  label_direction: null,
  vertical: null,
  sr_only: null,
  className: null,
  children: null
};

var GlobalStatusProvider = function () {
  function GlobalStatusProvider() {
    _classCallCheck(this, GlobalStatusProvider);
  }

  _createClass(GlobalStatusProvider, null, [{
    key: "init",
    value: function init() {
      var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'main';
      var onReady = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var props = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var existingStatus = GlobalStatusProvider.get(id);

      if (existingStatus) {
        if (props) {
          existingStatus.add(props);
        }

        if (typeof onReady === 'function') {
          onReady(existingStatus);
        }

        return existingStatus;
      }

      var newStatus = GlobalStatusProvider.create(id, props);

      if (onReady) {
        newStatus.addOnReady(newStatus, onReady);
      }

      if (id !== 'main') {
        warn("No <GlobalStatus ".concat("id=\"".concat(id, "\""), " /> found."));
      }

      return newStatus;
    }
  }, {
    key: "get",
    value: function get() {
      var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'main';
      return GlobalStatusProvider.providers[id] || null;
    }
  }, {
    key: "remove",
    value: function remove() {
      var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'main';

      if (GlobalStatusProvider.providers[id]) {
        delete GlobalStatusProvider.providers[id];
      }
    }
  }, {
    key: "prepareItemWithStatusId",
    value: function prepareItemWithStatusId(item) {
      var status_id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      if (typeof item === 'string') {
        item = {
          text: item
        };
      }

      if (!item.status_id) {
        item.status_id = status_id && status_id !== 'status-main' ? status_id : slugify(JSON.stringify(item));
      }

      return item;
    }
  }, {
    key: "combineMessages",
    value: function combineMessages(stack) {
      var globalStatus = stack.reduce(function (acc, _cur) {
        var cur = _extends({}, _cur);

        if (typeof cur.items === 'string' && cur.items[0] === '[') {
          cur.items = JSON.parse(cur.items);
        }

        if (cur.item) {
          if (typeof cur.item === 'string' && cur.item[0] === '{') {
            cur.item = JSON.parse(cur.item);
          }

          cur.items = cur.items || [];
          cur.items.push(cur.item);
        }

        if (cur.items) {
          cur.items = cur.items.reduce(function (acc, item) {
            item = GlobalStatusProvider.prepareItemWithStatusId(item);
            var foundAtIndex = acc.findIndex(function (_ref) {
              var status_id = _ref.status_id;
              return status_id === item.status_id;
            });

            if (foundAtIndex > -1) {
              acc[foundAtIndex] = item;
            } else {
              acc.push(item);
            }

            return acc;
          }, acc.items || []);
        }

        _extends(acc, cur);

        return acc;
      }, {});
      return globalStatus;
    }
  }]);

  return GlobalStatusProvider;
}();

GlobalStatusProvider.providers = {};

GlobalStatusProvider.create = function () {
  var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'main';
  var props = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  return GlobalStatusProvider.providers[id] = new GlobalStatusProviderItem(id, props);
};

var GlobalStatusProviderItem = function () {
  function GlobalStatusProviderItem(id) {
    var props = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

    _classCallCheck(this, GlobalStatusProviderItem);

    this.stack = [];
    this.globalStatus = {};
    this._onUpdateEvents = [];
    this._onReadyEvents = [];
    this.internal_id = id;

    if (props) {
      this.add(props);
    }
  }

  _createClass(GlobalStatusProviderItem, [{
    key: "onUpdate",
    value: function onUpdate(event) {
      if (this._onUpdateEvents.filter(function (cb) {
        return cb === event;
      }).length === 0) {
        this._onUpdateEvents.push(event);
      }
    }
  }, {
    key: "forceRerender",
    value: function forceRerender(globalStatus, props) {
      var _this = this;

      var _ref2 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
          _ref2$buffer_delay = _ref2.buffer_delay,
          buffer_delay = _ref2$buffer_delay === void 0 ? 0 : _ref2$buffer_delay,
          _ref2$isEmpty = _ref2.isEmpty,
          isEmpty = _ref2$isEmpty === void 0 ? false : _ref2$isEmpty;

      var run = function run() {
        _this._onUpdateEvents.forEach(function (event) {
          if (typeof event === 'function') {
            event(globalStatus, props, {
              isEmpty: isEmpty
            });
          }
        });
      };

      if (buffer_delay > 0) {
        clearTimeout(this._bufferDelayId);
        this._bufferDelayId = setTimeout(run, buffer_delay);
      } else {
        run();
      }
    }
  }, {
    key: "init",
    value: function init(props) {
      return this.add(props, {
        preventRerender: true
      });
    }
  }, {
    key: "add",
    value: function add(props) {
      var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      this.remove('internal-close', {
        preventRerender: true
      });

      var newProps = _extends({}, props);

      if (!newProps.status_id) {
        newProps.status_id = makeUniqueId();
      }

      if (typeof newProps.show === 'undefined') {
        newProps.show = true;
      }

      if (newProps.children) {
        newProps.text = newProps.children;
        delete newProps.children;
      }

      var stackIndex = this.stack.findIndex(function (cur) {
        return cur.status_id === newProps.status_id;
      });

      if (stackIndex > -1) {
        this.stack[stackIndex] = newProps;
      } else {
        this.stack.push(newProps);
      }

      var globalStatus = GlobalStatusProvider.combineMessages(this.stack);

      if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
        this.forceRerender(globalStatus, props, {
          buffer_delay: (props === null || props === void 0 ? void 0 : props.buffer_delay) > -1 ? props.buffer_delay : 0
        });
      }

      return globalStatus;
    }
  }, {
    key: "get",
    value: function get(status_id) {
      return this.stack.find(function (cur) {
        return cur.status_id === status_id;
      });
    }
  }, {
    key: "update",
    value: function update(status_id, newProps) {
      var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      if (status_id) {
        var item = this.get(status_id);

        if (!item) {
          this.add(newProps);
        }
      }

      this.stack = this.stack.map(function (cur, i, arr) {
        if (!status_id ? i === arr.length - 1 : cur.status_id === status_id) {
          if (!status_id) {
            newProps = _extends({}, newProps);
            delete newProps.status_id;
          }

          return _extends({}, cur, newProps);
        }

        return cur;
      });

      if (!(opts !== null && opts !== void 0 && opts.preventRestack)) {
        this.restack(status_id);
      }

      var globalStatus = GlobalStatusProvider.combineMessages(this.stack);

      if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
        var _newProps;

        this.forceRerender(globalStatus, null, {
          buffer_delay: ((_newProps = newProps) === null || _newProps === void 0 ? void 0 : _newProps.buffer_delay) > -1 ? newProps.buffer_delay : 0
        });
      }
    }
  }, {
    key: "restack",
    value: function restack(status_id) {
      var item = this.get(status_id);

      if (item) {
        this.stack = this.stack.filter(function (cur) {
          return cur.status_id !== status_id;
        });
        this.stack.push(item);
      }
    }
  }, {
    key: "remove",
    value: function remove(status_id) {
      var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (status_id) {
        this.stack = this.stack.filter(function (cur) {
          return cur.status_id !== status_id;
        });
        var globalStatus = GlobalStatusProvider.combineMessages(this.stack);

        if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
          this.forceRerender(globalStatus, null, {
            buffer_delay: (opts === null || opts === void 0 ? void 0 : opts.buffer_delay) > -1 ? opts.buffer_delay : 10
          });
        }
      }
    }
  }, {
    key: "empty",
    value: function empty() {
      var _this2 = this;

      this._onUpdateEvents.forEach(function (cb, i) {
        _this2._onUpdateEvents[i] = null;
      });

      this._onUpdateEvents = [];

      this._onReadyEvents.forEach(function (cb, i) {
        _this2._onReadyEvents[i] = null;
      });

      this._onReadyEvents = [];
    }
  }, {
    key: "unbind",
    value: function unbind() {
      this.empty();
      GlobalStatusProvider.remove(this.internal_id);
    }
  }, {
    key: "isReady",
    value: function isReady() {
      var _this3 = this;

      this._onReadyEvents = this._onReadyEvents.filter(function (_ref3, i) {
        var status = _ref3.status,
            cb = _ref3.cb;

        if (typeof cb === 'function') {
          cb(status);
        }

        _this3._onReadyEvents[i] = null;
        return false;
      });
      return true;
    }
  }, {
    key: "addOnReady",
    value: function addOnReady(status, cb) {
      this._onReadyEvents.push({
        status: status,
        cb: cb
      });
    }
  }]);

  return GlobalStatusProviderItem;
}();

if (typeof window !== 'undefined') {
  window.GlobalStatusProvider = GlobalStatusProvider;
}

var slugify = function slugify(s) {
  return s.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '');
};

function _createSuper$5(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$6(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$6() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var FormStatus = function (_React$PureComponent) {
  _inherits(FormStatus, _React$PureComponent);

  var _super = _createSuper$5(FormStatus);

  _createClass(FormStatus, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(FormStatus.tagName, FormStatus, FormStatus.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      if (props.text) {
        if (isTrue(props.text)) {
          return null;
        }

        return props.text;
      }

      return processChildren(props);
    }
  }, {
    key: "getIcon",
    value: function getIcon(_ref) {
      var state = _ref.state,
          icon = _ref.icon,
          icon_size = _ref.icon_size;

      if (typeof icon === 'string') {
        var IconToLoad = icon;

        switch (state) {
          case 'info':
          case 'information':
            IconToLoad = InfoIcon;
            break;

          case 'warn':
          case 'warning':
            IconToLoad = WarnIcon;
            break;

          case 'error':
          default:
            IconToLoad = ErrorIcon;
        }

        icon = react.createElement(Icon, {
          icon: react.createElement(IconToLoad, {
            title: null
          }),
          size: icon_size,
          inherit_color: false
        });
      }

      return icon;
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._id !== props.id) {
        state.id = props.id;
      }

      state._id = props.id;
      return state;
    }
  }]);

  function FormStatus(props) {
    var _this;

    _classCallCheck(this, FormStatus);

    _this = _super.call(this, props);
    _this.state = {
      id: null
    };
    _this.state.id = props.id || makeUniqueId();

    if (props.status !== 'info') {
      _this.gsProvider = GlobalStatusProvider.init(props.global_status_id || 'main', function (provider) {
        var _this$props = _this.props,
            state = _this$props.state,
            text = _this$props.text,
            label = _this$props.label;
        provider.add({
          state: state,
          status_id: "".concat(_this.state.id, "-gs"),
          item: {
            status_id: _this.state.id,
            text: text,
            status_anchor_label: label,
            status_anchor_url: true
          }
        });
      });
    }

    _this._ref = react.createRef();
    return _this;
  }

  _createClass(FormStatus, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.gsProvider) {
        this.gsProvider.isReady();
      }

      this.updateWidth();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.gsProvider && (prevProps.text !== this.props.text || prevProps.state !== this.props.state)) {
        var _this$props2 = this.props,
            state = _this$props2.state,
            text = _this$props2.text,
            label = _this$props2.label;
        var status_id = "".concat(this.state.id, "-gs");
        this.gsProvider.update(status_id, {
          state: state,
          item: {
            status_id: this.state.id,
            text: text,
            status_anchor_label: label,
            status_anchor_url: true
          }
        }, {
          preventRestack: true
        });
      }

      this.updateWidth();
    }
  }, {
    key: "correctStatus",
    value: function correctStatus(state) {
      switch (state) {
        case 'information':
          state = 'info';
          break;

        case 'warning':
          state = 'warn';
          break;
      }

      return state;
    }
  }, {
    key: "updateWidth",
    value: function updateWidth() {
      if (this._ref.current) {
        var _this$props3 = this.props,
            width_element = _this$props3.width_element,
            width_selector = _this$props3.width_selector;
        setMaxWidthToElement({
          element: this._ref.current,
          widthElement: width_element && width_element.current,
          widthSelector: width_selector
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.gsProvider) {
        var status_id = "".concat(this.state.id, "-gs");
        this.gsProvider.remove(status_id);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var props = extendPropsWithContext(this.props, FormStatus.defaultProps, {
        skeleton: this.context && this.context.skeleton
      }, this.context.formRow);

      var title = props.title,
          rawStatus = props.status,
          rawState = props.state,
          size = props.size,
          variant = props.variant,
          hidden = props.hidden,
          className = props.className,
          animation = props.animation,
          _className = props.class,
          text_id = props.text_id,
          status_id = props.status_id,
          id = props.id,
          text = props.text,
          icon = props.icon,
          icon_size = props.icon_size,
          skeleton = props.skeleton,
          children = props.children,
          attributes = _objectWithoutProperties(props, ["title", "status", "state", "size", "variant", "hidden", "className", "animation", "class", "text_id", "status_id", "id", "text", "icon", "icon_size", "skeleton", "children"]);

      var state = this.correctStatus(rawStatus || rawState);
      var iconToRender = FormStatus.getIcon({
        state: state,
        icon: icon,
        icon_size: icon_size
      });
      var contentToRender = FormStatus.getContent(this.props);

      if (contentToRender === null) {
        return react.createElement(react.Fragment, null);
      }

      var hasStringContent = typeof contentToRender === 'string' && contentToRender.length > 0;

      var params = _extends({
        id: this.state.id,
        hidden: hidden,
        className: classnames("dnb-form-status dnb-form-status--".concat(state, " dnb-form-status__size--").concat(size), createSpacingClasses(props), className, _className, variant && "dnb-form-status__variant--".concat(variant), animation && "dnb-form-status__animation--".concat(animation), hasStringContent && 'dnb-form-status--has-content'),
        title: title
      }, attributes);

      var textParams = {
        className: classnames('dnb-form-status__text', createSkeletonClass('font', skeleton, this.context)),
        id: text_id
      };

      if (hidden) {
        params['aria-hidden'] = hidden;
      }

      skeletonDOMAttributes(params, skeleton, this.context);
      validateDOMAttributes(this.props, params);
      validateDOMAttributes(null, textParams);
      return react.createElement("span", _extends({}, params, {
        ref: this._ref
      }), react.createElement("span", {
        className: "dnb-form-status__shell"
      }, iconToRender, react.createElement("span", textParams, contentToRender)));
    }
  }]);

  return FormStatus;
}(react.PureComponent);

FormStatus.tagName = 'dnb-form-status';
FormStatus.contextType = Context;
FormStatus.defaultProps = {
  id: null,
  title: null,
  text: null,
  label: null,
  icon: 'error',
  icon_size: 'medium',
  size: 'default',
  variant: null,
  state: 'error',
  status: null,
  global_status_id: null,
  hidden: false,
  text_id: null,
  width_selector: null,
  width_element: null,
  class: null,
  animation: null,
  skeleton: null,
  className: null,
  children: null
};

var _ref2 = react.createElement("path", {
  d: "M23.625 17.864A3.547 3.547 0 0120.45 23H3.548a3.546 3.546 0 01-3.172-5.136l8.45-14.902a3.548 3.548 0 016.347 0l8.452 14.902z",
  fill: "#DC2A2A"
});

var _ref3 = react.createElement("path", {
  d: "M12 16.286a1.286 1.286 0 100 2.572 1.286 1.286 0 000-2.572z",
  fill: "#fff"
});

var _ref4 = react.createElement("path", {
  d: "M12 13.818v-5",
  stroke: "#fff",
  strokeWidth: "1.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

var ErrorIcon = function ErrorIcon(props) {
  return react.createElement("svg", _extends({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react.createElement("title", null, props.title), _ref2, _ref3, _ref4);
};
ErrorIcon.defaultProps = {
  title: 'error'
};

var _ref5 = react.createElement("path", {
  d: "M23.625 17.864A3.547 3.547 0 0120.45 23H3.548a3.546 3.546 0 01-3.172-5.136l8.45-14.902a3.548 3.548 0 016.347 0l8.452 14.902z",
  fill: "#FDBB31"
});

var _ref6 = react.createElement("path", {
  d: "M12 16.286a1.286 1.286 0 100 2.572 1.286 1.286 0 000-2.572z",
  fill: "#333"
});

var _ref7 = react.createElement("path", {
  d: "M12 13.818v-5",
  stroke: "#333",
  strokeWidth: "1.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

var WarnIcon = function WarnIcon(props) {
  return react.createElement("svg", _extends({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react.createElement("title", null, props.title), _ref5, _ref6, _ref7);
};
WarnIcon.defaultProps = {
  title: 'error'
};

var _ref8 = react.createElement("path", {
  fillRule: "evenodd",
  clipRule: "evenodd",
  d: "M11.268 0a11.25 11.25 0 105.566 21.017l6.112 2.91a.75.75 0 001-1l-2.911-6.112A11.234 11.234 0 0011.268 0z",
  fill: "#007272"
});

var _ref9 = react.createElement("circle", {
  cx: "11",
  cy: "6.5",
  r: ".5",
  fill: "#fff",
  stroke: "#fff"
});

var _ref10 = react.createElement("path", {
  d: "M13.75 16H13a1.5 1.5 0 01-1.5-1.5v-3.75a.75.75 0 00-.75-.75H10",
  stroke: "#fff",
  strokeWidth: "1.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
});

var InfoIcon = function InfoIcon(props) {
  return react.createElement("svg", _extends({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react.createElement("title", null, props.title), _ref8, _ref9, _ref10);
};
InfoIcon.defaultProps = {
  title: 'info'
};
FormStatus.setMaxWidthToElement = setMaxWidthToElement;

function setMaxWidthToElement(_ref11) {
  var element = _ref11.element,
      _ref11$id = _ref11.id,
      id = _ref11$id === void 0 ? null : _ref11$id,
      _ref11$widthElement = _ref11.widthElement,
      widthElement = _ref11$widthElement === void 0 ? null : _ref11$widthElement,
      _ref11$widthSelector = _ref11.widthSelector,
      widthSelector = _ref11$widthSelector === void 0 ? null : _ref11$widthSelector;

  if (!(element && typeof window !== 'undefined')) {
    return;
  }

  try {
    if (!id && !widthSelector) {
      id = element.getAttribute('id');
    }

    var width = sumElementWidth({
      widthElement: widthElement,
      widthSelector: widthSelector || id.replace('-form-status', '') || id
    });

    if (width > 40) {
      var minWidth = 12 * 16;

      if (width < minWidth) {
        width = minWidth;
      }

      var remWidth = "".concat(width / 16, "rem");
      var cS = window.getComputedStyle(element);
      var hasCustomWidth = element.style.maxWidth ? false : cS.minWidth !== '' && cS.minWidth !== 'auto' || cS.maxWidth !== '' && cS.maxWidth !== 'none';

      if (!hasCustomWidth) {
        element.style.maxWidth = remWidth;
      }
    }
  } catch (e) {}
}

function sumElementWidth(_ref12) {
  var widthElement = _ref12.widthElement,
      widthSelector = _ref12.widthSelector;
  var width = 0;

  if (typeof document === 'undefined') {
    return width;
  }

  try {
    var ids = widthElement ? [widthElement] : widthSelector.split(/, |,/g);
    width = ids.reduce(function (acc, cur) {
      var elem = typeof cur === 'string' ? cur[0] === '.' ? document.querySelector(cur) : document.getElementById(cur) : cur;
      var width = elem && elem.offsetWidth || window.getComputedStyle(elem).width;

      if (/em|rem/.test(width)) {
        width = parseFloat(width) * 16;
      }

      if (width > 0) {
        if (acc > 0) {
          acc += 16;
        }

        acc += width;
      }

      return acc;
    }, width);
  } catch (e) {}

  return width;
}

function _createSuper$6(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$7(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$7() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var TooltipContainer = function (_React$PureComponent) {
  _inherits(TooltipContainer, _React$PureComponent);

  var _super = _createSuper$6(TooltipContainer);

  function TooltipContainer() {
    var _this;

    _classCallCheck(this, TooltipContainer);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    _this._rootRef = react.createRef();
    _this.offset = 16;
    _this.state = {
      hide: null,
      hover: null,
      width: 0,
      height: 0
    };

    _this.handleMouseEnter = function () {
      isTrue(_this.props.active) && _this.props.useHover && _this.setState({
        hover: true
      });
    };

    _this.handleMouseLeave = function () {
      _this.props.useHover && _this.setState({
        hover: false
      });
    };

    return _this;
  }

  _createClass(TooltipContainer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (isTrue(this.props.active)) {
        this.updateSize();
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.props !== prevProps) {
        this.updateSize();
      }
    }
  }, {
    key: "getGlobalStyle",
    value: function getGlobalStyle() {
      if (!this.props.targetElement) {
        return {
          display: 'none'
        };
      }

      var style = _extends({}, this.makeStyle(this.props.position, this.props.arrow));

      return style;
    }
  }, {
    key: "makeStyle",
    value: function makeStyle(position, arrow) {
      var _this2 = this;

      if (typeof window === 'undefined') {
        return {};
      }

      var alignOffset = 0;
      var target = this.props.targetElement;
      var align = this.props.align;
      var tooltipPosition = target.getBoundingClientRect();
      var scrollY = window.scrollY !== undefined ? window.scrollY : window.pageYOffset;
      var scrollX = window.scrollX !== undefined ? window.scrollX : window.pageXOffset;

      var _top = scrollY + tooltipPosition.top;

      var _left = scrollX + tooltipPosition.left;

      var style = {};
      var targetSize = {
        width: target.offsetWidth,
        height: target.offsetHeight
      };

      if (!target.offsetHeight && target.getBoundingClientRect) {
        targetSize.width = target.getBoundingClientRect().width;
        targetSize.height = target.getBoundingClientRect().height;
      }

      if (align === 'left') {
        alignOffset = -targetSize.width / 2;
      } else if (align === 'right') {
        alignOffset = targetSize.width / 2;
      }

      var stylesFromPosition = {
        left: function left() {
          style.top = _top + targetSize.height / 2 - _this2.state.height / 2;
          style.left = _left - _this2.state.width - _this2.offset;
        },
        right: function right() {
          style.top = _top + targetSize.height / 2 - _this2.state.height / 2;
          style.left = _left + targetSize.width + _this2.offset;
        },
        top: function top() {
          style.left = _left - _this2.state.width / 2 + targetSize.width / 2 + alignOffset;
          style.top = _top - _this2.state.height - _this2.offset;
        },
        bottom: function bottom() {
          style.left = _left - _this2.state.width / 2 + targetSize.width / 2 + alignOffset;
          style.top = _top + targetSize.height + _this2.offset;
        }
      };
      var stylesFromArrow = {
        left: function left() {
          style.left = _left + targetSize.width / 2 - _this2.offset + alignOffset;
        },
        right: function right() {
          style.left = _left - _this2.state.width + targetSize.width / 2 + _this2.offset + alignOffset;
        },
        top: function top() {
          style.top = _top + targetSize.height / 2 - _this2.offset;
        },
        bottom: function bottom() {
          style.top = _top + targetSize.height / 2 - _this2.state.height + _this2.offset;
        }
      };

      if (stylesFromPosition[position]) {
        stylesFromPosition[position]();
      }

      if (stylesFromArrow[arrow]) {
        stylesFromArrow[arrow]();
      }

      return style;
    }
  }, {
    key: "checkWindowPosition",
    value: function checkWindowPosition(style) {
      if (style.left < 0) {
        style.left = this.offset;
      } else {
        try {
          var rightOffset = style.left + this.state.width - window.innerWidth;

          if (rightOffset > 0) {
            style.left = window.innerWidth - this.state.width - this.offset;
          }
        } catch (e) {}
      }

      return style;
    }
  }, {
    key: "updateSize",
    value: function updateSize() {
      var width = this._rootRef.current.offsetWidth;
      var height = this._rootRef.current.offsetHeight;

      if (width !== this.state.width || height !== this.state.height) {
        this.setState({
          width: width,
          height: height,
          _listenForPropChanges: false
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          internal_id = _this$props.internal_id,
          active = _this$props.active,
          attributes = _this$props.attributes,
          arrow = _this$props.arrow,
          position = _this$props.position,
          animate_position = _this$props.animate_position,
          children = _this$props.children;
      var _this$state = this.state,
          hover = _this$state.hover,
          hide = _this$state.hide;
      var style = this.checkWindowPosition(this.getGlobalStyle());
      var isActive = isTrue(active) || hover;
      return react.createElement("div", _extends({
        role: "tooltip",
        "aria-hidden": true,
        style: style,
        ref: this._rootRef,
        onMouseEnter: this.handleMouseEnter,
        onMouseLeave: this.handleMouseLeave
      }, attributes, {
        className: classnames(attributes.className, isActive ? 'dnb-tooltip--active' : hide && 'dnb-tooltip--hide', isTrue(animate_position) && 'dnb-tooltip--animate_position')
      }), arrow && react.createElement("span", {
        className: "dnb-tooltip__arrow dnb-tooltip__arrow__arrow--".concat(arrow, " dnb-tooltip__arrow__position--").concat(position)
      }), react.createElement("div", {
        id: internal_id,
        className: "dnb-tooltip__content"
      }, children));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (state.wasActive && !props.active && !state.hover) {
          state.hide = true;
        }

        if (props.active || state.hover) {
          state.wasActive = true;
          state.hide = false;
        }
      }

      state._listenForPropChanges = true;
      return state;
    }
  }]);

  return TooltipContainer;
}(react.PureComponent);

TooltipContainer.defaultProps = {
  internal_id: null,
  targetElement: null,
  active: false,
  position: 'center',
  arrow: null,
  align: null,
  animate_position: null,
  useHover: true,
  attributes: null,
  children: null
};

function _createSuper$7(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$8(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$8() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var tooltipPortal;

if (typeof window !== 'undefined') {
  window.tooltipPortal = window.tooltipPortal || {};
  tooltipPortal = window.tooltipPortal;
} else {
  tooltipPortal = {};
}

var TooltipPortal = function (_React$PureComponent) {
  _inherits(TooltipPortal, _React$PureComponent);

  var _super = _createSuper$7(TooltipPortal);

  function TooltipPortal() {
    _classCallCheck(this, TooltipPortal);

    return _super.apply(this, arguments);
  }

  _createClass(TooltipPortal, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.renderPortal();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(props) {
      if (!tooltipPortal[this.props.group] || this.props.active && props.active) {
        return;
      }

      this.renderPortal({
        active: true
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (tooltipPortal[this.props.group]) {
        reactDom.unmountComponentAtNode(tooltipPortal[this.props.group].node);
        clearTimeout(tooltipPortal[this.props.group].timeout);

        try {
          document.body.removeChild(tooltipPortal[this.props.group].node);
        } catch (e) {}

        tooltipPortal[this.props.group] = null;
      }
    }
  }, {
    key: "createPortal",
    value: function createPortal() {
      if (typeof document !== 'undefined') {
        try {
          tooltipPortal[this.props.group] = {
            node: document.createElement('div'),
            timeout: null
          };
          tooltipPortal[this.props.group].node.className = 'TooltipPortal';
          document.body.insertBefore(tooltipPortal[this.props.group].node, document.body.firstChild);
        } catch (e) {
          console.warn('Could not create TooltipPortal!', e);
        }
      }
    }
  }, {
    key: "handleAria",
    value: function handleAria(elem) {
      if (elem && this.props.internal_id) {
        try {
          var describedby = makeArrayUnique(String(elem.getAttribute('aria-describedby') || '').split(' '));
          describedby.push(this.props.internal_id);
          elem.setAttribute('aria-describedby', describedby.join(' '));
        } catch (e) {}
      }
    }
  }, {
    key: "renderPortal",
    value: function renderPortal() {
      var _this = this;

      var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (typeof document === 'undefined') {
        return;
      }

      if (!tooltipPortal[this.props.group]) {
        this.createPortal();
      }

      var _this$props = this.props,
          group = _this$props.group,
          target = _this$props.target;
      var targetElement = typeof target === 'string' ? document.querySelector(target) : target;

      if (tooltipPortal[group].timeout) {
        clearTimeout(tooltipPortal[group].timeout);
      }

      if (!this.props.active && props.active) {
        tooltipPortal[group].timeout = setTimeout(function () {
          _this.renderPortal({
            active: false
          });
        }, parseFloat(this.props.hide_delay));
      }

      reactDom.render(react.createElement(TooltipContainer, _extends({
        targetElement: targetElement
      }, this.props, props)), tooltipPortal[this.props.group].node);
      this.handleAria(targetElement);
    }
  }, {
    key: "render",
    value: function render() {
      return null;
    }
  }]);

  return TooltipPortal;
}(react.PureComponent);

TooltipPortal.defaultProps = {
  internal_id: null,
  active: false,
  group: 'main',
  hide_delay: 500
};

var makeArrayUnique = function makeArrayUnique(array) {
  return array.filter(Boolean).filter(function (value, index, self) {
    return self.indexOf(value) === index;
  });
};

function _createSuper$8(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$9(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$9() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var TooltipWithEvents = function (_React$PureComponent) {
  _inherits(TooltipWithEvents, _React$PureComponent);

  var _super = _createSuper$8(TooltipWithEvents);

  function TooltipWithEvents() {
    var _this;

    _classCallCheck(this, TooltipWithEvents);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    _this.state = {
      isActive: false
    };

    _this.onMouseEnter = function () {
      clearTimeout(_this._onEnterTimeout);
      _this._onEnterTimeout = setTimeout(function () {
        _this.setState({
          isActive: true
        });
      }, _this.props.show_delay || 1);
    };

    _this.onMouseLeave = function () {
      clearTimeout(_this._onEnterTimeout);

      _this.setState({
        isActive: false
      });
    };

    return _this;
  }

  _createClass(TooltipWithEvents, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this._onEnterTimeout);
      clearTimeout(this._targetTimeout);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props = this.props,
          children = _this$props.children,
          className = _this$props.className,
          target = _this$props.target,
          props = _objectWithoutProperties(_this$props, ["children", "className", "target"]);

      if (!this.state.target && typeof target.current !== 'undefined') {
        this._targetTimeout = setTimeout(function () {
          if (!target.current) return;

          try {
            var elem = target.current;
            elem.addEventListener('mouseenter', _this2.onMouseEnter);
            elem.addEventListener('mouseleave', _this2.onMouseLeave);
            var describedby = [_this2.props.internal_id];
            var db = elem.getAttribute('aria-describedby');

            if (db) {
              describedby.unshift(db);
            }

            elem.setAttribute('aria-describedby', describedby.join(' '));
          } catch (e) {
            console.warn('Tooltip: Could not add event listeners', e);
          }

          _this2.setState({
            target: target.current
          });
        }, 1);
        return null;
      }

      var componentWrapper;

      if (react.isValidElement(target)) {
        var describedby = [this.props.internal_id];

        if (target.props && target.props['aria-describedby']) {
          describedby.unshift(target.props['aria-describedby']);
        }

        componentWrapper = react.createElement("span", {
          key: "target-wrapper",
          ref: function ref(target) {
            return _this2.setState({
              target: target
            });
          },
          className: className,
          onMouseEnter: this.onMouseEnter,
          onMouseLeave: this.onMouseLeave
        }, react.cloneElement(target, {
          'aria-describedby': describedby.join(' ')
        }));
      }

      return react.createElement(react.Fragment, null, componentWrapper, this.state.target && react.createElement(TooltipPortal, _extends({
        key: "tooltip",
        active: this.state.isActive,
        target: this.state.target
      }, props), children));
    }
  }]);

  return TooltipWithEvents;
}(react.PureComponent);

TooltipWithEvents.defaultProps = {
  className: '',
  internal_id: null,
  show_delay: 1,
  target: null,
  children: null
};

function _createSuper$9(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$a(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$a() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Tooltip = function (_React$PureComponent) {
  _inherits(Tooltip, _React$PureComponent);

  var _super = _createSuper$9(Tooltip);

  _createClass(Tooltip, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Tooltip.tagName, Tooltip, Tooltip.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return processChildren(props);
    }
  }]);

  function Tooltip(props) {
    var _this;

    _classCallCheck(this, Tooltip);

    _this = _super.call(this, props);
    _this._id = props.id || makeUniqueId();
    return _this;
  }

  _createClass(Tooltip, [{
    key: "render",
    value: function render() {
      var props = extendPropsWithContext(this.props, Tooltip.defaultProps, this.context.formRow);

      var component = props.component,
          target = props.target,
          class_name = props.class,
          className = props.className,
          group = props.group,
          animate_position = props.animate_position,
          show_delay = props.show_delay,
          hide_delay = props.hide_delay,
          active = props.active,
          position = props.position,
          arrow = props.arrow,
          align = props.align,
          params = _objectWithoutProperties(props, ["component", "target", "class", "className", "group", "animate_position", "show_delay", "hide_delay", "active", "position", "arrow", "align"]);

      var content = Tooltip.getContent(this.props);
      var classes = classnames("dnb-tooltip dnb-core-style", createSpacingClasses(props), class_name, className);

      var attributes = _extends({
        className: classes
      }, params);

      validateDOMAttributes(this.props, attributes);

      var newProps = _extends({}, this.props, {
        internal_id: this._id,
        group: this.props.id || group
      });

      if (typeof newProps.active === 'undefined') {
        delete newProps.active;
      }

      return react.createElement(react.Fragment, null, component ? react.createElement(TooltipWithEvents, _extends({
        target: component,
        attributes: attributes
      }, newProps), content) : target && react.createElement(TooltipPortal, _extends({
        target: target,
        attributes: attributes
      }, newProps), content));
    }
  }]);

  return Tooltip;
}(react.PureComponent);

Tooltip.tagName = 'dnb-tooltip';
Tooltip.contextType = Context;
Tooltip.defaultProps = {
  id: null,
  group: 'main',
  active: undefined,
  position: 'top',
  arrow: 'center',
  align: null,
  animate_position: false,
  show_delay: 300,
  hide_delay: 500,
  class: null,
  className: null,
  children: null,
  onClick: null,
  on_click: null
};

function _createSuper$a(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$b(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$b() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Button = function (_React$PureComponent) {
  _inherits(Button, _React$PureComponent);

  var _super = _createSuper$a(Button);

  _createClass(Button, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Button.tagName, Button, Button.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return processChildren(props);
    }
  }]);

  function Button(props) {
    var _this;

    _classCallCheck(this, Button);

    _this = _super.call(this, props);

    _this.onClickHandler = function (event) {
      var afterContent = dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_click', {
        event: event
      });

      if (afterContent && react.isValidElement(afterContent)) {
        _this.setState({
          afterContent: afterContent
        });
      }
    };

    _this._id = props.id || (props.status || props.tooltip) && makeUniqueId();
    _this._ref = react.createRef();
    _this.state = {
      afterContent: null
    };
    return _this;
  }

  _createClass(Button, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.props.innerRef) {
        this.props.innerRef.current = this._ref.current;
      }

      if (this.props.inner_ref) {
        this.props.inner_ref.current = this._ref.current;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$context;

      var props = extendPropsWithContext(this.props, Button.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.formRow);

      var class_name = props.class,
          className = props.className,
          type = props.type,
          variant = props.variant,
          size = props.size,
          title = props.title,
          tooltip = props.tooltip,
          status = props.status,
          status_state = props.status_state,
          status_animation = props.status_animation,
          global_status_id = props.global_status_id,
          id = props.id,
          disabled = props.disabled,
          _text = props.text,
          _icon = props.icon,
          _icon_position = props.icon_position,
          icon_size = props.icon_size,
          href = props.href,
          wrap = props.wrap,
          bounding = props.bounding,
          skeleton = props.skeleton,
          element = props.element,
          inner_ref = props.inner_ref,
          innerRef = props.innerRef,
          attributes = _objectWithoutProperties(props, ["class", "className", "type", "variant", "size", "title", "tooltip", "status", "status_state", "status_animation", "global_status_id", "id", "disabled", "text", "icon", "icon_position", "icon_size", "href", "wrap", "bounding", "skeleton", "element", "inner_ref", "innerRef"]);

      var showStatus = getStatusState(status);
      var text = props.text,
          icon = props.icon,
          iconPosition = props.icon_position;
      var usedVariant = variant;
      var usedSize = size;
      var content = Button.getContent(this.props) || text;

      if (variant === 'tertiary' && content && !icon && icon !== false) {
        warn("A Tertiary Button requires an icon. Please declare an icon to: ".concat(content));
      }

      var isIconOnly = Boolean(!text && !content && icon);

      if (isIconOnly) {
        if (!usedVariant) {
          usedVariant = 'secondary';
        }

        if (!usedSize) {
          usedSize = 'medium';
        }
      } else if (content) {
        if (!usedVariant) {
          usedVariant = 'primary';
        }

        if (!usedSize) {
          usedSize = 'default';
        }
      }

      var iconSize = usedSize === 'large' && (icon_size === 'default' || !icon_size) ? 'medium' : icon_size;
      var classes = classnames("dnb-button dnb-button--".concat(usedVariant || 'primary'), (text || content) && 'dnb-button--has-text', createSkeletonClass(variant === 'tertiary' ? 'font' : 'shape', skeleton, this.context), createSpacingClasses(props), class_name, className, icon && "dnb-button--icon-position-".concat(iconPosition, " dnb-button--has-icon") + (iconSize ? " dnb-button--icon-size-".concat(iconSize) : ""), usedSize && usedSize !== 'default' && "dnb-button--size-".concat(usedSize), wrap && 'dnb-button--wrap', status && "dnb-button__status--".concat(status_state));

      var params = _extends({
        className: classes,
        type: type,
        title: title,
        id: this._id,
        disabled: isTrue(disabled)
      }, attributes, {
        onClick: this.onClickHandler
      });

      if (href) {
        params.href = href;
      }

      skeletonDOMAttributes(params, skeleton, this.context);
      validateDOMAttributes(this.props, params);
      var Element = element ? element : href ? 'a' : 'button';
      return react.createElement(react.Fragment, null, react.createElement(Element, _extends({
        ref: this._ref
      }, params), react.createElement(Content, _extends({}, this.props, {
        icon: icon,
        text: text,
        icon_size: iconSize,
        content: content,
        isIconOnly: isIconOnly,
        skeleton: isTrue(skeleton)
      }))), this.state.afterContent, showStatus && react.createElement(FormStatus, {
        id: this._id + '-form-status',
        global_status_id: global_status_id,
        label: text,
        text: status,
        status: status_state,
        text_id: this._id + '-status',
        animation: status_animation,
        skeleton: skeleton
      }), tooltip && this._ref && react.createElement(Tooltip, _extends({
        id: this._id + '-tooltip',
        component: this._ref
      }, react.isValidElement(tooltip) && tooltip.props ? tooltip.props : {
        children: tooltip
      })));
    }
  }]);

  return Button;
}(react.PureComponent);

Button.tagName = 'dnb-button';
Button.contextType = Context;
Button.defaultProps = {
  type: 'button',
  text: null,
  variant: null,
  size: null,
  title: null,
  icon: null,
  icon_position: 'right',
  icon_size: null,
  href: null,
  id: null,
  class: null,
  wrap: false,
  bounding: false,
  skeleton: null,
  disabled: null,
  tooltip: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  inner_ref: null,
  className: null,
  innerRef: null,
  children: null,
  element: null,
  custom_element: null,
  custom_method: null,
  onClick: null,
  on_click: null
};

var _ref$I = react.createElement("span", {
  key: "button-bounding",
  className: "dnb-button__bounding"
});

var _ref2$1 = react.createElement("span", {
  key: "button-text-empty",
  className: "dnb-button__alignment"
}, "\u200C");

var _ref3$1 = react.createElement("span", {
  key: "button-text-empty",
  className: "dnb-button__alignment"
}, "\u200C");

var Content = function (_React$PureComponent2) {
  _inherits(Content, _React$PureComponent2);

  var _super2 = _createSuper$a(Content);

  function Content() {
    _classCallCheck(this, Content);

    return _super2.apply(this, arguments);
  }

  _createClass(Content, [{
    key: "render",
    value: function render() {
      var text = this.props.text;
      var _this$props = this.props,
          title = _this$props.title,
          content = _this$props.content,
          icon = _this$props.icon,
          icon_size = _this$props.icon_size,
          bounding = _this$props.bounding,
          skeleton = _this$props.skeleton,
          isIconOnly = _this$props.isIconOnly;
      var ret = [];

      if (isTrue(bounding)) {
        ret.push(_ref$I);
      }

      if (typeof content === 'string') {
          text = content;
        } else if (content) {
        ret.push(content);
      }

      if (text) {
        ret.push(_ref2$1, react.createElement("span", {
          key: "button-text",
          className: "dnb-button__text dnb-skeleton--show-font"
        }, text));
      } else if (icon) {
        ret.push(_ref3$1);
      }

      if (icon) {
        ret.push(react.isValidElement(icon) && /Icon/i.test(String(icon.type)) ? react.cloneElement(icon, {
          key: 'button-icon',
          className: "dnb-button__icon ".concat(icon.props.className || '')
        }) : react.createElement(IconPrimary, {
          key: "button-icon",
          className: "dnb-button__icon",
          icon: icon,
          size: icon_size,
          "aria-hidden": isIconOnly && !title ? null : true,
          skeleton: skeleton
        }));
      }

      return ret;
    }
  }]);

  return Content;
}(react.PureComponent);

Content.defaultProps = {
  text: null,
  title: null,
  content: null,
  icon: null,
  icon_size: 'default',
  bounding: false,
  skeleton: null,
  isIconOnly: null
};

var DrawerListContext = react.createContext({});

var parseContentTitle = function parseContentTitle(dataItem) {
  var _dataItem;

  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$separator = _ref.separator,
      separator = _ref$separator === void 0 ? '\n' : _ref$separator,
      _ref$removeNumericOnl = _ref.removeNumericOnlyValues,
      removeNumericOnlyValues = _ref$removeNumericOnl === void 0 ? false : _ref$removeNumericOnl,
      _ref$preferSelectedVa = _ref.preferSelectedValue,
      preferSelectedValue = _ref$preferSelectedVa === void 0 ? false : _ref$preferSelectedVa;

  var ret = '';
  var onlyNumericRegex = /[0-9.,-\s]+/;

  if (Array.isArray(dataItem) && dataItem.length > 0) {
    dataItem = {
      content: dataItem
    };
  }

  var hasValue = (_dataItem = dataItem) === null || _dataItem === void 0 ? void 0 : _dataItem.selected_value;

  if (!(preferSelectedValue && hasValue) && dataItem && Array.isArray(dataItem.content)) {
    ret = dataItem.content.reduce(function (acc, cur) {
      cur = convertJsxToString(cur, ' ');

      if (cur === false) {
        return acc;
      }

      var found = removeNumericOnlyValues && cur && cur.match(onlyNumericRegex);

      if (!(found && found[0].length === cur.length)) {
        acc.push(cur);
      }

      return acc;
    }, []).join(separator);
  } else {
    ret = convertJsxToString(dataItem && dataItem.content || dataItem, ' ');
  }

  if (hasValue) {
    if (preferSelectedValue) {
      ret = String(convertJsxToString(dataItem.selected_value));
    } else if (!onlyNumericRegex.test(dataItem.selected_value)) {
      ret = String(convertJsxToString(dataItem.selected_value)) + separator + ret;
    }
  }

  if (Array.isArray(dataItem) && dataItem.length === 0) {
    ret = null;
  }

  if (ret && ret.length === 1 && ret[0].ignore_events) {
    return null;
  }

  return ret;
};
var hasObjectKeyAsValue = function hasObjectKeyAsValue(data) {
  var _data;

  data = ((_data = data) === null || _data === void 0 ? void 0 : _data.raw_data) || data;
  return data && _typeof(data) === 'object' && !Array.isArray(data);
};
var preSelectData = function preSelectData(data) {
  if (typeof data === 'string') {
    data = data[0] === '{' || data[0] === '[' ? JSON.parse(data) : null;
  } else if (data && react.isValidElement(data)) {
    data = [];
  } else if (typeof data === 'function') {
    data = data();
  }

  return data;
};
var normalizeData = function normalizeData(props) {
  var data = preSelectData(props.data || props.children || props);

  if (data && _typeof(data) === 'object' && !Array.isArray(data)) {
    var list = [];

    for (var i in data) {
      list.push({
        selected_key: i,
        value: i,
        content: data[i],
        type: 'object'
      });
    }

    data = list;
  }

  return (data || []).map(function (item, __id) {
    if (typeof item === 'string' || Array.isArray(item) || react.isValidElement(item)) {
      item = {
        content: item,
        __isTransformed: true
      };
    }

    return typeof item.__id !== 'undefined' ? item : _extends({}, item, {
      __id: __id
    });
  });
};
var getData = function getData(props) {
  if (props.prepared_data && Array.isArray(props.prepared_data)) {
    return props.prepared_data;
  }

  return normalizeData(props);
};
var getCurrentIndex = function getCurrentIndex(value, data) {
  if (/[^0-9]/.test(String(value))) {
    return data === null || data === void 0 ? void 0 : data.findIndex(function (cur) {
      return parseCurrentValue(cur) === value;
    });
  } else if (parseFloat(value) > -1) {
      return value;
    }

  return null;
};
var getSelectedItemValue = function getSelectedItemValue(value, state) {
  if (hasObjectKeyAsValue(state)) {
    return parseCurrentValue(state.data.filter(function (_, i) {
      return i === parseFloat(value);
    })[0]);
  }

  return value;
};
var parseCurrentValue = function parseCurrentValue(current) {
  if (typeof (current === null || current === void 0 ? void 0 : current.selected_key) !== 'undefined') {
    return current === null || current === void 0 ? void 0 : current.selected_key;
  }

  if (typeof (current === null || current === void 0 ? void 0 : current.content) !== 'undefined') {
    return current === null || current === void 0 ? void 0 : current.content;
  }

  return current;
};
var getEventData = function getEventData(item_index, data) {
  data = getCurrentData(item_index, data);

  if (data && data.__id) {
    data = _extends({}, data);
    delete data.__id;
    delete data.__isTransformed;
  }

  return data;
};
var getCurrentData = function getCurrentData(item_index, data) {
  if (typeof data === 'function') {
    data = normalizeData(data);
  }

  data = data && data.find(function (_ref2) {
    var __id = _ref2.__id;
    return __id == item_index;
  }) || null;

  if (data && data.__isTransformed) {
    data = parseCurrentValue(data);
  }

  return data;
};
var prepareStartupState = function prepareStartupState(props) {
  var raw_data = preSelectData(props.raw_data || props.data || props.children);
  var data = getData(props);
  var opened = props.opened !== null ? isTrue(props.opened) : null;
  var selected_item = null;

  if (props.value !== null && typeof props.value !== 'undefined' && props.value !== 'initval') {
    selected_item = getCurrentIndex(props.value, data);
  } else if (props.default_value !== null) {
    selected_item = getCurrentIndex(props.default_value, data);
  }

  return {
    opened: opened,
    data: data,
    init_data: props.data,
    original_data: data,
    raw_data: raw_data,
    direction: props.direction,
    max_height: props.max_height,
    selected_item: selected_item,
    active_item: selected_item,
    on_hide: props.on_hide,
    on_show: props.on_show,
    on_chnage: props.on_chnage,
    on_select: props.on_select,
    _listenForPropChanges: false
  };
};
var prepareDerivedState = function prepareDerivedState(props, state) {
  if (state.opened && !state.data && typeof props.data === 'function') {
    state.data = getData(props);
  }

  if (state._listenForPropChanges) {
    if (props.data && props.data !== state.init_data) {
      state.data = getData(props);
      state.init_data = props.data;
    }

    state.usePortal = props.skip_portal !== null ? !isTrue(props.skip_portal) : true;

    if (typeof props.wrapper_element === 'string' && typeof document !== 'undefined') {
      var wrapper_element = document.querySelector(props.wrapper_element);

      if (wrapper_element) {
        state.wrapper_element = wrapper_element;
      }
    } else if (props.wrapper_element) {
      state.wrapper_element = props.wrapper_element;
    }

    if (typeof props.value !== 'undefined' && props.value !== 'initval' && state.selected_item !== props.value) {
      state.selected_item = getCurrentIndex(props.value, state.data);

      if (typeof props.on_state_update === 'function') {
        dispatchCustomElementEvent({
          props: props
        }, 'on_state_update', {
          selected_item: state.selected_item,
          value: getSelectedItemValue(state.selected_item, state),
          data: getEventData(state.selected_item, state.data)
        });
      }
    }

    if (!(parseFloat(state.active_item) > -1)) {
      state.active_item = state.selected_item;
    }

    if (props.direction !== 'auto' && props.direction !== state.direction) {
      state.direction = props.direction;
    }

    if (parseFloat(state.selected_item) > -1) {
      state.current_title = getCurrentDataTitle(state.selected_item, state.data);
    }
  }

  state._listenForPropChanges = true;
  return state;
};
var getCurrentDataTitle = function getCurrentDataTitle(selected_item, data) {
  var currentData = getCurrentData(selected_item, data);
  return parseContentTitle(currentData, {
    separator: ' ',
    preferSelectedValue: true
  });
};
var findClosest = function findClosest(arr, val) {
  return Math.max.apply(null, arr.filter(function (v) {
    return v <= val;
  }));
};

var isServer = function isServer() {
  return typeof window === 'undefined';
};

var detectOS = function detectOS(ua) {
  ua = ua || navigator.userAgent;
  var ipad = /(iPad).*OS\s([\d_]+)/.test(ua);
  var iphone = !ipad && /(iPhone\sOS)\s([\d_]+)/.test(ua);
  var android = /(Android);?[\s/]+([\d.]+)?/.test(ua);
  var ios = iphone || ipad;
  return {
    ios: ios,
    android: android
  };
};

var detectiOSVersion = function detectiOSVersion() {
  var match = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
  var version;

  if (match !== undefined && match !== null) {
    version = [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3] || 0, 10)];
    return parseFloat(version.join('.'));
  }

  return false;
};

var lockedNum = 0;
var initialClientY = 0;
var initialClientX = 0;
var unLockCallback = null;
var documentListenerAdded = false;
var lockedElements = [];
var eventListenerOptions = getEventListenerOptions({
  passive: false
});

function getEventListenerOptions(options) {
  if (isServer()) {
    return;
  }
  var capture = options.capture;
  return  options ;
}

var setOverflowHiddenPc = function setOverflowHiddenPc() {
  try {
    var $html = document.documentElement;
    var $body = document.body;

    var htmlStyle = _extends({}, $html.style);

    var bodyStyle = _extends({}, $body.style);

    var scrollBarWidth = window.innerWidth - $body.clientWidth;
    $html.style.height = 'auto';
    $html.style.overflow = 'hidden';
    $body.style.overflow = 'hidden';
    $body.style.height = 'auto';
    $body.style.boxSizing = 'border-box';
    $body.style.paddingRight = "".concat(scrollBarWidth, "px");
    return function () {
      try {
        ;
        ['height', 'overflow'].forEach(function (x) {
          $html.style[x] = htmlStyle[x] || '';
        });
        ['overflow', 'height', 'boxSizing', 'paddingRight'].forEach(function (x) {
          $body.style[x] = bodyStyle[x] || '';
        });
      } catch (e) {}
    };
  } catch (e) {}
};

var setOverflowHiddenMobile = function setOverflowHiddenMobile() {
  try {
    var $html = document.documentElement;
    var $body = document.body;
    var scrollTop = $html.scrollTop || $body.scrollTop;

    var htmlStyle = _extends({}, $html.style);

    var bodyStyle = _extends({}, $body.style);

    $html.style.height = '100%';
    $html.style.overflow = 'hidden';
    $body.style.top = "-".concat(scrollTop, "px");
    $body.style.width = '100%';
    $body.style.height = 'auto';
    $body.style.position = 'fixed';
    $body.style.overflow = 'hidden';
    return function () {
      try {
        ;
        ['height', 'overflow'].forEach(function (x) {
          $html.style[x] = htmlStyle[x] || '';
        });
        ['top', 'width', 'height', 'overflow', 'position'].forEach(function (x) {
          $body.style[x] = bodyStyle[x] || '';
        });
        var scrollBehavior = window.getComputedStyle($html).scrollBehavior;
        $html.style.scrollBehavior = 'auto';
        $html.scrollTop = scrollTop;
        $html.style.scrollBehavior = scrollBehavior;
      } catch (e) {}
    };
  } catch (e) {}
};

var preventDefault = function preventDefault(event) {
  var found = lockedElements.find(function (targetElement) {
    return isChildOfElement(event.target, targetElement);
  });

  if (found || !event.cancelable) {
    return;
  }

  event.preventDefault();
};

var handleScroll = function handleScroll(event, targetElement) {
  try {
    if (targetElement) {
      var scrollTop = targetElement.scrollTop,
          scrollLeft = targetElement.scrollLeft,
          scrollWidth = targetElement.scrollWidth,
          scrollHeight = targetElement.scrollHeight,
          clientWidth = targetElement.clientWidth,
          clientHeight = targetElement.clientHeight;
      var clientX = event.targetTouches[0].clientX - initialClientX;
      var clientY = event.targetTouches[0].clientY - initialClientY;
      var isVertical = Math.abs(clientY) > Math.abs(clientX);
      var isOnTop = clientY > 0 && scrollTop === 0;
      var isOnLeft = clientX > 0 && scrollLeft === 0;
      var isOnRight = clientX < 0 && scrollLeft + clientWidth + 1 >= scrollWidth;
      var isOnBottom = clientY < 0 && scrollTop + clientHeight + 1 >= scrollHeight;

      if (isVertical && (isOnTop || isOnBottom) || !isVertical && (isOnLeft || isOnRight)) {
        var hasScrollbar = isChildOfElement(event.target, targetElement, checkIfHasScrollbar);

        if (hasScrollbar && hasScrollbar !== targetElement) {
          return true;
        }

        return event.cancelable && event.preventDefault();
      }
    }

    event.stopPropagation();
    return true;
  } catch (e) {}
};

var checkTargetElement = function checkTargetElement(targetElement) {
  if (targetElement) return;
  if (targetElement === null) return;
  console.warn("If scrolling is also required in the floating layer, " + "the target element must be provided.");
};

var disableBodyScroll = function disableBodyScroll(targetElement) {
  if (isServer()) {
    return;
  }

  checkTargetElement(targetElement);

  try {
    if (detectOS().ios) {
      if (detectiOSVersion() >= 14) {
        if (lockedNum <= 0) {
          unLockCallback = setOverflowHiddenMobile();
        }
      } else {
        if (targetElement) {
          var elementArray = Array.isArray(targetElement) ? targetElement : [targetElement];
          elementArray.forEach(function (element) {
            if (element && lockedElements.indexOf(element) === -1) {
              element.ontouchstart = function (event) {
                initialClientY = event.targetTouches[0].clientY;
                initialClientX = event.targetTouches[0].clientX;
              };

              element.ontouchmove = function (event) {
                if (event.targetTouches.length !== 1) {
                  return;
                }

                handleScroll(event, element);
              };

              lockedElements.push(element);
            }
          });
        }

        if (!documentListenerAdded) {
          document.addEventListener('touchmove', preventDefault, eventListenerOptions);
          documentListenerAdded = true;
        }
      }
    } else if (lockedNum <= 0) {
      unLockCallback = detectOS().android ? setOverflowHiddenMobile() : setOverflowHiddenPc();
    }

    lockedNum += 1;
  } catch (e) {}
};
var enableBodyScroll = function enableBodyScroll(targetElement) {
  if (isServer()) {
    return;
  }

  checkTargetElement(targetElement);

  try {
    lockedNum -= 1;

    if (lockedNum > 0) {
      return;
    }

    if (typeof unLockCallback === 'function') {
      unLockCallback();
    }

    if (detectOS().ios && !(detectiOSVersion() >= 14)) {
      if (targetElement) {
        var elementArray = Array.isArray(targetElement) ? targetElement : [targetElement];
        elementArray.forEach(function (element) {
          var index = lockedElements.indexOf(element);

          if (index !== -1) {
            element.ontouchmove = null;
            element.ontouchstart = null;
            lockedElements.splice(index, 1);
          }
        });
      }

      if (documentListenerAdded) {
        document.removeEventListener('touchmove', preventDefault, eventListenerOptions);
        documentListenerAdded = false;
      }
    }
  } catch (e) {}
};

function _createSuper$b(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$c(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$c() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var DrawerListProvider = function (_React$PureComponent) {
  _inherits(DrawerListProvider, _React$PureComponent);

  var _super = _createSuper$b(DrawerListProvider);

  _createClass(DrawerListProvider, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      return prepareDerivedState(props, state);
    }
  }]);

  function DrawerListProvider(props) {
    var _this;

    _classCallCheck(this, DrawerListProvider);

    _this = _super.call(this, props);

    _this.enableBodyLock = function () {
      if (_this._refUl.current) {
        _this._bodyLockIsEnabled = true;
        disableBodyScroll(_this._refUl.current);
      }
    };

    _this.disableBodyLock = function () {
      if (_this._bodyLockIsEnabled && _this._refUl.current) {
        _this._bodyLockIsEnabled = null;
        enableBodyScroll(_this._refUl.current);
      }
    };

    _this.scrollToItem = function (active_item) {
      var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref$scrollTo = _ref.scrollTo,
          scrollTo = _ref$scrollTo === void 0 ? true : _ref$scrollTo;

      clearTimeout(_this._scrollTimeout);
      _this._scrollTimeout = setTimeout(function () {
        if (_this._refUl.current && parseFloat(active_item) > -1) {
          try {
            var ulElement = _this._refUl.current;

            var liElement = _this.getActiveElement();

            if (liElement) {
              var top = liElement.offsetTop;

              if (ulElement.scrollTo) {
                if (scrollTo === false || window.IS_TEST) {
                  ulElement.style.scrollBehavior = 'auto';
                }

                ulElement.scrollTo({
                  top: top,
                  behavior: scrollTo ? 'smooth' : 'auto'
                });

                if (scrollTo === false) {
                  ulElement.style.scrollBehavior = 'smooth';
                }
              } else if (ulElement.scrollTop) {
                ulElement.scrollTop = top;
              }

              if (!isTrue(_this.props.prevent_focus) && liElement) {
                liElement.focus();
                dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_show_focus', {
                  element: liElement
                });
              }
            }
          } catch (e) {
            warn('List could not scroll into element:', e);
          }
        }
      }, 1);
    };

    _this.scrollToAndSetActiveItem = function (active_item) {
      var _ref2 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref2$fireSelectEvent = _ref2.fireSelectEvent,
          fireSelectEvent = _ref2$fireSelectEvent === void 0 ? false : _ref2$fireSelectEvent,
          _ref2$scrollTo = _ref2.scrollTo,
          scrollTo = _ref2$scrollTo === void 0 ? true : _ref2$scrollTo,
          _ref2$event = _ref2.event,
          event = _ref2$event === void 0 ? null : _ref2$event;

      if (parseFloat(active_item) > -1) {
        _this.setState({
          active_item: active_item,
          _listenForPropChanges: false
        }, function () {
          var selected_item = _this.state.selected_item;

          if (fireSelectEvent) {
            var attributes = _this.attributes;
            var ret = dispatchCustomElementEvent(_this.state, 'on_select', {
              active_item: active_item,
              value: getSelectedItemValue(selected_item, _this.state),
              data: getEventData(active_item, _this.state.data),
              event: event,
              attributes: attributes
            });

            if (ret === false) {
              return;
            }
          }

          _this.scrollToItem(active_item, {
            scrollTo: scrollTo
          });
        });
      } else if (!isTrue(_this.props.prevent_focus)) {
        if (_this._refUl.current) {
          _this._refUl.current.focus({
            preventScroll: true
          });

          dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_show_focus', {
            element: _this._refUl.current
          });
        }
      }
    };

    _this.setWrapperElement = function () {
      var wrapper_element = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _this.props.wrapper_element;

      if (typeof wrapper_element === 'string' && typeof document !== 'undefined') {
        wrapper_element = document.querySelector(wrapper_element);
      }

      if (wrapper_element) {
        _this.setState({
          wrapper_element: wrapper_element,
          _listenForPropChanges: false
        });
      }

      return _assertThisInitialized(_this);
    };

    _this.anchorKeyDownHandler = function (e) {
      var key = keycode(e);

      switch (key) {
        case 'tab':
          try {
            var nextEl = _this.meta.shift ? e.target.previousSibling : e.target.nextSibling;
            e.stopPropagation();
            e.preventDefault();

            if (nextEl) {
              _this.focusAnchorElem(nextEl);
            } else {
              _this.getActiveElement().focus();
            }
          } catch (e) {}

          break;

        case 'enter':
        case 'space':
          e.stopPropagation();
          break;
      }
    };

    _this.setMetaKey = function (e) {
      var we = typeof window !== 'undefined' && window.event ? window.event : e;
      _this.meta = {
        cmd: we.metaKey,
        ctrl: we.ctrlKey,
        shift: we.shiftKey,
        alt: we.altKey
      };
    };

    _this.onKeyUpHandler = function (e) {
      _this.setMetaKey(e);
    };

    _this.onKeyDownHandler = function (e) {
      var key = keycode(e);

      if (/command|alt|shift|ctrl/.test(key)) {
        _this.setMetaKey(e);
      }

      if (isTrue(_this.props.prevent_close)) {
          var isSameDrawer = false;

          try {
            isSameDrawer = typeof document !== 'undefined' && "".concat(document.activeElement.getAttribute('id'), "-ul") === _this._refUl.current.getAttribute('id');
          } catch (e) {
            warn(e);
          }

          if (!isSameDrawer || key === 'tab') {
            return;
          }
        }

      if (isTrue(_this.state.ignore_events) && key !== 'tab') {
        return;
      }

      var active_item = parseFloat(_this.state.active_item);

      if (isNaN(active_item)) {
        active_item = -1;
      }

      var total = _this.state.data && _this.state.data.length - 1;

      switch (key) {
        case 'up':
          {
            e.preventDefault();
            active_item = _this.getPrevActiveItem();

            if (isNaN(active_item)) {
              active_item = _this.getFirstItem() || 0;
            }
          }
          break;

        case 'down':
          {
            e.preventDefault();

            var activeItem = _this.getCurrentActiveItem();

            if (active_item === -1 || isNaN(activeItem)) {
              active_item = _this.getFirstItem() || 0;
            } else {
              active_item = _this.getNextActiveItem();
            }
          }
          break;

        case 'page up':
        case 'home':
          {
            e.preventDefault();
            active_item = _this.getFirstItem() || 0;
          }
          break;

        case 'page down':
        case 'end':
          {
            e.preventDefault();
            active_item = _this.getLastItem();

            if (isNaN(active_item)) {
              active_item = total;
            }
          }
          break;

        case 'enter':
        case 'space':
          {
            active_item = _this.getCurrentActiveItem();

            if (isTrue(_this.props.skip_keysearch) ? active_item > -1 && key !== 'space' : true) {
              e.preventDefault();

              _this.selectItem(active_item, {
                fireSelectEvent: true,
                event: e
              });
            }
          }
          break;

        case 'esc':
          {
            _this.setHidden({
              event: e
            });

            e.preventDefault();
          }
          break;

        case 'tab':
          {
            if (_this.state.opened && active_item > -1) {
              var anchorElem = _this.getAnchorElem();

              if (anchorElem) {
                e.preventDefault();

                _this.focusAnchorElem(anchorElem);

                return;
              }
            }

            _this.setHidden({
              event: e
            });
          }
          break;

        default:
          active_item = _this.findItemByValue(keycode(e));
          break;
      }

      if (parseFloat(active_item) > -1 && active_item !== _this.state.active_item) {
        _this.scrollToAndSetActiveItem(active_item, {
          fireSelectEvent: true,
          event: e
        });
      }
    };

    _this.getSelectedElement = function () {
      var _this$_refUl$current;

      return ((_this$_refUl$current = _this._refUl.current) === null || _this$_refUl$current === void 0 ? void 0 : _this$_refUl$current.querySelector('li.dnb-drawer-list__option--selected')) || _this._refUl.current || {
        getAttribute: function getAttribute() {
          return null;
        }
      };
    };

    _this.getCurrentSelectedItem = function () {
      var elem = _this.getSelectedElement();

      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.getActiveElement = function () {
      var _this$_refUl$current2;

      return ((_this$_refUl$current2 = _this._refUl.current) === null || _this$_refUl$current2 === void 0 ? void 0 : _this$_refUl$current2.querySelector('li.dnb-drawer-list__option--focus')) || _this.getSelectedElement();
    };

    _this.getCurrentActiveItem = function () {
      var elem = _this.getActiveElement();

      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.getNextActiveItem = function () {
      var elem = _this.getActiveElement().nextSibling;

      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.getPrevActiveItem = function () {
      var elem = _this.getActiveElement().previousSibling;

      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.getFirstItem = function () {
      var _this$_refUl$current3;

      var elem = (_this$_refUl$current3 = _this._refUl.current) === null || _this$_refUl$current3 === void 0 ? void 0 : _this$_refUl$current3.querySelector('li.dnb-drawer-list__option.first-of-type');
      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.getLastItem = function () {
      var _this$_refUl$current4;

      var elem = (_this$_refUl$current4 = _this._refUl.current) === null || _this$_refUl$current4 === void 0 ? void 0 : _this$_refUl$current4.querySelector('li.dnb-drawer-list__option.last-of-type');
      return parseFloat(elem && elem.getAttribute('data-item'));
    };

    _this.setOutsideClickObserver = function () {
      _this.removeOutsideClickObserver();

      _this.outsideClick = detectOutsideClick([_this.state.wrapper_element, _this._refRoot.current, _this._refUl.current], _this.setHidden);

      if (typeof document !== 'undefined') {
        document.addEventListener('keydown', _this.onKeyDownHandler);
        document.addEventListener('keyup', _this.onKeyUpHandler);
      }
    };

    _this.assignObservers = function () {
      _this.setDirectionObserver();

      _this.setScrollObserver();

      _this.setOutsideClickObserver();
    };

    _this.setVisible = function () {
      clearTimeout(_this._hideTimeout);

      if (_this.state.opened && _this.state.hidden === false) {
        return;
      }

      _this.searchCache = null;

      _this.setState({
        hidden: false,
        opened: true,
        _listenForPropChanges: false
      }, _this.assignObservers);

      var _this$state = _this.state,
          selected_item = _this$state.selected_item,
          active_item = _this$state.active_item;
      dispatchCustomElementEvent(_this.state, 'on_show', {
        data: getEventData(parseFloat(selected_item) > -1 ? selected_item : active_item, _this.state.data),
        attributes: _this.attributes,
        ulElement: _this._refUl.current
      });
    };

    _this.setHidden = function () {
      var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var onStateComplete = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      if (!_this.state.opened || isTrue(_this.props.prevent_close)) {
        if (typeof onStateComplete === 'function') {
          onStateComplete();
        }

        return;
      }

      clearTimeout(_this._hideTimeout);
      var _this$state2 = _this.state,
          selected_item = _this$state2.selected_item,
          active_item = _this$state2.active_item;
      var res = dispatchCustomElementEvent(_this.state, 'on_hide', _extends({}, args, {
        data: getEventData(parseFloat(selected_item) > -1 ? selected_item : active_item, _this.state.data),
        attributes: _this.attributes
      }));

      if (res !== false) {
        _this.setState({
          opened: false,
          _listenForPropChanges: false
        });

        var delayHandler = function delayHandler() {
          _this.setState({
            hidden: true,
            _listenForPropChanges: false
          });

          if (typeof onStateComplete === 'function') {
            onStateComplete();
          }
        };

        if (isTrue(_this.props.no_animation)) {
          delayHandler();
        } else {
          _this._hideTimeout = setTimeout(delayHandler, DrawerListProvider.blurDelay);
        }

        _this.waitUntilUlIsReady = false;

        _this.removeDirectionObserver();

        _this.removeScrollObserver();

        _this.removeOutsideClickObserver();
      }
    };

    _this.setDataHandler = function (data) {
      var cb = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      var _ref3 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
          _ref3$overwriteOrigin = _ref3.overwriteOriginalData,
          overwriteOriginalData = _ref3$overwriteOrigin === void 0 ? false : _ref3$overwriteOrigin;

      if (!data) {
        return;
      }

      if (typeof data === 'function') {
        data = getData(data);
      }

      data = normalizeData(data);

      _this.setState({
        data: data,
        original_data: overwriteOriginalData ? data : _this.state.original_data,
        _listenForPropChanges: false
      }, function () {
        _this.refreshScrollObserver();

        typeof cb === 'function' && cb(data);
      });

      return _assertThisInitialized(_this);
    };

    _this.setStateHandler = function (state) {
      var cb = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      _this.setState(_extends({}, state, {
        _listenForPropChanges: false
      }), cb);

      return _assertThisInitialized(_this);
    };

    _this.selectItem = function (itemToSelect) {
      var _ref4 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref4$fireSelectEvent = _ref4.fireSelectEvent,
          fireSelectEvent = _ref4$fireSelectEvent === void 0 ? false : _ref4$fireSelectEvent,
          _ref4$event = _ref4.event,
          event = _ref4$event === void 0 ? null : _ref4$event;

      if (event && typeof event.persist === 'function') {
        event.persist();
      }

      if (itemToSelect === -1) {
        itemToSelect = null;
      }

      var data = getEventData(itemToSelect, _this.state.data) || null;
      var value = getSelectedItemValue(itemToSelect, _this.state);
      var attributes = _this.attributes;
      var attr = {
        selected_item: itemToSelect,
        value: value,
        data: data,
        event: event,
        attributes: attributes
      };
      var res = dispatchCustomElementEvent(_this.state, 'on_pre_change', attr);

      if (res === false || hasSelectedText()) {
        return;
      }

      var _this$props = _this.props,
          keep_open = _this$props.keep_open,
          no_animation = _this$props.no_animation,
          prevent_selection = _this$props.prevent_selection;
      var doCallOnChange = _this.state.selected_item !== itemToSelect;

      var onSelectionIsComplete = function onSelectionIsComplete() {
        var delayHandler = function delayHandler() {
          if (doCallOnChange) {
            dispatchCustomElementEvent(_this.state, 'on_change', attr);
          }

          if (fireSelectEvent) {
            dispatchCustomElementEvent(_this.state, 'on_select', _extends({}, attr, {
              active_item: itemToSelect
            }));
          }

          if (!isTrue(keep_open)) {
            _this.setHidden();
          }
        };

        if (isTrue(no_animation)) {
          delayHandler();
        } else {
          clearTimeout(_this._selectTimeout);
          _this._selectTimeout = setTimeout(delayHandler, DrawerListProvider.blurDelay / 2);
        }
      };

      if (isTrue(prevent_selection)) {
        onSelectionIsComplete();
      } else {
        _this.setState({
          _listenForPropChanges: false,
          selected_item: itemToSelect,
          active_item: itemToSelect
        }, onSelectionIsComplete);
      }
    };

    _this.attributes = {};
    _this.state = _extends({
      tagName: 'dnb-drawer-list',
      cache_hash: '',
      active_item: null,
      selected_item: null,
      ignore_events: false
    }, prepareStartupState(props), {
      _listenForPropChanges: true
    });
    _this._refRoot = react.createRef();
    _this._refShell = react.createRef();
    _this._refUl = react.createRef();
    _this._refTriangle = react.createRef();
    return _this;
  }

  _createClass(DrawerListProvider, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.state.opened) {
        this.setVisible();
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.props.opened !== null && this.props.opened !== prevProps.opened) {
        if (isTrue(this.props.opened)) {
          this.setVisible();
        } else if (isTrue(this.props.opened) === false) {
          this.setHidden();
        }
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearInterval(this._outsideClickTimeout);
      clearTimeout(this._hideTimeout);
      clearTimeout(this._selectTimeout);
      clearTimeout(this._scrollTimeout);
      clearTimeout(this._ddTimeout);
      clearTimeout(this._doTimeout);
      this.setState({
        opened: false,
        _listenForPropChanges: false
      });
      this.removeDirectionObserver();
      this.removeScrollObserver();
      this.removeOutsideClickObserver();
    }
  }, {
    key: "refreshScrollObserver",
    value: function refreshScrollObserver() {
      var _this2 = this;

      if (typeof window === 'undefined' || !this._refUl.current) {
        return;
      }

      this.itemSpots = this.state.data.reduce(function (acc, cur, i) {
        var _this2$_refUl$current;

        var element = (_this2$_refUl$current = _this2._refUl.current) === null || _this2$_refUl$current === void 0 ? void 0 : _this2$_refUl$current.querySelector("li.dnb-drawer-list__option:nth-of-type(".concat(i + 1, ")"));

        if (element) {
          acc[element.offsetTop] = {
            i: i
          };
        }

        return acc;
      }, {});
      this.itemSpotsCount = Object.keys(this.itemSpots).length;
    }
  }, {
    key: "setScrollObserver",
    value: function setScrollObserver() {
      var _this3 = this;

      if (!isTrue(this.props.enable_closest_observer) || typeof window === 'undefined' || !this._refUl.current) {
        return;
      }

      this.removeScrollObserver();
      this.itemSpotsCount = 1;

      try {
        var closestToTop = null,
            closestToBottom = null,
            tmpToTop,
            tmpToBottom;

        this.setOnScroll = function () {
          if (!_this3._refUl.current) {
            return;
          }

          if (_this3.itemSpotsCount <= 1) {
            _this3.refreshScrollObserver();
          }

          var counts = Object.keys(_this3.itemSpots);
          closestToBottom = findClosest(counts, _this3._refUl.current.scrollTop + _this3._refUl.current.offsetHeight);
          closestToTop = findClosest(counts, _this3._refUl.current.scrollTop);

          if (_this3.itemSpots[closestToTop] && closestToTop !== tmpToTop) {
            _this3.setState({
              closestToTop: _this3.itemSpots[closestToTop].i,
              _listenForPropChanges: false
            });
          }

          if (closestToBottom !== tmpToBottom && _this3.itemSpots[closestToBottom]) {
            _this3.setState({
              closestToBottom: _this3.itemSpots[closestToBottom].i,
              _listenForPropChanges: false
            });
          }

          tmpToTop = closestToTop;
          tmpToBottom = closestToBottom;
        };

        this._refUl.current.addEventListener('scroll', this.setOnScroll);

        this.setOnScroll();
      } catch (e) {
        warn('List could not set onScroll:', e);
      }
    }
  }, {
    key: "removeScrollObserver",
    value: function removeScrollObserver() {
      if (typeof window !== 'undefined' && this.setOnScroll) {
        window.removeEventListener('resize', this.setOnScroll);
        this.setOnScroll = null;
      }
    }
  }, {
    key: "setDirectionObserver",
    value: function setDirectionObserver() {
      var _this4 = this;

      if (typeof window === 'undefined' || typeof document === 'undefined' || !(this.state.wrapper_element || this._refRoot.current)) {
        return;
      }

      var _this$props2 = this.props,
          enable_body_lock = _this$props2.enable_body_lock,
          use_drawer_on_mobile = _this$props2.use_drawer_on_mobile,
          scrollable = _this$props2.scrollable,
          min_height = _this$props2.min_height,
          max_height = _this$props2.max_height,
          on_resize = _this$props2.on_resize,
          page_offset = _this$props2.page_offset,
          observer_element = _this$props2.observer_element;
      var useBodyLock = isTrue(enable_body_lock);
      var useDrawer = isTrue(use_drawer_on_mobile);
      var isScrollable = isTrue(scrollable);
      var customMinHeight = parseFloat(min_height) * 16;
      var customMaxHeight = parseFloat(max_height) || 0;
      var customElem = typeof observer_element === 'string' ? document.querySelector(observer_element) : null;

      if (!customElem) {
        customElem = isInsideScrollView(this._refRoot.current, true);
      }

      this.removeDirectionObserver();
      var directionOffset = 96;
      var spaceToTopOffset = 2 * 16;
      var spaceToBottomOffset = 2 * 16;
      var elem = this.state.wrapper_element || this._refRoot.current;

      var renderDirection = function renderDirection() {
        try {
          var rootElem = customElem || document.documentElement;
          var pageYOffset = !isNaN(parseFloat(page_offset)) ? parseFloat(page_offset) : rootElem.scrollTop;
          var spaceToTop = getOffsetTop(elem) + elem.offsetHeight - pageYOffset;
          var spaceToBottom = rootElem.clientHeight - (getOffsetTop(elem) + elem.offsetHeight) + pageYOffset;
          var direction = Math.max(spaceToBottom - directionOffset, directionOffset) < customMinHeight && spaceToTop > customMinHeight ? 'top' : 'bottom';
          var _max_height = customMaxHeight;

          if (!(_max_height > 0)) {
            _max_height = direction === 'top' ? spaceToTop - ((_this4.state.wrapper_element || _this4._refRoot.current).offsetHeight || 0) - spaceToTopOffset : spaceToBottom - spaceToBottomOffset;
            var vh = 0;

            if (typeof window.visualViewport !== 'undefined') {
              vh = window.visualViewport.height;
            } else {
              vh = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
            }

            vh = vh * (isScrollable ? 0.7 : 0.9);

            if (_max_height > vh) {
              _max_height = vh;
            }

            _max_height = roundToNearest(_max_height, 8) / 16;
          }

          if (_this4.props.direction === 'auto') {
            _this4.setState({
              direction: direction,
              _listenForPropChanges: false
            });
          }

          _this4.setState({
            max_height: _max_height,
            _listenForPropChanges: false
          });

          if (on_resize) {
            dispatchCustomElementEvent(_this4.state, 'on_resize', {
              direction: direction,
              max_height: _max_height
            });
          }
        } catch (e) {
          warn('List could not set onResize:', e);
        }
      };

      this.setDirection = function (e) {
        clearTimeout(_this4._ddTimeout);
        _this4._ddTimeout = setTimeout(renderDirection, 30);

        if (useDrawer && e.type === 'resize') {
          if (!_this4._bodyLockIsEnabled && (window.innerWidth / 16 <= 40 || window.innerHeight / 16 <= 40)) {
            _this4.enableBodyLock();
          } else if (_this4._bodyLockIsEnabled && !useBodyLock) {
            _this4.disableBodyLock();
          }
        }

        if (e.type === 'resize') {
          _this4.correctHiddenView();
        }
      };

      this._rootElem = customElem || window;

      this._rootElem.addEventListener('scroll', this.setDirection);

      if (typeof window.visualViewport !== 'undefined') {
        window.visualViewport.addEventListener('scroll', this.setDirection);
        window.visualViewport.addEventListener('resize', this.setDirection);
      } else {
        window.addEventListener('resize', this.setDirection);
      }

      clearTimeout(this._doTimeout);
      this._doTimeout = setTimeout(function () {
        if (useBodyLock || useDrawer && (window.innerWidth / 16 <= 40 || window.innerHeight / 16 <= 40)) {
          _this4.enableBodyLock();
        }

        _this4.correctHiddenView();

        _this4.refreshScrollObserver();

        var _this4$state = _this4.state,
            selected_item = _this4$state.selected_item,
            active_item = _this4$state.active_item;

        _this4.scrollToAndSetActiveItem(parseFloat(active_item) > -1 ? active_item : selected_item, {
          scrollTo: false
        });
      }, 1);
      renderDirection();
    }
  }, {
    key: "correctHiddenView",
    value: function correctHiddenView() {
      try {
        var ui = this._refUl.current;
        var spaceToLeft = getOffsetLeft(ui);
        var spaceToRight = window.innerWidth - (getOffsetLeft(ui) + ui.offsetWidth);
        var tri = this._refTriangle.current.style;
        var shell = this._refShell.current.style;

        if (spaceToLeft < 0) {
          shell.transform = "translateX(".concat(Math.abs(spaceToLeft), "px)");
          tri.right = "".concat(Math.abs(spaceToLeft), "px");
        } else if (spaceToRight < 0) {
          shell.transform = "translateX(".concat(spaceToRight, "px)");
          tri.left = "".concat(Math.abs(spaceToRight), "px");
        } else {
          if (shell.transform) {
            shell.transform = '';
            tri.left = 'auto';
            tri.right = 'auto';
          }
        }
      } catch (e) {}
    }
  }, {
    key: "findItemByValue",
    value: function findItemByValue(value) {
      if (isTrue(this.props.skip_keysearch)) {
        return;
      }

      var index = -1;

      try {
        value = String(value).toLowerCase();

        if (this.changedOrderFor !== value) {
          this.searchCache = null;
          this.changedOrderFor = null;
        }

        this.searchCache = this.searchCache || this.state.data.reduce(function (acc, itemData, i) {
          var str = String(parseContentTitle(itemData, {
            separator: ' ',
            removeNumericOnlyValues: true
          }));
          var firstLetter = String(str[0]).toLowerCase();
          acc[firstLetter] = acc[firstLetter] || [];
          acc[firstLetter].push({
            i: i
          });
          return acc;
        }, {});
        var found = this.searchCache[value];
        index = found && found[0] && found[0].i > -1 ? found[0].i : -1;

        if (found && found.length > 1) {
          found.push(found.shift());
          this.changedOrderFor = value;
        }
      } catch (e) {
        warn('List could not findItemByValue:', e);
      }

      return index;
    }
  }, {
    key: "removeDirectionObserver",
    value: function removeDirectionObserver() {
      this.disableBodyLock();
      clearTimeout(this._ddTimeout);

      if (typeof window !== 'undefined' && this.setDirection) {
        var _this$_rootElem;

        (_this$_rootElem = this._rootElem) === null || _this$_rootElem === void 0 ? void 0 : _this$_rootElem.removeEventListener('scroll', this.setDirection);

        if (typeof window.visualViewport !== 'undefined') {
          window.visualViewport.removeEventListener('scroll', this.setDirection);
          window.visualViewport.removeEventListener('resize', this.setDirection);
        } else {
          window.removeEventListener('resize', this.setDirection);
        }

        this.setDirection = null;
      }
    }
  }, {
    key: "getAnchorElem",
    value: function getAnchorElem() {
      try {
        return this.getActiveElement().querySelector('a:not(:focus):first-of-type');
      } catch (e) {
        return null;
      }
    }
  }, {
    key: "focusAnchorElem",
    value: function focusAnchorElem(elem) {
      if (elem) {
        elem.focus({
          preventScroll: true
        });

        if (!elem._hkh) {
          elem._hkh = true;
          elem.addEventListener('keydown', this.anchorKeyDownHandler);
        }
      }
    }
  }, {
    key: "removeOutsideClickObserver",
    value: function removeOutsideClickObserver() {
      if (this.outsideClick) {
        this.outsideClick.remove();
      }

      if (typeof document !== 'undefined') {
        document.removeEventListener('keydown', this.onKeyDownHandler);
        document.removeEventListener('keyup', this.onKeyUpHandler);
      }
    }
  }, {
    key: "render",
    value: function render() {
      return react.createElement(DrawerListContext.Provider, {
        value: _extends({}, this.context, {
          drawerList: _extends({
            attributes: this.attributes,
            _refRoot: this._refRoot,
            _refShell: this._refShell,
            _refUl: this._refUl,
            _refTriangle: this._refTriangle,
            _rootElem: this._rootElem,
            getActiveElement: this.getActiveElement,
            setData: this.setDataHandler,
            setState: this.setStateHandler,
            setWrapperElement: this.setWrapperElement,
            assignObservers: this.assignObservers,
            setVisible: this.setVisible,
            setHidden: this.setHidden,
            selectItem: this.selectItem,
            scrollToItem: this.scrollToItem,
            scrollToAndSetActiveItem: this.scrollToAndSetActiveItem
          }, this.state)
        })
      }, this.props.children);
    }
  }]);

  return DrawerListProvider;
}(react.PureComponent);

DrawerListProvider.contextType = Context;
DrawerListProvider.defaultProps = {
  no_animation: false,
  prevent_selection: false,
  direction: 'auto',
  wrapper_element: null,
  prevent_close: false,
  keep_open: false,
  prevent_focus: false,
  skip_keysearch: false,
  use_drawer_on_mobile: null,
  enable_body_lock: null,
  page_offset: null,
  observer_element: null,
  enable_closest_observer: null,
  opened: null,
  scrollable: null,
  min_height: 10,
  max_height: null,
  on_resize: null,
  children: null
};
DrawerListProvider.blurDelay = 201;

function _createSuper$c(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$d(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$d() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var drawerListPortal;

if (typeof window !== 'undefined') {
  window.drawerListPortal = window.drawerListPortal || {};
  drawerListPortal = window.drawerListPortal;
} else {
  drawerListPortal = {};
}

var DrawerListPortal = function (_React$PureComponent) {
  _inherits(DrawerListPortal, _React$PureComponent);

  var _super = _createSuper$c(DrawerListPortal);

  function DrawerListPortal(props) {
    var _this;

    _classCallCheck(this, DrawerListPortal);

    _this = _super.call(this, props);
    _this.ref = props.innerRef || react.createRef();
    return _this;
  }

  _createClass(DrawerListPortal, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (!this.props.inactive) {
        this.renderPortal();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      var id = this.props.id;

      if (drawerListPortal[id]) {
        reactDom.unmountComponentAtNode(drawerListPortal[id].node);

        try {
          document.body.removeChild(drawerListPortal[id].node);
        } catch (e) {}

        drawerListPortal[id] = null;
      }

      this.removePositionObserver();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.props !== prevProps) {
        this.renderPortal();
      }
    }
  }, {
    key: "createPortal",
    value: function createPortal() {
      if (typeof document !== 'undefined') {
        try {
          var elem = drawerListPortal[this.props.id] = {
            node: document.createElement('div')
          };
          elem.node.setAttribute('role', 'presentation');
          elem.node.className = 'dnb-drawer-list__portal dnb-core-style';
          document.body.insertBefore(elem.node, document.body.firstChild);
        } catch (e) {
          warn('Could not create DrawerListPortal!', e);
        }
      }
    }
  }, {
    key: "makeStyle",
    value: function makeStyle() {
      try {
        var _this$props = this.props,
            rootRef = _this$props.rootRef,
            include_owner_width = _this$props.include_owner_width,
            independent_width = _this$props.independent_width,
            fixed_position = _this$props.fixed_position;
        var rootElem = rootRef.current;
        var ownerElem = rootElem.parentElement;
        var width = 64;
        var ownerWidth = window.getComputedStyle(ownerElem).width;

        if (independent_width || parseFloat(ownerWidth) < 64) {
          var minWidth = parseFloat(window.getComputedStyle(document.documentElement).getPropertyValue('--drawer-list-width'));
          width = minWidth * 16;
        }

        var customWidth = rootElem.getBoundingClientRect().width;

        if (parseFloat(customWidth || 0) >= 64) {
          width = customWidth;
        }

        var rect = rootElem.getBoundingClientRect();
        var scrollY = fixed_position ? 0 : window.scrollY !== undefined ? window.scrollY : window.pageYOffset;
        var scrollX = fixed_position ? 0 : window.scrollX !== undefined ? window.scrollX : window.pageXOffset;
        var top = scrollY + rect.top;
        var left = scrollX + rect.left + (include_owner_width ? parseFloat(ownerWidth || 0) : 0);
        var style = {
          width: width,
          '--drawer-list-width': "".concat(width / 16, "rem"),
          top: top,
          left: left
        };
        return style;
      } catch (e) {
        warn('Could not create makeStyle in DrawerListPortal!', e);
      }
    }
  }, {
    key: "addPositionObserver",
    value: function addPositionObserver() {
      var _this2 = this;

      if (typeof window === 'undefined' || this.setPosition) {
        return;
      }

      var renderPosition = function renderPosition() {
        _this2.renderPortal();
      };

      this.setPosition = function () {
        clearTimeout(_this2._ddt);
        _this2._ddt = setTimeout(renderPosition, 30);
      };

      window.addEventListener('resize', this.setPosition);
      this.customElem = isInsideScrollView(this.props.rootRef.current, true);

      if (this.customElem) {
        this.customElem.addEventListener('scroll', this.setPosition);
      }
    }
  }, {
    key: "removePositionObserver",
    value: function removePositionObserver() {
      clearTimeout(this._ddt);

      if (typeof window !== 'undefined' && this.setPosition) {
        if (this.customElem) {
          this.customElem.addEventListener('scroll', this.setPosition);
        }

        window.removeEventListener('resize', this.setPosition);
      }
    }
  }, {
    key: "renderPortal",
    value: function renderPortal() {
      var _this$props2 = this.props,
          inactive = _this$props2.inactive,
          id = _this$props2.id,
          opened = _this$props2.opened,
          fixed_position = _this$props2.fixed_position,
          use_drawer_on_mobile = _this$props2.use_drawer_on_mobile,
          children = _this$props2.children;

      if (inactive) {
        return;
      }

      if (!drawerListPortal[id]) {
        this.createPortal();
      }

      if (opened) {
        this.addPositionObserver();
      }

      var style = opened ? this.makeStyle() : {};
      reactDom.render(react.createElement("span", {
        className: classnames('dnb-drawer-list__portal__style', fixed_position && 'dnb-drawer-list__portal__style--fixed', use_drawer_on_mobile && 'dnb-drawer-list__portal__style--mobile-view'),
        style: style,
        ref: this.ref
      }, children), drawerListPortal[id].node);
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props3 = this.props,
          inactive = _this$props3.inactive,
          children = _this$props3.children;
      return inactive ? children : null;
    }
  }]);

  return DrawerListPortal;
}(react.PureComponent);

DrawerListPortal.defaultProps = {
  rootRef: {
    current: null
  },
  innerRef: null,
  include_owner_width: false,
  independent_width: false,
  fixed_position: false,
  use_drawer_on_mobile: false,
  inactive: false
};
var DrawerListPortal$1 = react.forwardRef(function DrawerListPortalRef(props, ref) {
  return react.createElement(DrawerListPortal, _extends({
    innerRef: ref
  }, props));
});

function _createSuper$d(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$e(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$e() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }
var propsToFilterOut = {
  on_show: null,
  on_hide: null,
  on_change: null,
  on_pre_change: null,
  on_resize: null,
  on_select: null,
  on_state_update: null,
  options_render: null,
  wrapper_element: null
};

var DrawerList = function (_React$PureComponent) {
  _inherits(DrawerList, _React$PureComponent);

  var _super = _createSuper$d(DrawerList);

  function DrawerList() {
    _classCallCheck(this, DrawerList);

    return _super.apply(this, arguments);
  }

  _createClass(DrawerList, [{
    key: "render",
    value: function render() {
      var _this$context;

      var hasProvider = (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.drawerList;

      if (hasProvider) {
        return react.createElement(DrawerListInstance, this.props);
      }

      return react.createElement(DrawerListProvider, _extends({}, this.props, {
        data: this.props.data || this.props.children
      }), react.createElement(DrawerListInstance, this.props));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(DrawerList.tagName, DrawerList, DrawerList.defaultProps);
    }
  }]);

  return DrawerList;
}(react.PureComponent);

DrawerList.tagName = 'dnb-drawer-list';
DrawerList.contextType = DrawerListContext;
DrawerList.defaultProps = {
  id: null,
  role: 'listbox',
  cache_hash: null,
  triangle_position: 'left',
  scrollable: true,
  focusable: false,
  max_height: null,
  direction: 'auto',
  size: 'default',
  no_animation: false,
  no_scroll_animation: false,
  use_drawer_on_mobile: false,
  prevent_selection: false,
  action_menu: false,
  is_popup: false,
  align_drawer: 'left',
  wrapper_element: null,
  default_value: null,
  value: 'initval',
  skip_portal: null,
  prevent_close: false,
  keep_open: false,
  prevent_focus: false,
  fixed_position: false,
  independent_width: false,
  skip_keysearch: false,
  opened: null,
  class: null,
  data: null,
  prepared_data: null,
  raw_data: null,
  ignore_events: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_show: null,
  on_hide: null,
  on_change: null,
  on_pre_change: null,
  on_resize: null,
  on_select: null,
  on_state_update: null,
  options_render: null
};

var DrawerListInstance = function (_React$PureComponent2) {
  _inherits(DrawerListInstance, _React$PureComponent2);

  var _super2 = _createSuper$d(DrawerListInstance);

  function DrawerListInstance(props, context) {
    var _this;

    _classCallCheck(this, DrawerListInstance);

    _this = _super2.call(this, props);

    _this.preventTab = function (e) {
      switch (keycode(e)) {
        case 'tab':
          _this.context.drawerList.setHidden();

          break;

        case 'page down':
        case 'page up':
          e.preventDefault();
          break;
      }
    };

    _this.selectItemHandler = function (event) {
      var selected_item = parseFloat(event.currentTarget.getAttribute('data-item'));

      if (selected_item > -1) {
        _this.context.drawerList.selectItem(selected_item, {
          fireSelectEvent: true,
          event: event
        });
      }
    };

    _this._id = props.id || makeUniqueId();
    _this.state = _this.state || {};
    context.drawerList.setState(Object.entries(propsToFilterOut).reduce(function (acc, _ref) {
      var _ref2 = _slicedToArray$1(_ref, 1),
          key = _ref2[0];

      if (props[key]) {
        acc[key] = props[key];
      }

      return acc;
    }, {}));
    context.drawerList.setState({
      triangle_position: props.triangle_position
    });
    return _this;
  }

  _createClass(DrawerListInstance, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var props = extendPropsWithContext(this.props, DrawerList.defaultProps, this.context.formRow, this.context.getTranslation(this.props).DrawerList);

      var role = props.role,
          align_drawer = props.align_drawer,
          fixed_position = props.fixed_position,
          use_drawer_on_mobile = props.use_drawer_on_mobile,
          independent_width = props.independent_width,
          scrollable = props.scrollable,
          focusable = props.focusable,
          size = props.size,
          no_animation = props.no_animation,
          no_scroll_animation = props.no_scroll_animation,
          prevent_selection = props.prevent_selection,
          action_menu = props.action_menu,
          is_popup = props.is_popup,
          inner_class = props.inner_class,
          ignore_events = props.ignore_events,
          options_render = props.options_render,
          className = props.className,
          _className = props.class,
          _cache_hash = props.cache_hash,
          _wrapper_element = props.wrapper_element,
          _triangle_position = props.triangle_position,
          _direction = props.direction,
          _max_height = props.max_height,
          _id = props.id,
          _data = props.data,
          _prepared_data = props.prepared_data,
          _raw_data = props.raw_data,
          _opened = props.opened,
          _value = props.value,
          children = props.children,
          attributes = _objectWithoutProperties(props, ["role", "align_drawer", "fixed_position", "use_drawer_on_mobile", "independent_width", "scrollable", "focusable", "size", "no_animation", "no_scroll_animation", "prevent_selection", "action_menu", "is_popup", "inner_class", "ignore_events", "options_render", "className", "class", "cache_hash", "wrapper_element", "triangle_position", "direction", "max_height", "id", "data", "prepared_data", "raw_data", "opened", "value", "children"]);

      var id = this._id;
      var _this$context$drawerL = this.context.drawerList,
          data = _this$context$drawerL.data,
          opened = _this$context$drawerL.opened,
          hidden = _this$context$drawerL.hidden,
          triangle_position = _this$context$drawerL.triangle_position,
          direction = _this$context$drawerL.direction,
          max_height = _this$context$drawerL.max_height,
          cache_hash = _this$context$drawerL.cache_hash,
          selected_item = _this$context$drawerL.selected_item,
          active_item = _this$context$drawerL.active_item,
          closestToTop = _this$context$drawerL.closestToTop,
          closestToBottom = _this$context$drawerL.closestToBottom,
          assignObservers = _this$context$drawerL.assignObservers,
          _refShell = _this$context$drawerL._refShell,
          _refTriangle = _this$context$drawerL._refTriangle,
          _refUl = _this$context$drawerL._refUl,
          usePortal = _this$context$drawerL.usePortal,
          _refRoot = _this$context$drawerL._refRoot;

      var mainParams = _extends({
        id: "".concat(id, "-drawer-list"),
        className: classnames("dnb-drawer-list dnb-drawer-list--".concat(direction), isTrue(independent_width) || isTrue(action_menu) && 'dnb-drawer-list--independent-width', createSpacingClasses(props), _className, className, opened && 'dnb-drawer-list--opened', hidden && 'dnb-drawer-list--hidden', triangle_position && "dnb-drawer-list--triangle-position-".concat(triangle_position), align_drawer && "dnb-drawer-list--".concat(align_drawer), size && "dnb-drawer-list--".concat(size), isTrue(action_menu) && "dnb-drawer-list--action-menu", isTrue(is_popup) && 'dnb-drawer-list--is-popup', isTrue(scrollable) && 'dnb-drawer-list--scroll', isTrue(no_scroll_animation) && 'dnb-drawer-list--no-scroll-animation', isTrue(use_drawer_on_mobile) && 'dnb-drawer-list--mobile-view')
      }, attributes);

      var listParams = {
        id: "".concat(id, "-listbox"),
        className: classnames('dnb-drawer-list__list', inner_class, isTrue(no_animation) && 'dnb-drawer-list__list--no-animation')
      };
      var ulParams = {
        role: role,
        id: "".concat(id, "-ul"),
        'aria-expanded': opened,
        'aria-labelledby': "".concat(id, "-label"),
        tabIndex: '-1',
        style: {
          maxHeight: max_height > 0 ? "".concat(max_height, "rem") : null
        },
        ref: _refUl
      };

      if (!hidden && parseFloat(active_item) > -1) {
        ulParams['aria-activedescendant'] = "option-".concat(id, "-").concat(active_item);
      } else if (!isTrue(prevent_selection) && !hidden && parseFloat(selected_item) > -1) {
        ulParams['aria-activedescendant'] = "option-".concat(id, "-").concat(selected_item);
      }

      if (isTrue(focusable)) {
        ulParams.tabIndex = '0';
      }

      validateDOMAttributes(this.props, mainParams);
      validateDOMAttributes(null, listParams);
      validateDOMAttributes(null, ulParams);

      _extends(this.context.drawerList.attributes, validateDOMAttributes(null, attributes));

      var ignoreEvents = isTrue(ignore_events);

      var Items = function Items() {
        return data.map(function (dataItem, i) {
          var _id = dataItem.__id;
          var hash = "option-".concat(id, "-").concat(_id, "-").concat(i);
          var liParams = {
            role: role === 'menu' ? 'menuitem' : 'option',
            'data-item': _id,
            id: "option-".concat(id, "-").concat(_id),
            hash: hash,
            className: classnames(ignoreEvents || dataItem.ignore_events && 'ignore-events', dataItem.class_name, i === closestToTop && 'closest-to-top', i === closestToBottom && 'closest-to-bottom', i === 0 && 'first-of-type', i === data.length - 1 && 'last-of-type'),
            active: _id == active_item,
            selected: !dataItem.ignore_events && _id == selected_item,
            onClick: _this2.selectItemHandler,
            onKeyDown: _this2.preventTab
          };

          if (ignoreEvents) {
            liParams.active = null;
            liParams.selected = null;
            liParams.onClick = null;
            liParams.onKeyDown = null;
            liParams.className = classnames(liParams.className, 'dnb-drawer-list__option--ignore');
          }

          return react.createElement(DrawerList.Item, _extends({
            key: hash
          }, liParams), dataItem);
        });
      };

      var mainList = react.createElement("span", _extends({}, mainParams, {
        ref: _refShell
      }), react.createElement("span", listParams, hidden === false && data && data.length > 0 ? react.createElement(react.Fragment, null, react.createElement(DrawerList.Options, _extends({
        cache_hash: cache_hash + active_item + selected_item + closestToTop + closestToBottom + direction + max_height
      }, ulParams, {
        triangleRef: _refTriangle
      }), typeof options_render === 'function' ? options_render({
        data: data,
        Items: Items,
        Item: DrawerList.Item
      }) : react.createElement(Items, null)), react.createElement(OnMounted, {
        assignObservers: assignObservers
      })) : children && react.createElement("span", {
        className: "dnb-drawer-list__content"
      }, children, react.createElement("span", {
        className: "dnb-drawer-list__triangle",
        ref: _refTriangle
      }))));
      return react.createElement("span", {
        className: 'dnb-drawer-list__root' + (usePortal ? " dnb-drawer-list__root--portal" : ""),
        ref: _refRoot
      }, usePortal ? react.createElement(DrawerListPortal$1, {
        id: this._id,
        rootRef: _refRoot,
        opened: hidden === false,
        include_owner_width: align_drawer === 'right',
        independent_width: isTrue(independent_width),
        fixed_position: isTrue(fixed_position),
        use_drawer_on_mobile: isTrue(use_drawer_on_mobile)
      }, mainList) : mainList);
    }
  }]);

  return DrawerListInstance;
}(react.PureComponent);

DrawerListInstance.defaultProps = DrawerList.defaultProps;
DrawerListInstance.contextType = DrawerListContext;
DrawerList.Options = react.memo(react.forwardRef(function (props, ref) {
  var children = props.children,
      className = props.className,
      _className = props.class,
      _props$triangleRef = props.triangleRef,
      triangleRef = _props$triangleRef === void 0 ? null : _props$triangleRef,
      cache_hash = props.cache_hash,
      rest = _objectWithoutProperties(props, ["children", "className", "class", "triangleRef", "cache_hash"]);

  return react.createElement("ul", _extends({
    className: classnames('dnb-drawer-list__options', className, _className)
  }, rest, {
    ref: ref
  }), children, react.createElement("li", {
    className: "dnb-drawer-list__triangle",
    "aria-hidden": true,
    ref: triangleRef
  }));
}), function (prevProps, nextProps) {
  if (!prevProps.cache_hash) {
    return null;
  }

  return prevProps.cache_hash === nextProps.cache_hash;
});
DrawerList.Options.displayName = 'DrawerList.Options';
DrawerList.Options.propTypes = {
  children: propTypes.oneOfType([propTypes.node, propTypes.func]),
  className: propTypes.string,
  class: propTypes.string,
  triangleRef: propTypes.object
};
DrawerList.Options.defaultProps = {
  children: null,
  className: null,
  class: null,
  triangleRef: null
};
DrawerList.Item = react.forwardRef(function (props, ref) {
  var role = props.role,
      hash = props.hash,
      children = props.children,
      className = props.className,
      _className = props.class,
      on_click = props.on_click,
      selected = props.selected,
      active = props.active,
      value = props.value,
      rest = _objectWithoutProperties(props, ["role", "hash", "children", "className", "class", "on_click", "selected", "active", "value"]);

  var params = {
    className: classnames(className, _className, 'dnb-drawer-list__option', selected && 'dnb-drawer-list__option--selected', active && 'dnb-drawer-list__option--focus'),
    role: role,
    tabIndex: selected ? '0' : '-1',
    'aria-selected': active
  };

  if (selected) {
    params['aria-current'] = true;
  }

  if (on_click) {
    params.onClick = function () {
      return dispatchCustomElementEvent({
        props: _extends({}, props, {
          displayName: DrawerList.Item.displayName
        })
      }, 'on_click', _extends({
        selected: selected,
        value: value
      }, rest));
    };
  }

  return react.createElement("li", _extends({}, params, rest, {
    ref: ref,
    key: 'li' + hash
  }), react.createElement("span", {
    className: "dnb-drawer-list__option__inner"
  }, react.createElement(ItemContent, {
    hash: hash
  }, children)));
});
DrawerList.Item.displayName = 'DrawerList.Item';
DrawerList.Item.propTypes = {
  role: propTypes.string,
  hash: propTypes.string,
  children: propTypes.oneOfType([propTypes.node, propTypes.func, propTypes.object]).isRequired,
  className: propTypes.string,
  class: propTypes.string,
  on_click: propTypes.func,
  selected: propTypes.bool,
  active: propTypes.bool,
  value: propTypes.oneOfType([propTypes.string, propTypes.number])
};
DrawerList.Item.defaultProps = {
  role: 'option',
  hash: '',
  className: null,
  class: null,
  on_click: null,
  selected: null,
  active: null,
  value: null
};

var ItemContent = function ItemContent(_ref3) {
  var hash = _ref3.hash,
      children = _ref3.children;

  if (Array.isArray(children.content || children)) {
    return (children.content || children).map(function (item, n) {
      return react.createElement("span", {
        key: hash + n,
        className: "dnb-drawer-list__option__item"
      }, children.render ? children.render(item, hash + n) : item);
    });
  } else if (children.content) {
    return children.render ? children.render(children.content, hash) : children.content;
  }

  return children;
};

DrawerList.HorizontalItem = function (_ref4) {
  var className = _ref4.className,
      props = _objectWithoutProperties(_ref4, ["className"]);

  return react.createElement("span", _extends({
    className: classnames('dnb-drawer-list__option__inner__item', className)
  }, props));
};

DrawerList.HorizontalItem.propTypes = {
  className: propTypes.string
};
DrawerList.HorizontalItem.defaultProps = {
  className: null
};

var OnMounted = function (_React$PureComponent3) {
  _inherits(OnMounted, _React$PureComponent3);

  var _super3 = _createSuper$d(OnMounted);

  function OnMounted() {
    _classCallCheck(this, OnMounted);

    return _super3.apply(this, arguments);
  }

  _createClass(OnMounted, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.props.assignObservers();
    }
  }, {
    key: "render",
    value: function render() {
      return null;
    }
  }]);

  return OnMounted;
}(react.PureComponent);

function _createSuper$e(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$f(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$f() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var _ref$J = react.createElement(AlignmentHelper, null);

var _ref2$2 = react.createElement("span", {
  className: "dnb-checkbox__focus"
});

var Checkbox = function (_React$PureComponent) {
  _inherits(Checkbox, _React$PureComponent);

  var _super = _createSuper$e(Checkbox);

  _createClass(Checkbox, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Checkbox.tagName, Checkbox, Checkbox.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          if (props.default_state !== null && typeof state.checked === 'undefined') {
            state.checked = Checkbox.parseChecked(props.default_state);
          } else {
            state.checked = Checkbox.parseChecked(props.checked);
          }
        }
      }

      state._listenForPropChanges = true;

      if (state.checked !== state.__checked) {
        dispatchCustomElementEvent({
          props: props
        }, 'on_state_update', {
          checked: state.checked
        });
      }

      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);

  function Checkbox(props) {
    var _this;

    _classCallCheck(this, Checkbox);

    _this = _super.call(this, props);

    _this.onKeyDownHandler = function (event) {
      switch (keycode(event)) {
        case 'enter':
          _this.onChangeHandler(event);

          break;
      }
    };

    _this.onChangeHandler = function (event) {
      if (isTrue(_this.props.readOnly)) {
        return event.preventDefault();
      }

      var checked = !_this.state.checked;

      _this.setState({
        checked: checked,
        _listenForPropChanges: false
      });

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', {
        checked: checked,
        event: event
      });

      if (_this._refInput.current) {
        _this._refInput.current.focus();
      }
    };

    _this._refInput = react.createRef();
    _this._id = props.id || makeUniqueId();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }

  _createClass(Checkbox, [{
    key: "render",
    value: function render() {
      var props = extendPropsWithContext(this.props, Checkbox.defaultProps, {
        skeleton: this.context && this.context.skeleton
      }, this.context.formRow);

      var value = props.value,
          status = props.status,
          status_state = props.status_state,
          status_animation = props.status_animation,
          global_status_id = props.global_status_id,
          suffix = props.suffix,
          size = props.size,
          label = props.label,
          label_position = props.label_position,
          label_sr_only = props.label_sr_only,
          title = props.title,
          disabled = props.disabled,
          readOnly = props.readOnly,
          skeleton = props.skeleton,
          className = props.className,
          _className = props.class,
          _id = props.id,
          _default_state = props.default_state,
          _checked = props.checked,
          attributes = props.attributes,
          children = props.children,
          on_change = props.on_change,
          on_state_update = props.on_state_update,
          custom_method = props.custom_method,
          custom_element = props.custom_element,
          rest = _objectWithoutProperties(props, ["value", "status", "status_state", "status_animation", "global_status_id", "suffix", "size", "label", "label_position", "label_sr_only", "title", "disabled", "readOnly", "skeleton", "className", "class", "id", "default_state", "checked", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);

      var checked = this.state.checked;
      var id = this._id;
      var showStatus = getStatusState(status);
      var mainParams = {
        className: classnames("dnb-checkbox dnb-form-component", createSkeletonClass(null, skeleton), createSpacingClasses(props), className, _className, status && "dnb-checkbox__status--".concat(status_state), size && "dnb-checkbox--".concat(size), label && "dnb-checkbox--label-position-".concat(label_position || 'right'))
      };

      var inputParams = _extends({
        disabled: disabled,
        checked: checked
      }, rest);

      if (showStatus || suffix) {
        inputParams['aria-describedby'] = combineDescribedBy(inputParams, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
      }

      if (readOnly) {
        inputParams['aria-readonly'] = inputParams.readOnly = true;
      }

      skeletonDOMAttributes(inputParams, skeleton, this.context);
      validateDOMAttributes(this.props, inputParams);
      var statusComp = showStatus && react.createElement(FormStatus, {
        id: id + '-form-status',
        global_status_id: global_status_id,
        label: label,
        text_id: id + '-status',
        width_selector: id + ', ' + id + '-label',
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton: skeleton
      });
      return react.createElement("span", mainParams, react.createElement("span", {
        className: "dnb-checkbox__order"
      }, label && react.createElement(FormLabel, {
        id: id + '-label',
        for_id: id,
        text: label,
        disabled: disabled,
        skeleton: skeleton,
        sr_only: label_sr_only
      }), react.createElement("span", {
        className: "dnb-checkbox__inner"
      }, _ref$J, label_position === 'left' && statusComp, react.createElement("span", {
        className: "dnb-checkbox__shell"
      }, react.createElement("input", _extends({
        id: id,
        name: id,
        type: "checkbox",
        title: title,
        "aria-checked": checked,
        className: "dnb-checkbox__input",
        value: checked ? value || '' : '',
        disabled: isTrue(disabled)
      }, inputParams, {
        onChange: this.onChangeHandler,
        onKeyDown: this.onKeyDownHandler,
        ref: this._refInput
      })), react.createElement("span", {
        className: classnames('dnb-checkbox__button', createSkeletonClass('shape', skeleton, this.context)),
        "aria-hidden": true
      }, _ref2$2), react.createElement(CheckIcon, {
        size: size
      }))), suffix && react.createElement("span", {
        className: "dnb-checkbox__suffix",
        id: id + '-suffix'
      }, react.createElement(Suffix, props, suffix))), (label_position === 'right' || !label_position) && statusComp);
    }
  }]);

  return Checkbox;
}(react.PureComponent);

Checkbox.tagName = 'dnb-checkbox';
Checkbox.contextType = Context;
Checkbox.defaultProps = {
  label: null,
  label_position: null,
  title: null,
  default_state: null,
  checked: null,
  disabled: null,
  id: null,
  size: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: null,
  attributes: null,
  readOnly: false,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};

Checkbox.parseChecked = function (state) {
  return /true|on/.test(String(state));
};
var CheckIcon = function CheckIcon(_ref3) {
  var size = _ref3.size,
      props = _objectWithoutProperties(_ref3, ["size"]);

  var vB = 16;

  if (size === 'large') {
    vB = 24;
  }

  return react.createElement("svg", _extends({
    width: vB,
    height: vB,
    viewBox: "0 0 ".concat(vB, " ").concat(vB),
    fill: "none",
    className: "dnb-checkbox__gfx",
    "aria-hidden": true
  }, props), react.createElement("path", {
    d: size === 'large' ? 'M1.5 15L7.5 21L22.5 3' : 'M1 10L5 14L15 2',
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
};
CheckIcon.defaultProps = {
  size: 'default'
};

var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function (string, tag, attribute, value) {
  var S = String(_defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
var _stringHtml = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  _export(_export.P + _export.F * _fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};

function pad(hash, len) {
  while (hash.length < len) {
    hash = '0' + hash;
  }

  return hash;
}

function fold(hash, text) {
  var i;
  var chr;
  var len;

  if (text.length === 0) {
    return hash;
  }

  for (i = 0, len = text.length; i < len; i++) {
    chr = text.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }

  return hash < 0 ? hash * -2 : hash;
}

function foldObject(hash, o, seen, deep) {
  return Object.keys(o).sort().reduce(foldKey, hash);

  function foldKey(hash, key) {
    if (deep === false && (_typeof(o[key]) === 'object' || typeof o[key] === 'function')) {
      return hash;
    }

    return foldValue(hash, o[key], key, seen, deep);
  }
}

function foldValue(input, value, key, seen, deep) {
  var hash = fold(fold(fold(input, key), toString$1(value)), _typeof(value));

  if (value === null) {
    return fold(hash, 'null');
  }

  if (value === undefined) {
    return fold(hash, 'undefined');
  }

  if (_typeof(value) === 'object' || typeof value === 'function') {
    if (seen.indexOf(value) !== -1) {
      return fold(hash, '[Circular]' + key);
    }

    seen.push(value);
    var objHash = foldObject(hash, value, seen, deep);

    if (!('valueOf' in value) || typeof value.valueOf !== 'function') {
      return objHash;
    }

    try {
      return fold(objHash, String(value.valueOf()));
    } catch (err) {
      return fold(objHash, '[valueOf exception]' + (err.stack || err.message));
    }
  }

  return fold(hash, value.toString());
}

function toString$1(o) {
  return Object.prototype.toString.call(o);
}

function sum(o) {
  var deep = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  return pad(foldValue(0, o, '', [], deep).toString(16), 8);
}

function _createSuper$f(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$g(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$g() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var _ref$K = react.createElement(AlignmentHelper, null);

var _ref2$3 = react.createElement("span", {
  className: "dnb-form-label dnb-form-row__label-dummy",
  "aria-hidden": true
});

var FormRow = function (_React$PureComponent) {
  _inherits(FormRow, _React$PureComponent);

  var _super = _createSuper$f(FormRow);

  _createClass(FormRow, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(FormRow.tagName, FormRow, FormRow.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      var label = null;
      var children = typeof props.children === 'function' ? props.children(props) : props.children;

      if (Array.isArray(props.children)) {
        children = children.reduce(function (pV, cV) {
          if (cV.type && cV.type.name === 'FormLabel') {
            label = cV.props.children;
          } else {
            pV.push(cV);
          }

          return pV;
        }, []);
      }

      return {
        label: label,
        children: children
      };
    }
  }]);

  function FormRow(props) {
    var _this;

    _classCallCheck(this, FormRow);

    _this = _super.call(this, props);
    _this._id = props.id || makeUniqueId();
    return _this;
  }

  _createClass(FormRow, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var props = extendPropsWithContext(this.props, FormRow.defaultProps, this.context.formRow);

      var label = props.label,
          label_direction = props.label_direction,
          label_sr_only = props.label_sr_only,
          label_id = props.label_id,
          label_class = props.label_class,
          no_fieldset = props.no_fieldset,
          no_label = props.no_label,
          indent = props.indent,
          direction = props.direction,
          vertical = props.vertical,
          centered = props.centered,
          indent_offset = props.indent_offset,
          section_style = props.section_style,
          section_spacing = props.section_spacing,
          global_status_id = props.global_status_id,
          responsive = props.responsive,
          disabled = props.disabled,
          skeleton = props.skeleton,
          wrap = props.wrap,
          _id = props.id,
          className = props.className,
          _className = props.class,
          skipContentWrapperIfNested = props.skipContentWrapperIfNested,
          attributes = _objectWithoutProperties(props, ["label", "label_direction", "label_sr_only", "label_id", "label_class", "no_fieldset", "no_label", "indent", "direction", "vertical", "centered", "indent_offset", "section_style", "section_spacing", "global_status_id", "responsive", "disabled", "skeleton", "wrap", "id", "className", "class", "skipContentWrapperIfNested"]);

      var isNested = this.context.formRow && this.context.formRow.itsMeAgain;

      var _FormRow$getContent = FormRow.getContent(this.props),
          nestedLabel = _FormRow$getContent.label,
          children = _FormRow$getContent.children;

      if (!label && nestedLabel) {
        label = nestedLabel;
      }

      var hasLabel = typeof label === 'string' && label.length > 0 || label ? true : false;
      var id = this._id;

      var params = _extends({
        className: classnames('dnb-form-row', (isTrue(vertical) || direction) && "dnb-form-row--".concat(isTrue(vertical) ? 'vertical' : direction), (isTrue(vertical) || label_direction) && "dnb-form-row--".concat(isTrue(vertical) ? 'vertical' : label_direction, "-label"), createSpacingClasses(props), className, _className, indent && !(isNested && this.context.formRow.hasLabel && this.context.formRow.indent) && "dnb-form-row__indent--".concat(isTrue(indent) ? 'default' : indent), centered && 'dnb-form-row--centered', isNested && 'dnb-form-row--nested', section_style && "dnb-section dnb-section--".concat(section_style), section_spacing && "dnb-section--spacing-".concat(isTrue(section_spacing) ? 'default' : section_spacing))
      }, attributes);

      validateDOMAttributes(this.props, params);

      if (this._cachedContext !== sum(this.context, false) || this._cachedProps !== sum(this.props, false)) {
        this._cachedContext = sum(this.context, false);
        this._cachedProps = sum(this.props, false);
        var formRow = {
          useId: function useId() {
            if (_this2.isIsUsed) {
              return makeUniqueId();
            }

            _this2.isIsUsed = true;
            return id;
          },
          itsMeAgain: true,
          hasLabel: hasLabel,
          indent: indent,
          global_status_id: global_status_id,
          direction: direction,
          vertical: vertical,
          label_direction: isTrue(vertical) ? 'vertical' : label_direction,
          responsive: responsive,
          disabled: disabled,
          skeleton: skeleton
        };
        this._contextWeUse = extend(this.context, {
          formRow: formRow
        });
      }

      var useFieldset = !isTrue(no_fieldset) && hasLabel;
      return react.createElement(Context.Provider, {
        value: this._contextWeUse
      }, react.createElement(Fieldset, {
        useFieldset: useFieldset
      }, react.createElement("div", params, _ref$K, label && react.createElement(FormLabel, {
        className: classnames('dnb-form-row__label', label_class),
        id: label_id ? label_id : id + '-label',
        for_id: useFieldset ? null : id,
        text: label,
        element: useFieldset ? 'legend' : 'label',
        label_direction: label_direction,
        sr_only: label_sr_only,
        disabled: disabled,
        skeleton: skeleton
      }), isTrue(no_label) && _ref2$3, isNested && skipContentWrapperIfNested ? children : react.createElement("div", {
        className: classnames('dnb-form-row__content', isTrue(wrap) && 'dnb-form-row__content--wrap', label && !isTrue(vertical) && direction !== 'vertical' && "dnb-form-row__content--".concat(indent_offset || 'default'), responsive && 'dnb-responsive-component'),
        ref: this._contentRef
      }, children))));
    }
  }]);

  return FormRow;
}(react.PureComponent);

FormRow.tagName = 'dnb-form-row';
FormRow.contextType = Context;
FormRow.defaultProps = {
  id: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  label_id: null,
  label_class: null,
  no_label: false,
  no_fieldset: null,
  indent: null,
  wrap: null,
  direction: null,
  vertical: null,
  centered: null,
  indent_offset: null,
  section_style: null,
  section_spacing: null,
  global_status_id: null,
  responsive: null,
  disabled: null,
  skeleton: null,
  class: null,
  skipContentWrapperIfNested: false,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null
};

var Fieldset = function Fieldset(_ref3) {
  var useFieldset = _ref3.useFieldset,
      className = _ref3.className,
      children = _ref3.children,
      props = _objectWithoutProperties(_ref3, ["useFieldset", "className", "children"]);

  if (useFieldset) {
    return react.createElement("fieldset", _extends({
      className: classnames('dnb-form-row__fieldset', className)
    }, props), children);
  }

  return react.createElement("div", _extends({
    className: classnames('dnb-form-row__fieldset', className)
  }, props), children);
};
Fieldset.defaultProps = {
  useFieldset: false,
  className: null
};
var prepareFormRowContext = function prepareFormRowContext(props) {
  if (typeof props.label_direction === 'undefined') {
    props.label_direction = isTrue(props.vertical) ? 'vertical' : props.label_direction;
  }

  return props;
};

var RadioGroupContext = react.createContext({});

function _createSuper$g(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$h(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$h() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var RadioGroup = function (_React$PureComponent) {
  _inherits(RadioGroup, _React$PureComponent);

  var _super = _createSuper$g(RadioGroup);

  _createClass(RadioGroup, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(RadioGroup.tagName, RadioGroup, RadioGroup.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.value !== state._value) {
          state.value = props.value;
        }

        if (typeof props.value !== 'undefined') {
          state._value = props.value;
        }
      }

      state._listenForPropChanges = true;
      return state;
    }
  }]);

  function RadioGroup(props) {
    var _this;

    _classCallCheck(this, RadioGroup);

    _this = _super.call(this, props);

    _this.onChangeHandler = function (_ref) {
      var value = _ref.value,
          event = _ref.event;

      _this.setState({
        value: value,
        _listenForPropChanges: false
      });

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', {
        value: value,
        event: event
      });
    };

    _this._refInput = react.createRef();
    _this._id = props.id || makeUniqueId();
    _this._name = props.name || _this._id;
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }

  _createClass(RadioGroup, [{
    key: "render",
    value: function render() {
      var props = extendPropsWithContext(this.props, RadioGroup.defaultProps, this.context.formRow);

      var status = props.status,
          status_state = props.status_state,
          status_animation = props.status_animation,
          global_status_id = props.global_status_id,
          suffix = props.suffix,
          label = props.label,
          label_direction = props.label_direction,
          label_sr_only = props.label_sr_only,
          label_position = props.label_position,
          vertical = props.vertical,
          layout_direction = props.layout_direction,
          no_fieldset = props.no_fieldset,
          size = props.size,
          disabled = props.disabled,
          skeleton = props.skeleton,
          className = props.className,
          _className = props.class,
          _id = props.id,
          _name = props.name,
          _value = props.value,
          attributes = props.attributes,
          children = props.children,
          on_change = props.on_change,
          custom_method = props.custom_method,
          custom_element = props.custom_element,
          rest = _objectWithoutProperties(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "label_position", "vertical", "layout_direction", "no_fieldset", "size", "disabled", "skeleton", "className", "class", "id", "name", "value", "attributes", "children", "on_change", "custom_method", "custom_element"]);

      var value = this.state.value;
      var id = this._id;
      var showStatus = getStatusState(status);
      var classes = classnames("dnb-radio-group dnb-radio-group--".concat(layout_direction, " dnb-form-component"), createSpacingClasses(props), className, _className, status && "dnb-radio-group__status--".concat(status_state));

      var params = _extends({}, rest);

      if (showStatus || suffix) {
        params['aria-describedby'] = combineDescribedBy(params, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
      }

      if (label) {
        params['aria-labelledby'] = id + '-label';
      }

      validateDOMAttributes(this.props, params);
      var context = {
        name: this._name,
        value: value,
        size: size,
        disabled: disabled,
        label_position: label_position,
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id: id,
        label: label,
        label_id: id + '-label',
        label_direction: label_direction,
        label_sr_only: label_sr_only,
        direction: label_direction,
        vertical: vertical,
        disabled: disabled,
        skeleton: skeleton,
        no_fieldset: no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(RadioGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, react.createElement(FormRow, formRowParams, react.createElement("span", _extends({
        id: id,
        className: "dnb-radio-group__shell",
        role: "radiogroup"
      }, params), children, suffix && react.createElement("span", {
        className: "dnb-radio-group__suffix",
        id: id + '-suffix'
      }, react.createElement(Suffix, props, suffix)), showStatus && react.createElement(FormStatus, {
        id: id + '-form-status',
        global_status_id: global_status_id,
        label: label,
        text: status,
        status: status_state,
        text_id: id + '-status',
        width_selector: id + ', ' + id + '-label',
        animation: status_animation,
        skeleton: skeleton
      })))));
    }
  }]);

  return RadioGroup;
}(react.PureComponent);

RadioGroup.tagName = 'dnb-radio-group';
RadioGroup.contextType = Context;
RadioGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  label_position: null,
  title: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  size: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: 'row',
  value: undefined,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};

RadioGroup.parseChecked = function (state) {
  return /true|on/.test(String(state));
};

function _createSuper$h(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$i(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$i() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var _ref2$4 = react.createElement(AlignmentHelper, null);

var _ref3$2 = react.createElement("span", {
  className: "dnb-radio__focus",
  "aria-hidden": true
});

var _ref4$1 = react.createElement("span", {
  className: "dnb-radio__dot",
  "aria-hidden": true
});

var Radio = function (_React$PureComponent) {
  _inherits(Radio, _React$PureComponent);

  var _super = _createSuper$h(Radio);

  _createClass(Radio, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Radio.tagName, Radio, Radio.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = Radio.parseChecked(props.checked);
        }
      }

      state._listenForPropChanges = true;

      if (state.checked !== state.__checked) {
        dispatchCustomElementEvent({
          props: props
        }, 'on_state_update', {
          checked: state.checked
        });
      }

      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);

  function Radio(props) {
    var _this;

    _classCallCheck(this, Radio);

    _this = _super.call(this, props);

    _this.onKeyDownHandler = function (event) {
      var key = keycode(event);

      if (_this.isInNoGroup()) {
        switch (key) {
          case 'enter':
            _this.onChangeHandler(event);

            break;
        }
      } else if (_this.isContextGroupOrSingle()) {
        switch (key) {
          case 'space':
          case 'enter':
            {
              var value = _this.context.value;

              if (value !== null && typeof value !== 'undefined') {
                event.preventDefault();
              }

              if (key === 'enter') {
                var checked = !_this.state.checked;

                _this.setState({
                  checked: checked,
                  _listenForPropChanges: false
                });
              }

              break;
            }
        }
      } else {
        switch (key) {
          case 'space':
            {
              event.preventDefault();
              break;
            }
        }
      }

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_key_down', {
        event: event
      });
    };

    _this.onChangeHandler = function (_event) {
      var event = _event;

      if (isTrue(_this.props.readOnly)) {
        return event.preventDefault();
      }

      var value = event.target.value;
      var checked = !_this.state.checked;

      if (_this.isPlainGroup()) {
        setTimeout(function () {
          _this.setState({
            checked: checked,
            _listenForPropChanges: false
          }, function () {
            return _this.callOnChange({
              value: value,
              checked: checked,
              event: event
            });
          });
        }, 1);
      } else {
        _this.setState({
          checked: checked,
          _listenForPropChanges: false
        });

        _this.callOnChange({
          value: value,
          checked: checked,
          event: event
        });
      }
    };

    _this.isContextGroupOrSingle = function () {
      return typeof _this.context.value !== 'undefined' && !_this.props.group;
    };

    _this.isPlainGroup = function () {
      return typeof _this.context.value === 'undefined' && _this.props.group;
    };

    _this.isInNoGroup = function () {
      return typeof _this.context.value === 'undefined' && !_this.props.group;
    };

    _this.onClickHandler = function (event) {
      if (isTrue(_this.props.readOnly)) {
        return event.preventDefault();
      }

      if (!_this.isPlainGroup()) {
        return;
      }

      var value = event.target.value;
      var checked = event.target.checked;

      _this.callOnChange({
        value: value,
        checked: checked,
        event: event
      });
    };

    _this.callOnChange = function (_ref) {
      var value = _ref.value,
          checked = _ref.checked,
          event = _ref.event;
      var group = _this.props.group;

      if (_this.context.onChange) {
        _this.context.onChange({
          value: value
        });
      }

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', {
        group: group,
        checked: checked,
        value: value,
        event: event
      });

      if (_this._refInput.current) {
        _this._refInput.current.focus();
      }
    };

    _this._refInput = react.createRef();
    _this._id = props.id || makeUniqueId();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }

  _createClass(Radio, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      return react.createElement(Context.Consumer, null, function (context) {
        var props = extendPropsWithContext(_this2.props, Radio.defaultProps, _this2.context, {
          skeleton: context === null || context === void 0 ? void 0 : context.skeleton
        }, context.formRow);

        var status = props.status,
            status_state = props.status_state,
            status_animation = props.status_animation,
            global_status_id = props.global_status_id,
            suffix = props.suffix,
            label = props.label,
            label_sr_only = props.label_sr_only,
            label_position = props.label_position,
            size = props.size,
            readOnly = props.readOnly,
            skeleton = props.skeleton,
            className = props.className,
            _className = props.class,
            _id = props.id,
            _group = props.group,
            _value = props.value,
            _checked = props.checked,
            _disabled = props.disabled,
            attributes = props.attributes,
            children = props.children,
            on_change = props.on_change,
            on_state_update = props.on_state_update,
            custom_method = props.custom_method,
            custom_element = props.custom_element,
            rest = _objectWithoutProperties(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_sr_only", "label_position", "size", "readOnly", "skeleton", "className", "class", "id", "group", "value", "checked", "disabled", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);

        var checked = _this2.state.checked;
        var value = props.value,
            group = props.group,
            disabled = props.disabled;
        var hasContext = typeof _this2.context.name !== 'undefined';

        if (hasContext) {
          if (typeof _this2.context.value !== 'undefined') {
            checked = _this2.context.value === value;
          }

          group = _this2.context.name;
          disabled = isTrue(_this2.context.disabled);
        } else if (typeof rest.name !== 'undefined') {
          group = rest.name;
        }

        var id = _this2._id;
        var showStatus = getStatusState(status);
        var mainParams = {
          className: classnames('dnb-radio', createSpacingClasses(props), className, _className, status && "dnb-radio__status--".concat(status_state), size && "dnb-radio--".concat(size), label && "dnb-radio--label-position-".concat(label_position || 'right'))
        };

        var inputParams = _extends({
          role: hasContext || group ? 'radio' : null,
          type: hasContext || group ? 'radio' : 'checkbox'
        }, rest);

        if (showStatus || suffix) {
          inputParams['aria-describedby'] = combineDescribedBy(inputParams, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
        }

        if (readOnly) {
          inputParams['aria-readonly'] = inputParams.readOnly = true;
        }

        if (!group) {
          inputParams.type = 'checkbox';
          inputParams.role = 'radio';
        }

        skeletonDOMAttributes(inputParams, skeleton, _this2.context);
        validateDOMAttributes(_this2.props, inputParams);
        var labelComp = label && react.createElement(FormLabel, {
          id: id + '-label',
          for_id: id,
          text: label,
          disabled: disabled,
          skeleton: skeleton,
          sr_only: label_sr_only
        });
        return react.createElement("span", mainParams, react.createElement("span", {
          className: "dnb-radio__order"
        }, label_position === 'left' && labelComp, react.createElement("span", {
          className: "dnb-radio__inner"
        }, _ref2$4, showStatus && react.createElement(FormStatus, {
          id: id + '-form-status',
          global_status_id: global_status_id,
          label: label,
          text_id: id + '-status',
          width_selector: id + ', ' + id + '-label',
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton: skeleton
        }), react.createElement("span", {
          className: "dnb-radio__row"
        }, react.createElement("span", {
          className: "dnb-radio__shell"
        }, react.createElement("input", _extends({
          type: "radio",
          value: value,
          id: id,
          name: group,
          className: "dnb-radio__input",
          checked: checked,
          "aria-checked": checked,
          disabled: isTrue(disabled),
          ref: _this2._refInput
        }, inputParams, {
          onChange: _this2.onChangeHandler,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler
        })), react.createElement("span", {
          className: classnames('dnb-radio__button', createSkeletonClass('shape', skeleton, _this2.context)),
          "aria-hidden": true
        }), _ref3$2, _ref4$1), label_position !== 'left' && labelComp, suffix && react.createElement("span", {
          className: "dnb-radio__suffix",
          id: id + '-suffix'
        }, react.createElement(Suffix, props, suffix))))));
      });
    }
  }]);

  return Radio;
}(react.PureComponent);

Radio.tagName = 'dnb-radio';
Radio.contextType = RadioGroupContext;
Radio.defaultProps = {
  label: null,
  label_sr_only: null,
  label_position: null,
  checked: null,
  disabled: false,
  id: null,
  size: null,
  group: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: '',
  attributes: null,
  readOnly: false,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
Radio.Group = RadioGroup;

Radio.parseChecked = function (state) {
  return /true|on/.test(String(state));
};

var ToggleButtonGroupContext = react.createContext({});

function _createSuper$i(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$j(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$j() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var ToggleButtonGroup = function (_React$PureComponent) {
  _inherits(ToggleButtonGroup, _React$PureComponent);

  var _super = _createSuper$i(ToggleButtonGroup);

  _createClass(ToggleButtonGroup, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(ToggleButtonGroup.tagName, ToggleButtonGroup, ToggleButtonGroup.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (typeof props.value !== 'undefined' && props.value !== state.value) {
          state.value = props.value;
        }

        if (typeof props.values !== 'undefined' && props.values !== state.values) {
          state.values = ToggleButtonGroup.getValues(props);
        }
      }

      state._listenForPropChanges = true;
      return state;
    }
  }, {
    key: "getValues",
    value: function getValues(props) {
      if (typeof props.values === 'string' && props.values[0] === '[') {
        return JSON.parse(props.values);
      }

      return props.values;
    }
  }]);

  function ToggleButtonGroup(props) {
    var _this;

    _classCallCheck(this, ToggleButtonGroup);

    _this = _super.call(this, props);

    _this.onChangeHandler = function (_ref) {
      var value = _ref.value,
          event = _ref.event;
      var multiselect = _this.props.multiselect;
      var values = _this.state.values || [];

      if (isTrue(multiselect)) {
        if (!values.includes(value)) {
          values.push(value);
        } else {
          values.splice(values.indexOf(value), 1);
        }
      }

      _this.setState({
        value: value,
        values: values,
        _listenForPropChanges: false
      });

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', {
        value: value,
        values: values,
        event: event
      });
    };

    _this._refInput = react.createRef();
    _this._id = props.id || makeUniqueId();
    _this._name = props.name || makeUniqueId();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }

  _createClass(ToggleButtonGroup, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var props = extendPropsWithContext(this.props, ToggleButtonGroup.defaultProps, this.context.formRow, this.context.translation.ToggleButton);

      var status = props.status,
          status_state = props.status_state,
          status_animation = props.status_animation,
          global_status_id = props.global_status_id,
          suffix = props.suffix,
          label_direction = props.label_direction,
          label_sr_only = props.label_sr_only,
          vertical = props.vertical,
          layout_direction = props.layout_direction,
          label = props.label,
          variant = props.variant,
          left_component = props.left_component,
          no_fieldset = props.no_fieldset,
          disabled = props.disabled,
          skeleton = props.skeleton,
          className = props.className,
          _className = props.class,
          multiselect = props.multiselect,
          _id = props.id,
          _name = props.name,
          _value = props.value,
          _values = props.values,
          attributes = props.attributes,
          children = props.children,
          on_change = props.on_change,
          custom_method = props.custom_method,
          custom_element = props.custom_element,
          rest = _objectWithoutProperties(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label_direction", "label_sr_only", "vertical", "layout_direction", "label", "variant", "left_component", "no_fieldset", "disabled", "skeleton", "className", "class", "multiselect", "id", "name", "value", "values", "attributes", "children", "on_change", "custom_method", "custom_element"]);

      var _this$state = this.state,
          value = _this$state.value,
          values = _this$state.values;
      var id = this._id;
      var showStatus = getStatusState(status);
      var classes = classnames("dnb-toggle-button-group dnb-toggle-button-group--".concat(layout_direction, " dnb-form-component"), createSpacingClasses(props), className, _className, status && "dnb-toggle-button-group__status--".concat(status_state), !label && 'dnb-toggle-button-group--no-label');

      var params = _extends({}, rest);

      if (showStatus || suffix) {
        params['aria-describedby'] = combineDescribedBy(params, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
      }

      if (label) {
        params['aria-labelledby'] = id + '-label';
      }

      validateDOMAttributes(this.props, params);
      var context = {
        name: this._name,
        value: value,
        values: values,
        multiselect: isTrue(multiselect),
        variant: variant,
        left_component: left_component,
        disabled: disabled,
        skeleton: skeleton,
        setContext: function setContext(context) {
          if (typeof context === 'function') {
            context = context(_this2._tmp);
          }

          _this2._tmp = _extends({}, _this2._tmp, context);

          _this2.setState(_extends({}, context, {
            _listenForPropChanges: false
          }));
        },
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id: id,
        label: label,
        label_id: id + '-label',
        label_direction: label_direction,
        label_sr_only: label_sr_only,
        direction: label_direction,
        vertical: vertical,
        disabled: disabled,
        skeleton: skeleton,
        no_fieldset: no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(ToggleButtonGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, react.createElement(FormRow, formRowParams, react.createElement("span", _extends({
        id: id,
        className: "dnb-toggle-button-group__shell",
        role: "group"
      }, params), showStatus && react.createElement(FormStatus, {
        id: id + '-form-status',
        global_status_id: global_status_id,
        label: label,
        text_id: id + '-status',
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton: skeleton
      }), react.createElement("span", {
        className: "dnb-toggle-button-group__children"
      }, children, suffix && react.createElement("span", {
        className: "dnb-toggle-button-group__suffix",
        id: id + '-suffix'
      }, react.createElement(Suffix, props, suffix)))))));
    }
  }]);

  return ToggleButtonGroup;
}(react.PureComponent);

ToggleButtonGroup.tagName = 'dnb-toggle-button-group';
ToggleButtonGroup.contextType = Context;
ToggleButtonGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  multiselect: null,
  variant: null,
  left_component: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: 'row',
  value: undefined,
  values: undefined,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};

function _createSuper$j(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$k(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$k() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var _ref3$3 = react.createElement(AlignmentHelper, null);

var ToggleButton = function (_React$PureComponent) {
  _inherits(ToggleButton, _React$PureComponent);

  var _super = _createSuper$j(ToggleButton);

  _createClass(ToggleButton, null, [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(ToggleButton.tagName, ToggleButton, ToggleButton.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = ToggleButton.parseChecked(props.checked);
        }
      }

      state._listenForPropChanges = true;

      if (state.checked !== state.__checked) {
        dispatchCustomElementEvent({
          props: props
        }, 'on_state_update', {
          checked: state.checked
        });
      }

      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);

  function ToggleButton(props, context) {
    var _this;

    _classCallCheck(this, ToggleButton);

    _this = _super.call(this, props);

    _this.onKeyDownHandler = function (event) {
      switch (keycode(event)) {
        case 'enter':
          _this.onClickHandler(event);

          break;
      }
    };

    _this.onKeyUpHandler = function (event) {
      switch (keycode(event)) {
        case 'enter':
          _this.onClickHandler(event);

          break;
      }
    };

    _this.onClickHandler = function (_ref) {
      var event = _ref.event;

      if (isTrue(_this.props.readOnly)) {
        return event.preventDefault();
      }

      event.persist();

      if (!isTrue(_this.context.multiselect) && _this.props.value === _this.context.value) {
        return;
      }

      var checked = !_this.state.checked;

      _this.setState({
        checked: checked,
        _listenForPropChanges: false
      });

      _this.callOnChange({
        checked: checked,
        event: event
      });

      if (_this._refButton.current && checked) {
        try {
          _this._refButton.current._ref.current.focus();
        } catch (e) {
          warn(e);
        }
      }
    };

    _this.callOnChange = function (_ref2) {
      var checked = _ref2.checked,
          event = _ref2.event;
      var value = _this.props.value;

      if (_this.context.onChange) {
        _this.context.onChange({
          value: value,
          event: event
        });
      }

      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', {
        checked: checked,
        value: value,
        event: event
      });
    };

    _this._id = props.id || makeUniqueId();
    _this._refButton = react.createRef();
    _this.state = {
      _listenForPropChanges: true
    };

    if (context.name && typeof props.value !== 'undefined') {
      if (typeof context.value !== 'undefined') {
        _this.state.checked = context.value === props.value;
        _this.state._listenForPropChanges = false;
      } else if (context.values && Array.isArray(context.values)) {
        _this.state.checked = context.values.includes(props.value);
        _this.state._listenForPropChanges = false;
      } else if (ToggleButton.parseChecked(props.checked)) {
        if (context.setContext) {
          if (context.multiselect) {
            context.setContext(function (tmp) {
              return {
                values: tmp && Array.isArray(tmp.values) ? [].concat(_toConsumableArray$1(tmp.values), [props.value]) : [props.value]
              };
            });
          } else {
            context.setContext({
              value: props.value
            });
          }
        }
      }
    }

    return _this;
  }

  _createClass(ToggleButton, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      return react.createElement(Context.Consumer, null, function (context) {
        var _componentParams;

        var props = extendPropsWithContext(_this2.props, ToggleButton.defaultProps, _this2.context, context.formRow, context.translation.ToggleButton);

        var status = props.status,
            status_state = props.status_state,
            status_animation = props.status_animation,
            global_status_id = props.global_status_id,
            suffix = props.suffix,
            label = props.label,
            label_direction = props.label_direction,
            label_sr_only = props.label_sr_only,
            text = props.text,
            title = props.title,
            readOnly = props.readOnly,
            className = props.className,
            _className = props.class,
            disabled = props.disabled,
            skeleton = props.skeleton,
            variant = props.variant,
            left_component = props.left_component,
            icon = props.icon,
            icon_size = props.icon_size,
            icon_position = props.icon_position,
            propValue = props.value,
            _id = props.id,
            _checked = props.checked,
            attributes = props.attributes,
            children = props.children,
            on_change = props.on_change,
            on_state_update = props.on_state_update,
            custom_method = props.custom_method,
            custom_element = props.custom_element,
            rest = _objectWithoutProperties(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "text", "title", "readOnly", "className", "class", "disabled", "skeleton", "variant", "left_component", "icon", "icon_size", "icon_position", "value", "id", "checked", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);

        var checked = _this2.state.checked;

        if (!isTrue(_this2.context.multiselect) && typeof _this2.context.value !== 'undefined') {
          var contextValue = _this2.context.value;

          if (typeof propValue === 'string' || typeof propValue === 'number') {
            checked = propValue === contextValue;
          } else if (typeof JSON !== 'undefined') {
            checked = JSON.stringify(propValue) === JSON.stringify(contextValue);
          }
        }

        var id = _this2._id;
        var showStatus = getStatusState(status);
        var mainParams = {
          className: classnames('dnb-toggle-button', createSpacingClasses(props), className, _className, status && "dnb-toggle-button__status--".concat(status_state), checked && "dnb-toggle-button--checked", label_direction && "dnb-toggle-button--".concat(label_direction))
        };
        validateDOMAttributes(_this2.props, rest);

        var buttonParams = _extends(_defineProperty({
          id: id,
          disabled: disabled,
          skeleton: skeleton,
          text: text || children,
          title: title,
          icon: icon,
          icon_size: icon_size,
          icon_position: icon_position
        }, 'aria-pressed', String(checked)), rest);

        var componentParams = (_componentParams = {
          checked: checked,
          disabled: disabled
        }, _defineProperty(_componentParams, 'aria-hidden', true), _defineProperty(_componentParams, "tabIndex", '-1'), _componentParams);

        if (status) {
          if (status_state === 'info') {
            componentParams.status_state = 'info';
          } else {
            componentParams.status = 'error';
          }
        }

        if (showStatus || suffix) {
          buttonParams['aria-describedby'] = combineDescribedBy(buttonParams, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
        }

        if (readOnly) {
          buttonParams['aria-readonly'] = buttonParams.readOnly = true;
        }

        var leftComponent = null;

        switch (variant) {
          case 'radio':
            leftComponent = react.createElement(Radio, _extends({
              id: "".concat(id, "-radio")
            }, componentParams));
            break;

          case 'checkbox':
            leftComponent = react.createElement(Checkbox, _extends({
              id: "".concat(id, "-checkbox")
            }, componentParams));
            break;

          case 'default':
          default:
            leftComponent = left_component;
            break;
        }

        return react.createElement("span", mainParams, label && react.createElement(FormLabel, {
          id: id + '-label',
          for_id: id,
          text: label,
          disabled: disabled,
          skeleton: skeleton,
          label_direction: label_direction,
          sr_only: label_sr_only
        }), react.createElement("span", {
          className: "dnb-toggle-button__inner"
        }, showStatus && react.createElement(FormStatus, {
          id: id + '-form-status',
          global_status_id: global_status_id,
          label: label,
          text_id: id + '-status',
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton: skeleton
        }), react.createElement("span", {
          className: "dnb-toggle-button__shell"
        }, _ref3$3, react.createElement(Button, _extends({
          variant: "secondary",
          className: "dnb-toggle-button__button"
        }, buttonParams, {
          ref: _this2._refButton,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler,
          onKeyUp: _this2.onKeyUpHandler
        }), leftComponent && react.createElement("span", {
          className: "dnb-toggle-button__component"
        }, leftComponent)), suffix && react.createElement("span", {
          className: "dnb-toggle-button__suffix",
          id: id + '-suffix'
        }, react.createElement(Suffix, props, suffix)))));
      });
    }
  }]);

  return ToggleButton;
}(react.PureComponent);

ToggleButton.Group = ToggleButtonGroup;
ToggleButton.tagName = 'dnb-toggle-button';
ToggleButton.contextType = ToggleButtonGroupContext;
ToggleButton.defaultProps = {
  text: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  checked: undefined,
  variant: null,
  left_component: null,
  disabled: null,
  skeleton: null,
  id: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: '',
  icon: null,
  icon_position: 'right',
  icon_size: null,
  attributes: null,
  readOnly: false,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};

ToggleButton.parseChecked = function (state) {
  return /true|on/.test(String(state));
};

function _createSuper$k(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$l(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$l() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Dropdown = function (_React$PureComponent) {
  _inherits(Dropdown, _React$PureComponent);

  var _super = _createSuper$k(Dropdown);

  function Dropdown() {
    _classCallCheck(this, Dropdown);

    return _super.apply(this, arguments);
  }

  _createClass(Dropdown, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          more_menu = _this$props.more_menu,
          action_menu = _this$props.action_menu,
          prevent_selection = _this$props.prevent_selection,
          children = _this$props.children,
          data = _this$props.data;
      return react.createElement(DrawerListProvider, _extends({}, this.props, {
        data: data || children,
        opened: null,
        tagName: "dnb-dropdown",
        ignore_events: false,
        prevent_selection: isTrue(more_menu) || isTrue(action_menu) || isTrue(prevent_selection)
      }), react.createElement(DropdownInstance, this.props));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Dropdown.tagName, Dropdown, Dropdown.defaultProps);
    }
  }]);

  return Dropdown;
}(react.PureComponent);

Dropdown.tagName = 'dnb-dropdown';
Dropdown.defaultProps = {
  id: null,
  title: 'Option Menu',
  icon: null,
  icon_size: null,
  icon_position: null,
  triangle_position: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  status: null,
  status_state: 'error',
  status_animation: null,
  global_status_id: null,
  suffix: null,
  scrollable: true,
  focusable: false,
  max_height: null,
  direction: 'auto',
  skip_portal: null,
  no_animation: false,
  no_scroll_animation: false,
  prevent_selection: false,
  more_menu: false,
  action_menu: false,
  independent_width: false,
  size: 'default',
  align_dropdown: null,
  trigger_component: null,
  data: null,
  default_value: null,
  value: 'initval',
  open_on_focus: false,
  prevent_close: false,
  keep_open: false,
  opened: false,
  disabled: null,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_show: null,
  on_hide: null,
  on_change: null,
  on_select: null,
  on_state_update: null
};

var _ref$L = react.createElement(AlignmentHelper, null);

var DropdownInstance = function (_React$PureComponent2) {
  _inherits(DropdownInstance, _React$PureComponent2);

  var _super2 = _createSuper$k(DropdownInstance);

  function DropdownInstance(props) {
    var _this;

    _classCallCheck(this, DropdownInstance);

    _this = _super2.call(this, props);

    _this.setVisible = function () {
      _this.context.drawerList.setWrapperElement(_this._refShell.current).setVisible();
    };

    _this.setHidden = function () {
      var _this$context$drawerL;

      (_this$context$drawerL = _this.context.drawerList).setHidden.apply(_this$context$drawerL, arguments);
    };

    _this.onFocusHandler = function () {
      if (isTrue(_this.props.open_on_focus)) {
        _this.setVisible();
      }
    };

    _this.onBlurHandler = function () {
      if (isTrue(_this.props.open_on_focus)) {
        _this.setHidden();
      }
    };

    _this.toggleVisible = function () {
      if (!_this.context.drawerList.hidden && _this.context.drawerList.opened) {
        _this.setHidden();
      } else {
        _this.setVisible();
      }
    };

    _this.onMouseDownHandler = function () {
      if (!_this.context.drawerList.hidden && _this.context.drawerList.opened) {
        _this.setHidden();
      } else {
        _this.setVisible();
      }
    };

    _this.onTriggerKeyDownHandler = function (e) {
      switch (keycode(e)) {
        case 'enter':
        case 'space':
        case 'up':
        case 'down':
          e.preventDefault();

          _this.setVisible();

          break;

        case 'esc':
          _this.setHidden();

          break;

        case 'home':
        case 'end':
        case 'page down':
        case 'page up':
          e.preventDefault();
          break;
      }
    };

    _this.onHideHandler = function () {
      var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var attributes = _this.attributes || {};
      var res = dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_hide', _extends({}, args, {
        attributes: attributes
      }));

      if (res !== false) {
        clearTimeout(_this._focusTimeout);
        _this._focusTimeout = setTimeout(function () {
          try {
            var element = _this._refButton.current._ref.current;

            if (element && typeof element.focus === 'function') {
              element.focus({
                preventScroll: true
              });
              dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_hide_focus', {
                element: element
              });
            }
          } catch (e) {}
        }, 1);
      }

      return res;
    };

    _this.onSelectHandler = function (args) {
      if (parseFloat(args.active_item) > -1) {
        var attributes = _this.attributes || {};
        dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_select', _extends({}, args, {
          attributes: attributes
        }));
      }
    };

    _this.onChangeHandler = function (args) {
      var attributes = _this.attributes || {};
      dispatchCustomElementEvent(_assertThisInitialized(_this), 'on_change', _extends({}, args, {
        attributes: attributes
      }));
    };

    _this._id = props.id || makeUniqueId();
    _this.attributes = {};
    _this.state = _this.state || {};
    _this._ref = react.createRef();
    _this._refShell = react.createRef();
    _this._refButton = react.createRef();
    var dep = 'selected_item';

    if (typeof props[dep] !== 'undefined') {
      warn("Dropdown: Please use \"value\" instead of \"".concat(dep, "\"."));
    }

    return _this;
  }

  _createClass(DropdownInstance, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (isTrue(this.props.opened)) {
        this.setVisible();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.setHidden();
      clearTimeout(this._hideTimeout);
      clearTimeout(this._focusTimeout);
    }
  }, {
    key: "getTitle",
    value: function getTitle() {
      var title = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var data = this.context.drawerList.data;

      if (data && data.length > 0) {
        var currentOptionData = getCurrentData(this.context.drawerList.selected_item, data);

        if (currentOptionData) {
          title = currentOptionData.selected_value || parseContentTitle(currentOptionData);
        }
      }

      return title;
    }
  }, {
    key: "render",
    value: function render() {
      var _this$context;

      var props = extendPropsWithContext(this.props, Dropdown.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.formRow, this.context.getTranslation(this.props).Dropdown);

      var label = props.label,
          label_direction = props.label_direction,
          label_sr_only = props.label_sr_only,
          icon_size = props.icon_size,
          size = props.size,
          fixed_position = props.fixed_position,
          use_drawer_on_mobile = props.use_drawer_on_mobile,
          enable_body_lock = props.enable_body_lock,
          status = props.status,
          status_state = props.status_state,
          status_animation = props.status_animation,
          global_status_id = props.global_status_id,
          suffix = props.suffix,
          scrollable = props.scrollable,
          focusable = props.focusable,
          keep_open = props.keep_open,
          prevent_close = props.prevent_close,
          no_animation = props.no_animation,
          no_scroll_animation = props.no_scroll_animation,
          triangle_position = props.triangle_position,
          skip_portal = props.skip_portal,
          CustomTrigger = props.trigger_component,
          more_menu = props.more_menu,
          action_menu = props.action_menu,
          independent_width = props.independent_width,
          prevent_selection = props.prevent_selection,
          max_height = props.max_height,
          default_value = props.default_value,
          className = props.className,
          _className = props.class,
          disabled = props.disabled,
          skeleton = props.skeleton,
          _title = props.title,
          _icon = props.icon,
          _align_dropdown = props.align_dropdown,
          _icon_position = props.icon_position,
          _data = props.data,
          _children = props.children,
          _direction = props.direction,
          _id = props.id,
          _opened = props.opened,
          _value = props.value,
          attributes = _objectWithoutProperties(props, ["label", "label_direction", "label_sr_only", "icon_size", "size", "fixed_position", "use_drawer_on_mobile", "enable_body_lock", "status", "status_state", "status_animation", "global_status_id", "suffix", "scrollable", "focusable", "keep_open", "prevent_close", "no_animation", "no_scroll_animation", "triangle_position", "skip_portal", "trigger_component", "more_menu", "action_menu", "independent_width", "prevent_selection", "max_height", "default_value", "className", "class", "disabled", "skeleton", "title", "icon", "align_dropdown", "icon_position", "data", "children", "direction", "id", "opened", "value"]);

      var icon = props.icon,
          icon_position = props.icon_position,
          align_dropdown = props.align_dropdown;
      var id = this._id;
      var handleAsMenu = isTrue(action_menu) || isTrue(more_menu) || isTrue(prevent_selection);
      var isPopupMenu = isTrue(more_menu) || !(_title && _title.length > 0);

      if (isPopupMenu) {
        icon = icon || (isTrue(more_menu) ? 'more' : 'chevron_down');
      }

      if (isPopupMenu || isTrue(action_menu)) {
        if (icon_position !== 'right' && align_dropdown !== 'right') {
          icon_position = 'left';
          align_dropdown = 'left';
        }
      }

      var _this$context$drawerL2 = this.context.drawerList,
          selected_item = _this$context$drawerL2.selected_item,
          direction = _this$context$drawerL2.direction,
          opened = _this$context$drawerL2.opened;
      var showStatus = getStatusState(status);
      var title = this.getTitle(_title);

      _extends(this.context.drawerList.attributes, validateDOMAttributes(null, attributes));

      var mainParams = {
        className: classnames("dnb-dropdown dnb-dropdown--".concat(direction, " dnb-dropdown--icon-position-").concat(icon_position || 'right', " dnb-dropdown--").concat(align_dropdown || 'right', " dnb-form-component"), (isTrue(independent_width) || isTrue(action_menu)) && 'dnb-dropdown--independent-width', createSpacingClasses(props), _className, className, opened && 'dnb-dropdown--opened', label_direction && "dnb-dropdown--".concat(label_direction), isPopupMenu && 'dnb-dropdown--is-popup', isTrue(action_menu) && "dnb-dropdown--action-menu", size && "dnb-dropdown--".concat(size), status && "dnb-dropdown__status--".concat(status_state), showStatus && 'dnb-dropdown__form-status')
      };

      var triggerParams = _extends({
        className: 'dnb-dropdown__trigger' + (opened ? " dnb-button--active" : ""),
        id: id,
        disabled: disabled,
        'aria-haspopup': handleAsMenu ? true : 'listbox',
        'aria-expanded': opened
      }, attributes, {
        onFocus: this.onFocusHandler,
        onBlur: this.onBlurHandler,
        onMouseDown: this.onMouseDownHandler,
        onKeyDown: this.onTriggerKeyDownHandler
      });

      if (opened) {
        triggerParams['aria-controls'] = "".concat(id, "-drawer-list");
      }

      if (showStatus || suffix) {
        triggerParams['aria-describedby'] = combineDescribedBy(triggerParams, showStatus ? id + '-status' : null, suffix ? id + '-suffix' : null);
      }

      if (label) {
        triggerParams['aria-labelledby'] = [triggerParams['aria-labelledby'], id + '-label', id].filter(Boolean).join(' ');
      }

      validateDOMAttributes(null, mainParams);
      validateDOMAttributes(this.props, triggerParams);
      this.attributes = validateDOMAttributes(null, attributes);
      return react.createElement("span", mainParams, label && react.createElement(FormLabel, {
        id: id + '-label',
        for_id: id,
        text: label,
        label_direction: label_direction,
        sr_only: label_sr_only,
        disabled: disabled,
        skeleton: skeleton,
        onMouseDown: this.toggleVisible
      }), react.createElement("span", {
        className: "dnb-dropdown__inner",
        ref: this._ref
      }, _ref$L, showStatus && react.createElement(FormStatus, {
        id: id + '-form-status',
        global_status_id: global_status_id,
        label: label,
        text_id: id + '-status',
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton: skeleton
      }), react.createElement("span", {
        className: "dnb-dropdown__row"
      }, react.createElement("span", {
        className: "dnb-dropdown__shell",
        ref: this._refShell
      }, CustomTrigger ? react.createElement(CustomTrigger, triggerParams) : react.createElement(Button, _extends({
        variant: "secondary",
        icon: false,
        size: size === 'default' ? 'medium' : size,
        ref: this._refButton
      }, triggerParams), !isPopupMenu && react.createElement("span", {
        className: "dnb-dropdown__text dnb-button__text"
      }, react.createElement("span", {
        className: "dnb-dropdown__text__inner"
      }, title)), react.createElement("span", {
        "aria-hidden": true,
        className: 'dnb-dropdown__icon' + (parseFloat(selected_item) === 0 ? " dnb-dropdown__icon--first" : "")
      }, icon !== false && react.createElement(IconPrimary, {
        icon: icon || 'chevron_down',
        size: icon_size || (size === 'large' ? 'medium' : 'default')
      }))), react.createElement(DrawerList, {
        id: id,
        role: handleAsMenu ? 'menu' : 'listbox',
        inner_class: "dnb-dropdown__list",
        value: selected_item,
        default_value: default_value,
        scrollable: scrollable,
        focusable: focusable,
        no_animation: no_animation,
        no_scroll_animation: no_scroll_animation,
        skip_portal: skip_portal,
        prevent_selection: handleAsMenu,
        action_menu: action_menu,
        triangle_position: triangle_position || icon_position || 'right',
        keep_open: keep_open,
        prevent_close: prevent_close,
        independent_width: isTrue(independent_width) || isPopupMenu || action_menu,
        is_popup: isPopupMenu || action_menu,
        align_drawer: align_dropdown || 'right',
        fixed_position: fixed_position,
        use_drawer_on_mobile: use_drawer_on_mobile || action_menu,
        enable_body_lock: enable_body_lock,
        disabled: disabled,
        max_height: max_height,
        direction: direction,
        size: size,
        on_change: this.onChangeHandler,
        on_select: this.onSelectHandler,
        on_hide: this.onHideHandler
      })), suffix && react.createElement("span", {
        className: "dnb-dropdown__suffix",
        id: id + '-suffix'
      }, react.createElement(Suffix, props, suffix)))));
    }
  }]);

  return DropdownInstance;
}(react.PureComponent);

DropdownInstance.defaultProps = Dropdown.defaultProps;
DropdownInstance.contextType = DrawerListContext;
Dropdown.HorizontalItem = DrawerList.HorizontalItem;

function _createSuper$l(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$m(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$m() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Elem = function (_React$PureComponent) {
  _inherits(Elem, _React$PureComponent);

  var _super = _createSuper$l(Elem);

  function Elem(props) {
    _classCallCheck(this, Elem);

    return _super.call(this, props);
  }

  _createClass(Elem, [{
    key: "render",
    value: function render() {
      var _this$context, _this$context2;

      var props = this.props.skeleton !== false && typeof ((_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton) !== 'undefined' ? extendPropsWithContext(this.props, Elem.defaultProps, {
        skeleton: (_this$context2 = this.context) === null || _this$context2 === void 0 ? void 0 : _this$context2.skeleton
      }) : this.props;

      var className = props.className,
          _className = props.class,
          internalClass = props.internalClass,
          css = props.css,
          Tag = props.is,
          _ref = props._ref,
          skeleton = props.skeleton,
          skeleton_method = props.skeleton_method,
          rest = _objectWithoutProperties(props, ["className", "class", "internalClass", "css", "is", "_ref", "skeleton", "skeleton_method"]);

      var tagClass = internalClass || "dnb-".concat(Tag);
      rest.className = classnames(className, _className, css, createSkeletonClass(skeleton_method, skeleton, this.context), createSpacingClasses(rest, Tag), !new RegExp("".concat(tagClass, "(\\s|$)")).test(String(className)) && tagClass);
      validateDOMAttributes(null, rest);
      skeletonDOMAttributes(rest, skeleton, this.context);
      return react.createElement(Tag, _extends({
        ref: _ref
      }, rest));
    }
  }]);

  return Elem;
}(react.PureComponent);

Elem.contextType = Context;
Elem.defaultProps = {
  skeleton: null,
  skeleton_method: 'font',
  className: null,
  class: null,
  internalClass: null,
  css: null,
  _ref: null
};
var Element$2 = react.forwardRef(function (props, ref) {
  return react.createElement(Elem, _extends({
    _ref: ref
  }, props));
});
Element$2.defaultProps = Elem.defaultProps;

// B.2.3.5 String.prototype.bold()
_stringHtml('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});

// B.2.3.11 String.prototype.small()
_stringHtml('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});

var P$1 = function P(_ref) {
  var style_type = _ref.style_type,
      modifier = _ref.modifier,
      element = _ref.element,
      className = _ref.className,
      small = _ref.small,
      medium = _ref.medium,
      bold = _ref.bold,
      size = _ref.size,
      props = _objectWithoutProperties(_ref, ["style_type", "modifier", "element", "className", "small", "medium", "bold", "size"]);

  if (typeof modifier === 'string' && / /.test(modifier)) {
    modifier = modifier.split(/ /g);
  } else if (!Array.isArray(modifier)) {
    modifier = [modifier];
  }

  if (style_type) {
    modifier.push(style_type);
  }

  if (medium === true) {
    modifier.push('medium');
  } else if (bold === true) {
    modifier.push('bold');
  }

  modifier = modifier.filter(Boolean).reduce(function (acc, cur) {
    if (['x-small', 'small'].includes(cur)) {
      return "".concat(acc, " dnb-p__size--").concat(cur);
    }

    return "".concat(acc, " dnb-p--").concat(cur);
  }, '');

  if (size) {
    className = classnames(className, "dnb-p__size--".concat(size));
  } else if (small === true) {
    className = classnames(className, 'dnb-p__size--small');
  }

  return react.createElement(Element$2, _extends({
    is: element
  }, props, {
    className: classnames('dnb-p', modifier, className)
  }));
};

P$1.tagName = 'dnb-p';
P$1.defaultProps = {
  element: 'p',
  className: null,
  small: null,
  medium: null,
  bold: null,
  size: null,
  style_type: null,
  modifier: null
};

function _createSuper$m(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$n(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$n() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Space = function (_React$PureComponent) {
  _inherits(Space, _React$PureComponent);

  var _super = _createSuper$m(Space);

  function Space() {
    _classCallCheck(this, Space);

    return _super.apply(this, arguments);
  }

  _createClass(Space, [{
    key: "render",
    value: function render() {
      var _this$context;

      var props = this.context.space ? extendPropsWithContext(this.props, Space.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.space) : this.props;

      var element = props.element,
          inline = props.inline,
          no_collapse = props.no_collapse,
          top = props.top,
          right = props.right,
          bottom = props.bottom,
          left = props.left,
          skeleton = props.skeleton,
          _id = props.id,
          className = props.className,
          _className = props.class,
          attributes = _objectWithoutProperties(props, ["element", "inline", "no_collapse", "top", "right", "bottom", "left", "skeleton", "id", "className", "class"]);

      var children = Space.getContent(this.props);

      var params = _extends({
        className: classnames('dnb-space', createSkeletonClass(null, skeleton), createSpacingClasses({
          top: top,
          right: right,
          bottom: bottom,
          left: left
        }), className, _className, isTrue(inline) && 'dnb-space--inline')
      }, attributes);

      skeletonDOMAttributes(params, skeleton);
      validateDOMAttributes(this.props, params);
      return react.createElement(Element$3, _extends({
        element: element,
        no_collapse: no_collapse
      }, params), children);
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      registerElement(Space.tagName, Space, Space.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return processChildren(props);
    }
  }]);

  return Space;
}(react.PureComponent);

Space.tagName = 'dnb-space';
Space.contextType = Context;
Space.defaultProps = _extends({
  id: null,
  element: 'div',
  inline: null,
  no_collapse: null
}, spacingDefaultProps, {
  skeleton: null,
  class: null,
  className: null,
  children: null
});

var Element$3 = function Element(_ref) {
  var E = _ref.element,
      no_collapse = _ref.no_collapse,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, ["element", "no_collapse", "children"]);

  if (isTrue(no_collapse)) {
    var R = E === 'span' || isInline(Element) ? 'span' : 'div';
    return react.createElement(R, {
      className: 'dnb-space--no-collapse' + (isInline(Element) ? " dnb-space--inline" : "")
    }, react.createElement(E, props, children));
  }

  return react.createElement(E, props, children);
};
Element$3.defaultProps = {
  children: null,
  element: 'div',
  no_collapse: true
};

function _createSuper$n(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$o(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct$o() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var Provider = function (_React$PureComponent) {
  _inherits(Provider, _React$PureComponent);

  var _super = _createSuper$n(Provider);

  _createClass(Provider, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        var children = props.children,
            updatedProps = _objectWithoutProperties(props, ["children"]);

        var newContext = state;

        if (state._startupProps !== updatedProps) {
          var hasChanges = false;

          for (var i in updatedProps) {
            if (state._startupProps[i] !== updatedProps[i] || typeof updatedProps[i] === 'boolean') {
              hasChanges = true;
              break;
            }
          }

          if (hasChanges) {
            newContext = _extends(state, updatedProps);
            state._startupProps = updatedProps;
          }
        }

        if (newContext.formRow) {
          newContext.formRow = prepareFormRowContext(newContext.formRow);
        }

        state = newContext;
      }

      state._listenForPropChanges = true;
      return prepareContext(state);
    }
  }]);

  function Provider(props, context) {
    var _this;

    _classCallCheck(this, Provider);

    _this = _super.call(this, props);

    var children = props.children,
        startupProps = _objectWithoutProperties(props, ["children"]);

    var newContext = _extends({}, context, startupProps);

    var isRoot = !(newContext && newContext.__providerId);
    newContext.__providerId = makeUniqueId();
    var pC = isRoot ? prepareContext(newContext) : newContext;

    pC.updateCurrent = function (props) {
      return _this.setNewContext(props);
    };

    pC.setCurrentLocale = function (locale) {
      return _this.setNewContext({
        locale: locale
      });
    };

    pC.update = function (props) {
      if (typeof context.update === 'function') {
        context.update(props);
      }

      _this.setNewContext(props);
    };

    pC.setLocale = function (locale) {
      if (typeof context.update === 'function') {
        context.update({
          locale: locale
        });
      }

      _this.setNewContext({
        locale: locale
      });
    };

    _this.state = pC;
    _this.state.isRoot = isRoot;
    _this.state._listenForPropChanges = true;
    _this.state._startupProps = startupProps;
    return _this;
  }

  _createClass(Provider, [{
    key: "setNewContext",
    value: function setNewContext(__newContext) {
      this.setState({
        _listenForPropChanges: false
      });
      this.setState({
        __newContext: __newContext
      });
    }
  }, {
    key: "render",
    value: function render() {
      var children = this.props.children;
      var context = !this.state.isRoot ? _extends({}, this.context, this.state) : this.state;
      this.context.updateTranslation(context.locale, context.translation);
      return react.createElement(Context.Provider, {
        value: context
      }, children);
    }
  }]);

  return Provider;
}(react.PureComponent);

Provider.contextType = Context;

function _defineProperty$1(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty$1(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

var properties = {
  '--font-family-default': "'DNB', sans-serif",
  '--font-family-monospace': "'DNBMono', 'Menlo', 'Consolas', 'Roboto Mono',",
  '--font-family-book': "'DNB', sans-serif",
  '--font-family-demi': "'DNB', sans-serif",
  '--font-weight-basis': 'normal',
  '--font-weight-regular': 'normal',
  '--font-weight-medium': '500',
  '--font-weight-bold': '600',
  '--font-weight-default': 'normal',
  '--font-weight-book': 'normal',
  '--font-weight-demi': '500',
  '--font-size-x-small': '0.875rem',
  '--font-size-small': '1rem',
  '--font-size-basis': '1.125rem',
  '--font-size-basis--em': '1em',
  '--font-size-medium': '1.25rem',
  '--font-size-large': '1.625rem',
  '--font-size-x-large': '2.125rem',
  '--font-size-xx-large': '3rem',
  '--line-height-xx-small--em': '1em',
  '--line-height-x-small': '1.125rem',
  '--line-height-small': '1.25rem',
  '--line-height-basis': '1.5rem',
  '--line-height-basis--em': '1.333em',
  '--line-height-medium': '2rem',
  '--line-height-large': '2.5rem',
  '--line-height-x-large': '3.5rem',
  '--color-mint-green-50': '#d2f0e9',
  '--color-mint-green-25': '#e9f8f4',
  '--color-mint-green-12': '#f4fbf9',
  '--color-sea-green-30': '#b3dada',
  '--color-sea-green-alt-30': '#b3dada',
  '--color-signal-yellow-30': '#ffffd7',
  '--color-accent-yellow-30': '#feebc1',
  '--color-signal-orange': '#ff5400',
  '--color-fire-red': '#dc2a2a',
  '--color-success-green': '#008000',
  '--color-fire-red-8': '#fdeeee',
  '--color-black': '#000',
  '--color-black-80': '#333',
  '--color-black-55': '#737373',
  '--color-black-30': '#b3b3b3',
  '--color-black-20': '#ccc',
  '--color-black-8': '#ebebeb',
  '--color-black-3': '#f8f8f8',
  '--color-white': '#fff',
  '--color-black-border': '#cdcdcd',
  '--color-black-background': '#fafafa',
  '--color-sea-green': '#007272',
  '--color-sea-green-alt': '#007272',
  '--color-mint-green': '#a5e1d2',
  '--color-summer-green': '#28b482',
  '--color-emerald-green': '#14555a',
  '--color-ocean-green': '#00343e',
  '--color-signal-yellow': '#ffff7a',
  '--color-accent-yellow': '#fdbb31',
  '--color-indigo': '#23195a',
  '--color-violet': '#6e2382',
  '--color-sky-blue': '#4bbed2',
  '--color-lavender': '#f2f2f5',
  '--color-sand-yellow': '#fbf6ec',
  '--color-pistachio': '#f2f4ec',
  '--color-mint-green-alt': '#ebfffa',
  '--color-indigo-medium': '#6e6491',
  '--color-indigo-light': '#b9afc8',
  '--color-violet-medium': '#a06eaf',
  '--color-violet-light': '#cfb9d7',
  '--color-sky-blue-medium': '#87d2e1',
  '--color-sky-blue-light': '#c3ebf0',
  '--spacing-xx-small': '0.25rem',
  '--spacing-x-small': '0.5rem',
  '--spacing-small': '1rem',
  '--spacing-medium': '1.5rem',
  '--spacing-large': '2rem',
  '--spacing-x-large': '3rem',
  '--spacing-xx-large': '3.5rem',
  '--layout-small': '40em',
  '--layout-medium': '50em',
  '--layout-large': '60em',
  '--layout-x-large': '72em',
  '--layout-xx-large': '80em',
  '--layout-xxx-large': '90em'
};

var originalColorsAsObject = getOriginalColorsAsObject();
var originalColorsAsArray = getOriginalColorsAsArray();
function getOriginalColorsAsArray() {
  var colors = Object.entries(originalColorsAsObject).map(function (_ref4) {
    var _ref5 = _slicedToArray(_ref4, 2),
        key = _ref5[0],
        value = _ref5[1];

    var name = key.replace(/--color-/g, ' ').replace(/-/g, ' ').trim().replace(/(^|\s)([a-z])/g, function (s) {
      return s.toUpperCase();
    });
    return {
      key: key,
      name: name,
      value: value
    };
  });
  return colors;
}
function getOriginalColorsAsObject() {
  var colors = Object.entries(properties).filter(function (_ref6) {
    var _ref7 = _slicedToArray(_ref6, 1),
        name = _ref7[0];

    return name.includes('--color-');
  }).reduce(function (acc, _ref8) {
    var _ref9 = _slicedToArray(_ref8, 2),
        key = _ref9[0],
        value = _ref9[1];

    acc[key] = value;
    if (key.includes('-border')) delete acc[key];
    if (key.includes('-background')) delete acc[key];
    if (key.includes('-light')) delete acc[key];
    if (key.includes('-medium')) delete acc[key];
    return acc;
  }, {});
  delete colors['--color-sea-green-alt-30'];
  delete colors['--color-signal-yellow-30'];
  delete colors['--color-black-30'];
  delete colors['--color-sea-green-alt'];
  delete colors['--color-signal-yellow'];
  return colors;
}
var generateThemeIgnoreColors = function generateThemeIgnoreColors() {
  return originalColorsAsArray.map(function (_ref10) {
    var key = _ref10.key,
        value = _ref10.value;
    return "".concat(key, ": ").concat(value, ";");
  }).join('\n');
};

function create(createState) {
  let state;
  const listeners = new Set();

  const setState = (partial, replace) => {
    const nextState = typeof partial === 'function' ? partial(state) : partial;

    if (nextState !== state) {
      const previousState = state;
      state = replace ? nextState : Object.assign({}, state, nextState);
      listeners.forEach(listener => listener(state, previousState));
    }
  };

  const getState = () => state;

  const subscribeWithSelector = (listener, selector = getState, equalityFn = Object.is) => {
    let currentSlice = selector(state);

    function listenerToAdd() {
      const nextSlice = selector(state);

      if (!equalityFn(currentSlice, nextSlice)) {
        const previousSlice = currentSlice;
        listener(currentSlice = nextSlice, previousSlice);
      }
    }

    listeners.add(listenerToAdd); // Unsubscribe

    return () => listeners.delete(listenerToAdd);
  };

  const subscribe = (listener, selector, equalityFn) => {
    if (selector || equalityFn) {
      return subscribeWithSelector(listener, selector, equalityFn);
    }

    listeners.add(listener); // Unsubscribe

    return () => listeners.delete(listener);
  };

  const destroy = () => listeners.clear();

  const api = {
    setState,
    getState,
    subscribe,
    destroy
  };
  state = createState(setState, getState, api);
  return api;
}

const useIsoLayoutEffect = typeof window === 'undefined' ? react.useEffect : react.useLayoutEffect;
function create$1(createState) {
  const api = typeof createState === 'function' ? create(createState) : createState;

  const useStore = (selector = api.getState, equalityFn = Object.is) => {
    const [, forceUpdate] = react.useReducer(c => c + 1, 0);
    const state = api.getState();
    const stateRef = react.useRef(state);
    const selectorRef = react.useRef(selector);
    const equalityFnRef = react.useRef(equalityFn);
    const erroredRef = react.useRef(false);
    const currentSliceRef = react.useRef();

    if (currentSliceRef.current === undefined) {
      currentSliceRef.current = selector(state);
    }

    let newStateSlice;
    let hasNewStateSlice = false; // The selector or equalityFn need to be called during the render phase if
    // they change. We also want legitimate errors to be visible so we re-run
    // them if they errored in the subscriber.

    if (stateRef.current !== state || selectorRef.current !== selector || equalityFnRef.current !== equalityFn || erroredRef.current) {
      // Using local variables to avoid mutations in the render phase.
      newStateSlice = selector(state);
      hasNewStateSlice = !equalityFn(currentSliceRef.current, newStateSlice);
    } // Syncing changes in useEffect.


    useIsoLayoutEffect(() => {
      if (hasNewStateSlice) {
        currentSliceRef.current = newStateSlice;
      }

      stateRef.current = state;
      selectorRef.current = selector;
      equalityFnRef.current = equalityFn;
      erroredRef.current = false;
    });
    const stateBeforeSubscriptionRef = react.useRef(state);
    useIsoLayoutEffect(() => {
      const listener = () => {
        try {
          const nextState = api.getState();
          const nextStateSlice = selectorRef.current(nextState);

          if (!equalityFnRef.current(currentSliceRef.current, nextStateSlice)) {
            stateRef.current = nextState;
            currentSliceRef.current = nextStateSlice;
            forceUpdate();
          }
        } catch (error) {
          erroredRef.current = true;
          forceUpdate();
        }
      };

      const unsubscribe = api.subscribe(listener);

      if (api.getState() !== stateBeforeSubscriptionRef.current) {
        listener(); // state has changed before subscription
      }

      return unsubscribe;
    }, []);
    return hasNewStateSlice ? newStateSlice : currentSliceRef.current;
  };

  Object.assign(useStore, api); // For backward compatibility (No TS types for this)

  useStore[Symbol.iterator] = function* () {
    console.warn('[useStore, api] = create() is deprecated and will be removed in v4');
    yield useStore;
    yield api;
  };

  return useStore;
}

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

var asyncToGenerator = _asyncToGenerator;

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var _regeneratorRuntime__default = /*#__PURE__*/_interopDefaultLegacy(regenerator);
var _asyncToGenerator__default = /*#__PURE__*/_interopDefaultLegacy(asyncToGenerator);
var _extends__default = /*#__PURE__*/_interopDefaultLegacy(_extends_1);
var persist = function persist(config, options) {
  return function (set, get, api) {
    var _ref = options || {},
        name = _ref.name,
        _ref$getStorage = _ref.getStorage,
        getStorage = _ref$getStorage === void 0 ? function () {
      return localStorage;
    } : _ref$getStorage,
        _ref$serialize = _ref.serialize,
        serialize = _ref$serialize === void 0 ? JSON.stringify : _ref$serialize,
        _ref$deserialize = _ref.deserialize,
        deserialize = _ref$deserialize === void 0 ? JSON.parse : _ref$deserialize,
        blacklist = _ref.blacklist,
        whitelist = _ref.whitelist,
        onRehydrateStorage = _ref.onRehydrateStorage,
        _ref$version = _ref.version,
        version = _ref$version === void 0 ? 0 : _ref$version;

    var storage;

    try {
      storage = getStorage();
    } catch (e) {// prevent error if the storage is not defined (e.g. when server side rendering a page)
    }

    if (!storage) return config(set, get, api);

    var setItem = /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator__default['default']( /*#__PURE__*/_regeneratorRuntime__default['default'].mark(function _callee() {
        var _storage;

        var state;
        return _regeneratorRuntime__default['default'].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                state = _extends__default['default']({}, get());

                if (whitelist) {
                  Object.keys(state).forEach(function (key) {
                    !whitelist.includes(key) && delete state[key];
                  });
                }

                if (blacklist) {
                  blacklist.forEach(function (key) {
                    return delete state[key];
                  });
                }

                if (!((_storage = storage) == null)) {
                  _context.next = 7;
                  break;
                }
                _context.next = 13;
                break;

              case 7:
                _context.t0 = _storage;
                _context.t1 = name;
                _context.next = 11;
                return serialize({
                  state: state,
                  version: version
                });

              case 11:
                _context.t2 = _context.sent;

                _context.t0.setItem.call(_context.t0, _context.t1, _context.t2);

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function setItem() {
        return _ref2.apply(this, arguments);
      };
    }();

    var savedSetState = api.setState;

    api.setState = function (state, replace) {
      savedSetState(state, replace);
      setItem();
    };

    _asyncToGenerator__default['default']( /*#__PURE__*/_regeneratorRuntime__default['default'].mark(function _callee2() {
      var postRehydrationCallback, storageValue, deserializedStorageValue;
      return _regeneratorRuntime__default['default'].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              postRehydrationCallback = (onRehydrateStorage == null ? void 0 : onRehydrateStorage(get())) || undefined;
              _context2.prev = 1;
              _context2.next = 4;
              return storage.getItem(name);

            case 4:
              storageValue = _context2.sent;

              if (!storageValue) {
                _context2.next = 10;
                break;
              }

              _context2.next = 8;
              return deserialize(storageValue);

            case 8:
              deserializedStorageValue = _context2.sent;

              // if versions mismatch, clear storage by storing the new initial state
              if (deserializedStorageValue.version !== version) {
                setItem();
              } else {
                set(deserializedStorageValue.state);
              }

            case 10:
              _context2.next = 15;
              break;

            case 12:
              _context2.prev = 12;
              _context2.t0 = _context2["catch"](1);
              throw new Error("Unable to get to stored state in \"" + name + "\"");

            case 15:
              _context2.prev = 15;
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(get());
              return _context2.finish(15);

            case 18:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 12, 15, 18]]);
    }))();

    return config(function (payload) {
      set(payload);
      setItem();
    }, get, api);
  };
};
var persist_1 = persist;

function _objectWithoutPropertiesLoose$1(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function _objectWithoutProperties$1(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose$1(source, excluded);
  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

function _classCallCheck$1(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties$1(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass$1(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties$1(Constructor, staticProps);
  return Constructor;
}

var useBrowser = undefined;
// String(window.location.host).includes('localhost')

{
  {
    useBrowser = window.chrome;
  }
}

var browser$1 = useBrowser;

var extensionStorePlain = create$1(themesStore);
var useThemeStore = create$1(persist_1(themesStore, getPersistConfig('eufemia-theme-data')));
var useAppStore = create$1(persist_1(hostStore, getPersistConfig('eufemia-theme-app')));
var useWindowStore = create$1(persist_1(hostStore, getPersistConfig('eufemia-theme-window')));
var useErrorStore = create$1(errorStore);

function themesStore(set, get) {
  return {
    themes: {},
    getThemes: function getThemes() {
      var _get = get(),
          getThemeConstructs = _get.getThemeConstructs,
          themes = _get.themes;

      if (!themes['dnb-ui']) {
        themes['dnb-ui'] = getThemeConstructs();
        themes['demo'] = getThemeConstructs();
      }

      if (!themes['blue-test']) {
        themes['blue-test'] = getThemeConstructs();
      }

      if (!themes['2x-test']) {
        themes['2x-test'] = getThemeConstructs();
      }

      return themes;
    },
    importThemes: function importThemes(themesData) {
      var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          overwrite = _ref.overwrite;

      try {
        if (themesData) {
          var existingThemes = get().themes;
          var themes = Object.entries(themesData).reduce(function (acc, _ref2) {
            var _ref3 = _slicedToArray(_ref2, 2),
                key = _ref3[0],
                theme = _ref3[1];

            if (!['dnb-ui', 'blue-test', '2x-test'].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }

            return acc;
          }, _objectSpread2({}, existingThemes));
          set({
            themes: themes
          });
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: function createEmptyTheme(themeId) {
      var _get2 = get(),
          themes = _get2.themes,
          getThemeConstructs = _get2.getThemeConstructs;

      if (!themes[themeId]) {
        themes[themeId] = _objectSpread2({}, getThemeConstructs());
        set({
          themes: themes
        });
      }
    },
    copySelectedTheme: function copySelectedTheme(themeId) {
      var _get3 = get(),
          themes = _get3.themes,
          selectedThemeId = _get3.selectedThemeId;

      if (!themes[themeId]) {
        themes[themeId] = _objectSpread2({}, themes[selectedThemeId]);
        set({
          themes: themes
        });
      }
    },
    removeTheme: function removeTheme(themeId) {
      var themes = get().themes;

      if (themes[themeId]) {
        delete themes[themeId];
        set({
          themes: themes
        });
      }
    },
    getThemeConstructs: function getThemeConstructs() {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: function getTheme() {
      var themeId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (!themeId) {
        themeId = get().selectedThemeId;
      }

      var setState = function setState(object) {
        var themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object); // themes[themeId] = { ...(themes[themeId] || {}), ...object }

        var state = {
          themes: themes
        };
        state.selectedThemeId = themeId;
        set(state);
      };

      var getState = function getState() {
        var theme = get().themes[themeId] || null; // || get().getThemeConstructs()

        return theme;
      };

      var getThemeChanges = function getThemeChanges() {
        switch (themeId) {
          case 'dnb-ui':
            {
              return _toConsumableArray(originalColorsAsArray.map(function (_ref4) {
                var key = _ref4.key,
                    value = _ref4.value;
                return {
                  key: key,
                  change: value
                };
              }));
            }

          case 'blue-test':
            {
              return _toConsumableArray(originalColorsAsArray.map(function (_ref5) {
                var key = _ref5.key;
                return {
                  key: key,
                  change: 'blue'
                };
              }));
            }

          case '2x-test':
            {
              return [{
                css: 'html{font-size: 200%;}'
              }];
            }

          default:
            {
              var theme = getState();
              return [].concat(_toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.colorsList) || []), _toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.spacingsList) || []), _toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.fontsizesList) || []));
            }
        }
      }; // Color utils


      var changeColor = function changeColor(origKey, object) {
        var theme = getState();
        var found = false;
        object.key = origKey;
        var colorsList = ((theme === null || theme === void 0 ? void 0 : theme.colorsList) || []).map(function (item) {
          if (item.key === origKey) {
            item = _objectSpread2(_objectSpread2({}, item), object);
            found = Boolean(item);
          }

          return item;
        });

        if (!found) {
          colorsList.push(object);
        }

        setState({
          colorsList: colorsList
        });
      };

      var setColor = function setColor(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeColor(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetColor = function resetColor(rmKey) {
        changeColor(rmKey, {
          change: null,
          useCustomColor: null
        });
      };

      var useColorTools = function useColorTools() {
        return {
          changeColor: changeColor,
          setColor: setColor,
          resetColor: resetColor
        };
      }; // Spacing utils


      var changeSpacing = function changeSpacing(origKey, object) {
        var theme = getState();
        var found;
        var spacingsList = ((theme === null || theme === void 0 ? void 0 : theme.spacingsList) || []).map(function (item) {
          if (item.key === origKey) {
            found = item = _objectSpread2(_objectSpread2({}, item), object);
          }

          return item;
        });

        if (!found) {
          spacingsList.push(Object.assign(object));
        }

        setState({
          spacingsList: spacingsList
        });
      };

      var setSpacing = function setSpacing(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetSpacing = function resetSpacing(rmKey) {
        changeSpacing(rmKey, {
          change: null
        });
      };

      var useSpacingTools = function useSpacingTools() {
        return {
          changeSpacing: changeSpacing,
          setSpacing: setSpacing,
          resetSpacing: resetSpacing
        };
      }; // Font-size utils


      var changeFontsize = function changeFontsize(origKey, object) {
        var theme = getState();
        var found;
        var fontsizesList = ((theme === null || theme === void 0 ? void 0 : theme.fontsizesList) || []).map(function (item) {
          if (item.key === origKey) {
            found = item = _objectSpread2(_objectSpread2({}, item), object);
          }

          return item;
        });

        if (!found) {
          fontsizesList.push(Object.assign(object));
        }

        setState({
          fontsizesList: fontsizesList
        });
      };

      var setFontsize = function setFontsize(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetFontsize = function resetFontsize(rmKey) {
        changeFontsize(rmKey, {
          change: null
        });
      };

      var useFontsizeTools = function useFontsizeTools() {
        return {
          changeFontsize: changeFontsize,
          setFontsize: setFontsize,
          resetFontsize: resetFontsize
        };
      };

      return _objectSpread2(_objectSpread2({
        themeId: themeId
      }, getState()), {}, {
        setState: setState,
        getState: getState,
        getThemeChanges: getThemeChanges,
        useColorTools: useColorTools,
        useSpacingTools: useSpacingTools,
        useFontsizeTools: useFontsizeTools
      });
    }
  };
}

var defaultFallback = {
  enabled: false,
  selectedTab: 'colors',
  currentThemeId: null,
  selectedThemeId: 'demo'
};

function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: function setEnabled(enabled) {
      get().setByHost({
        enabled: enabled
      });
    },
    setFilter: function setFilter(cacheKey, filter) {
      var _get$getHostData;

      var filters = ((_get$getHostData = get().getHostData()) === null || _get$getHostData === void 0 ? void 0 : _get$getHostData.filters) || {};
      var existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({
        filters: filters
      });
    },
    getFilter: function getFilter(cacheKey) {
      var data = get().getHostData();
      return (data === null || data === void 0 ? void 0 : data.filters) ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: function setCurrentThemeId(currentThemeId) {
      get().setByHost({
        currentThemeId: currentThemeId
      });
    },
    setSelectedThemeId: function setSelectedThemeId(selectedThemeId) {
      get().setByHost({
        selectedThemeId: selectedThemeId
      });
    },
    setSelectedTab: function setSelectedTab(selectedTab) {
      get().setByHost({
        selectedTab: selectedTab
      });
    },
    getHostData: function getHostData() {
      var _get4 = get(),
          hosts = _get4.hosts;

      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: function setByHost(data) {
      var _get5 = get(),
          hosts = _get5.hosts;

      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({
        hosts: hosts
      });
    },
    importAppData: function importAppData(hostsData) {
      var _ref6 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          overwrite = _ref6.overwrite;

      try {
        if (hostsData) {
          var existingData = get().hosts;
          var hosts = Object.entries(hostsData).reduce(function (acc, _ref7) {
            var _ref8 = _slicedToArray(_ref7, 2),
                key = _ref8[0],
                data = _ref8[1];

            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }

            return acc;
          }, _objectSpread2({}, existingData));
          set({
            hosts: hosts
          });
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}

function errorStore(set) {
  return {
    error: null,
    setError: function setError(error) {
      console.warn(error);
      set({
        error: error
      });
    },
    hideError: function hideError() {
      set({
        error: null
      });
    }
  };
} // function postRehydrationMiddleware() {
//   const theme = useTheme.getState().getTheme()
//   ...
// }


function getPersistConfig(name) {
  var writeTimeoutId;
  return {
    name: name,
    // blacklist: ['colorTools', 'sgetItempacingTools'],
    // whitelist: ['colorTools', 'spacingTools'],
    // postRehydrationMiddleware,
    // onRehydrateStorage: () => {
    //   console.log('onRehydrateStorage')
    // },
    getStorage: function getStorage() {
      return {
        getItem: function getItem(name) {
          return new Promise(function (resolve, reject) {
            if ( browser$1 && browser$1.storage !== 'undefined') {
              try {
                var _browser$storage;

                (_browser$storage = browser$1.storage) === null || _browser$storage === void 0 ? void 0 : _browser$storage.sync.get([name], function (_ref9) {
                  var themeData = _ref9[name];

                  if (browser$1.runtime.lastError) {
                    useErrorStore.getState().setError(browser$1.runtime.lastError.message);
                  } else {
                    // const themeData = data?.themeData || data || '{}'
                    resolve(themeData);
                  }
                });
              } catch (e) {
                var _window$localStorage;

                useErrorStore.getState().setError(e.message);
                resolve(((_window$localStorage = window.localStorage) === null || _window$localStorage === void 0 ? void 0 : _window$localStorage.getItem(name)) || '{}');
              }
            } else {
              var _window$localStorage2;

              resolve(((_window$localStorage2 = window.localStorage) === null || _window$localStorage2 === void 0 ? void 0 : _window$localStorage2.getItem(name)) || '{}');
            }
          });
        },
        setItem: function setItem(name, themeData) {
          if ( browser$1 && browser$1.storage !== 'undefined') {
            /**
             * Because of the message: setError This request exceeds the MAX_WRITE_OPERATIONS_PER_MINUTE quota.
             * we do debounce the write
             */
            var write = function write() {
              try {
                var _browser$storage2;

                (_browser$storage2 = browser$1.storage) === null || _browser$storage2 === void 0 ? void 0 : _browser$storage2.sync.set(_defineProperty$1({}, name, themeData), function () {
                  // console.lo('setItem:', name, themeData)
                  if (browser$1.runtime.lastError) {
                    useErrorStore.getState().setError(browser$1.runtime.lastError.message);
                  }
                });
              } catch (e) {
                var _window$localStorage3;

                useErrorStore.getState().setError(e.message);
                (_window$localStorage3 = window.localStorage) === null || _window$localStorage3 === void 0 ? void 0 : _window$localStorage3.setItem(name, themeData);
              }
            };

            if (!writeTimeoutId) {
              writeTimeoutId = 1;
              write();
            } else {
              clearTimeout(writeTimeoutId);
              writeTimeoutId = setTimeout(function () {
                write();
              }, 1e3);
            }
          } else {
            var _window$localStorage4;

            (_window$localStorage4 = window.localStorage) === null || _window$localStorage4 === void 0 ? void 0 : _window$localStorage4.setItem(name, themeData);
          }
        }
      };
    }
  };
}

var containers = []; // stores container HTMLElement references

var styleElements = []; // stores {prepend: HTMLElement, append: HTMLElement}

function insertCSS(css) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$elementId = _ref.elementId,
      elementId = _ref$elementId === void 0 ? 'inserted-css' : _ref$elementId,
      _ref$replace = _ref.replace,
      replace = _ref$replace === void 0 ? true : _ref$replace,
      _ref$prepend = _ref.prepend,
      prepend = _ref$prepend === void 0 ? false : _ref$prepend,
      _ref$targetElement = _ref.targetElement,
      targetElement = _ref$targetElement === void 0 ? document.querySelector('head') : _ref$targetElement;

  css = String(css || '');
  var position = prepend === true ? 'prepend' : 'append';
  var containerId = containers.indexOf(targetElement); // first time we see this container, create the necessary entries

  if (containerId === -1) {
    containerId = containers.push(targetElement) - 1;
    styleElements[containerId] = {};
  } // try to get the corresponding container + position styleElement, create it otherwise


  var styleElement;

  if (typeof styleElements[containerId] !== 'undefined' && typeof styleElements[containerId][elementId] !== 'undefined') {
    styleElement = styleElements[containerId][elementId];
  } else {
    styleElement = styleElements[containerId][elementId] = createStyleElement$1({
      elementId: elementId
    });

    if (position === 'prepend') {
      targetElement.insertBefore(styleElement, targetElement.childNodes[0]);
    } else {
      targetElement.appendChild(styleElement);
    }
  } // strip potential UTF-8 BOM if css was read from a file


  if (css.charCodeAt(0) === 0xfeff) {
    css = css.substr(1, css.length);
  } // actually add the stylesheet


  if (replace) {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = css;
    } else {
      styleElement.textContent = css;
    }
  } else {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText += css;
    } else {
      styleElement.textContent += css;
    }
  }

  return styleElement;
}

function createStyleElement$1() {
  var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref2$elementId = _ref2.elementId,
      elementId = _ref2$elementId === void 0 ? null : _ref2$elementId;

  var styleElement = document.createElement('style');
  styleElement.setAttribute('type', 'text/css');

  if (elementId) {
    styleElement.setAttribute('id', elementId);
  }

  return styleElement;
}

function constructCSSPath(el) {
  if (!(el instanceof Element)) {
    return; // stop here
  }

  var VALID_CLASSNAME = /^[_a-zA-Z\- ]*$/;
  var path = [];

  while (el.nodeType === Node.ELEMENT_NODE) {
    var selector = el.nodeName.toLowerCase();

    if (el.id) {
      selector += "#".concat(el.id);
      path.unshift(selector);
      break;
    } else if (el.className && VALID_CLASSNAME.test(el.className)) {
      selector += ".".concat(el.className.trim().replace(/\s+/g, '.'));
    } else {
      var sib = el,
          nth = 1;

      while (sib = sib.previousElementSibling) {
        if (sib.nodeName.toLowerCase() === selector) nth++;
      }

      if (nth !== 1) selector += ':nth-of-type(' + nth + ')';
    }

    path.unshift(selector);
    el = el.parentNode;
  }

  return path.join(' > ');
}

function createDOMInspector() {
  var _ref3 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref3$root = _ref3.root,
      root = _ref3$root === void 0 ? 'body' : _ref3$root,
      _ref3$exclude = _ref3.exclude,
      exclude = _ref3$exclude === void 0 ? [] : _ref3$exclude,
      _ref3$preventClick = _ref3.preventClick,
      preventClick = _ref3$preventClick === void 0 ? true : _ref3$preventClick,
      _ref3$outlineStyle = _ref3.outlineStyle,
      outlineStyle = _ref3$outlineStyle === void 0 ? '0.5rem solid rgba(0, 114, 114, 0.5)' : _ref3$outlineStyle,
      onClick = _ref3.onClick,
      onHover = _ref3.onHover;

  var selected, excludedElements;

  var removeHighlight = function removeHighlight(el) {
    if (el) {
      el.style.outline = '';
      el.style.cursor = '';
    }
  };

  var highlight = function highlight(el) {
    if (preventClick) {
      el.style.cursor = '';
    }

    el.style.outline = outlineStyle;
    el.style.outlineOffset = "-".concat(el.style.outlineWidth);
  };

  var shouldBeExcluded = function shouldBeExcluded(ev) {
    if (excludedElements && excludedElements.length && excludedElements.some(function (parent) {
      return parent === ev.target || parent.contains(ev.target);
    })) {
      return true;
    }
  };

  var handleMouseOver = function handleMouseOver(ev) {
    if (shouldBeExcluded(ev)) {
      return; // stop here
    }

    selected = ev.target;
    highlight(selected);

    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }

    if (typeof onHover === 'function') {
      onHover({
        element: ev.target,
        path: constructCSSPath(ev.target)
      });
    }
  };

  var handleMouseOut = function handleMouseOut(ev) {
    if (shouldBeExcluded(ev)) {
      return; // stop here
    }

    removeHighlight(ev.target);
  };

  var handleMouseDown = function handleMouseDown(ev) {
    if (shouldBeExcluded(ev)) {
      return; // stop here
    }

    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  };

  var handleClick = function handleClick(ev) {
    if (shouldBeExcluded(ev)) {
      return; // stop here
    }

    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }

    if (typeof onClick === 'function') {
      onClick({
        element: ev.target,
        path: constructCSSPath(ev.target)
      });
    }
  };

  var prepareExcluded = function prepareExcluded(rootEl) {
    if (!exclude.length) {
      return [];
    }

    var excludedNested = exclude.flatMap(function (element) {
      if (typeof element === 'string' || element instanceof String) {
        return Array.from(rootEl.querySelectorAll(element));
      } else if (element instanceof Element) {
        return [element];
      } else if (element.length > 0 && element[0] instanceof Element) {
        return Array.from(element);
      }

      return [];
    });
    return Array.from(excludedNested).flat();
  };

  var enable = function enable(onClickCallback) {
    var rootEl = document.querySelector(root);

    if (!rootEl) {
      return; // stop here
    }

    if (exclude) {
      excludedElements = prepareExcluded(rootEl);
    }

    rootEl.addEventListener('mouseover', handleMouseOver, true);
    rootEl.addEventListener('mouseout', handleMouseOut, true);
    rootEl.addEventListener('mousedown', handleMouseDown, true);
    rootEl.addEventListener('click', handleClick, true);

    if (onClickCallback) {
      onClick = onClickCallback;
    } // createInspectorMarker()

  };

  var cancel = function cancel() {
    var rootEl = document.querySelector(root);

    if (!rootEl) {
      return; // stop here
    }

    rootEl.removeEventListener('mouseover', handleMouseOver, true);
    rootEl.removeEventListener('mouseout', handleMouseOut, true);
    rootEl.removeEventListener('mousedown', handleMouseDown, true);
    rootEl.removeEventListener('click', handleClick, true);
    removeHighlight(selected);
  };

  return {
    enable: enable,
    cancel: cancel
  };
}
function createInspectorMarker() {
  try {
    var markerEl = document.getElementById('eufmeia-theme-inspector-marker');

    if (!markerEl) {
      markerEl = document.createElement('div');
      markerEl.setAttribute('id', 'eufmeia-theme-inspector-marker');
      markerEl.style.display = 'none';
      markerEl.style.position = 'absolute';
      markerEl.style.zIndex = '9000'; // markerEl.style.background = 'rgba(0, 114, 114, 0.5)'

      markerEl.style.transition = 'background 2s ease';
      markerEl.style.outline = '0.5rem solid rgba(0, 114, 114, 0.5)';
      document.body.appendChild(markerEl);
    }

    return {
      element: markerEl,
      hide: function hide() {
        if (markerEl) {
          markerEl.style.display = 'none';
        }
      },
      show: function show(element) {
        if (markerEl) {
          var style = getComputedStyle(element);
          markerEl.style.display = 'block';
          markerEl.style.top = "".concat(getOffsetTop(element), "px");
          markerEl.style.left = "".concat(getOffsetLeft(element), "px");
          markerEl.style.width = style.width;
          markerEl.style.height = style.height;
          markerEl.style.background = 'rgba(0, 114, 114, 0.5)';
          setTimeout(function () {
            try {
              markerEl.style.background = 'transparent';
            } catch (e) {
              console.warn(e);
            }
          }, 300);
        }
      }
    };
  } catch (e) {
    console.warn(e);
  }
}

var extensionId =  undefined;
function getTabId(cbFunc) {
  if (browser$1) {
    var _browser$tabs;

    browser$1 === null || browser$1 === void 0 ? void 0 : (_browser$tabs = browser$1.tabs) === null || _browser$tabs === void 0 ? void 0 : _browser$tabs.query({
      currentWindow: true,
      active: true
    }, function (tabs) {
      var tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests() {
  var _browser$runtime, _browser$runtime$onMe;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref$onResponse = _ref.onResponse,
      onResponse = _ref$onResponse === void 0 ? null : _ref$onResponse;

  if (!browser$1) {
    return; // stop here
  }

  browser$1 === null || browser$1 === void 0 ? void 0 : (_browser$runtime = browser$1.runtime) === null || _browser$runtime === void 0 ? void 0 : (_browser$runtime$onMe = _browser$runtime.onMessage) === null || _browser$runtime$onMe === void 0 ? void 0 : _browser$runtime$onMe.addListener(function (request, sender, response) {
    switch (request.type) {
      case 'get-extension-url':
        {
          getTabId(function (tabId) {
            browser$1.browserAction.getPopup({
              tabId: tabId
            }, function (popup) {
              response(popup);
            });
          });
          break;
        }

      case 'insert-css':
        {
          var elementId = request.elementId,
              css = request.css;

          if (typeof css !== 'undefined') {
            insertCSS(css, {
              elementId: elementId
            });
          }

          response(request);
          break;
        }

      case 'store-css':
        {
          var _css = request.css;

          if (typeof _css !== 'undefined') {
            setLocalThemeData({
              css: _css
            });
          }

          response(request);
          break;
        }

      case 'store-themes':
        {
          var themes = request.themes;

          if (typeof themes !== 'undefined') {
            setLocalThemeData({
              themes: themes
            });
          }

          response(request);
          break;
        }

      case 'get-modifications':
        {
          var modifications = JSON.parse(window.localStorage.getItem('eufemia-theme-editor') || '{}');
          response({
            modifications: modifications
          });
          break;
        }

      default:
        response(request); // only to have a fallback

        return false;
    }

    if (typeof onResponse === 'function') {
      onResponse(request);
    }

    return true;
  });
}
function getThemesAsync() {
  return new Promise(function (resolve, reject) {
    if (browser$1) {
      try {
        sendMessageToRuntime({
          type: 'get-themes'
        }, function (response) {
          resolve(response || {
            themes: []
          });
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({
        themes: null
      });
    }
  });
}
function getLocalThemeData() {
  var _window$localStorage;

  return JSON.parse(((_window$localStorage = window.localStorage) === null || _window$localStorage === void 0 ? void 0 : _window$localStorage.getItem('eufemia-theme-content')) || '{}');
}
function setLocalThemeData(data) {
  var _window$localStorage2;

  var localData = getLocalThemeData();
  (_window$localStorage2 = window.localStorage) === null || _window$localStorage2 === void 0 ? void 0 : _window$localStorage2.setItem('eufemia-theme-content', JSON.stringify(_objectSpread2(_objectSpread2({}, localData), data)));
}
function setLocalThemeCSS() {
  var localData = getLocalThemeData();

  if (localData && localData.css) {
    insertCSS(localData.css, {
      elementId: 'eufemia-theme'
    });
  }
}
function hasEnabledLocalThemeData() {
  var localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data) {
  var responseFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  sendMessageToTab(_objectSpread2({
    type: 'insert-css'
  }, data), responseFunc);
}
function storeCSSInPage(data) {
  var responseFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  sendMessageToTab(_objectSpread2({
    type: 'store-css'
  }, data), responseFunc);
}

function storeThemesInPage(themes) {
  var responseFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  // send it to the background
  sendMessageToRuntime({
    type: 'set-themes',
    themes: themes
  }, responseFunc); // send it to the content

  sendMessageToTab({
    type: 'store-themes',
    themes: themes
  }, responseFunc);
}

function sendMessageToRuntime(data) {
  var _browser$runtime2;

  var responseFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function (r) {
    return console.log('Defualt Response', r);
  };
  browser$1 === null || browser$1 === void 0 ? void 0 : (_browser$runtime2 = browser$1.runtime) === null || _browser$runtime2 === void 0 ? void 0 : _browser$runtime2.sendMessage(extensionId, data, responseFunc);
}

function sendMessageToTab(data) {
  var responseFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function (r) {
    return console.log('Defualt Response', r);
  };

  if (browser$1) {
    getTabId(function (tabId) {
      var themeId = window.EXTENSION_HOST ? useAppStore.getState().getHostData().currentThemeId : null;
      browser$1 === null || browser$1 === void 0 ? void 0 : browser$1.tabs.sendMessage(tabId, Object.assign(data, {
        themeId: themeId
      }), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc('localhost');
  }
}
// export function insertInlineExtension() {
//   const iframe = document.createElement('iframe')
//   const button = document.createElement('button')
//   const elem = document.body.firstChild
//   iframe.style.position = 'absolute'
//   button.style.position = 'absolute'
//   iframe.style.zIndex = '1000'
//   button.style.zIndex = '1000'
//   iframe.style.width = '42rem'
//   iframe.style.height = '100vh'
//   button.innerHTML = 'Open'
//   button.addEventListener('click', (evt) => {
//     evt.preventDefault()
//     browser?.runtime.sendMessage({ type: 'url' }, (response) => {
//       if (response) {
//         iframe.src = response
//         // elem.appendChild(iframe)
//         document.body.insertBefore(
//           iframe,
//           elem
//           //
//         )
//       }
//     })
//   })
//   // elem.appendChild(button)
//   document.body.insertBefore(button, elem)
// }

var Compiler = /*#__PURE__*/function () {
  function Compiler() {
    var _this = this;

    _classCallCheck$1(this, Compiler);

    this.run = function () {
      var _useThemeStore$getSta = useThemeStore.getState(),
          themes = _useThemeStore$getSta.themes;

      var _useAppStore$getState = useAppStore.getState(),
          getHostData = _useAppStore$getState.getHostData;

      var _getHostData = getHostData(),
          enabled = _getHostData.enabled,
          currentThemeId = _getHostData.currentThemeId;

      if (enabled) {
        var _useThemeStore$getSta2 = useThemeStore.getState(),
            getTheme = _useThemeStore$getSta2.getTheme;

        var theme = getTheme(currentThemeId);

        var css = _this.compileList(theme.getThemeChanges());

        _this.setCSS(css);

        _this.storeCSS(css);
      } else {
        _this.reset();
      } // have to run after insert/store css


      storeThemesInPage(themes);
    };
  }

  _createClass$1(Compiler, [{
    key: "listen",
    value: function listen() {
      var unsubStore = useThemeStore.subscribe(this.run);
      var unsubHost = useAppStore.subscribe(this.run);
      return function () {
        unsubStore();
        unsubHost();
      };
    }
  }, {
    key: "reset",
    value: function reset() {
      this.setCSS('');
      this.storeCSS('');
    }
  }, {
    key: "compileList",
    value: function compileList(listWithChanges) {
      var declarations = this.buildDeclarations(listWithChanges);
      var css = listWithChanges.filter(function (cur) {
        return cur.css;
      }).map(function (_ref) {
        var css = _ref.css;
        return css;
      }).join('');
      return css + this.combineWithRoot(declarations);
    }
  }, {
    key: "setCSS",
    value: function setCSS(css) {
      var elementId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'eufemia-theme';
      var hash = String(css) + String(elementId);

      if (this._cssMemoHash === hash) {
        return; // stop here
      }

      this._cssMemoHash = hash;

      if (browser$1 === null || browser$1 === void 0 ? void 0 : browser$1.tabs) {
        insertCSSIntoPage({
          css: css,
          elementId: elementId
        });
      } else {
        insertCSS(css, {
          elementId: elementId
        });
      }
    }
  }, {
    key: "storeCSS",
    value: function storeCSS(css) {
      if (browser$1 === null || browser$1 === void 0 ? void 0 : browser$1.tabs) {
        storeCSSInPage({
          css: css
        });
      }
    }
  }, {
    key: "compileFromTheme",
    value: function compileFromTheme(theme, opts) {
      return this.buildDeclarations(theme.getThemeChanges(), opts);
    }
  }, {
    key: "buildDeclarations",
    value: function buildDeclarations(listWithChanges) {
      var _ref2 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref2$modifyDeclarati = _ref2.modifyDeclaration,
          modifyDeclaration = _ref2$modifyDeclarati === void 0 ? null : _ref2$modifyDeclarati;

      return listWithChanges.filter(function (cur) {
        return cur.change;
      }).map(function (_ref3) {
        var key = _ref3.key,
            change = _ref3.change;

        if (typeof modifyDeclaration === 'function') {
          return modifyDeclaration({
            key: key,
            change: change
          });
        }

        return "".concat(key, ": ").concat(change, ";");
      });
    }
  }, {
    key: "combineWithRoot",
    value: function combineWithRoot(declarations) {
      return (declarations === null || declarations === void 0 ? void 0 : declarations.length) ? ":root{".concat(declarations.join(''), "}") : '';
    }
  }]);

  return Compiler;
}();
function compileModifications(_ref4) {
  var modifications = _ref4.modifications,
      themes = _ref4.themes,
      opts = _objectWithoutProperties$1(_ref4, ["modifications", "themes"]);

  if (themes) {
    extensionStorePlain.setState({
      themes: themes
    });

    var _extensionStorePlain$ = extensionStorePlain.getState(),
        getTheme = _extensionStorePlain$.getTheme;

    var css = Object.entries(modifications).map(function (_ref5) {
      var _ref6 = _slicedToArray(_ref5, 2),
          path = _ref6[0],
          themeId = _ref6[1].themeId;

      if (themeId && themeId !== 'inactive') {
        var theme = getTheme(themeId);
        var themeCSS = new Compiler().compileFromTheme(theme, opts).join('');
        return "".concat(path, "{").concat(themeCSS, "}");
      }

      return null;
    }).filter(Boolean).join('\n');
    return {
      css: css
    };
  }

  return {
    css: ''
  };
}

var useEditorStore = create$1(persist_1(function (set, get) {
  return {
    enabled: false,
    themesHash: null,
    modifications: {},
    addModification: function addModification(_ref) {
      var path = _ref.path,
          _ref$themeId = _ref.themeId,
          themeId = _ref$themeId === void 0 ? null : _ref$themeId;

      var _get = get(),
          modifications = _get.modifications;

      modifications[path] = {
        themeId: themeId
      };
      set({
        modifications: modifications
      });
    },
    setTheme: function setTheme(_ref2) {
      var path = _ref2.path,
          themeId = _ref2.themeId;

      var _get2 = get(),
          modifications = _get2.modifications;

      modifications[path] = {
        themeId: themeId
      };
      set({
        modifications: modifications
      });
    },
    removeTheme: function removeTheme(_ref3) {
      var path = _ref3.path;

      var _get3 = get(),
          modifications = _get3.modifications;

      delete modifications[path];
      set({
        modifications: modifications
      });
    },
    setEnabled: function setEnabled(enabled) {
      set({
        enabled: enabled
      });
    }
  };
}, getPersistConfig$1()));
function listenForModifications() {
  var _ref4 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      onModification = _ref4.onModification;

  return useEditorStore.subscribe(function () {
    if (typeof onModification === 'function') {
      onModification();
    }
  } // (state) => state.modifications // Does not work, but why? the subscription gets not called!
  );
}

function getPersistConfig$1() {
  return {
    name: 'eufemia-theme-editor',
    blacklist: ['themesHash'] // onRehydrateStorage: () => {
    //   console.log('onRehydrateStorage')
    // },

  };
}

function applyModifications(_ref5) {
  var themes = _ref5.themes;

  var _useEditorStore$getSt = useEditorStore.getState(),
      modifications = _useEditorStore$getSt.modifications;

  var _compileModifications = compileModifications({
    modifications: modifications,
    themes: themes,
    modifyDeclaration: function modifyDeclaration(_ref6) {
      var key = _ref6.key,
          change = _ref6.change;
      return "".concat(key, ": ").concat(change, ";").concat(key.replace('--', "--theme-"), ": ").concat(change, ";");
    }
  }),
      css = _compileModifications.css;

  insertCSS(css, {
    elementId: 'eufemia-theme-custom'
  });
}
function removeCustomModifications() {
  insertCSS('', {
    elementId: 'eufemia-theme-custom'
  });
}
function flushThemesHash() {
  useEditorStore.setState({
    themesHash: Date.now()
  });
}

var Layout = createStyled("div", {
  target: "eoylc335",
  label: "Layout"
})( {
  name: "4xdcmf",
  styles: "position:fixed;z-index:10000;top:1.5rem;bottom:0;left:2px;display:flex;flex-direction:column;width:var(--ete-width);height:100vh;padding:0.5rem;padding-top:1rem;background-color:var(--color-black-3);border:1px solid var(--color-black-8)"
} );

var EditorButton = /*#__PURE__*/createStyled(ToggleButton, {
  target: "eoylc334",
  label: "EditorButton"
})( {
  name: "1rl0o2y",
  styles: "position:fixed;z-index:10001;top:2px;left:2px;button{border-radius:0;color:var(--color-white);}button[aria-pressed='false']{padding:0;opacity:0.5;box-shadow:none;background-color:var(--color-black-55);}button[aria-pressed='true']{width:var(--ete-width);}"
} );

var EteApp = createStyled("div", {
  target: "eoylc333",
  label: "EteApp"
})("--ete-width:10rem;", generateThemeIgnoreColors(), ";" + ( "" ));

var App = function App() {
  var _useEditorStore = useEditorStore(),
      enabled = _useEditorStore.enabled,
      setEnabled = _useEditorStore.setEnabled;

  var _React$useState = react.useState(null),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      logPath = _React$useState2[0],
      setLogPath = _React$useState2[1];

  var _React$useState3 = react.useState(function () {
    return function (_ref) {
      var checked = _ref.checked;
      return setEnabled(checked);
    };
  }),
      _React$useState4 = _slicedToArray(_React$useState3, 1),
      toggleEnabled = _React$useState4[0];

  return jsx(EteApp, null, jsx(EditorButton, {
    title: "Eufemia Theme Editor",
    id: "ete-toggle-enabled",
    size: "small",
    checked: enabled,
    on_change: toggleEnabled,
    icon: enabled ? chevron_up : chevron_down
  }), enabled && jsx(Layout, {
    id: "ete",
    className: "dnb-core-style"
  }, jsx(InspectorHandler, {
    onHover: function onHover(_ref2) {
      var path = _ref2.path;
      setLogPath(path);
    },
    onCancel: function onCancel() {
      setLogPath(null);
    }
  }), logPath ? jsx(Path, {
    top: "1rem",
    modifier: "x-small"
  }, logPath) : jsx(ModificationManager, {
    top: "1rem"
  })));
};

function InspectorHandler(_ref3) {
  var _onHover = _ref3.onHover,
      onCancel = _ref3.onCancel;

  var _useEditorStore2 = useEditorStore(),
      addModification = _useEditorStore2.addModification;

  var _React$useState5 = react.useState(false),
      _React$useState6 = _slicedToArray(_React$useState5, 2),
      inspect = _React$useState6[0],
      setInspect = _React$useState6[1];

  var _React$useState7 = react.useState(function () {
    return function () {
      return setInspect(function (s) {
        if (s && onCancel) {
          onCancel();
        }

        return !s;
      });
    };
  }),
      _React$useState8 = _slicedToArray(_React$useState7, 1),
      toggleEnabled = _React$useState8[0];

  var _React$useState9 = react.useState(function () {
    return createDOMInspector({
      exclude: ['#ete', '#ete-toggle-inspector'],
      onHover: function onHover(_ref4) {
        var element = _ref4.element,
            path = _ref4.path;

        if (_onHover) {
          _onHover({
            element: element,
            path: path
          });
        }
      },
      onClick: function onClick(_ref5) {
        var element = _ref5.element,
            path = _ref5.path;

        if (onCancel) {
          onCancel({
            element: element,
            path: path
          });
        }

        setInspect(false);
        addModification({
          path: path
        });
      }
    });
  }),
      _React$useState10 = _slicedToArray(_React$useState9, 1),
      inspector = _React$useState10[0];

  if (inspect) {
    inspector.enable();
  } else {
    inspector.cancel();
  }

  return jsx(react.Fragment, null, jsx(ToggleButton, {
    id: "ete-toggle-inspector" // size="small"
    ,
    icon: add,
    icon_position: "left",
    checked: inspect,
    on_change: toggleEnabled
  }, inspect ? 'Cancel' : 'Inspect'));
}

var marker = createInspectorMarker();

function hideOutline(_ref6) {
  var _document$querySelect;

  var path = _ref6.path;
  (_document$querySelect = document.querySelectorAll(path)) === null || _document$querySelect === void 0 ? void 0 : _document$querySelect.forEach(function (elem) {
    marker.hide();
  });
}

function showOutline(_ref7) {
  var _document$querySelect2;

  var path = _ref7.path;
  (_document$querySelect2 = document.querySelectorAll(path)) === null || _document$querySelect2 === void 0 ? void 0 : _document$querySelect2.forEach(function (elem) {
    marker.show(elem);
  });
  var element = document.querySelector(path);

  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }
}

function useThemes(themesHash) {
  var _React$useState11 = react.useState([]),
      _React$useState12 = _slicedToArray(_React$useState11, 2),
      listOfThemes = _React$useState12[0],
      setListOfThemes = _React$useState12[1];

  react.useEffect(function () {
    getThemesAsync().then(function (_ref8) {
      var themes = _ref8.themes;
      setListOfThemes(Object.keys(themes).map(function (key) {
        return key;
      }).filter(function (key) {
        return !['blue-test', '2x-test'].includes(key);
      }));
    }).catch(function (e) {
      console.warn(e);
    });
  }, [themesHash]);
  return listOfThemes;
}

function ModificationManager(props) {
  var _useEditorStore3 = useEditorStore(),
      modifications = _useEditorStore3.modifications,
      themesHash = _useEditorStore3.themesHash,
      setTheme = _useEditorStore3.setTheme,
      removeTheme = _useEditorStore3.removeTheme;

  var listOfThemes = useThemes(themesHash);
  return jsx(Space, props, jsx(List, null, Object.entries(modifications).map(function (_ref9) {
    var _ref10 = _slicedToArray(_ref9, 2),
        path = _ref10[0],
        themeId = _ref10[1].themeId;

    var dontExist = !document.querySelectorAll(path);
    return jsx("li", {
      key: path
    }, jsx("div", {
      onMouseOver: function onMouseOver() {
        return showOutline({
          path: path
        });
      },
      onMouseOut: function onMouseOut() {
        return hideOutline({
          path: path
        });
      }
    }, jsx(Path, {
      className: dontExist ? 'dont-exist' : '',
      modifier: "x-small"
    }, path), jsx(StyledDropdown, {
      size: "small",
      skip_portal: true,
      data: [].concat(_toConsumableArray(listOfThemes), [{
        content: 'Inactive',
        selected_key: 'inactive'
      }, {
        content: 'Remove',
        selected_key: 'remove'
      }]),
      value: themeId || 'inactive',
      on_change: function on_change(_ref11) {
        var data = _ref11.data;
        var themeId = typeof (data === null || data === void 0 ? void 0 : data.selected_key) !== 'undefined' ? data === null || data === void 0 ? void 0 : data.selected_key : data;

        switch (themeId) {
          case 'remove':
            {
              removeTheme({
                path: path
              });
              break;
            }

          default:
            {
              setTheme({
                path: path,
                themeId: themeId
              });
            }
        }
      }
    })));
  })));
}

var Path = /*#__PURE__*/createStyled(P$1, {
  target: "eoylc332",
  label: "Path"
})( {
  name: "142artk",
  styles: "color:var(--color-success-green);&.dont-exist{color:var(--color-fire-red);}"
} );

var StyledDropdown = /*#__PURE__*/createStyled(Dropdown, {
  target: "eoylc331",
  label: "StyledDropdown"
})( {
  name: "277oq6",
  styles: "display:flex;--dropdown-width:8rem"
} );

var List = createStyled("ul", {
  target: "eoylc330",
  label: "List"
})( {
  name: "1e7s6mn",
  styles: "list-style:none;padding:0;>li{margin-top:0.5rem;background-color:var(--color-pistachio);}"
} );

function createThemeEditor() {
  var root = document.getElementById('eufemia-theme-editor'); // Because of hot-reload
  // if (root) {
  //   root.remove()
  //   root = null
  // }

  if (!root) {
    root = document.createElement('div');
    root.setAttribute('id', 'eufemia-theme-editor');
    document.body.insertBefore(root, document.body.firstChild);
  }

  reactDom.render(jsx(Provider, {
    locale: "en-GB"
  }, jsx(App, null)), root);
}
function removeThemeEditor() {
  var root = document.getElementById('eufemia-theme-editor');

  if (root) {
    root.remove();
  }
}

if (hasEnabledLocalThemeData()) {
  setLocalThemeModifications(); // or, get fresh themes, in case a data has changed

  getThemesAsync().then(function (_ref) {
    var themes = _ref.themes;
    setLocalThemeData({
      themes: themes
    });
    setLocalThemeModifications();
  });
}

listenForExtensionRequests({
  onResponse: function onResponse(response) {
    switch (response.type) {
      case 'store-themes':
        {
          var themes = response.themes;
          setLocalThemeData({
            themes: themes
          });
          setLocalThemeModifications();
          flushThemesHash();

          if (response.themeId === 'blue-test' && response.css) {
            removeCustomModifications();
          }

          break;
        }
    }
  }
});
var unsub;

function setLocalThemeModifications() {
  if (hasEnabledLocalThemeData()) {
    var _getLocalThemeData;

    setLocalThemeCSS();
    var themes = (_getLocalThemeData = getLocalThemeData()) === null || _getLocalThemeData === void 0 ? void 0 : _getLocalThemeData.themes;

    if (themes) {
      applyModifications({
        themes: themes
      });
    }

    createThemeEditor();

    if (typeof unsub === 'undefined') {
      unsub = listenForModifications({
        onModification: function onModification() {
          var _getLocalThemeData2;

          var themes = (_getLocalThemeData2 = getLocalThemeData()) === null || _getLocalThemeData2 === void 0 ? void 0 : _getLocalThemeData2.themes;
          applyModifications({
            themes: themes
          }); // or, get fresh themes
          // getThemesAsync().then(({ themes }) => {
          //   applyModifications({ themes })
          // })
        }
      });
    }
  } else if (unsub) {
    removeThemeEditor();
    removeCustomModifications();
    unsub();
    unsub = undefined;
  }
}
