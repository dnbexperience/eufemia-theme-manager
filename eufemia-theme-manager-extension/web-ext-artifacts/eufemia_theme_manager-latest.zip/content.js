/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 8138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ph": () => (/* binding */ extensionStorePlain),
/* harmony export */   "fl": () => (/* binding */ useThemeStore),
/* harmony export */   "qr": () => (/* binding */ useAppStore)
/* harmony export */ });
/* unused harmony exports useWindowStore, useErrorStore, useTheme */
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2742);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1818);
/* harmony import */ var _shared_Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5101);
/* harmony import */ var _shared_ColorController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4513);




const extensionStorePlain = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(themesStore);
const useThemeStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(themesStore, getPersistConfig("eufemia-theme-data")));
const useAppStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-app")));
const useWindowStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-window")));
const useErrorStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(errorStore);
function useTheme(themeId) {
  const {getTheme} = useThemeStore();
  return getTheme(themeId);
}
function themesStore(set, get) {
  return {
    themes: {},
    getThemes: () => {
      const {getThemeConstructs, themes} = get();
      if (!themes["dnb-ui"]) {
        themes["dnb-ui"] = getThemeConstructs();
        themes["demo"] = getThemeConstructs();
      }
      if (!themes["blue-test"]) {
        themes["blue-test"] = getThemeConstructs();
      }
      if (!themes["2x-test"]) {
        themes["2x-test"] = getThemeConstructs();
      }
      return themes;
    },
    importThemes: (themesData, {overwrite} = {}) => {
      try {
        if (themesData) {
          const existingThemes = get().themes;
          const themes = Object.entries(themesData).reduce((acc, [key, theme]) => {
            if (!["dnb-ui", "blue-test", "2x-test"].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }
            return acc;
          }, {...existingThemes});
          set({themes});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: (themeId) => {
      const {themes, getThemeConstructs} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...getThemeConstructs()};
        set({themes});
      }
    },
    copySelectedTheme: (themeId) => {
      const {themes, selectedThemeId} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...themes[selectedThemeId]};
        set({themes});
      }
    },
    removeTheme: (themeId) => {
      const themes = get().themes;
      if (themes[themeId]) {
        delete themes[themeId];
        set({themes});
      }
    },
    getThemeConstructs: () => {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: (themeId = null) => {
      if (!themeId) {
        themeId = get().selectedThemeId;
      }
      const setState = (object) => {
        const themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object);
        const state = {themes};
        state.selectedThemeId = themeId;
        set(state);
      };
      const getState = () => {
        const theme = get().themes[themeId] || null;
        return theme;
      };
      const getThemeChanges = () => {
        switch (themeId) {
          case "dnb-ui": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key, value}) => ({
                key,
                change: value
              }))
            ];
          }
          case "blue-test": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key}) => ({
                key,
                change: "blue"
              }))
            ];
          }
          case "2x-test": {
            return [
              {
                css: "html{font-size: 200%;}"
              }
            ];
          }
          default: {
            const theme = getState();
            return [
              ...theme?.colorsList || [],
              ...theme?.spacingsList || [],
              ...theme?.fontsizesList || []
            ];
          }
        }
      };
      const changeColor = (origKey, object) => {
        const theme = getState();
        let found = false;
        object.key = origKey;
        const colorsList = (theme?.colorsList || []).map((item) => {
          if (item.key === origKey) {
            item = {...item, ...object};
            found = Boolean(item);
          }
          return item;
        });
        if (!found) {
          colorsList.push(object);
        }
        setState({colorsList});
      };
      const setColor = (origKey, change, fallbackParams = {}) => {
        changeColor(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetColor = (rmKey) => {
        changeColor(rmKey, {
          change: null
        });
      };
      const useColorTools = () => {
        return {
          changeColor,
          setColor,
          resetColor
        };
      };
      const changeSpacing = (origKey, object) => {
        const theme = getState();
        let found;
        const spacingsList = (theme?.spacingsList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          spacingsList.push(Object.assign(object));
        }
        setState({spacingsList});
      };
      const setSpacing = (origKey, change, fallbackParams = {}) => {
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetSpacing = (rmKey) => {
        changeSpacing(rmKey, {
          change: null
        });
      };
      const useSpacingTools = () => {
        return {
          changeSpacing,
          setSpacing,
          resetSpacing
        };
      };
      const changeFontsize = (origKey, object) => {
        const theme = getState();
        let found;
        const fontsizesList = (theme?.fontsizesList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          fontsizesList.push(Object.assign(object));
        }
        setState({fontsizesList});
      };
      const setFontsize = (origKey, change, fallbackParams = {}) => {
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetFontsize = (rmKey) => {
        changeFontsize(rmKey, {
          change: null
        });
      };
      const useFontsizeTools = () => {
        return {
          changeFontsize,
          setFontsize,
          resetFontsize
        };
      };
      return {
        themeId,
        ...getState(),
        setState,
        getState,
        getThemeChanges,
        useColorTools,
        useSpacingTools,
        useFontsizeTools
      };
    }
  };
}
const defaultFallback = {
  enabled: false,
  selectedTab: "colors",
  currentThemeId: null,
  selectedThemeId: "demo"
};
function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: (enabled) => {
      get().setByHost({enabled});
    },
    setFilter: (cacheKey, filter) => {
      const filters = get().getHostData()?.filters || {};
      const existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({filters});
    },
    getFilter: (cacheKey) => {
      const data = get().getHostData();
      return data?.filters ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: (currentThemeId) => {
      get().setByHost({currentThemeId});
    },
    setSelectedThemeId: (selectedThemeId) => {
      get().setByHost({selectedThemeId});
    },
    setSelectedTab: (selectedTab) => {
      get().setByHost({selectedTab});
    },
    getHostData: () => {
      const {hosts} = get();
      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: (data) => {
      const {hosts} = get();
      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({hosts});
    },
    importAppData: (hostsData, {overwrite} = {}) => {
      try {
        if (hostsData) {
          const existingData = get().hosts;
          const hosts = Object.entries(hostsData).reduce((acc, [key, data]) => {
            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }
            return acc;
          }, {...existingData});
          set({hosts});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}
function errorStore(set) {
  return {
    error: null,
    setError: (error) => {
      console.warn(error);
      set({error});
    },
    hideError: () => {
      set({error: null});
    }
  };
}
function getPersistConfig(name) {
  let writeTimeoutId;
  const useBrowserStorage = true;
  return {
    name,
    getStorage: () => ({
      getItem: (name2) => {
        return new Promise((resolve, reject) => {
          if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.get */ .Z.storage.sync.get([name2], ({[name2]: themeData}) => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                } else {
                  resolve(themeData);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              resolve(window.localStorage?.getItem(name2) || "{}");
            }
          } else {
            resolve(window.localStorage?.getItem(name2) || "{}");
          }
        });
      },
      setItem: (name2, themeData) => {
        if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
          const write = () => {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.set */ .Z.storage.sync.set({[name2]: themeData}, () => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              window.localStorage?.setItem(name2, themeData);
            }
          };
          if (!writeTimeoutId) {
            writeTimeoutId = 1;
            write();
          } else {
            clearTimeout(writeTimeoutId);
            writeTimeoutId = setTimeout(() => {
              write();
            }, 1e3);
          }
        } else {
          window.localStorage?.setItem(name2, themeData);
        }
      }
    })
  };
}


/***/ }),

/***/ 8208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pb": () => (/* binding */ listenForExtensionRequests),
/* harmony export */   "ys": () => (/* binding */ getThemesAsync),
/* harmony export */   "$x": () => (/* binding */ getLocalThemeData),
/* harmony export */   "YB": () => (/* binding */ setLocalThemeData),
/* harmony export */   "eF": () => (/* binding */ setLocalThemeCSS),
/* harmony export */   "R": () => (/* binding */ hasEnabledLocalThemeData),
/* harmony export */   "nn": () => (/* binding */ insertCSSIntoPage),
/* harmony export */   "rc": () => (/* binding */ storeCSSInPage),
/* harmony export */   "XW": () => (/* binding */ storeThemesInPage)
/* harmony export */ });
/* unused harmony exports getTabId, getModificationsFromContentAsync, getHost, listenForBackgroundMessages */
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5101);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9494);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8138);



const extensionId =  false || void 0;
function getTabId(cbFunc) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.query */ .Z.tabs.query({currentWindow: true, active: true}, (tabs) => {
      const tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests({onResponse = null} = {}) {
  if (!_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    return;
  }
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.onMessage.addListener */ .Z.runtime.onMessage.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-extension-url": {
        getTabId((tabId) => {
          _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.browserAction.getPopup */ .Z.browserAction.getPopup({tabId}, (popup) => {
            response(popup);
          });
        });
        break;
      }
      case "insert-css": {
        const {elementId, css} = request;
        if (typeof css !== "undefined") {
          (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(css, {elementId});
        }
        response(request);
        break;
      }
      case "store-css": {
        const {css} = request;
        if (typeof css !== "undefined") {
          setLocalThemeData({css});
        }
        response(request);
        break;
      }
      case "store-themes": {
        const {themes} = request;
        if (typeof themes !== "undefined") {
          setLocalThemeData({themes});
        }
        response(request);
        break;
      }
      case "get-modifications": {
        const modifications = JSON.parse(window.localStorage.getItem("eufemia-theme-editor") || "{}");
        response({modifications});
        break;
      }
      default:
        response(request);
        return false;
    }
    if (typeof onResponse === "function") {
      onResponse(request);
    }
    return true;
  });
}
function getThemesAsync() {
  return new Promise((resolve, reject) => {
    if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
      try {
        sendMessageToRuntime({
          type: "get-themes"
        }, (response) => {
          resolve(response || {themes: []});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({themes: null});
    }
  });
}
function getModificationsFromContentAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToTab({
          type: "get-modifications"
        }, (response) => {
          resolve(response || {modifications: {}});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({modifications: {}});
    }
  });
}
function getLocalThemeData() {
  return JSON.parse(window.localStorage?.getItem("eufemia-theme-content") || "{}");
}
function setLocalThemeData(data) {
  const localData = getLocalThemeData();
  window.localStorage?.setItem("eufemia-theme-content", JSON.stringify({...localData, ...data}));
}
function setLocalThemeCSS() {
  const localData = getLocalThemeData();
  if (localData && localData.css) {
    (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(localData.css, {elementId: "eufemia-theme"});
  }
}
function hasEnabledLocalThemeData() {
  const localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data, responseFunc = null) {
  sendMessageToTab({type: "insert-css", ...data}, responseFunc);
}
function storeCSSInPage(data, responseFunc = null) {
  sendMessageToTab({type: "store-css", ...data}, responseFunc);
}
async function getHost() {
  return new Promise((resolve) => {
    if (browser) {
      browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
        const url = new URL(tabs[0].url);
        resolve(url.hostname);
      });
    } else {
      resolve("localhost");
    }
  });
}
function storeThemesInPage(themes, responseFunc = null) {
  sendMessageToRuntime({type: "set-themes", themes}, responseFunc);
  sendMessageToTab({type: "store-themes", themes}, responseFunc);
}
function sendMessageToRuntime(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.sendMessage */ .Z.runtime.sendMessage(extensionId, data, responseFunc);
}
function sendMessageToTab(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    getTabId((tabId) => {
      const themeId = window.EXTENSION_HOST ? _app_core_Store__WEBPACK_IMPORTED_MODULE_1__/* .useAppStore.getState */ .qr.getState().getHostData().currentThemeId : null;
      _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.sendMessage */ .Z.tabs.sendMessage(tabId, Object.assign(data, {themeId}), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc("localhost");
  }
}
function listenForBackgroundMessages() {
  browser?.runtime?.onMessage?.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-themes": {
        const {themes} = backgroundStore.getState();
        response({themes});
        break;
      }
      case "set-themes": {
        const {themes} = request;
        backgroundStore.setState({themes});
        response({themes});
        break;
      }
      default:
        return false;
    }
    return true;
  });
}


/***/ }),

/***/ 5101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export isDev */
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","RUNTIME_CHROME_EXTENSION_ID":"","RUNTIME_EXTENSION_DEV_LOCALHOST":"false","RUNTIME_EXTENSION_DEV_WATCH":"true","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useBrowser);


/***/ }),

/***/ 4513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v0": () => (/* binding */ originalColorsAsArray),
/* harmony export */   "RZ": () => (/* binding */ generateThemeIgnoreColors)
/* harmony export */ });
/* unused harmony exports originalColorsAsObject, fillRemaningColors, getOriginalColorsAsArray, getOriginalColorsAsObject */
/* harmony import */ var _dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7034);

const originalColorsAsObject = getOriginalColorsAsObject();
const originalColorsAsArray = getOriginalColorsAsArray();
function fillRemaningColors(originalColorsList, customColorsList) {
  const keyRef = originalColorsAsObject;
  const notInList = (customColorsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalColorsList.map((item) => ({
    ...item,
    ...(customColorsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalColorsAsArray() {
  const colors = Object.entries(originalColorsAsObject).map(([key, value]) => {
    const name = key.replace(/--color-/g, " ").replace(/-/g, " ").trim().replace(/(^|\s)([a-z])/g, (s) => s.toUpperCase());
    return {key, name, value};
  });
  return colors;
}
function getOriginalColorsAsObject() {
  const colors = Object.entries(_dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z).filter(([name]) => name.includes("--color-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("-border"))
      delete acc[key];
    if (key.includes("-background"))
      delete acc[key];
    if (key.includes("-light"))
      delete acc[key];
    if (key.includes("-medium"))
      delete acc[key];
    return acc;
  }, {});
  delete colors["--color-sea-green-alt-30"];
  delete colors["--color-signal-yellow-30"];
  delete colors["--color-black-30"];
  delete colors["--color-sea-green-alt"];
  delete colors["--color-signal-yellow"];
  return colors;
}
const generateThemeIgnoreColors = () => originalColorsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");


/***/ }),

/***/ 9301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VV": () => (/* binding */ compileModifications)
/* harmony export */ });
/* unused harmony exports useCompilerListener, default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5101);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8138);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9494);
/* harmony import */ var _shared_Bridge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8208);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {enumerable: true, configurable: true, writable: true, value}) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};





const useCompilerListener = () => React.useState(() => new Compiler().listen());
class Compiler {
  constructor() {
    __publicField(this, "run", () => {
      const {themes} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
      const {getHostData} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.getState */ .qr.getState();
      const {enabled, currentThemeId} = getHostData();
      if (enabled) {
        const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
        const theme = getTheme(currentThemeId);
        const css = this.compileList(theme.getThemeChanges());
        this.setCSS(css);
        this.storeCSS(css);
      } else {
        this.reset();
      }
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeThemesInPage */ .XW)(themes);
    });
  }
  listen() {
    const unsubStore = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.subscribe */ .fl.subscribe(this.run);
    const unsubHost = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.subscribe */ .qr.subscribe(this.run);
    return () => {
      unsubStore();
      unsubHost();
    };
  }
  reset() {
    this.setCSS("");
    this.storeCSS("");
  }
  compileList(listWithChanges) {
    const declarations = this.buildDeclarations(listWithChanges);
    const css = listWithChanges.filter((cur) => cur.css).map(({css: css2}) => css2).join("");
    return css + this.combineWithRoot(declarations);
  }
  setCSS(css, elementId = "eufemia-theme") {
    const hash = String(css) + String(elementId);
    if (this._cssMemoHash === hash) {
      return;
    }
    this._cssMemoHash = hash;
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .insertCSSIntoPage */ .nn)({css, elementId});
    } else {
      (0,_DOM__WEBPACK_IMPORTED_MODULE_4__/* .insertCSS */ .Q4)(css, {elementId});
    }
  }
  storeCSS(css) {
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeCSSInPage */ .rc)({css});
    }
  }
  compileFromTheme(theme, opts) {
    return this.buildDeclarations(theme.getThemeChanges(), opts);
  }
  buildDeclarations(listWithChanges, {modifyDeclaration = null} = {}) {
    return listWithChanges.filter((cur) => cur.change).map(({key, change}) => {
      if (typeof modifyDeclaration === "function") {
        return modifyDeclaration({key, change});
      }
      return `${key}: ${change};`;
    });
  }
  combineWithRoot(declarations) {
    return declarations?.length ? `:root{${declarations.join("")}}` : "";
  }
}
function compileModifications({modifications, themes, ...opts}) {
  if (themes) {
    _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.setState */ .ph.setState({themes});
    const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.getState */ .ph.getState();
    const css = Object.entries(modifications).map(([path, {themeId}]) => {
      if (themeId && themeId !== "inactive") {
        const theme = getTheme(themeId);
        const themeCSS = new Compiler().compileFromTheme(theme, opts).join("");
        return `${path}{${themeCSS}}`;
      }
      return null;
    }).filter(Boolean).join("\n");
    return {css};
  }
  return {css: ""};
}


/***/ }),

/***/ 9494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q4": () => (/* binding */ insertCSS),
/* harmony export */   "yQ": () => (/* binding */ createDOMInspector),
/* harmony export */   "gD": () => (/* binding */ createInspectorMarker)
/* harmony export */ });
/* harmony import */ var _dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6620);

const containers = [];
const styleElements = [];
function insertCSS(css, {
  elementId = "inserted-css",
  replace = true,
  prepend = false,
  targetElement = document.querySelector("head")
} = {}) {
  css = String(css || "");
  const position = prepend === true ? "prepend" : "append";
  let containerId = containers.indexOf(targetElement);
  if (containerId === -1) {
    containerId = containers.push(targetElement) - 1;
    styleElements[containerId] = {};
  }
  let styleElement;
  if (typeof styleElements[containerId] !== "undefined" && typeof styleElements[containerId][elementId] !== "undefined") {
    styleElement = styleElements[containerId][elementId];
  } else {
    styleElement = styleElements[containerId][elementId] = createStyleElement({
      elementId
    });
    if (position === "prepend") {
      targetElement.insertBefore(styleElement, targetElement.childNodes[0]);
    } else {
      targetElement.appendChild(styleElement);
    }
  }
  if (css.charCodeAt(0) === 65279) {
    css = css.substr(1, css.length);
  }
  if (replace) {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = css;
    } else {
      styleElement.textContent = css;
    }
  } else {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText += css;
    } else {
      styleElement.textContent += css;
    }
  }
  return styleElement;
}
function createStyleElement({elementId = null} = {}) {
  const styleElement = document.createElement("style");
  styleElement.setAttribute("type", "text/css");
  if (elementId) {
    styleElement.setAttribute("id", elementId);
  }
  return styleElement;
}
function constructCSSPath(el) {
  if (!(el instanceof Element)) {
    return;
  }
  const VALID_CLASSNAME = /^[_a-zA-Z\- ]*$/;
  let path = [];
  while (el.nodeType === Node.ELEMENT_NODE) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) {
      selector += `#${el.id}`;
      path.unshift(selector);
      break;
    } else if (el.className && VALID_CLASSNAME.test(el.className)) {
      selector += `.${el.className.trim().replace(/\s+/g, ".")}`;
    } else {
      let sib = el, nth = 1;
      while (sib = sib.previousElementSibling) {
        if (sib.nodeName.toLowerCase() === selector)
          nth++;
      }
      if (nth !== 1)
        selector += ":nth-of-type(" + nth + ")";
    }
    path.unshift(selector);
    el = el.parentNode;
  }
  return path.join(" > ");
}
function createDOMInspector({
  root = "body",
  exclude = [],
  preventClick = true,
  outlineStyle = "0.5rem solid rgba(0, 114, 114, 0.5)",
  onClick,
  onHover
} = {}) {
  let selected, excludedElements;
  const removeHighlight = (el) => {
    if (el) {
      el.style.outline = "";
      el.style.cursor = "";
    }
  };
  const highlight = (el) => {
    if (preventClick) {
      el.style.cursor = "";
    }
    el.style.outline = outlineStyle;
    el.style.outlineOffset = `-${el.style.outlineWidth}`;
  };
  const shouldBeExcluded = (ev) => {
    if (excludedElements && excludedElements.length && excludedElements.some((parent) => parent === ev.target || parent.contains(ev.target))) {
      return true;
    }
  };
  const handleMouseOver = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    selected = ev.target;
    highlight(selected);
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onHover === "function") {
      onHover({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const handleMouseOut = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    removeHighlight(ev.target);
  };
  const handleMouseDown = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  };
  const handleClick = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onClick === "function") {
      onClick({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const prepareExcluded = (rootEl) => {
    if (!exclude.length) {
      return [];
    }
    const excludedNested = exclude.flatMap((element) => {
      if (typeof element === "string" || element instanceof String) {
        return Array.from(rootEl.querySelectorAll(element));
      } else if (element instanceof Element) {
        return [element];
      } else if (element.length > 0 && element[0] instanceof Element) {
        return Array.from(element);
      }
      return [];
    });
    return Array.from(excludedNested).flat();
  };
  const enable = (onClickCallback) => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    if (exclude) {
      excludedElements = prepareExcluded(rootEl);
    }
    rootEl.addEventListener("mouseover", handleMouseOver, true);
    rootEl.addEventListener("mouseout", handleMouseOut, true);
    rootEl.addEventListener("mousedown", handleMouseDown, true);
    rootEl.addEventListener("click", handleClick, true);
    if (onClickCallback) {
      onClick = onClickCallback;
    }
  };
  const cancel = () => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    rootEl.removeEventListener("mouseover", handleMouseOver, true);
    rootEl.removeEventListener("mouseout", handleMouseOut, true);
    rootEl.removeEventListener("mousedown", handleMouseDown, true);
    rootEl.removeEventListener("click", handleClick, true);
    removeHighlight(selected);
  };
  return {
    enable,
    cancel
  };
}
function createInspectorMarker() {
  try {
    let markerEl = document.getElementById("eufmeia-theme-inspector-marker");
    if (!markerEl) {
      markerEl = document.createElement("div");
      markerEl.setAttribute("id", "eufmeia-theme-inspector-marker");
      markerEl.style.display = "none";
      markerEl.style.position = "absolute";
      markerEl.style.zIndex = "9000";
      markerEl.style.transition = "background 2s ease";
      markerEl.style.outline = "0.5rem solid rgba(0, 114, 114, 0.5)";
      document.body.appendChild(markerEl);
    }
    return {
      element: markerEl,
      hide: () => {
        if (markerEl) {
          markerEl.style.display = "none";
        }
      },
      show: (element) => {
        if (markerEl) {
          const style = getComputedStyle(element);
          markerEl.style.display = "block";
          markerEl.style.top = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetTop */ .oJ)(element)}px`;
          markerEl.style.left = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetLeft */ .pB)(element)}px`;
          markerEl.style.width = style.width;
          markerEl.style.height = style.height;
          markerEl.style.background = "rgba(0, 114, 114, 0.5)";
          setTimeout(() => {
            try {
              markerEl.style.background = "transparent";
            } catch (e) {
              console.warn(e);
            }
          }, 300);
        }
      }
    };
  } catch (e) {
    console.warn(e);
  }
}


/***/ }),

/***/ 1327:
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function() {
    var self = this, args = arguments;
    return new Promise(function(resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator;
module.exports.default = module.exports, module.exports.__esModule = true;


/***/ }),

/***/ 1459:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _arrayLikeToArray)
/* harmony export */ });
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length)
    len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }
  return arr2;
}


/***/ }),

/***/ 6934:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _assertThisInitialized)
/* harmony export */ });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}


/***/ }),

/***/ 1295:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _classCallCheck)
/* harmony export */ });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}


/***/ }),

/***/ 8504:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ _construct)
});

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js
var setPrototypeOf = __webpack_require__(2618);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/isNativeReflectConstruct.js
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/construct.js


function _construct(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct2(Parent2, args2, Class2) {
      var a = [null];
      a.push.apply(a, args2);
      var Constructor = Function.bind.apply(Parent2, a);
      var instance = new Constructor();
      if (Class2)
        (0,setPrototypeOf/* default */.Z)(instance, Class2.prototype);
      return instance;
    };
  }
  return _construct.apply(null, arguments);
}


/***/ }),

/***/ 7817:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _createClass)
/* harmony export */ });
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  return Constructor;
}


/***/ }),

/***/ 691:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _defineProperty)
/* harmony export */ });
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}


/***/ }),

/***/ 4973:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _extends)
/* harmony export */ });
function _extends() {
  _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}


/***/ }),

/***/ 3086:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _getPrototypeOf)
/* harmony export */ });
function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf2(o2) {
    return o2.__proto__ || Object.getPrototypeOf(o2);
  };
  return _getPrototypeOf(o);
}


/***/ }),

/***/ 7198:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _inherits)
/* harmony export */ });
/* harmony import */ var _setPrototypeOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2618);

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass)
    (0,_setPrototypeOf_js__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(subClass, superClass);
}


/***/ }),

/***/ 8802:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ _objectWithoutProperties)
});

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null)
    return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;
  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0)
      continue;
    target[key] = source[key];
  }
  return target;
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js

function _objectWithoutProperties(source, excluded) {
  if (source == null)
    return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;
  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0)
        continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key))
        continue;
      target[key] = source[key];
    }
  }
  return target;
}


/***/ }),

/***/ 8465:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _possibleConstructorReturn)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4687);
/* harmony import */ var _assertThisInitialized_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6934);


function _possibleConstructorReturn(self, call) {
  if (call && ((0,_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(call) === "object" || typeof call === "function")) {
    return call;
  }
  return (0,_assertThisInitialized_js__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(self);
}


/***/ }),

/***/ 2618:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _setPrototypeOf)
/* harmony export */ });
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
}


/***/ }),

/***/ 9840:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ _slicedToArray)
});

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
function _arrayWithHoles(arr) {
  if (Array.isArray(arr))
    return arr;
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js
function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr)))
    return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = void 0;
  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);
      if (i && _arr.length === i)
        break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null)
        _i["return"]();
    } finally {
      if (_d)
        throw _e;
    }
  }
  return _arr;
}

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
var unsupportedIterableToArray = __webpack_require__(7223);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/slicedToArray.js




function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || (0,unsupportedIterableToArray/* default */.Z)(arr, i) || _nonIterableRest();
}


/***/ }),

/***/ 2707:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ _toConsumableArray)
});

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
var arrayLikeToArray = __webpack_require__(1459);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr))
    return (0,arrayLikeToArray/* default */.Z)(arr);
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/iterableToArray.js
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter))
    return Array.from(iter);
}

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
var unsupportedIterableToArray = __webpack_require__(7223);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/toConsumableArray.js




function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || (0,unsupportedIterableToArray/* default */.Z)(arr) || _nonIterableSpread();
}


/***/ }),

/***/ 4687:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _typeof)
/* harmony export */ });
function _typeof(obj) {
  "@babel/helpers - typeof";
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof2(obj2) {
      return typeof obj2;
    };
  } else {
    _typeof = function _typeof2(obj2) {
      return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
    };
  }
  return _typeof(obj);
}


/***/ }),

/***/ 7223:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _unsupportedIterableToArray)
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1459);

function _unsupportedIterableToArray(o, minLen) {
  if (!o)
    return;
  if (typeof o === "string")
    return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor)
    n = o.constructor.name;
  if (n === "Map" || n === "Set")
    return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
    return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(o, minLen);
}


/***/ }),

/***/ 2186:
/***/ ((module) => {

function _extends() {
  module.exports = _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  module.exports.default = module.exports, module.exports.__esModule = true;
  return _extends.apply(this, arguments);
}
module.exports = _extends;
module.exports.default = module.exports, module.exports.__esModule = true;


/***/ }),

/***/ 9096:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(7684);


/***/ }),

/***/ 9826:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZP": () => (/* binding */ Button)
});

// UNUSED EXPORTS: buttonPropTypes, buttonVariantPropType

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__(8802);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__(6934);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/prop-types/index.js
var prop_types = __webpack_require__(6050);
// EXTERNAL MODULE: ../node_modules/classnames/index.js
var classnames = __webpack_require__(855);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Context.js + 3 modules
var Context = __webpack_require__(3898);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/custom-element.js + 3 modules
var custom_element = __webpack_require__(6357);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/SpacingHelper.js
var SpacingHelper = __webpack_require__(3039);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/skeleton/SkeletonHelper.js
var SkeletonHelper = __webpack_require__(5818);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/icon-primary/IconPrimary.js + 41 modules
var IconPrimary = __webpack_require__(6336);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-status/FormStatus.js
var FormStatus = __webpack_require__(3427);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/Element.js
var Element = __webpack_require__(5857);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(6091);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(7888);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/helpers.js
var helpers = __webpack_require__(6620);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/tooltip/TooltipContainer.js








function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var TooltipContainer = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(TooltipContainer2, _React$PureComponent);
  var _super = _createSuper(TooltipContainer2);
  function TooltipContainer2() {
    var _this;
    (0,classCallCheck/* default */.Z)(this, TooltipContainer2);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _super.call.apply(_super, [this].concat(args));
    _this._rootRef = react.createRef();
    _this.offset = 16;
    _this.state = {
      hide: null,
      hover: null,
      width: 0,
      height: 0
    };
    _this.handleMouseEnter = function() {
      (0,component_helper/* isTrue */.oA)(_this.props.active) && _this.props.useHover && _this.setState({
        hover: true
      });
    };
    _this.handleMouseLeave = function() {
      _this.props.useHover && _this.setState({
        hover: false
      });
    };
    return _this;
  }
  (0,createClass/* default */.Z)(TooltipContainer2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if ((0,component_helper/* isTrue */.oA)(this.props.active)) {
        this.updateSize();
      }
      this.addPositionObserver();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.props !== prevProps) {
        this.updateSize();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.removePositionObserver();
    }
  }, {
    key: "addPositionObserver",
    value: function addPositionObserver() {
      var _this2 = this;
      if (this.resizeObserver || typeof document === "undefined") {
        return;
      }
      try {
        this.resizeObserver = new ResizeObserver(function(entries) {
          clearTimeout(_this2._ddt);
          _this2._ddt = setTimeout(function() {
            _this2.setState({
              w: entries[0].contentRect.width,
              h: entries[0].contentRect.height
            });
          }, 30);
        });
        this.resizeObserver.observe(document.body);
      } catch (e) {
      }
    }
  }, {
    key: "removePositionObserver",
    value: function removePositionObserver() {
      clearTimeout(this._ddt);
      if (this.resizeObserver) {
        this.resizeObserver.disconnect();
        this.resizeObserver = null;
      }
    }
  }, {
    key: "getGlobalStyle",
    value: function getGlobalStyle() {
      if (!this.props.targetElement) {
        return {
          display: "none"
        };
      }
      return this.makeStyle(this.props.position, this.props.arrow);
    }
  }, {
    key: "makeStyle",
    value: function makeStyle(position, arrow) {
      var _this3 = this;
      if (typeof window === "undefined") {
        return {};
      }
      var alignOffset = 0;
      var target = this.props.targetElement;
      var rect = target.getBoundingClientRect();
      var align = this.props.align;
      var targetSize = {
        width: target.offsetWidth,
        height: target.offsetHeight
      };
      if (!target.offsetHeight) {
        targetSize.width = rect.width;
        targetSize.height = rect.height;
      }
      var scrollY = window.scrollY !== void 0 ? window.scrollY : window.pageYOffset;
      var scrollX = window.scrollX !== void 0 ? window.scrollX : window.pageXOffset;
      var _top = scrollY + rect.top;
      var useMouseWhen = targetSize.width > 400;
      var mousePos = this.props.clientX - (0,helpers/* getOffsetLeft */.pB)(target) + rect.left / 2 + (this._rootRef.current ? this._rootRef.current.offsetWidth : 0);
      var widthBased = scrollX + rect.left;
      var _left = useMouseWhen && mousePos < targetSize.width ? mousePos : widthBased;
      var style = {};
      if (align === "left") {
        alignOffset = -targetSize.width / 2;
      } else if (align === "right") {
        alignOffset = targetSize.width / 2;
      }
      var stylesFromPosition = {
        left: function left() {
          style.top = _top + targetSize.height / 2 - _this3.state.height / 2;
          style.left = _left - _this3.state.width - _this3.offset;
        },
        right: function right() {
          style.top = _top + targetSize.height / 2 - _this3.state.height / 2;
          style.left = _left + targetSize.width + _this3.offset;
        },
        top: function top() {
          style.left = _left - _this3.state.width / 2 + targetSize.width / 2 + alignOffset;
          style.top = _top - _this3.state.height - _this3.offset;
        },
        bottom: function bottom() {
          style.left = _left - _this3.state.width / 2 + targetSize.width / 2 + alignOffset;
          style.top = _top + targetSize.height + _this3.offset;
        }
      };
      var stylesFromArrow = {
        left: function left() {
          style.left = _left + targetSize.width / 2 - _this3.offset + alignOffset;
        },
        right: function right() {
          style.left = _left - _this3.state.width + targetSize.width / 2 + _this3.offset + alignOffset;
        },
        top: function top() {
          style.top = _top + targetSize.height / 2 - _this3.offset;
        },
        bottom: function bottom() {
          style.top = _top + targetSize.height / 2 - _this3.state.height + _this3.offset;
        }
      };
      if (stylesFromPosition[position]) {
        stylesFromPosition[position]();
      }
      if (stylesFromArrow[arrow]) {
        stylesFromArrow[arrow]();
      }
      return style;
    }
  }, {
    key: "checkWindowPosition",
    value: function checkWindowPosition(style) {
      if (style.left < 0) {
        style.left = this.offset;
      } else {
        try {
          var rightOffset = style.left + this.state.width - window.innerWidth;
          if (rightOffset > 0) {
            style.left = window.innerWidth - this.state.width - this.offset;
          }
        } catch (e) {
        }
      }
      return style;
    }
  }, {
    key: "updateSize",
    value: function updateSize() {
      var width = this._rootRef.current.offsetWidth;
      var height = this._rootRef.current.offsetHeight;
      if (width !== this.state.width || height !== this.state.height) {
        this.setState({
          width,
          height,
          _listenForPropChanges: false
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props, internal_id = _this$props.internal_id, active = _this$props.active, attributes = _this$props.attributes, arrow = _this$props.arrow, position = _this$props.position, animate_position = _this$props.animate_position, children = _this$props.children;
      var _this$state = this.state, hover = _this$state.hover, hide = _this$state.hide;
      var style = this.checkWindowPosition(this.getGlobalStyle());
      var isActive = (0,component_helper/* isTrue */.oA)(active) || hover;
      return react.createElement("span", (0,esm_extends/* default */.Z)({
        role: "tooltip",
        "aria-hidden": true,
        style,
        ref: this._rootRef,
        onMouseEnter: this.handleMouseEnter,
        onMouseLeave: this.handleMouseLeave
      }, attributes, {
        className: classnames(attributes.className, isActive ? "dnb-tooltip--active" : hide && "dnb-tooltip--hide", (0,component_helper/* isTrue */.oA)(animate_position) && "dnb-tooltip--animate_position")
      }), arrow && react.createElement("span", {
        className: "dnb-tooltip__arrow dnb-tooltip__arrow__arrow--".concat(arrow, " dnb-tooltip__arrow__position--").concat(position)
      }), react.createElement("span", {
        id: internal_id,
        className: "dnb-tooltip__content"
      }, children));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (state.wasActive && !props.active && !state.hover) {
          state.hide = true;
        }
        if (props.active || state.hover) {
          state.wasActive = true;
          state.hide = false;
        }
      }
      state._listenForPropChanges = true;
      return state;
    }
  }]);
  return TooltipContainer2;
}(react.PureComponent);
TooltipContainer.defaultProps = {
  internal_id: null,
  targetElement: null,
  clientX: null,
  active: false,
  position: "center",
  arrow: null,
  align: null,
  animate_position: null,
  useHover: true,
  attributes: null,
  children: null
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/tooltip/TooltipPortal.js







function TooltipPortal_createSuper(Derived) {
  var hasNativeReflectConstruct = TooltipPortal_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function TooltipPortal_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var tooltipPortal;
if (typeof window !== "undefined") {
  window.tooltipPortal = window.tooltipPortal || {};
  tooltipPortal = window.tooltipPortal;
} else {
  tooltipPortal = {};
}
var TooltipPortal = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(TooltipPortal2, _React$PureComponent);
  var _super = TooltipPortal_createSuper(TooltipPortal2);
  function TooltipPortal2() {
    (0,classCallCheck/* default */.Z)(this, TooltipPortal2);
    return _super.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(TooltipPortal2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.renderPortal();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(props) {
      if (tooltipPortal[this.props.group] && this.props.active !== props.active) {
        this.renderPortal({
          active: true
        });
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (tooltipPortal[this.props.group]) {
        react_dom.unmountComponentAtNode(tooltipPortal[this.props.group].node);
        clearTimeout(tooltipPortal[this.props.group].timeout);
        try {
          document.body.removeChild(tooltipPortal[this.props.group].node);
        } catch (e) {
        }
        tooltipPortal[this.props.group] = null;
      }
    }
  }, {
    key: "createPortal",
    value: function createPortal() {
      if (typeof document !== "undefined") {
        try {
          tooltipPortal[this.props.group] = {
            node: document.createElement("div"),
            timeout: null
          };
          var elem = tooltipPortal[this.props.group].node;
          elem.classList.add("TooltipPortal");
          elem.classList.add("dnb-core-style");
          document.body.appendChild(elem);
        } catch (e) {
          (0,component_helper/* warn */.ZK)(e);
        }
      }
    }
  }, {
    key: "handleAria",
    value: function handleAria(elem) {
      try {
        if (!elem.classList.contains("dnb-tooltip__wrapper")) {
          var existing = {
            "aria-describedby": elem.getAttribute("aria-describedby")
          };
          elem.setAttribute("aria-describedby", (0,component_helper/* combineDescribedBy */.u5)(existing, this.props.internal_id));
        }
      } catch (e) {
      }
    }
  }, {
    key: "renderPortal",
    value: function renderPortal() {
      var _this = this;
      var props = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      if (!tooltipPortal[this.props.group]) {
        this.createPortal();
      }
      var _this$props = this.props, group = _this$props.group, target = _this$props.target;
      var targetElement = typeof target === "string" ? typeof document !== "undefined" && document.querySelector(target) : target;
      if (targetElement) {
        if (tooltipPortal[group].timeout) {
          clearTimeout(tooltipPortal[group].timeout);
        }
        if (!this.props.active && props.active) {
          tooltipPortal[group].timeout = setTimeout(function() {
            _this.renderPortal({
              active: false
            });
          }, parseFloat(this.props.hide_delay));
        }
        this.handleAria(targetElement);
        var component = react.createElement(TooltipContainer, (0,esm_extends/* default */.Z)({
          targetElement
        }, this.props, props));
        react_dom.render(component, tooltipPortal[this.props.group].node);
      }
    }
  }, {
    key: "render",
    value: function render() {
      return null;
    }
  }]);
  return TooltipPortal2;
}(react.PureComponent);
TooltipPortal.defaultProps = {
  internal_id: null,
  active: false,
  group: "main",
  hide_delay: 500
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/tooltip/TooltipWithEvents.js









function TooltipWithEvents_createSuper(Derived) {
  var hasNativeReflectConstruct = TooltipWithEvents_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function TooltipWithEvents_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var TooltipWithEvents = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(TooltipWithEvents2, _React$PureComponent);
  var _super = TooltipWithEvents_createSuper(TooltipWithEvents2);
  function TooltipWithEvents2() {
    var _this;
    (0,classCallCheck/* default */.Z)(this, TooltipWithEvents2);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _super.call.apply(_super, [this].concat(args));
    _this.state = {
      isActive: false
    };
    _this.addEvents = function() {
      var domElement = _this.state.domElement;
      try {
        domElement.addEventListener("focus", _this.onMouseEnter);
        domElement.addEventListener("blur", _this.onMouseLeave);
        domElement.addEventListener("mouseenter", _this.onMouseEnter);
        domElement.addEventListener("mouseleave", _this.onMouseLeave);
      } catch (e) {
        (0,component_helper/* warn */.ZK)(e);
      }
    };
    _this.onMouseEnter = function(e) {
      clearTimeout(_this._onEnterTimeout);
      _this._onEnterTimeout = setTimeout(function() {
        _this.setState({
          isActive: true,
          clientX: e.clientX
        });
      }, _this.props.show_delay || 1);
    };
    _this.onMouseLeave = function() {
      clearTimeout(_this._onEnterTimeout);
      _this.setState({
        isActive: false
      });
    };
    return _this;
  }
  (0,createClass/* default */.Z)(TooltipWithEvents2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var target = this.props.target;
      if (Object.prototype.hasOwnProperty.call(target, "current")) {
        this.setState({
          domElement: target.current
        }, this.addEvents);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this._onEnterTimeout);
      var domElement = this.state.domElement;
      if (domElement) {
        domElement.removeEventListener("focus", this.onMouseEnter);
        domElement.removeEventListener("blur", this.onMouseLeave);
        domElement.removeEventListener("mouseenter", this.onMouseEnter);
        domElement.removeEventListener("mouseleave", this.onMouseLeave);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;
      var _this$props = this.props, children = _this$props.children, className = _this$props.className, target = _this$props.target, props = (0,objectWithoutProperties/* default */.Z)(_this$props, ["children", "className", "target"]);
      var domElement = this.state.domElement;
      var componentWrapper = null;
      if (react.isValidElement(target)) {
        componentWrapper = react.createElement("span", {
          key: "target-wrapper",
          className: classnames("dnb-tooltip__wrapper", className),
          onMouseEnter: this.onMouseEnter,
          onMouseLeave: this.onMouseLeave,
          ref: function ref(domElement2) {
            return _this2.setState({
              domElement: domElement2
            });
          }
        }, react.cloneElement(target, {
          "aria-describedby": (0,component_helper/* combineDescribedBy */.u5)(target.props, this.props.internal_id)
        }));
      }
      return react.createElement(react.Fragment, null, componentWrapper, domElement && react.createElement(TooltipPortal, (0,esm_extends/* default */.Z)({
        key: "tooltip",
        active: this.state.isActive,
        target: domElement,
        clientX: this.state.clientX
      }, props), children));
    }
  }]);
  return TooltipWithEvents2;
}(react.PureComponent);
TooltipWithEvents.defaultProps = {
  className: "",
  internal_id: null,
  show_delay: 1,
  target: null,
  children: null
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/tooltip/Tooltip.js








function Tooltip_createSuper(Derived) {
  var hasNativeReflectConstruct = Tooltip_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Tooltip_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}








var Tooltip = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Tooltip2, _React$PureComponent);
  var _super = Tooltip_createSuper(Tooltip2);
  function Tooltip2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, Tooltip2);
    _this = _super.call(this, props);
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    return _this;
  }
  (0,createClass/* default */.Z)(Tooltip2, [{
    key: "getPropsFromTooltipProp",
    value: function getPropsFromTooltipProp() {
      return this.props.tooltip ? react.isValidElement(this.props.tooltip) && this.props.tooltip.props ? this.props.tooltip.props : {
        children: this.props.tooltip
      } : null;
    }
  }, {
    key: "render",
    value: function render() {
      var inherited = this.getPropsFromTooltipProp();
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, Tooltip2.defaultProps, inherited, this.context.getTranslation(this.props).Tooltip, this.context.FormRow, this.context.Tooltip);
      var target_ref = props.target_ref, target = props.target, class_name = props.class, className = props.className, tooltip = props.tooltip, group = props.group, animate_position = props.animate_position, show_delay = props.show_delay, hide_delay = props.hide_delay, active = props.active, position = props.position, arrow = props.arrow, align = props.align, params = (0,objectWithoutProperties/* default */.Z)(props, ["target_ref", "target", "class", "className", "tooltip", "group", "animate_position", "show_delay", "hide_delay", "active", "position", "arrow", "align"]);
      var content = Tooltip2.getContent(props);
      var classes = classnames("dnb-tooltip", (0,SpacingHelper/* createSpacingClasses */.HU)(props), class_name, className);
      var attributes = (0,esm_extends/* default */.Z)({
        className: classes
      }, params);
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, attributes);
      var newProps = (0,esm_extends/* default */.Z)({}, this.props, inherited, {
        internal_id: this._id,
        group: this.props.id || group
      });
      if (newProps.active === null) {
        delete newProps.active;
      }
      return react.createElement(react.Fragment, null, target_ref ? react.createElement(TooltipWithEvents, (0,esm_extends/* default */.Z)({
        target: target_ref,
        attributes
      }, newProps), content) : target && react.createElement(TooltipPortal, (0,esm_extends/* default */.Z)({
        target,
        attributes
      }, newProps), content));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(Tooltip2.tagName, Tooltip2, Tooltip2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return (0,component_helper/* processChildren */.Ob)(props);
    }
  }]);
  return Tooltip2;
}(react.PureComponent);
Tooltip.tagName = "dnb-tooltip";
Tooltip.contextType = Context/* default */.Z;
Tooltip.defaultProps = {
  id: null,
  group: "main",
  active: null,
  position: "top",
  arrow: "center",
  align: null,
  animate_position: false,
  show_delay: 300,
  hide_delay: 500,
  class: null,
  className: null,
  children: null,
  tooltip: null,
  onClick: null,
  on_click: null
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/elements/Anchor.js








function Anchor_createSuper(Derived) {
  var hasNativeReflectConstruct = Anchor_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Anchor_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}








var Anchor = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Anchor2, _React$PureComponent);
  var _super = Anchor_createSuper(Anchor2);
  function Anchor2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, Anchor2);
    _this = _super.call(this, props);
    _this.state = {};
    _this._id = props.id || "id" + (0,component_helper/* makeUniqueId */.Xo)();
    _this._ref = props.inner_ref || react.createRef();
    return _this;
  }
  (0,createClass/* default */.Z)(Anchor2, [{
    key: "render",
    value: function render() {
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, AnchorInstance.defaultProps, {
        skeleton: this.context && this.context.skeleton
      }, this.context.getTranslation(this.props).Anchor, this.context.Anchor);
      var className = props.className, children = props.children, tooltip = props.tooltip, omitClass = props.omitClass, attributes = (0,objectWithoutProperties/* default */.Z)(props, ["className", "children", "tooltip", "omitClass"]);
      var showTooltip = props.target === "_blank" && !props.title;
      attributes.className = classnames(className, omitClass !== true && "dnb-anchor", props.target === "_blank" && typeof children !== "string" && "dnb-anchor--no-icon");
      return react.createElement(react.Fragment, null, react.createElement(Element/* default */.Z, (0,esm_extends/* default */.Z)({
        is: "a"
      }, attributes, {
        inner_ref: this._ref
      }), children), showTooltip && react.createElement(Tooltip, {
        show_delay: 100,
        id: this._id + "-tooltip",
        target_ref: this._ref,
        tooltip
      }, props.title || props.target_blank_title));
    }
  }]);
  return Anchor2;
}(react.PureComponent);
Anchor.contextType = Context/* default */.Z;
Anchor.tagName = "dnb-anchor";
var AnchorInstance = react.forwardRef(function(props, ref) {
  return react.createElement(Anchor, (0,esm_extends/* default */.Z)({
    inner_ref: ref
  }, props));
});
 false ? 0 : void 0;
AnchorInstance.defaultProps = {
  href: null,
  omitClass: null,
  target_blank_title: null,
  target: null,
  className: null,
  tooltip: null,
  children: null
};
/* harmony default export */ const elements_Anchor = (AnchorInstance);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/launch_medium.js

var _path;

function launch_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react.createElement("path", {
    d: "M9.14286 4H4V20H20V14.8571M12.5714 11.4286L20 4M20 4H14.2857M20 4V9.71429",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_launch_medium = (launch_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/launch.js

var launch_path;

function launch(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), launch_path || (launch_path = react.createElement("path", {
    d: "M5.85714 2H2V14H14V10.1429M8.42857 7.57143L14 2M14 2H9.71429M14 2V6.28571",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_launch = (launch);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/button/Button.js









var _span, _span2, _span3;
function Button_createSuper(Derived) {
  var hasNativeReflectConstruct = Button_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Button_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}












var buttonVariantPropType = {
  variant: prop_types.oneOf(["primary", "secondary", "tertiary", "signal"])
};
var buttonPropTypes = (0,esm_extends/* default */.Z)({
  text: prop_types.oneOfType([prop_types.string, prop_types.node]),
  type: prop_types.string,
  title: prop_types.node,
  variant: buttonVariantPropType.variant,
  size: prop_types.oneOf(["default", "small", "medium", "large"]),
  icon: prop_types.oneOfType([prop_types.string, prop_types.node, prop_types.func]),
  icon_position: prop_types.oneOf(["left", "right"]),
  icon_size: prop_types.oneOfType([prop_types.string, prop_types.number]),
  tooltip: prop_types.oneOfType([prop_types.string, prop_types.func, prop_types.node]),
  status: prop_types.oneOfType([prop_types.string, prop_types.bool, prop_types.func, prop_types.node]),
  status_state: prop_types.string,
  status_animation: prop_types.string,
  global_status_id: prop_types.string,
  id: prop_types.string,
  class: prop_types.string,
  href: prop_types.string,
  wrap: prop_types.oneOfType([prop_types.string, prop_types.bool]),
  bounding: prop_types.oneOfType([prop_types.string, prop_types.bool]),
  skeleton: prop_types.oneOfType([prop_types.string, prop_types.bool]),
  disabled: prop_types.oneOfType([prop_types.string, prop_types.bool]),
  inner_ref: prop_types.object,
  className: prop_types.string,
  innerRef: prop_types.object,
  children: prop_types.oneOfType([prop_types.string, prop_types.func, prop_types.node]),
  element: prop_types.node
}, SpacingHelper/* spacingPropTypes */.Xj, {
  custom_element: prop_types.object,
  custom_method: prop_types.func,
  onClick: prop_types.func,
  on_click: prop_types.oneOfType([prop_types.string, prop_types.func])
});
var Button = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Button2, _React$PureComponent);
  var _super = Button_createSuper(Button2);
  function Button2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, Button2);
    _this = _super.call(this, props);
    _this.onClickHandler = function(event) {
      var afterContent = (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_click", {
        event
      });
      if (afterContent && react.isValidElement(afterContent)) {
        _this.setState({
          afterContent
        });
      }
    };
    _this._id = props.id || (props.status || props.tooltip) && (0,component_helper/* makeUniqueId */.Xo)();
    _this._ref = react.createRef();
    _this.state = {
      afterContent: null
    };
    return _this;
  }
  (0,createClass/* default */.Z)(Button2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.props.innerRef) {
        this.props.innerRef.current = this._ref.current;
      }
      if (this.props.inner_ref) {
        this.props.inner_ref.current = this._ref.current;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$context;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, Button2.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.FormRow, this.context.Button);
      var class_name = props.class, className = props.className, type = props.type, variant = props.variant, size = props.size, title = props.title, tooltip = props.tooltip, status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, id = props.id, disabled = props.disabled, _text = props.text, _icon = props.icon, _icon_position = props.icon_position, icon_size = props.icon_size, href = props.href, wrap = props.wrap, bounding = props.bounding, skeleton = props.skeleton, element = props.element, inner_ref = props.inner_ref, innerRef = props.innerRef, attributes = (0,objectWithoutProperties/* default */.Z)(props, ["class", "className", "type", "variant", "size", "title", "tooltip", "status", "status_state", "status_animation", "global_status_id", "id", "disabled", "text", "icon", "icon_position", "icon_size", "href", "wrap", "bounding", "skeleton", "element", "inner_ref", "innerRef"]);
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var text = props.text, icon = props.icon, iconPosition = props.icon_position;
      var usedVariant = variant;
      var usedSize = size;
      var iconSize = icon_size;
      var content = Button2.getContent(this.props);
      if (variant === "tertiary" && (content || text) && !icon && icon !== false) {
        (0,component_helper/* warn */.ZK)("A Tertiary Button requires an icon. Please declare an icon to: ".concat(content));
      }
      var isIconOnly = Boolean(!text && !content && icon);
      if (isIconOnly) {
        if (!usedVariant) {
          usedVariant = "secondary";
        }
        if (!iconSize && (usedSize === "default" || usedSize === "large")) {
          iconSize = "medium";
        }
        if (!usedSize) {
          usedSize = "medium";
        }
      } else if (content) {
        if (!usedVariant) {
          usedVariant = "primary";
        }
        if (!usedSize) {
          usedSize = "default";
        }
      }
      if (!iconSize && variant === "tertiary" && usedSize === "large") {
        iconSize = "medium";
      }
      var Element = element ? element : href ? elements_Anchor : "button";
      if (Element === elements_Anchor) {
        attributes.omitClass = true;
        if (href && !icon) {
          icon = icon_size === "medium" ? icons_launch_medium : icons_launch;
        }
      }
      var classes = classnames("dnb-button dnb-button--".concat(usedVariant || "primary"), (text || content) && "dnb-button--has-text", (0,SkeletonHelper/* createSkeletonClass */.BD)(variant === "tertiary" ? "font" : "shape", skeleton, this.context), (0,SpacingHelper/* createSpacingClasses */.HU)(props), class_name, className, icon && "dnb-button--icon-position-".concat(iconPosition, " dnb-button--has-icon") + (iconSize ? " dnb-button--icon-size-".concat(iconSize) : ""), usedSize && usedSize !== "default" && "dnb-button--size-".concat(usedSize), wrap && "dnb-button--wrap", status && "dnb-button__status--".concat(status_state));
      var params = (0,esm_extends/* default */.Z)({
        className: classes,
        type,
        title,
        id: this._id,
        disabled: (0,component_helper/* isTrue */.oA)(disabled)
      }, attributes, {
        onClick: this.onClickHandler
      });
      if (href) {
        params.href = href;
      }
      (0,SkeletonHelper/* skeletonDOMAttributes */.rZ)(params, skeleton, this.context);
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, params);
      return react.createElement(react.Fragment, null, react.createElement(Element, (0,esm_extends/* default */.Z)({
        ref: this._ref
      }, params), react.createElement(Content, (0,esm_extends/* default */.Z)({}, this.props, {
        icon,
        text,
        icon_size: iconSize,
        content,
        isIconOnly,
        skeleton: (0,component_helper/* isTrue */.oA)(skeleton)
      }))), this.state.afterContent, showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: this._id + "-form-status",
        global_status_id,
        label: text,
        text: status,
        status: status_state,
        text_id: this._id + "-status",
        animation: status_animation,
        skeleton
      }), tooltip && this._ref && react.createElement(Tooltip, {
        id: this._id + "-tooltip",
        target_ref: this._ref,
        tooltip
      }));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(Button2.tagName, Button2, Button2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return (0,component_helper/* processChildren */.Ob)(props);
    }
  }]);
  return Button2;
}(react.PureComponent);
Button.tagName = "dnb-button";
Button.contextType = Context/* default */.Z;
Button.defaultProps = {
  type: "button",
  text: null,
  variant: null,
  size: null,
  title: null,
  icon: null,
  icon_position: "right",
  icon_size: null,
  href: null,
  id: null,
  class: null,
  wrap: false,
  bounding: false,
  skeleton: null,
  disabled: null,
  tooltip: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  inner_ref: null,
  className: null,
  innerRef: null,
  children: null,
  element: null,
  custom_element: null,
  custom_method: null,
  onClick: null,
  on_click: null
};

 false ? 0 : void 0;
var Content = function(_React$PureComponent2) {
  (0,inherits/* default */.Z)(Content2, _React$PureComponent2);
  var _super2 = Button_createSuper(Content2);
  function Content2() {
    (0,classCallCheck/* default */.Z)(this, Content2);
    return _super2.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(Content2, [{
    key: "render",
    value: function render() {
      var text = this.props.text;
      var _this$props = this.props, title = _this$props.title, content = _this$props.content, icon = _this$props.icon, icon_size = _this$props.icon_size, bounding = _this$props.bounding, skeleton = _this$props.skeleton, isIconOnly = _this$props.isIconOnly;
      var ret = [];
      if ((0,component_helper/* isTrue */.oA)(bounding)) {
        ret.push(_span || (_span = react.createElement("span", {
          key: "button-bounding",
          className: "dnb-button__bounding"
        })));
      }
      if (typeof content === "string") {
        text = content;
      } else if (content) {
        ret.push(content);
      }
      if (text) {
        ret.push(_span2 || (_span2 = react.createElement("span", {
          key: "button-text-empty",
          className: "dnb-button__alignment"
        }, "\u200C")), react.createElement("span", {
          key: "button-text",
          className: "dnb-button__text dnb-skeleton--show-font"
        }, text));
      } else if (icon) {
        ret.push(_span3 || (_span3 = react.createElement("span", {
          key: "button-text-empty",
          className: "dnb-button__alignment"
        }, "\u200C")));
      }
      if (icon) {
        ret.push(react.isValidElement(icon) && /Icon/i.test(String(icon.type)) ? react.cloneElement(icon, {
          key: "button-icon",
          className: "dnb-button__icon ".concat(icon.props.className || "")
        }) : react.createElement(IconPrimary/* default */.Z, {
          key: "button-icon",
          className: "dnb-button__icon",
          icon,
          size: icon_size,
          "aria-hidden": isIconOnly && !title ? null : true,
          skeleton
        }));
      }
      return ret;
    }
  }]);
  return Content2;
}(react.PureComponent);
Content.defaultProps = {
  text: null,
  title: null,
  content: null,
  icon: null,
  icon_size: "default",
  bounding: false,
  skeleton: null,
  isIconOnly: null
};
 false ? 0 : void 0;


/***/ }),

/***/ 4742:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Checkbox)
/* harmony export */ });
/* unused harmony export CheckIcon */
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6934);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3086);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6091);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(855);
/* harmony import */ var keycode__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1984);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6357);
/* harmony import */ var _shared_AlignmentHelper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2294);
/* harmony import */ var _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3039);
/* harmony import */ var _skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5818);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3898);
/* harmony import */ var _shared_helpers_Suffix__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8231);
/* harmony import */ var _form_label_FormLabel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6799);
/* harmony import */ var _form_status_FormStatus__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3427);









var _AlignmentHelper, _span;

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}












var Checkbox = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(Checkbox2, _React$PureComponent);
  var _super = _createSuper(Checkbox2);
  function Checkbox2(props) {
    var _this;
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(this, Checkbox2);
    _this = _super.call(this, props);
    _this.onKeyDownHandler = function(event) {
      switch (keycode__WEBPACK_IMPORTED_MODULE_7__(event)) {
        case "enter":
          _this.onChangeHandler(event);
          break;
      }
    };
    _this.onChangeHandler = function(event) {
      if ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .isTrue */ .oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      var checked = !_this.state.checked;
      _this.setState({
        checked,
        _listenForPropChanges: false
      });
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .dispatchCustomElementEvent */ .RW)((0,_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(_this), "on_change", {
        checked,
        event
      });
      if (_this._refInput.current) {
        _this._refInput.current.focus();
      }
    };
    _this._refInput = react__WEBPACK_IMPORTED_MODULE_4__.createRef();
    _this._id = props.id || (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .makeUniqueId */ .Xo)();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)(Checkbox2, [{
    key: "render",
    value: function render() {
      var props = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .extendPropsWithContext */ .Xw)(this.props, Checkbox2.defaultProps, {
        skeleton: this.context && this.context.skeleton
      }, this.context.getTranslation(this.props).Checkbox, this.context.FormRow, this.context.Checkbox);
      var value = props.value, status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, size = props.size, label = props.label, label_position = props.label_position, label_sr_only = props.label_sr_only, title = props.title, disabled = props.disabled, readOnly = props.readOnly, skeleton = props.skeleton, className = props.className, _className = props.class, _id = props.id, _default_state = props.default_state, _checked = props.checked, attributes = props.attributes, children = props.children, on_change = props.on_change, on_state_update = props.on_state_update, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)(props, ["value", "status", "status_state", "status_animation", "global_status_id", "suffix", "size", "label", "label_position", "label_sr_only", "title", "disabled", "readOnly", "skeleton", "className", "class", "id", "default_state", "checked", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);
      var checked = this.state.checked;
      var id = this._id;
      var showStatus = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .getStatusState */ .Bx)(status);
      var mainParams = {
        className: classnames__WEBPACK_IMPORTED_MODULE_6__("dnb-checkbox dnb-form-component", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__/* .createSkeletonClass */ .BD)(null, skeleton), (0,_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_15__/* .createSpacingClasses */ .HU)(props), className, _className, status && "dnb-checkbox__status--".concat(status_state), size && "dnb-checkbox--".concat(size), label && "dnb-checkbox--label-position-".concat(label_position || "right"))
      };
      var inputParams = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
        disabled,
        checked
      }, rest);
      if (showStatus || suffix) {
        inputParams["aria-describedby"] = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .combineDescribedBy */ .u5)(inputParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (readOnly) {
        inputParams["aria-readonly"] = inputParams.readOnly = true;
      }
      (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__/* .skeletonDOMAttributes */ .rZ)(inputParams, skeleton, this.context);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .validateDOMAttributes */ .L_)(this.props, inputParams);
      var statusComp = showStatus && react__WEBPACK_IMPORTED_MODULE_4__.createElement(_form_status_FormStatus__WEBPACK_IMPORTED_MODULE_17__/* .default */ .ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text_id: id + "-status",
        width_selector: id + ", " + id + "-label",
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton
      });
      return react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", mainParams, react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", {
        className: "dnb-checkbox__order"
      }, label && react__WEBPACK_IMPORTED_MODULE_4__.createElement(_form_label_FormLabel__WEBPACK_IMPORTED_MODULE_18__/* .default */ .Z, {
        id: id + "-label",
        for_id: id,
        text: label,
        disabled,
        skeleton,
        sr_only: label_sr_only
      }), react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", {
        className: "dnb-checkbox__inner"
      }, _AlignmentHelper || (_AlignmentHelper = react__WEBPACK_IMPORTED_MODULE_4__.createElement(_shared_AlignmentHelper__WEBPACK_IMPORTED_MODULE_19__/* .default */ .Z, null)), label_position === "left" && statusComp, react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", {
        className: "dnb-checkbox__shell"
      }, react__WEBPACK_IMPORTED_MODULE_4__.createElement("input", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
        id,
        name: id,
        type: "checkbox",
        title,
        "aria-checked": checked,
        className: "dnb-checkbox__input",
        value: checked ? value || "" : "",
        disabled: (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .isTrue */ .oA)(disabled)
      }, inputParams, {
        onChange: this.onChangeHandler,
        onKeyDown: this.onKeyDownHandler,
        ref: this._refInput
      })), react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6__("dnb-checkbox__button", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__/* .createSkeletonClass */ .BD)("shape", skeleton, this.context)),
        "aria-hidden": true
      }, _span || (_span = react__WEBPACK_IMPORTED_MODULE_4__.createElement("span", {
        className: "dnb-checkbox__focus"
      }))), react__WEBPACK_IMPORTED_MODULE_4__.createElement(CheckIcon, {
        size
      }))), suffix && react__WEBPACK_IMPORTED_MODULE_4__.createElement(_shared_helpers_Suffix__WEBPACK_IMPORTED_MODULE_20__/* .default */ .Z, {
        className: "dnb-checkbox__suffix",
        id: id + "-suffix",
        context: props
      }, suffix)), (label_position === "right" || !label_position) && statusComp);
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .registerElement */ .ui)(Checkbox2.tagName, Checkbox2, Checkbox2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          if (props.default_state !== null && typeof state.checked === "undefined") {
            state.checked = Checkbox2.parseChecked(props.default_state);
          } else {
            state.checked = Checkbox2.parseChecked(props.checked);
          }
        }
      }
      state._listenForPropChanges = true;
      if (state.checked !== state.__checked) {
        (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .dispatchCustomElementEvent */ .RW)({
          props
        }, "on_state_update", {
          checked: state.checked
        });
      }
      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);
  return Checkbox2;
}(react__WEBPACK_IMPORTED_MODULE_4__.PureComponent);
Checkbox.tagName = "dnb-checkbox";
Checkbox.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_22__/* .default */ .Z;
Checkbox.defaultProps = {
  label: null,
  label_position: null,
  title: null,
  default_state: null,
  checked: null,
  disabled: null,
  id: null,
  size: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: null,
  attributes: null,
  readOnly: false,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
Checkbox.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;
var CheckIcon = function CheckIcon2(_ref) {
  var size = _ref.size, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)(_ref, ["size"]);
  var vB = 16;
  if (size === "large") {
    vB = 24;
  }
  return react__WEBPACK_IMPORTED_MODULE_4__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
    width: vB,
    height: vB,
    viewBox: "0 0 ".concat(vB, " ").concat(vB),
    fill: "none",
    className: "dnb-checkbox__gfx",
    "aria-hidden": true
  }, props), react__WEBPACK_IMPORTED_MODULE_4__.createElement("path", {
    d: size === "large" ? "M1.5 15L7.5 21L22.5 3" : "M1 10L5 14L15 2",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
};
 false ? 0 : void 0;
CheckIcon.defaultProps = {
  size: "default"
};


/***/ }),

/***/ 8755:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Dropdown)
});

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__(8802);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__(6934);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(6091);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__(3070);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(520);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/prop-types/index.js
var prop_types = __webpack_require__(6050);
// EXTERNAL MODULE: ../node_modules/classnames/index.js
var classnames = __webpack_require__(855);
// EXTERNAL MODULE: ../node_modules/keycode/index.js
var keycode = __webpack_require__(1984);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/custom-element.js + 3 modules
var custom_element = __webpack_require__(6357);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/AlignmentHelper.js
var AlignmentHelper = __webpack_require__(2294);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/SpacingHelper.js
var SpacingHelper = __webpack_require__(3039);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/helpers/Suffix.js
var Suffix = __webpack_require__(8231);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/icon-primary/IconPrimary.js + 41 modules
var IconPrimary = __webpack_require__(6336);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-label/FormLabel.js
var FormLabel = __webpack_require__(6799);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-status/FormStatus.js
var FormStatus = __webpack_require__(3427);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/button/Button.js + 7 modules
var Button = __webpack_require__(9826);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__(9840);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.reduce.js
var es_array_reduce = __webpack_require__(6306);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.entries.js
var es_object_entries = __webpack_require__(5982);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(8381);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/fragments/drawer-list/DrawerListContext.js

var DrawerListContext = react.createContext({});
/* harmony default export */ const drawer_list_DrawerListContext = (DrawerListContext);

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.keys.js
var es_object_keys = __webpack_require__(2478);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Context.js + 3 modules
var Context = __webpack_require__(3898);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/helpers.js
var helpers = __webpack_require__(6620);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__(4687);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.match.js
var es_string_match = __webpack_require__(6679);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(7298);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.find-index.js
var es_array_find_index = __webpack_require__(6849);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__(1362);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/fragments/drawer-list/DrawerListHelpers.js












var parseContentTitle = function parseContentTitle2(dataItem) {
  var _dataItem;
  var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$separator = _ref.separator, separator = _ref$separator === void 0 ? "\n" : _ref$separator, _ref$removeNumericOnl = _ref.removeNumericOnlyValues, removeNumericOnlyValues = _ref$removeNumericOnl === void 0 ? false : _ref$removeNumericOnl, _ref$preferSelectedVa = _ref.preferSelectedValue, preferSelectedValue = _ref$preferSelectedVa === void 0 ? false : _ref$preferSelectedVa;
  var ret = "";
  var onlyNumericRegex = /[0-9.,-\s]+/;
  if (Array.isArray(dataItem) && dataItem.length > 0) {
    dataItem = {
      content: dataItem
    };
  }
  var hasValue = (_dataItem = dataItem) === null || _dataItem === void 0 ? void 0 : _dataItem.selected_value;
  if (!(preferSelectedValue && hasValue) && dataItem && Array.isArray(dataItem.content)) {
    ret = dataItem.content.reduce(function(acc, cur) {
      cur = (0,component_helper/* convertJsxToString */.F4)(cur, " ");
      if (cur === false) {
        return acc;
      }
      var found = removeNumericOnlyValues && cur && cur.match(onlyNumericRegex);
      if (!(found && found[0].length === cur.length)) {
        acc.push(cur);
      }
      return acc;
    }, []).join(separator);
  } else {
    ret = (0,component_helper/* convertJsxToString */.F4)(dataItem && dataItem.content || dataItem, " ");
  }
  if (hasValue) {
    if (preferSelectedValue) {
      ret = String((0,component_helper/* convertJsxToString */.F4)(dataItem.selected_value));
    } else if (!onlyNumericRegex.test(dataItem.selected_value)) {
      ret = String((0,component_helper/* convertJsxToString */.F4)(dataItem.selected_value)) + separator + ret;
    }
  }
  if (Array.isArray(dataItem) && dataItem.length === 0) {
    ret = null;
  }
  if (ret && ret.length === 1 && ret[0].ignore_events) {
    return null;
  }
  return ret;
};
var hasObjectKeyAsValue = function hasObjectKeyAsValue2(data) {
  var _data;
  data = ((_data = data) === null || _data === void 0 ? void 0 : _data.raw_data) || data;
  return data && (0,esm_typeof/* default */.Z)(data) === "object" && !Array.isArray(data);
};
var preSelectData = function preSelectData2(data) {
  if (typeof data === "string") {
    data = data[0] === "{" || data[0] === "[" ? JSON.parse(data) : null;
  } else if (data && react.isValidElement(data)) {
    data = [];
  } else if (typeof data === "function") {
    data = data();
  }
  return data;
};
var normalizeData = function normalizeData2(props) {
  var data = preSelectData(props.data || props.children || props);
  if (data && (0,esm_typeof/* default */.Z)(data) === "object" && !Array.isArray(data)) {
    var list = [];
    for (var i in data) {
      list.push({
        selected_key: i,
        value: i,
        content: data[i],
        type: "object"
      });
    }
    data = list;
  }
  return (data || []).map(function(item, __id) {
    if (typeof item === "string" || Array.isArray(item) || react.isValidElement(item)) {
      item = {
        content: item,
        __isTransformed: true
      };
    }
    return typeof item.__id !== "undefined" ? item : (0,esm_extends/* default */.Z)({}, item, {
      __id
    });
  });
};
var getData = function getData2(props) {
  if (props.prepared_data && Array.isArray(props.prepared_data)) {
    return props.prepared_data;
  }
  return normalizeData(props);
};
var getCurrentIndex = function getCurrentIndex2(value, data) {
  if (/[^0-9]/.test(String(value))) {
    return data === null || data === void 0 ? void 0 : data.findIndex(function(cur) {
      return parseCurrentValue(cur) === value;
    });
  } else if (parseFloat(value) > -1) {
    return value;
  }
  return null;
};
var getSelectedItemValue = function getSelectedItemValue2(value, state) {
  if (hasObjectKeyAsValue(state)) {
    return parseCurrentValue(state.data.filter(function(_, i) {
      return i === parseFloat(value);
    })[0]);
  }
  return value;
};
var parseCurrentValue = function parseCurrentValue2(current) {
  if (typeof (current === null || current === void 0 ? void 0 : current.selected_key) !== "undefined") {
    return current === null || current === void 0 ? void 0 : current.selected_key;
  }
  if (typeof (current === null || current === void 0 ? void 0 : current.content) !== "undefined") {
    return current === null || current === void 0 ? void 0 : current.content;
  }
  return current;
};
var getEventData = function getEventData2(item_index, data) {
  data = getCurrentData(item_index, data);
  if (data && data.__id) {
    data = (0,esm_extends/* default */.Z)({}, data);
    delete data.__id;
    delete data.__isTransformed;
  }
  return data;
};
var getCurrentData = function getCurrentData2(item_index, data) {
  if (typeof data === "function") {
    data = normalizeData(data);
  }
  data = data && data.find(function(_ref2) {
    var __id = _ref2.__id;
    return __id == item_index;
  }) || null;
  if (data && data.__isTransformed) {
    data = parseCurrentValue(data);
  }
  return data;
};
var prepareStartupState = function prepareStartupState2(props) {
  var raw_data = preSelectData(props.raw_data || props.data || props.children);
  var data = getData(props);
  var opened = props.opened !== null ? (0,component_helper/* isTrue */.oA)(props.opened) : null;
  var selected_item = null;
  if (props.value !== null && typeof props.value !== "undefined" && props.value !== "initval") {
    selected_item = getCurrentIndex(props.value, data);
  } else if (props.default_value !== null) {
    selected_item = getCurrentIndex(props.default_value, data);
  }
  return {
    opened,
    data,
    init_data: props.data,
    original_data: data,
    raw_data,
    direction: props.direction,
    max_height: props.max_height,
    selected_item,
    active_item: selected_item,
    on_hide: props.on_hide,
    on_show: props.on_show,
    on_chnage: props.on_chnage,
    on_select: props.on_select,
    _listenForPropChanges: false
  };
};
var prepareDerivedState = function prepareDerivedState2(props, state) {
  if (state.opened && !state.data && typeof props.data === "function") {
    state.data = getData(props);
  }
  if (state._listenForPropChanges) {
    if (props.data && props.data !== state.init_data) {
      state.data = getData(props);
      state.init_data = props.data;
    }
    state.usePortal = props.skip_portal !== null ? !(0,component_helper/* isTrue */.oA)(props.skip_portal) : true;
    if (typeof props.wrapper_element === "string" && typeof document !== "undefined") {
      var wrapper_element = document.querySelector(props.wrapper_element);
      if (wrapper_element) {
        state.wrapper_element = wrapper_element;
      }
    } else if (props.wrapper_element) {
      state.wrapper_element = props.wrapper_element;
    }
    if (typeof props.value !== "undefined" && props.value !== "initval" && state.selected_item !== props.value && (state._value !== props.value || (0,component_helper/* isTrue */.oA)(props.prevent_selection))) {
      state.selected_item = getCurrentIndex(props.value, state.data);
      if (typeof props.on_state_update === "function") {
        (0,component_helper/* dispatchCustomElementEvent */.RW)({
          props
        }, "on_state_update", {
          selected_item: state.selected_item,
          value: getSelectedItemValue(state.selected_item, state),
          data: getEventData(state.selected_item, state.data)
        });
      }
    }
    if (!(parseFloat(state.active_item) > -1)) {
      state.active_item = state.selected_item;
    }
    if (props.direction !== "auto" && props.direction !== state.direction) {
      state.direction = props.direction;
    }
    if (parseFloat(state.selected_item) > -1) {
      state.current_title = getCurrentDataTitle(state.selected_item, state.data);
    }
  }
  state._value = props.value;
  state._listenForPropChanges = true;
  return state;
};
var getCurrentDataTitle = function getCurrentDataTitle2(selected_item, data) {
  var currentData = getCurrentData(selected_item, data);
  return parseContentTitle(currentData, {
    separator: " ",
    preferSelectedValue: true
  });
};
var findClosest = function findClosest2(arr, val) {
  return Math.max.apply(null, arr.filter(function(v) {
    return v <= val;
  }));
};

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/libs/bodyScrollLock.js
var bodyScrollLock = __webpack_require__(7927);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/fragments/drawer-list/DrawerListProvider.js










function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}









var DrawerListProvider = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(DrawerListProvider2, _React$PureComponent);
  var _super = _createSuper(DrawerListProvider2);
  function DrawerListProvider2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, DrawerListProvider2);
    _this = _super.call(this, props);
    _this.enableBodyLock = function() {
      if (_this._refUl.current) {
        _this._bodyLockIsEnabled = true;
        (0,bodyScrollLock/* disableBodyScroll */.Qp)(_this._refUl.current);
      }
    };
    _this.disableBodyLock = function() {
      if (_this._bodyLockIsEnabled && _this._refUl.current) {
        _this._bodyLockIsEnabled = null;
        (0,bodyScrollLock/* enableBodyScroll */.tG)(_this._refUl.current);
      }
    };
    _this.scrollToItem = function(active_item) {
      var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$scrollTo = _ref.scrollTo, scrollTo = _ref$scrollTo === void 0 ? true : _ref$scrollTo;
      clearTimeout(_this._scrollTimeout);
      _this._scrollTimeout = setTimeout(function() {
        if (_this._refUl.current && parseFloat(active_item) > -1) {
          try {
            var ulElement = _this._refUl.current;
            var liElement = _this.getActiveElement();
            if (liElement) {
              var top = liElement.offsetTop;
              if (ulElement.scrollTo) {
                if (scrollTo === false || window.IS_TEST) {
                  ulElement.style.scrollBehavior = "auto";
                }
                ulElement.scrollTo({
                  top,
                  behavior: scrollTo ? "smooth" : "auto"
                });
                if (scrollTo === false) {
                  ulElement.style.scrollBehavior = "smooth";
                }
              } else if (ulElement.scrollTop) {
                ulElement.scrollTop = top;
              }
              if (!(0,component_helper/* isTrue */.oA)(_this.props.prevent_focus) && liElement) {
                liElement.focus();
                (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_show_focus", {
                  element: liElement
                });
              }
            }
          } catch (e) {
            (0,component_helper/* warn */.ZK)("List could not scroll into element:", e);
          }
        }
      }, 1);
    };
    _this.scrollToAndSetActiveItem = function(active_item) {
      var _ref2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref2$fireSelectEvent = _ref2.fireSelectEvent, fireSelectEvent = _ref2$fireSelectEvent === void 0 ? false : _ref2$fireSelectEvent, _ref2$scrollTo = _ref2.scrollTo, scrollTo = _ref2$scrollTo === void 0 ? true : _ref2$scrollTo, _ref2$event = _ref2.event, event = _ref2$event === void 0 ? null : _ref2$event;
      if (parseFloat(active_item) > -1) {
        _this.setState({
          active_item,
          _listenForPropChanges: false
        }, function() {
          var selected_item = _this.state.selected_item;
          if (fireSelectEvent) {
            var attributes = _this.attributes;
            var ret = (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_select", {
              active_item,
              value: getSelectedItemValue(selected_item, _this.state),
              data: getEventData(active_item, _this.state.data),
              event,
              attributes
            });
            if (ret === false) {
              return;
            }
          }
          _this.scrollToItem(active_item, {
            scrollTo
          });
        });
      } else if (!(0,component_helper/* isTrue */.oA)(_this.props.prevent_focus)) {
        if (_this._refUl.current) {
          _this._refUl.current.focus({
            preventScroll: true
          });
          (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_show_focus", {
            element: _this._refUl.current
          });
        }
      }
    };
    _this.setWrapperElement = function() {
      var wrapper_element = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : _this.props.wrapper_element;
      if (typeof wrapper_element === "string" && typeof document !== "undefined") {
        wrapper_element = document.querySelector(wrapper_element);
      }
      if (wrapper_element !== _this.state.wrapper_element) {
        _this.setState({
          wrapper_element,
          _listenForPropChanges: false
        }, _this.setOutsideClickObserver);
      }
      return (0,assertThisInitialized/* default */.Z)(_this);
    };
    _this.anchorKeyDownHandler = function(e) {
      var key = keycode(e);
      switch (key) {
        case "tab":
          try {
            var nextEl = _this.meta.shift ? e.target.previousSibling : e.target.nextSibling;
            e.stopPropagation();
            e.preventDefault();
            if (nextEl) {
              _this.focusAnchorElem(nextEl);
            } else {
              _this.getActiveElement().focus();
            }
          } catch (e2) {
          }
          break;
        case "enter":
        case "space":
          e.stopPropagation();
          break;
        default:
          break;
      }
    };
    _this.setMetaKey = function(e) {
      var we = typeof window !== "undefined" && window.event ? window.event : e;
      _this.meta = {
        cmd: we.metaKey,
        ctrl: we.ctrlKey,
        shift: we.shiftKey,
        alt: we.altKey
      };
    };
    _this.onKeyUpHandler = function(e) {
      _this.setMetaKey(e);
    };
    _this.onKeyDownHandler = function(e) {
      var key = keycode(e);
      if (/command|alt|shift|ctrl/.test(key)) {
        _this.setMetaKey(e);
      }
      if ((0,component_helper/* isTrue */.oA)(_this.props.prevent_close)) {
        var isSameDrawer = false;
        try {
          isSameDrawer = typeof document !== "undefined" && "".concat(document.activeElement.getAttribute("id"), "-ul") === _this._refUl.current.getAttribute("id");
        } catch (e2) {
          (0,component_helper/* warn */.ZK)(e2);
        }
        if (!isSameDrawer || key === "tab") {
          return;
        }
      }
      if ((0,component_helper/* isTrue */.oA)(_this.state.ignore_events) && key !== "tab") {
        return;
      }
      if (!_this.state.isOpen) {
        return;
      }
      var active_item = parseFloat(_this.state.active_item);
      if (isNaN(active_item)) {
        active_item = -1;
      }
      var total = _this.state.data && _this.state.data.length - 1;
      switch (key) {
        case "up":
          {
            e.preventDefault();
            active_item = _this.getPrevActiveItem();
            if (isNaN(active_item)) {
              active_item = _this.getFirstItem() || 0;
            }
          }
          break;
        case "down":
          {
            e.preventDefault();
            var activeItem = _this.getCurrentActiveItem();
            if (active_item === -1 || isNaN(activeItem)) {
              active_item = _this.getFirstItem() || 0;
            } else {
              active_item = _this.getNextActiveItem();
            }
          }
          break;
        case "page up":
        case "home":
          {
            e.preventDefault();
            active_item = _this.getFirstItem() || 0;
          }
          break;
        case "page down":
        case "end":
          {
            e.preventDefault();
            active_item = _this.getLastItem();
            if (isNaN(active_item)) {
              active_item = total;
            }
          }
          break;
        case "enter":
        case "space":
          {
            active_item = _this.getCurrentActiveItem();
            if ((0,component_helper/* isTrue */.oA)(_this.props.skip_keysearch) ? active_item > -1 && key !== "space" : true) {
              e.preventDefault();
              _this.selectItem(active_item, {
                fireSelectEvent: true,
                event: e
              });
            }
          }
          break;
        case "esc":
          {
            _this.setHidden({
              event: e
            });
            e.preventDefault();
          }
          break;
        case "tab":
          {
            if (active_item > -1) {
              var anchorElem = _this.getAnchorElem();
              if (anchorElem) {
                e.preventDefault();
                _this.focusAnchorElem(anchorElem);
                return;
              }
            }
            _this.setHidden({
              event: e
            });
          }
          break;
        default:
          active_item = _this.findItemByValue(keycode(e));
          break;
      }
      if (parseFloat(active_item) > -1 && active_item !== _this.state.active_item) {
        _this.scrollToAndSetActiveItem(active_item, {
          fireSelectEvent: true,
          event: e
        });
      }
    };
    _this.getSelectedElement = function() {
      var _this$_refUl$current;
      return ((_this$_refUl$current = _this._refUl.current) === null || _this$_refUl$current === void 0 ? void 0 : _this$_refUl$current.querySelector("li.dnb-drawer-list__option--selected")) || _this._refUl.current || {
        getAttribute: function getAttribute() {
          return null;
        }
      };
    };
    _this.getCurrentSelectedItem = function() {
      var elem = _this.getSelectedElement();
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.getActiveElement = function() {
      var _this$_refUl$current2;
      return ((_this$_refUl$current2 = _this._refUl.current) === null || _this$_refUl$current2 === void 0 ? void 0 : _this$_refUl$current2.querySelector("li.dnb-drawer-list__option--focus")) || _this.getSelectedElement();
    };
    _this.getCurrentActiveItem = function() {
      var elem = _this.getActiveElement();
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.getNextActiveItem = function() {
      var elem = _this.getActiveElement().nextSibling;
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.getPrevActiveItem = function() {
      var elem = _this.getActiveElement().previousSibling;
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.getFirstItem = function() {
      var _this$_refUl$current3;
      var elem = (_this$_refUl$current3 = _this._refUl.current) === null || _this$_refUl$current3 === void 0 ? void 0 : _this$_refUl$current3.querySelector("li.dnb-drawer-list__option.first-of-type");
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.getLastItem = function() {
      var _this$_refUl$current4;
      var elem = (_this$_refUl$current4 = _this._refUl.current) === null || _this$_refUl$current4 === void 0 ? void 0 : _this$_refUl$current4.querySelector("li.dnb-drawer-list__option.last-of-type");
      return parseFloat(elem && elem.getAttribute("data-item"));
    };
    _this.setOutsideClickObserver = function() {
      _this.removeOutsideClickObserver();
      _this.outsideClick = (0,component_helper/* detectOutsideClick */.J3)([_this.state.wrapper_element, _this._refRoot.current, _this._refUl.current], function() {
        return _this.setHidden({
          preventHideFocus: true
        });
      }, {
        includedKeys: ["tab"]
      });
      if (typeof document !== "undefined") {
        document.addEventListener("keydown", _this.onKeyDownHandler);
        document.addEventListener("keyup", _this.onKeyUpHandler);
      }
    };
    _this.addObservers = function() {
      _this.setDirectionObserver();
      _this.setScrollObserver();
      _this.setOutsideClickObserver();
    };
    _this.removeObservers = function() {
      _this.removeDirectionObserver();
      _this.removeScrollObserver();
      _this.removeOutsideClickObserver();
    };
    _this.setVisible = function() {
      clearTimeout(_this._hideTimeout);
      if (_this.state.opened && _this.state.hidden === false) {
        return;
      }
      _this.searchCache = null;
      var handleSingleComponentCheck = function handleSingleComponentCheck2() {
        _this.setState({
          hidden: false,
          opened: true,
          _listenForPropChanges: false
        });
        var animationDelayHandler = function animationDelayHandler2() {
          _this.setState({
            isOpen: true,
            _listenForPropChanges: false
          });
        };
        if ((0,component_helper/* isTrue */.oA)(_this.props.no_animation)) {
          animationDelayHandler();
        } else {
          DrawerListProvider2.isOpen = true;
          clearTimeout(_this._hideTimeout);
          _this._hideTimeout = setTimeout(animationDelayHandler, DrawerListProvider2.blurDelay);
        }
        var _this$state = _this.state, selected_item = _this$state.selected_item, active_item = _this$state.active_item;
        (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_show", {
          data: getEventData(parseFloat(selected_item) > -1 ? selected_item : active_item, _this.state.data),
          attributes: _this.attributes,
          ulElement: _this._refUl.current
        });
      };
      if (DrawerListProvider2.isOpen) {
        clearTimeout(_this._hideTimeout);
        _this._hideTimeout = setTimeout(handleSingleComponentCheck, DrawerListProvider2.blurDelay);
      } else {
        handleSingleComponentCheck();
      }
    };
    _this.setHidden = function() {
      var args = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var onStateComplete = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      if (!_this.state.opened || (0,component_helper/* isTrue */.oA)(_this.props.prevent_close)) {
        if (typeof onStateComplete === "function") {
          onStateComplete();
        }
        return;
      }
      clearTimeout(_this._hideTimeout);
      var _this$state2 = _this.state, selected_item = _this$state2.selected_item, active_item = _this$state2.active_item;
      var res = (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_hide", (0,esm_extends/* default */.Z)({}, args, {
        data: getEventData(parseFloat(selected_item) > -1 ? selected_item : active_item, _this.state.data),
        attributes: _this.attributes
      }));
      if (res !== false) {
        _this.removeObservers();
        _this.setState({
          opened: false,
          _listenForPropChanges: false
        });
        var delayHandler = function delayHandler2() {
          _this.setState({
            hidden: true,
            isOpen: false,
            _listenForPropChanges: false
          });
          if (typeof onStateComplete === "function") {
            onStateComplete();
          }
          DrawerListProvider2.isOpen = false;
        };
        if ((0,component_helper/* isTrue */.oA)(_this.props.no_animation)) {
          delayHandler();
        } else {
          clearTimeout(_this._hideTimeout);
          _this._hideTimeout = setTimeout(delayHandler, DrawerListProvider2.blurDelay);
        }
      }
    };
    _this.setDataHandler = function(data) {
      var cb = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      var _ref3 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, _ref3$overwriteOrigin = _ref3.overwriteOriginalData, overwriteOriginalData = _ref3$overwriteOrigin === void 0 ? false : _ref3$overwriteOrigin;
      if (!data) {
        return;
      }
      if (typeof data === "function") {
        data = getData(data);
      }
      data = normalizeData(data);
      _this.setState({
        data,
        original_data: overwriteOriginalData ? data : _this.state.original_data,
        _listenForPropChanges: false
      }, function() {
        _this.refreshScrollObserver();
        typeof cb === "function" && cb(data);
      });
      return (0,assertThisInitialized/* default */.Z)(_this);
    };
    _this.setStateHandler = function(state) {
      var cb = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      _this.setState((0,esm_extends/* default */.Z)({}, state, {
        _listenForPropChanges: false
      }), cb);
      return (0,assertThisInitialized/* default */.Z)(_this);
    };
    _this.selectItem = function(itemToSelect) {
      var _ref4 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref4$fireSelectEvent = _ref4.fireSelectEvent, fireSelectEvent = _ref4$fireSelectEvent === void 0 ? false : _ref4$fireSelectEvent, _ref4$event = _ref4.event, event = _ref4$event === void 0 ? null : _ref4$event;
      if (event && typeof event.persist === "function") {
        event.persist();
      }
      if (itemToSelect === -1) {
        itemToSelect = null;
      }
      var data = getEventData(itemToSelect, _this.state.data) || null;
      var value = getSelectedItemValue(itemToSelect, _this.state);
      var attributes = _this.attributes;
      var attr = {
        selected_item: itemToSelect,
        value,
        data,
        event,
        attributes
      };
      var res = (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_pre_change", attr);
      if (res === false) {
        return;
      }
      if ((0,helpers/* hasSelectedText */.qF)()) {
        var elem = (0,helpers/* getSelectedElement */.BP)();
        var isInput = (0,component_helper/* getPreviousSibling */.U)("dnb-input", elem);
        if (!isInput) {
          return;
        }
      }
      var _this$props = _this.props, keep_open = _this$props.keep_open, no_animation = _this$props.no_animation, prevent_selection = _this$props.prevent_selection;
      var doCallOnChange = _this.state.selected_item !== itemToSelect;
      var onSelectionIsComplete = function onSelectionIsComplete2() {
        var delayHandler = function delayHandler2() {
          if (doCallOnChange) {
            (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_change", attr);
          }
          if (fireSelectEvent) {
            (0,component_helper/* dispatchCustomElementEvent */.RW)(_this.state, "on_select", (0,esm_extends/* default */.Z)({}, attr, {
              active_item: itemToSelect
            }));
          }
          if (!(0,component_helper/* isTrue */.oA)(keep_open)) {
            _this.setHidden();
          }
        };
        if ((0,component_helper/* isTrue */.oA)(no_animation)) {
          delayHandler();
        } else {
          clearTimeout(_this._selectTimeout);
          _this._selectTimeout = setTimeout(delayHandler, DrawerListProvider2.blurDelay / 2);
        }
      };
      if ((0,component_helper/* isTrue */.oA)(prevent_selection)) {
        onSelectionIsComplete();
      } else {
        _this.setState({
          _listenForPropChanges: false,
          selected_item: itemToSelect,
          active_item: itemToSelect
        }, onSelectionIsComplete);
      }
    };
    _this.attributes = {};
    _this.state = (0,esm_extends/* default */.Z)({
      tagName: "dnb-drawer-list",
      cache_hash: "",
      active_item: null,
      selected_item: null,
      ignore_events: false
    }, prepareStartupState(props), {
      _listenForPropChanges: true
    });
    _this._refRoot = react.createRef();
    _this._refShell = react.createRef();
    _this._refUl = react.createRef();
    _this._refTriangle = react.createRef();
    return _this;
  }
  (0,createClass/* default */.Z)(DrawerListProvider2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if ((0,component_helper/* isTrue */.oA)(this.props.opened)) {
        this.setVisible();
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.props.opened !== null && this.props.opened !== prevProps.opened) {
        if ((0,component_helper/* isTrue */.oA)(this.props.opened)) {
          this.setVisible();
        } else if ((0,component_helper/* isTrue */.oA)(this.props.opened) === false) {
          this.setHidden();
        }
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this._hideTimeout);
      clearTimeout(this._selectTimeout);
      clearTimeout(this._scrollTimeout);
      clearTimeout(this._ddTimeout);
      this.removeObservers();
    }
  }, {
    key: "refreshScrollObserver",
    value: function refreshScrollObserver() {
      var _this2 = this;
      if (typeof window === "undefined" || !this._refUl.current) {
        return;
      }
      this.itemSpots = this.state.data.reduce(function(acc, cur, i) {
        var _this2$_refUl$current;
        var element = (_this2$_refUl$current = _this2._refUl.current) === null || _this2$_refUl$current === void 0 ? void 0 : _this2$_refUl$current.querySelector("li.dnb-drawer-list__option:nth-of-type(".concat(i + 1, ")"));
        if (element) {
          acc[element.offsetTop] = {
            i
          };
        }
        return acc;
      }, {});
      this.itemSpotsCount = Object.keys(this.itemSpots).length;
    }
  }, {
    key: "setScrollObserver",
    value: function setScrollObserver() {
      var _this3 = this;
      if (!(0,component_helper/* isTrue */.oA)(this.props.enable_closest_observer) || typeof window === "undefined" || !this._refUl.current) {
        return;
      }
      this.removeScrollObserver();
      this.itemSpotsCount = 1;
      try {
        var closestToTop = null, closestToBottom = null, tmpToTop, tmpToBottom;
        this.setOnScroll = function() {
          if (!_this3._refUl.current) {
            return;
          }
          if (_this3.itemSpotsCount <= 1) {
            _this3.refreshScrollObserver();
          }
          var counts = Object.keys(_this3.itemSpots);
          closestToBottom = findClosest(counts, _this3._refUl.current.scrollTop + _this3._refUl.current.offsetHeight);
          closestToTop = findClosest(counts, _this3._refUl.current.scrollTop);
          if (_this3.itemSpots[closestToTop] && closestToTop !== tmpToTop) {
            _this3.setState({
              closestToTop: _this3.itemSpots[closestToTop].i,
              _listenForPropChanges: false
            });
          }
          if (closestToBottom !== tmpToBottom && _this3.itemSpots[closestToBottom]) {
            _this3.setState({
              closestToBottom: _this3.itemSpots[closestToBottom].i,
              _listenForPropChanges: false
            });
          }
          tmpToTop = closestToTop;
          tmpToBottom = closestToBottom;
        };
        this._refUl.current.addEventListener("scroll", this.setOnScroll);
        this.setOnScroll();
      } catch (e) {
        (0,component_helper/* warn */.ZK)("List could not set onScroll:", e);
      }
    }
  }, {
    key: "removeScrollObserver",
    value: function removeScrollObserver() {
      if (typeof window !== "undefined" && this.setOnScroll) {
        window.removeEventListener("resize", this.setOnScroll);
        this.setOnScroll = null;
      }
    }
  }, {
    key: "setDirectionObserver",
    value: function setDirectionObserver() {
      var _this4 = this;
      if (typeof window === "undefined" || typeof document === "undefined" || !(this.state.wrapper_element || this._refRoot.current)) {
        return;
      }
      var _this$props2 = this.props, enable_body_lock = _this$props2.enable_body_lock, use_drawer_on_mobile = _this$props2.use_drawer_on_mobile, scrollable = _this$props2.scrollable, min_height = _this$props2.min_height, max_height = _this$props2.max_height, on_resize = _this$props2.on_resize, page_offset = _this$props2.page_offset, observer_element = _this$props2.observer_element;
      var useBodyLock = (0,component_helper/* isTrue */.oA)(enable_body_lock);
      var useDrawer = (0,component_helper/* isTrue */.oA)(use_drawer_on_mobile);
      var isScrollable = (0,component_helper/* isTrue */.oA)(scrollable);
      var customMinHeight = parseFloat(min_height) * 16;
      var customMaxHeight = parseFloat(max_height) || 0;
      var customElem = typeof observer_element === "string" ? document.querySelector(observer_element) : null;
      if (!customElem) {
        customElem = (0,component_helper/* isInsideScrollView */.e0)(this._refRoot.current, true);
      }
      this.removeDirectionObserver();
      var directionOffset = 96;
      var spaceToTopOffset = 2 * 16;
      var spaceToBottomOffset = 2 * 16;
      var elem = this.state.wrapper_element || this._refRoot.current;
      var renderDirection = function renderDirection2() {
        try {
          var rootElem = customElem || document.documentElement;
          var pageYOffset = !isNaN(parseFloat(page_offset)) ? parseFloat(page_offset) : rootElem.scrollTop;
          var spaceToTop = (0,helpers/* getOffsetTop */.oJ)(elem) + elem.offsetHeight - pageYOffset;
          var spaceToBottom = rootElem.clientHeight - ((0,helpers/* getOffsetTop */.oJ)(elem) + elem.offsetHeight) + pageYOffset;
          var direction = Math.max(spaceToBottom - directionOffset, directionOffset) < customMinHeight && spaceToTop > customMinHeight ? "top" : "bottom";
          var _max_height = customMaxHeight;
          if (!(_max_height > 0)) {
            _max_height = direction === "top" ? spaceToTop - ((_this4.state.wrapper_element || _this4._refRoot.current).offsetHeight || 0) - spaceToTopOffset : spaceToBottom - spaceToBottomOffset;
            var vh = 0;
            if (typeof window.visualViewport !== "undefined") {
              vh = window.visualViewport.height;
            } else {
              vh = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
            }
            vh = vh * (isScrollable ? 0.7 : 0.9);
            if (_max_height > vh) {
              _max_height = vh;
            }
            _max_height = (0,component_helper/* roundToNearest */.Nm)(_max_height, 8) / 16;
          }
          if (_this4.props.direction === "auto") {
            _this4.setState({
              direction,
              _listenForPropChanges: false
            });
          }
          _this4.setState({
            max_height: _max_height,
            _listenForPropChanges: false
          });
          if (on_resize) {
            (0,component_helper/* dispatchCustomElementEvent */.RW)(_this4.state, "on_resize", {
              direction,
              max_height: _max_height
            });
          }
        } catch (e) {
          (0,component_helper/* warn */.ZK)("List could not set onResize:", e);
        }
      };
      this.setDirection = function(e) {
        clearTimeout(_this4._ddTimeout);
        _this4._ddTimeout = setTimeout(renderDirection, 30);
        if (useDrawer && e.type === "resize") {
          if (!_this4._bodyLockIsEnabled && (window.innerWidth / 16 <= 40 || window.innerHeight / 16 <= 40)) {
            _this4.enableBodyLock();
          } else if (_this4._bodyLockIsEnabled && !useBodyLock) {
            _this4.disableBodyLock();
          }
        }
        if (e.type === "resize") {
          _this4.correctHiddenView();
        }
      };
      this._rootElem = customElem || window;
      this._rootElem.addEventListener("scroll", this.setDirection);
      if (typeof window.visualViewport !== "undefined") {
        window.visualViewport.addEventListener("scroll", this.setDirection);
        window.visualViewport.addEventListener("resize", this.setDirection);
      } else {
        window.addEventListener("resize", this.setDirection);
      }
      if (useBodyLock || useDrawer && (window.innerWidth / 16 <= 40 || window.innerHeight / 16 <= 40)) {
        this.enableBodyLock();
      }
      this.correctHiddenView();
      this.refreshScrollObserver();
      var _this$state3 = this.state, selected_item = _this$state3.selected_item, active_item = _this$state3.active_item;
      this.scrollToAndSetActiveItem(parseFloat(active_item) > -1 ? active_item : selected_item, {
        scrollTo: false
      });
      renderDirection();
    }
  }, {
    key: "correctHiddenView",
    value: function correctHiddenView() {
      try {
        var ui = this._refUl.current;
        var spaceToLeft = (0,helpers/* getOffsetLeft */.pB)(ui);
        var spaceToRight = window.innerWidth - ((0,helpers/* getOffsetLeft */.pB)(ui) + ui.offsetWidth);
        var tri = this._refTriangle.current.style;
        var shell = this._refShell.current.style;
        if (spaceToLeft < 0) {
          shell.transform = "translateX(".concat(Math.abs(spaceToLeft), "px)");
          tri.right = "".concat(Math.abs(spaceToLeft), "px");
        } else if (spaceToRight < 0) {
          shell.transform = "translateX(".concat(spaceToRight, "px)");
          tri.left = "".concat(Math.abs(spaceToRight), "px");
        } else {
          if (shell.transform) {
            shell.transform = "";
            tri.left = "auto";
            tri.right = "auto";
          }
        }
      } catch (e) {
      }
    }
  }, {
    key: "findItemByValue",
    value: function findItemByValue(value) {
      if ((0,component_helper/* isTrue */.oA)(this.props.skip_keysearch)) {
        return;
      }
      var index = -1;
      try {
        value = String(value).toLowerCase();
        if (this.changedOrderFor !== value) {
          this.searchCache = null;
          this.changedOrderFor = null;
        }
        this.searchCache = this.searchCache || this.state.data.reduce(function(acc, itemData, i) {
          var str = String(parseContentTitle(itemData, {
            separator: " ",
            removeNumericOnlyValues: true
          }));
          var firstLetter = String(str[0]).toLowerCase();
          acc[firstLetter] = acc[firstLetter] || [];
          acc[firstLetter].push({
            i
          });
          return acc;
        }, {});
        var found = this.searchCache[value];
        index = found && found[0] && found[0].i > -1 ? found[0].i : -1;
        if (found && found.length > 1) {
          found.push(found.shift());
          this.changedOrderFor = value;
        }
      } catch (e) {
        (0,component_helper/* warn */.ZK)("List could not findItemByValue:", e);
      }
      return index;
    }
  }, {
    key: "removeDirectionObserver",
    value: function removeDirectionObserver() {
      this.disableBodyLock();
      clearTimeout(this._ddTimeout);
      if (typeof window !== "undefined" && this.setDirection) {
        var _this$_rootElem;
        (_this$_rootElem = this._rootElem) === null || _this$_rootElem === void 0 ? void 0 : _this$_rootElem.removeEventListener("scroll", this.setDirection);
        if (typeof window.visualViewport !== "undefined") {
          window.visualViewport.removeEventListener("scroll", this.setDirection);
          window.visualViewport.removeEventListener("resize", this.setDirection);
        } else {
          window.removeEventListener("resize", this.setDirection);
        }
        this.setDirection = null;
      }
    }
  }, {
    key: "getAnchorElem",
    value: function getAnchorElem() {
      try {
        return this.getActiveElement().querySelector("a:not(:focus):first-of-type");
      } catch (e) {
        return null;
      }
    }
  }, {
    key: "focusAnchorElem",
    value: function focusAnchorElem(elem) {
      if (elem) {
        elem.focus({
          preventScroll: true
        });
        if (!elem._hkh) {
          elem._hkh = true;
          elem.addEventListener("keydown", this.anchorKeyDownHandler);
        }
      }
    }
  }, {
    key: "removeOutsideClickObserver",
    value: function removeOutsideClickObserver() {
      if (this.outsideClick) {
        this.outsideClick.remove();
      }
      if (typeof document !== "undefined") {
        document.removeEventListener("keydown", this.onKeyDownHandler);
        document.removeEventListener("keyup", this.onKeyUpHandler);
      }
    }
  }, {
    key: "render",
    value: function render() {
      return react.createElement(drawer_list_DrawerListContext.Provider, {
        value: (0,esm_extends/* default */.Z)({}, this.context, {
          drawerList: (0,esm_extends/* default */.Z)({
            attributes: this.attributes,
            _refRoot: this._refRoot,
            _refShell: this._refShell,
            _refUl: this._refUl,
            _refTriangle: this._refTriangle,
            _rootElem: this._rootElem,
            getActiveElement: this.getActiveElement,
            setData: this.setDataHandler,
            setState: this.setStateHandler,
            setWrapperElement: this.setWrapperElement,
            addObservers: this.addObservers,
            removeObservers: this.removeObservers,
            setVisible: this.setVisible,
            setHidden: this.setHidden,
            selectItem: this.selectItem,
            scrollToItem: this.scrollToItem,
            scrollToAndSetActiveItem: this.scrollToAndSetActiveItem
          }, this.state)
        })
      }, this.props.children);
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      return prepareDerivedState(props, state);
    }
  }]);
  return DrawerListProvider2;
}(react.PureComponent);
DrawerListProvider.contextType = Context/* default */.Z;
DrawerListProvider.defaultProps = {
  no_animation: false,
  prevent_selection: false,
  direction: "auto",
  wrapper_element: null,
  prevent_close: false,
  keep_open: false,
  prevent_focus: false,
  skip_keysearch: false,
  use_drawer_on_mobile: null,
  enable_body_lock: null,
  page_offset: null,
  observer_element: null,
  enable_closest_observer: null,
  opened: null,
  scrollable: null,
  min_height: 10,
  max_height: null,
  on_resize: null,
  children: null
};
DrawerListProvider.blurDelay = 201;

 false ? 0 : void 0;

// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(7888);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/fragments/drawer-list/DrawerListPortal.js







function DrawerListPortal_createSuper(Derived) {
  var hasNativeReflectConstruct = DrawerListPortal_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function DrawerListPortal_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var DrawerListPortal = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(DrawerListPortal2, _React$PureComponent);
  var _super = DrawerListPortal_createSuper(DrawerListPortal2);
  function DrawerListPortal2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, DrawerListPortal2);
    _this = _super.call(this, props);
    _this.init = function() {
      _this.portalElem = _this.useRootElement();
      if (_this._isMounted) {
        _this.renderPortal();
      }
    };
    _this.renderPortal = function() {
      var _this$props = _this.props, opened = _this$props.opened, fixed_position = _this$props.fixed_position, use_drawer_on_mobile = _this$props.use_drawer_on_mobile, className = _this$props.className, children = _this$props.children;
      if (!_this.portalElem) {
        return;
      }
      if (opened) {
        _this.addPositionObserver();
      }
      var style = opened ? _this.makeStyle() : {};
      react_dom.render(react.createElement("span", {
        className: classnames("dnb-drawer-list__portal__style", className, fixed_position && "dnb-drawer-list__portal__style--fixed", use_drawer_on_mobile && "dnb-drawer-list__portal__style--mobile-view"),
        style,
        ref: _this.ref
      }, children), _this.portalElem);
    };
    _this.ref = props.innerRef || react.createRef();
    return _this;
  }
  (0,createClass/* default */.Z)(DrawerListPortal2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this._isMounted = true;
      if (document.readyState === "complete") {
        this.init();
      } else if (typeof window !== "undefined") {
        window.addEventListener("load", this.init);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this._isMounted = false;
      if (typeof window !== "undefined") {
        window.removeEventListener("load", this.init);
      }
      this.removePositionObserver();
      react_dom.unmountComponentAtNode(this.portalElem);
      if (typeof document !== "undefined") {
        try {
          document.body.removeChild(this.portalElem);
        } catch (e) {
        }
        this.portalElem = null;
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this._isMounted && this.portalElem && (this.props.opened || prevProps.opened)) {
        this.renderPortal();
      }
    }
  }, {
    key: "useRootElement",
    value: function useRootElement() {
      if (typeof document !== "undefined") {
        try {
          var elem = document.getElementById("".concat(this.props.id, "-portal"));
          if (elem) {
            return elem;
          }
          elem = document.createElement("div");
          elem.setAttribute("id", "".concat(this.props.id, "-portal"));
          elem.classList.add("dnb-drawer-list__portal");
          this.createMainElement().appendChild(elem);
          return elem;
        } catch (e) {
          (0,component_helper/* warn */.ZK)(e);
        }
      }
    }
  }, {
    key: "createMainElement",
    value: function createMainElement() {
      if (typeof document !== "undefined") {
        try {
          var elem = document.getElementById("dnb-drawer-list__portal");
          if (elem) {
            return elem;
          }
          elem = document.createElement("div");
          elem.setAttribute("role", "presentation");
          elem.setAttribute("id", "dnb-drawer-list__portal");
          elem.classList.add("dnb-core-style");
          document.body.appendChild(elem);
          return elem;
        } catch (e) {
          (0,component_helper/* warn */.ZK)(e);
        }
      }
    }
  }, {
    key: "makeStyle",
    value: function makeStyle() {
      if (typeof window === "undefined" || !this._isMounted) {
        return;
      }
      try {
        var _this$props2 = this.props, rootRef = _this$props2.rootRef, include_owner_width = _this$props2.include_owner_width, independent_width = _this$props2.independent_width, fixed_position = _this$props2.fixed_position;
        var rootElem = rootRef.current;
        if (!rootElem) {
          return;
        }
        var ownerElem = rootElem.parentElement;
        var width = 64;
        var ownerWidth = window.getComputedStyle(ownerElem).width;
        if (independent_width || parseFloat(ownerWidth) < 64) {
          var minWidth = parseFloat(window.getComputedStyle(document.documentElement).getPropertyValue("--drawer-list-width"));
          width = minWidth * 16;
        }
        var customWidth = rootElem.getBoundingClientRect().width;
        if (parseFloat(customWidth || 0) >= 64) {
          width = customWidth;
        }
        var rect = rootElem.getBoundingClientRect();
        var scrollY = fixed_position ? 0 : window.scrollY !== void 0 ? window.scrollY : window.pageYOffset;
        var scrollX = fixed_position ? 0 : window.scrollX !== void 0 ? window.scrollX : window.pageXOffset;
        var top = scrollY + rect.top;
        var left = scrollX + rect.left + (include_owner_width ? parseFloat(ownerWidth || 0) : 0);
        if (width > window.innerWidth) {
          width = window.innerWidth;
        }
        var style = {
          width,
          "--drawer-list-width": "".concat(width / 16, "rem"),
          top,
          left
        };
        return style;
      } catch (e) {
        (0,component_helper/* warn */.ZK)(e);
      }
    }
  }, {
    key: "addPositionObserver",
    value: function addPositionObserver() {
      var _this2 = this;
      if (this.setPosition || typeof window === "undefined") {
        return;
      }
      this.setPosition = function() {
        clearTimeout(_this2._ddt);
        _this2._ddt = setTimeout(_this2.renderPortal, 30);
      };
      this.customElem = (0,component_helper/* isInsideScrollView */.e0)(this.props.rootRef.current, true);
      if (this.customElem) {
        this.customElem.addEventListener("scroll", this.setPosition);
      }
      try {
        this.resizeObserver = new ResizeObserver(this.setPosition);
        this.resizeObserver.observe(document.body);
      } catch (e) {
        window.addEventListener("resize", this.setPosition);
      }
    }
  }, {
    key: "removePositionObserver",
    value: function removePositionObserver() {
      clearTimeout(this._ddt);
      if (typeof window !== "undefined" && this.setPosition) {
        if (this.customElem) {
          this.customElem.removeEventListener("scroll", this.setPosition);
        }
        if (this.resizeObserver) {
          this.resizeObserver.disconnect();
          this.resizeObserver = null;
        }
        window.removeEventListener("resize", this.setPosition);
      }
      this.setPosition = null;
    }
  }, {
    key: "render",
    value: function render() {
      return null;
    }
  }]);
  return DrawerListPortal2;
}(react.PureComponent);
DrawerListPortal.defaultProps = {
  rootRef: {
    current: null
  },
  innerRef: null,
  include_owner_width: false,
  independent_width: false,
  fixed_position: false,
  use_drawer_on_mobile: false,
  className: null
};
 false ? 0 : void 0;
/* harmony default export */ const drawer_list_DrawerListPortal = (react.forwardRef(function(props, ref) {
  return react.createElement(DrawerListPortal, (0,esm_extends/* default */.Z)({
    innerRef: ref
  }, props));
}));

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/fragments/drawer-list/DrawerList.js













function DrawerList_createSuper(Derived) {
  var hasNativeReflectConstruct = DrawerList_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function DrawerList_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}









var propsToFilterOut = {
  on_show: null,
  on_hide: null,
  on_change: null,
  on_pre_change: null,
  on_resize: null,
  on_select: null,
  on_state_update: null,
  options_render: null,
  wrapper_element: null
};
var DrawerList = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(DrawerList2, _React$PureComponent);
  var _super = DrawerList_createSuper(DrawerList2);
  function DrawerList2() {
    (0,classCallCheck/* default */.Z)(this, DrawerList2);
    return _super.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(DrawerList2, [{
    key: "render",
    value: function render() {
      var _this$context;
      var hasProvider = (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.drawerList;
      if (hasProvider) {
        return react.createElement(DrawerListInstance, this.props);
      }
      return react.createElement(DrawerListProvider, (0,esm_extends/* default */.Z)({}, this.props, {
        data: this.props.data || this.props.children
      }), react.createElement(DrawerListInstance, this.props));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(DrawerList2.tagName, DrawerList2, DrawerList2.defaultProps);
    }
  }]);
  return DrawerList2;
}(react.PureComponent);
DrawerList.tagName = "dnb-drawer-list";
DrawerList.contextType = drawer_list_DrawerListContext;
DrawerList.defaultProps = {
  id: null,
  role: "listbox",
  cache_hash: null,
  triangle_position: "left",
  scrollable: true,
  focusable: false,
  max_height: null,
  direction: "auto",
  size: "default",
  no_animation: false,
  no_scroll_animation: false,
  use_drawer_on_mobile: false,
  prevent_selection: false,
  action_menu: false,
  is_popup: false,
  align_drawer: "left",
  wrapper_element: null,
  default_value: null,
  value: "initval",
  portal_class: null,
  list_class: null,
  skip_portal: null,
  prevent_close: false,
  keep_open: false,
  prevent_focus: false,
  fixed_position: false,
  independent_width: false,
  skip_keysearch: false,
  opened: null,
  class: null,
  data: null,
  prepared_data: null,
  raw_data: null,
  ignore_events: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_show: null,
  on_hide: null,
  on_change: null,
  on_pre_change: null,
  on_resize: null,
  on_select: null,
  on_state_update: null,
  options_render: null
};

 false ? 0 : void 0;
var DrawerListInstance = function(_React$PureComponent2) {
  (0,inherits/* default */.Z)(DrawerListInstance2, _React$PureComponent2);
  var _super2 = DrawerList_createSuper(DrawerListInstance2);
  function DrawerListInstance2(props, context) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, DrawerListInstance2);
    _this = _super2.call(this, props);
    _this.preventTab = function(e) {
      switch (keycode(e)) {
        case "tab":
          _this.context.drawerList.setHidden();
          break;
        case "page down":
        case "page up":
          e.preventDefault();
          break;
      }
    };
    _this.selectItemHandler = function(event) {
      var selected_item = parseFloat(event.currentTarget.getAttribute("data-item"));
      if (selected_item > -1) {
        _this.context.drawerList.selectItem(selected_item, {
          fireSelectEvent: true,
          event
        });
      }
    };
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this.state = _this.state || {};
    context.drawerList.setState(Object.entries(propsToFilterOut).reduce(function(acc, _ref) {
      var _ref2 = (0,slicedToArray/* default */.Z)(_ref, 1), key = _ref2[0];
      if (props[key]) {
        acc[key] = props[key];
      }
      return acc;
    }, {}));
    context.drawerList.setState({
      triangle_position: props.triangle_position
    });
    return _this;
  }
  (0,createClass/* default */.Z)(DrawerListInstance2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, DrawerList.defaultProps, this.context.getTranslation(this.props).DrawerList, this.context.FormRow, this.context.DrawerList);
      var role = props.role, align_drawer = props.align_drawer, fixed_position = props.fixed_position, use_drawer_on_mobile = props.use_drawer_on_mobile, independent_width = props.independent_width, scrollable = props.scrollable, focusable = props.focusable, size = props.size, no_animation = props.no_animation, no_scroll_animation = props.no_scroll_animation, prevent_selection = props.prevent_selection, action_menu = props.action_menu, is_popup = props.is_popup, portal_class = props.portal_class, list_class = props.list_class, ignore_events = props.ignore_events, options_render = props.options_render, className = props.className, _className = props.class, _cache_hash = props.cache_hash, _wrapper_element = props.wrapper_element, _triangle_position = props.triangle_position, _direction = props.direction, _max_height = props.max_height, _id = props.id, _data = props.data, _prepared_data = props.prepared_data, _raw_data = props.raw_data, _opened = props.opened, _value = props.value, children = props.children, attributes = (0,objectWithoutProperties/* default */.Z)(props, ["role", "align_drawer", "fixed_position", "use_drawer_on_mobile", "independent_width", "scrollable", "focusable", "size", "no_animation", "no_scroll_animation", "prevent_selection", "action_menu", "is_popup", "portal_class", "list_class", "ignore_events", "options_render", "className", "class", "cache_hash", "wrapper_element", "triangle_position", "direction", "max_height", "id", "data", "prepared_data", "raw_data", "opened", "value", "children"]);
      var id = this._id;
      var _this$context$drawerL = this.context.drawerList, data = _this$context$drawerL.data, opened = _this$context$drawerL.opened, hidden = _this$context$drawerL.hidden, triangle_position = _this$context$drawerL.triangle_position, direction = _this$context$drawerL.direction, max_height = _this$context$drawerL.max_height, cache_hash = _this$context$drawerL.cache_hash, selected_item = _this$context$drawerL.selected_item, active_item = _this$context$drawerL.active_item, closestToTop = _this$context$drawerL.closestToTop, closestToBottom = _this$context$drawerL.closestToBottom, usePortal = _this$context$drawerL.usePortal, addObservers = _this$context$drawerL.addObservers, removeObservers = _this$context$drawerL.removeObservers, _refShell = _this$context$drawerL._refShell, _refTriangle = _this$context$drawerL._refTriangle, _refUl = _this$context$drawerL._refUl, _refRoot = _this$context$drawerL._refRoot;
      var mainParams = (0,esm_extends/* default */.Z)({
        id: "".concat(id, "-drawer-list"),
        className: classnames("dnb-drawer-list dnb-drawer-list--".concat(direction), (0,component_helper/* isTrue */.oA)(independent_width) || (0,component_helper/* isTrue */.oA)(action_menu) && "dnb-drawer-list--independent-width", (0,SpacingHelper/* createSpacingClasses */.HU)(props), _className, className, opened && "dnb-drawer-list--opened", hidden && "dnb-drawer-list--hidden", triangle_position && "dnb-drawer-list--triangle-position-".concat(triangle_position), align_drawer && "dnb-drawer-list--".concat(align_drawer), size && "dnb-drawer-list--".concat(size), (0,component_helper/* isTrue */.oA)(action_menu) && "dnb-drawer-list--action-menu", (0,component_helper/* isTrue */.oA)(is_popup) && "dnb-drawer-list--is-popup", (0,component_helper/* isTrue */.oA)(scrollable) && "dnb-drawer-list--scroll", (0,component_helper/* isTrue */.oA)(no_scroll_animation) && "dnb-drawer-list--no-scroll-animation", (0,component_helper/* isTrue */.oA)(use_drawer_on_mobile) && "dnb-drawer-list--mobile-view")
      }, attributes);
      var listParams = {
        id: "".concat(id, "-listbox"),
        className: classnames("dnb-drawer-list__list", list_class, (0,component_helper/* isTrue */.oA)(no_animation) && "dnb-drawer-list__list--no-animation")
      };
      var ulParams = {
        role,
        id: "".concat(id, "-ul"),
        "aria-expanded": opened,
        "aria-labelledby": "".concat(id, "-label"),
        tabIndex: "-1",
        style: {
          maxHeight: max_height > 0 ? "".concat(max_height, "rem") : null
        },
        ref: _refUl
      };
      if (!hidden && parseFloat(active_item) > -1) {
        ulParams["aria-activedescendant"] = "option-".concat(id, "-").concat(active_item);
      } else if (!(0,component_helper/* isTrue */.oA)(prevent_selection) && !hidden && parseFloat(selected_item) > -1) {
        ulParams["aria-activedescendant"] = "option-".concat(id, "-").concat(selected_item);
      }
      if ((0,component_helper/* isTrue */.oA)(focusable)) {
        ulParams.tabIndex = "0";
      }
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, mainParams);
      (0,component_helper/* validateDOMAttributes */.L_)(null, listParams);
      (0,component_helper/* validateDOMAttributes */.L_)(null, ulParams);
      (0,esm_extends/* default */.Z)(this.context.drawerList.attributes, (0,component_helper/* validateDOMAttributes */.L_)(null, attributes));
      var ignoreEvents = (0,component_helper/* isTrue */.oA)(ignore_events);
      var Items = function Items2() {
        return data.map(function(dataItem, i) {
          var _id2 = dataItem.__id;
          var hash = "option-".concat(id, "-").concat(_id2, "-").concat(i);
          var liParams = {
            role: role === "menu" ? "menuitem" : "option",
            "data-item": _id2,
            id: "option-".concat(id, "-").concat(_id2),
            hash,
            className: classnames(ignoreEvents || dataItem.ignore_events && "ignore-events", dataItem.class_name, i === closestToTop && "closest-to-top", i === closestToBottom && "closest-to-bottom", i === 0 && "first-of-type", i === data.length - 1 && "last-of-type"),
            active: _id2 == active_item,
            selected: !dataItem.ignore_events && _id2 == selected_item,
            onClick: _this2.selectItemHandler,
            onKeyDown: _this2.preventTab
          };
          if (ignoreEvents) {
            liParams.active = null;
            liParams.selected = null;
            liParams.onClick = null;
            liParams.onKeyDown = null;
            liParams.className = classnames(liParams.className, "dnb-drawer-list__option--ignore");
          }
          return react.createElement(DrawerList.Item, (0,esm_extends/* default */.Z)({
            key: hash
          }, liParams), dataItem);
        });
      };
      var mainList = react.createElement("span", (0,esm_extends/* default */.Z)({}, mainParams, {
        ref: _refShell
      }), react.createElement("span", listParams, hidden === false && data && data.length > 0 ? react.createElement(react.Fragment, null, react.createElement(DrawerList.Options, (0,esm_extends/* default */.Z)({
        cache_hash: cache_hash + active_item + selected_item + closestToTop + closestToBottom + direction + max_height
      }, ulParams, {
        triangleRef: _refTriangle
      }), typeof options_render === "function" ? options_render({
        data,
        Items,
        Item: DrawerList.Item
      }) : react.createElement(Items, null)), react.createElement(OnMounted, {
        addObservers,
        removeObservers
      })) : children && react.createElement("span", {
        className: "dnb-drawer-list__content"
      }, children, react.createElement("span", {
        className: "dnb-drawer-list__triangle",
        ref: _refTriangle
      }))));
      return react.createElement("span", {
        className: "dnb-drawer-list__root" + (usePortal ? " dnb-drawer-list__root--portal" : ""),
        ref: _refRoot
      }, usePortal ? react.createElement(drawer_list_DrawerListPortal, {
        id: this._id,
        rootRef: _refRoot,
        opened: hidden === false,
        include_owner_width: align_drawer === "right",
        independent_width: (0,component_helper/* isTrue */.oA)(independent_width),
        fixed_position: (0,component_helper/* isTrue */.oA)(fixed_position),
        use_drawer_on_mobile: (0,component_helper/* isTrue */.oA)(use_drawer_on_mobile),
        className: portal_class
      }, mainList) : mainList);
    }
  }]);
  return DrawerListInstance2;
}(react.PureComponent);
DrawerListInstance.defaultProps = DrawerList.defaultProps;
DrawerListInstance.contextType = drawer_list_DrawerListContext;
 false ? 0 : void 0;
DrawerList.Options = react.memo(react.forwardRef(function(props, ref) {
  var children = props.children, className = props.className, _className = props.class, _props$triangleRef = props.triangleRef, triangleRef = _props$triangleRef === void 0 ? null : _props$triangleRef, cache_hash = props.cache_hash, rest = (0,objectWithoutProperties/* default */.Z)(props, ["children", "className", "class", "triangleRef", "cache_hash"]);
  return react.createElement("ul", (0,esm_extends/* default */.Z)({
    className: classnames("dnb-drawer-list__options", className, _className)
  }, rest, {
    ref
  }), children, react.createElement("li", {
    className: "dnb-drawer-list__triangle",
    "aria-hidden": true,
    ref: triangleRef
  }));
}), function(prevProps, nextProps) {
  if (!prevProps.cache_hash) {
    return null;
  }
  return prevProps.cache_hash === nextProps.cache_hash;
});
DrawerList.Options.displayName = "DrawerList.Options";
DrawerList.Options.propTypes = {
  children: prop_types.oneOfType([prop_types.node, prop_types.func]),
  className: prop_types.string,
  class: prop_types.string,
  triangleRef: prop_types.object
};
DrawerList.Options.defaultProps = {
  children: null,
  className: null,
  class: null,
  triangleRef: null
};
DrawerList.Item = react.forwardRef(function(props, ref) {
  var role = props.role, hash = props.hash, children = props.children, className = props.className, _className = props.class, on_click = props.on_click, selected = props.selected, active = props.active, value = props.value, rest = (0,objectWithoutProperties/* default */.Z)(props, ["role", "hash", "children", "className", "class", "on_click", "selected", "active", "value"]);
  var params = {
    className: classnames(className, _className, "dnb-drawer-list__option", selected && "dnb-drawer-list__option--selected", active && "dnb-drawer-list__option--focus"),
    role,
    tabIndex: selected ? "0" : "-1",
    "aria-selected": active
  };
  if (selected) {
    params["aria-current"] = true;
  }
  if (on_click) {
    params.onClick = function() {
      return (0,component_helper/* dispatchCustomElementEvent */.RW)({
        props: (0,esm_extends/* default */.Z)({}, props, {
          displayName: DrawerList.Item.displayName
        })
      }, "on_click", (0,esm_extends/* default */.Z)({
        selected,
        value
      }, rest));
    };
  }
  return react.createElement("li", (0,esm_extends/* default */.Z)({}, params, rest, {
    ref,
    key: "li" + hash
  }), react.createElement("span", {
    className: "dnb-drawer-list__option__inner"
  }, react.createElement(ItemContent, {
    hash
  }, children)));
});
DrawerList.Item.displayName = "DrawerList.Item";
DrawerList.Item.propTypes = {
  role: prop_types.string,
  hash: prop_types.string,
  children: prop_types.oneOfType([prop_types.node, prop_types.func, prop_types.object]).isRequired,
  className: prop_types.string,
  class: prop_types.string,
  on_click: prop_types.func,
  selected: prop_types.bool,
  active: prop_types.bool,
  value: prop_types.oneOfType([prop_types.string, prop_types.number])
};
DrawerList.Item.defaultProps = {
  role: "option",
  hash: "",
  className: null,
  class: null,
  on_click: null,
  selected: null,
  active: null,
  value: null
};
var ItemContent = function ItemContent2(_ref3) {
  var hash = _ref3.hash, children = _ref3.children;
  if (Array.isArray(children.content || children)) {
    return (children.content || children).map(function(item, n) {
      return react.createElement("span", {
        key: hash + n,
        className: "dnb-drawer-list__option__item"
      }, children.render ? children.render(item, hash + n) : item);
    });
  } else if (children.content) {
    return children.render ? children.render(children.content, hash) : children.content;
  }
  return children;
};
 false ? 0 : void 0;
DrawerList.HorizontalItem = function(_ref4) {
  var className = _ref4.className, props = (0,objectWithoutProperties/* default */.Z)(_ref4, ["className"]);
  return react.createElement("span", (0,esm_extends/* default */.Z)({
    className: classnames("dnb-drawer-list__option__inner__item", className)
  }, props));
};
DrawerList.HorizontalItem.propTypes = {
  className: prop_types.string
};
DrawerList.HorizontalItem.defaultProps = {
  className: null
};
var OnMounted = function(_React$PureComponent3) {
  (0,inherits/* default */.Z)(OnMounted2, _React$PureComponent3);
  var _super3 = DrawerList_createSuper(OnMounted2);
  function OnMounted2() {
    (0,classCallCheck/* default */.Z)(this, OnMounted2);
    return _super3.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(OnMounted2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.props.addObservers();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.props.removeObservers();
    }
  }, {
    key: "render",
    value: function render() {
      return null;
    }
  }]);
  return OnMounted2;
}(react.PureComponent);
 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js









var _AlignmentHelper;



function Dropdown_createSuper(Derived) {
  var hasNativeReflectConstruct = Dropdown_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Dropdown_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}
















var Dropdown = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Dropdown2, _React$PureComponent);
  var _super = Dropdown_createSuper(Dropdown2);
  function Dropdown2() {
    (0,classCallCheck/* default */.Z)(this, Dropdown2);
    return _super.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(Dropdown2, [{
    key: "render",
    value: function render() {
      var _this$props = this.props, more_menu = _this$props.more_menu, action_menu = _this$props.action_menu, prevent_selection = _this$props.prevent_selection, children = _this$props.children, data = _this$props.data;
      return react.createElement(DrawerListProvider, (0,esm_extends/* default */.Z)({}, this.props, {
        data: data || children,
        opened: null,
        tagName: "dnb-dropdown",
        ignore_events: false,
        prevent_selection: (0,component_helper/* isTrue */.oA)(more_menu) || (0,component_helper/* isTrue */.oA)(action_menu) || (0,component_helper/* isTrue */.oA)(prevent_selection)
      }), react.createElement(DropdownInstance, this.props));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(Dropdown2.tagName, Dropdown2, Dropdown2.defaultProps);
    }
  }]);
  return Dropdown2;
}(react.PureComponent);
Dropdown.tagName = "dnb-dropdown";
Dropdown.defaultProps = {
  id: null,
  title: "Option Menu",
  icon: null,
  icon_size: null,
  icon_position: null,
  triangle_position: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  scrollable: true,
  focusable: false,
  max_height: null,
  direction: "auto",
  skip_portal: null,
  portal_class: null,
  no_animation: false,
  no_scroll_animation: false,
  prevent_selection: false,
  more_menu: false,
  action_menu: false,
  independent_width: false,
  size: "default",
  align_dropdown: null,
  trigger_component: null,
  data: null,
  default_value: null,
  value: "initval",
  open_on_focus: false,
  prevent_close: false,
  keep_open: false,
  opened: false,
  disabled: null,
  stretch: null,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_show: null,
  on_hide: null,
  on_change: null,
  on_select: null,
  on_state_update: null
};

 false ? 0 : void 0;
var DropdownInstance = function(_React$PureComponent2) {
  (0,inherits/* default */.Z)(DropdownInstance2, _React$PureComponent2);
  var _super2 = Dropdown_createSuper(DropdownInstance2);
  function DropdownInstance2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, DropdownInstance2);
    _this = _super2.call(this, props);
    _this.setVisible = function() {
      _this.context.drawerList.setWrapperElement(_this._ref.current).setVisible();
    };
    _this.setHidden = function() {
      var _this$context$drawerL;
      (_this$context$drawerL = _this.context.drawerList).setHidden.apply(_this$context$drawerL, arguments);
    };
    _this.onFocusHandler = function() {
      if ((0,component_helper/* isTrue */.oA)(_this.props.open_on_focus)) {
        _this.setVisible();
      }
    };
    _this.onBlurHandler = function() {
      if ((0,component_helper/* isTrue */.oA)(_this.props.open_on_focus)) {
        _this.setHidden();
      }
    };
    _this.onClickHandler = function() {
      if ((0,component_helper/* isTrue */.oA)(_this.props.disabled)) {
        return;
      }
      if (!_this.context.drawerList.hidden && _this.context.drawerList.isOpen) {
        _this.setHidden();
      } else {
        _this.setVisible();
      }
    };
    _this.onTriggerKeyDownHandler = function(e) {
      switch (keycode(e)) {
        case "enter":
        case "space":
        case "up":
        case "down":
          e.preventDefault();
          _this.setVisible();
          break;
        case "esc":
          _this.setHidden();
          break;
        case "home":
        case "end":
        case "page down":
        case "page up":
          e.preventDefault();
          break;
      }
    };
    _this.onHideHandler = function() {
      var args = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      var attributes = _this.attributes || {};
      var res = (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_hide", (0,esm_extends/* default */.Z)({}, args, {
        attributes
      }));
      if (res !== false) {
        clearTimeout(_this._focusTimeout);
        _this._focusTimeout = setTimeout(function() {
          try {
            var element = _this._refButton.current._ref.current;
            if (element && typeof element.focus === "function") {
              if (args.preventHideFocus !== true) {
                element.focus({
                  preventScroll: true
                });
              }
              (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_hide_focus", {
                element
              });
            }
          } catch (e) {
          }
        }, 1);
      }
      return res;
    };
    _this.onSelectHandler = function(args) {
      if (parseFloat(args.active_item) > -1) {
        var attributes = _this.attributes || {};
        (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_select", (0,esm_extends/* default */.Z)({}, args, {
          attributes
        }));
      }
    };
    _this.onChangeHandler = function(args) {
      var attributes = _this.attributes || {};
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", (0,esm_extends/* default */.Z)({}, args, {
        attributes
      }));
    };
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this.attributes = {};
    _this.state = _this.state || {};
    _this._ref = react.createRef();
    _this._refShell = react.createRef();
    _this._refButton = react.createRef();
    var dep = "selected_item";
    if (typeof props[dep] !== "undefined") {
      (0,component_helper/* warn */.ZK)('Dropdown: Please use "value" instead of "'.concat(dep, '".'));
    }
    return _this;
  }
  (0,createClass/* default */.Z)(DropdownInstance2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if ((0,component_helper/* isTrue */.oA)(this.props.opened)) {
        this.setVisible();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.setHidden();
      clearTimeout(this._hideTimeout);
      clearTimeout(this._focusTimeout);
    }
  }, {
    key: "getTitle",
    value: function getTitle() {
      var title = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      var data = this.context.drawerList.data;
      if (data && data.length > 0) {
        var currentOptionData = getCurrentData(this.context.drawerList.selected_item, data);
        if (currentOptionData) {
          title = currentOptionData.selected_value || parseContentTitle(currentOptionData);
        }
      }
      return title;
    }
  }, {
    key: "render",
    value: function render() {
      var _this$context;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, Dropdown.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.getTranslation(this.props).Dropdown, this.context.FormRow, this.context.Dropdown);
      var label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, icon_size = props.icon_size, size = props.size, fixed_position = props.fixed_position, use_drawer_on_mobile = props.use_drawer_on_mobile, enable_body_lock = props.enable_body_lock, status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, scrollable = props.scrollable, focusable = props.focusable, keep_open = props.keep_open, prevent_close = props.prevent_close, no_animation = props.no_animation, no_scroll_animation = props.no_scroll_animation, triangle_position = props.triangle_position, skip_portal = props.skip_portal, portal_class = props.portal_class, CustomTrigger = props.trigger_component, more_menu = props.more_menu, action_menu = props.action_menu, independent_width = props.independent_width, prevent_selection = props.prevent_selection, max_height = props.max_height, default_value = props.default_value, className = props.className, _className = props.class, disabled = props.disabled, stretch = props.stretch, skeleton = props.skeleton, _title = props.title, _icon = props.icon, _align_dropdown = props.align_dropdown, _icon_position = props.icon_position, _data = props.data, _children = props.children, _direction = props.direction, _id = props.id, _opened = props.opened, _value = props.value, attributes = (0,objectWithoutProperties/* default */.Z)(props, ["label", "label_direction", "label_sr_only", "icon_size", "size", "fixed_position", "use_drawer_on_mobile", "enable_body_lock", "status", "status_state", "status_animation", "global_status_id", "suffix", "scrollable", "focusable", "keep_open", "prevent_close", "no_animation", "no_scroll_animation", "triangle_position", "skip_portal", "portal_class", "trigger_component", "more_menu", "action_menu", "independent_width", "prevent_selection", "max_height", "default_value", "className", "class", "disabled", "stretch", "skeleton", "title", "icon", "align_dropdown", "icon_position", "data", "children", "direction", "id", "opened", "value"]);
      var icon = props.icon, icon_position = props.icon_position, align_dropdown = props.align_dropdown;
      var id = this._id;
      var handleAsMenu = (0,component_helper/* isTrue */.oA)(action_menu) || (0,component_helper/* isTrue */.oA)(more_menu) || (0,component_helper/* isTrue */.oA)(prevent_selection);
      var isPopupMenu = (0,component_helper/* isTrue */.oA)(more_menu) || !(_title && _title.length > 0);
      if (isPopupMenu) {
        icon = icon || ((0,component_helper/* isTrue */.oA)(more_menu) ? "more" : "chevron_down");
      }
      if (isPopupMenu || (0,component_helper/* isTrue */.oA)(action_menu)) {
        if (icon_position !== "right" && align_dropdown !== "right") {
          icon_position = "left";
          align_dropdown = "left";
        }
      }
      var _this$context$drawerL2 = this.context.drawerList, selected_item = _this$context$drawerL2.selected_item, direction = _this$context$drawerL2.direction, opened = _this$context$drawerL2.opened;
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var title = this.getTitle(_title);
      (0,esm_extends/* default */.Z)(this.context.drawerList.attributes, (0,component_helper/* validateDOMAttributes */.L_)(null, attributes));
      var mainParams = {
        className: classnames("dnb-dropdown dnb-dropdown--".concat(direction, " dnb-dropdown--icon-position-").concat(icon_position || "right", " dnb-dropdown--").concat(align_dropdown || "right", " dnb-form-component"), ((0,component_helper/* isTrue */.oA)(independent_width) || (0,component_helper/* isTrue */.oA)(action_menu)) && "dnb-dropdown--independent-width", (0,SpacingHelper/* createSpacingClasses */.HU)(props), _className, className, opened && "dnb-dropdown--opened", label_direction && "dnb-dropdown--".concat(label_direction), isPopupMenu && "dnb-dropdown--is-popup", (0,component_helper/* isTrue */.oA)(action_menu) && "dnb-dropdown--action-menu", size && "dnb-dropdown--".concat(size), (0,component_helper/* isTrue */.oA)(stretch) && "dnb-dropdown--stretch", status && "dnb-dropdown__status--".concat(status_state), showStatus && "dnb-dropdown__form-status")
      };
      var triggerParams = (0,esm_extends/* default */.Z)({
        className: "dnb-dropdown__trigger" + (opened ? " dnb-button--active" : ""),
        id,
        disabled,
        "aria-haspopup": handleAsMenu ? true : "listbox",
        "aria-expanded": opened
      }, attributes, {
        onFocus: this.onFocusHandler,
        onBlur: this.onBlurHandler,
        onClick: this.onClickHandler,
        onKeyDown: this.onTriggerKeyDownHandler
      });
      if (opened) {
        triggerParams["aria-controls"] = "".concat(id, "-drawer-list");
      }
      if (showStatus || suffix) {
        triggerParams["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(triggerParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (label) {
        triggerParams["aria-labelledby"] = [triggerParams["aria-labelledby"], id + "-label", id].filter(Boolean).join(" ");
      }
      (0,component_helper/* validateDOMAttributes */.L_)(null, mainParams);
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, triggerParams);
      this.attributes = (0,component_helper/* validateDOMAttributes */.L_)(null, attributes);
      return react.createElement("span", mainParams, label && react.createElement(FormLabel/* default */.Z, {
        id: id + "-label",
        for_id: id,
        text: label,
        label_direction,
        sr_only: label_sr_only,
        disabled,
        skeleton,
        onClick: this.onClickHandler
      }), react.createElement("span", {
        className: "dnb-dropdown__inner",
        ref: this._ref
      }, _AlignmentHelper || (_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text_id: id + "-status",
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton
      }), react.createElement("span", {
        className: "dnb-dropdown__row"
      }, react.createElement("span", {
        className: "dnb-dropdown__shell",
        ref: this._refShell
      }, CustomTrigger ? react.createElement(CustomTrigger, triggerParams) : react.createElement(Button/* default */.ZP, (0,esm_extends/* default */.Z)({
        variant: "secondary",
        icon: false,
        size: size === "default" ? "medium" : size,
        ref: this._refButton
      }, triggerParams), !isPopupMenu && react.createElement("span", {
        className: "dnb-dropdown__text dnb-button__text"
      }, react.createElement("span", {
        className: "dnb-dropdown__text__inner"
      }, title)), react.createElement("span", {
        "aria-hidden": true,
        className: "dnb-dropdown__icon" + (parseFloat(selected_item) === 0 ? " dnb-dropdown__icon--first" : "")
      }, icon !== false && react.createElement(IconPrimary/* default */.Z, {
        icon: icon || "chevron_down",
        size: icon_size || (size === "large" ? "medium" : "default")
      }))), react.createElement(DrawerList, {
        id,
        role: handleAsMenu ? "menu" : "listbox",
        portal_class,
        list_class: "dnb-dropdown__list",
        value: selected_item,
        default_value,
        scrollable,
        focusable,
        no_animation,
        no_scroll_animation,
        skip_portal,
        prevent_selection: handleAsMenu,
        action_menu,
        triangle_position: triangle_position || icon_position || "right",
        keep_open,
        prevent_close,
        independent_width: (0,component_helper/* isTrue */.oA)(independent_width) || isPopupMenu || action_menu,
        is_popup: isPopupMenu || action_menu,
        align_drawer: align_dropdown || "left",
        fixed_position,
        use_drawer_on_mobile: use_drawer_on_mobile || action_menu,
        enable_body_lock,
        disabled,
        max_height,
        direction,
        size,
        on_change: this.onChangeHandler,
        on_select: this.onSelectHandler,
        on_hide: this.onHideHandler
      })), suffix && react.createElement(Suffix/* default */.Z, {
        className: "dnb-dropdown__suffix",
        id: id + "-suffix",
        context: props
      }, suffix))));
    }
  }]);
  return DropdownInstance2;
}(react.PureComponent);
DropdownInstance.defaultProps = Dropdown.defaultProps;
DropdownInstance.contextType = drawer_list_DrawerListContext;
 false ? 0 : void 0;
Dropdown.HorizontalItem = DrawerList.HorizontalItem;


/***/ }),

/***/ 6799:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FormLabel)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3086);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(855);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6357);
/* harmony import */ var _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3039);
/* harmony import */ var _skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5818);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3898);








function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}







var FormLabel = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(FormLabel2, _React$PureComponent);
  var _super = _createSuper(FormLabel2);
  function FormLabel2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(this, FormLabel2);
    return _super.apply(this, arguments);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(FormLabel2, [{
    key: "render",
    value: function render() {
      var _this$context;
      var props = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .extendPropsWithContext */ .Xw)(this.props, FormLabel2.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.FormRow, this.context.FormLabel);
      var for_id = props.for_id, element = props.element, title = props.title, className = props.className, id = props.id, disabled = props.disabled, skeleton = props.skeleton, label_direction = props.label_direction, vertical = props.vertical, sr_only = props.sr_only, _className = props.class, _text = props.text, attributes = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(props, ["for_id", "element", "title", "className", "id", "disabled", "skeleton", "label_direction", "vertical", "sr_only", "class", "text"]);
      var content = FormLabel2.getContent(this.props);
      var params = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({
        className: classnames__WEBPACK_IMPORTED_MODULE_5__("dnb-form-label", ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .isTrue */ .oA)(vertical) || label_direction === "vertical") && "dnb-form-label--vertical", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__/* .createSkeletonClass */ .BD)("font", skeleton, this.context), (0,_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_13__/* .createSpacingClasses */ .HU)(props), className, _className, (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .isTrue */ .oA)(sr_only) && "dnb-form-label--sr-only"),
        htmlFor: for_id,
        id,
        title,
        disabled: (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .isTrue */ .oA)(disabled)
      }, attributes);
      if (disabled) {
        params.disabled = true;
      }
      (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__/* .skeletonDOMAttributes */ .rZ)(params, skeleton, this.context);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .validateDOMAttributes */ .L_)(this.props, params);
      params.children = content;
      var Element = element;
      return react__WEBPACK_IMPORTED_MODULE_3__.createElement(Element, params);
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_14__/* .registerElement */ .ui)(FormLabel2.tagName, FormLabel2, FormLabel2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      if (props.text)
        return props.text;
      return (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .processChildren */ .Ob)(props);
    }
  }]);
  return FormLabel2;
}(react__WEBPACK_IMPORTED_MODULE_3__.PureComponent);
FormLabel.tagName = "dnb-form-label";
FormLabel.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z;
FormLabel.defaultProps = {
  for_id: null,
  element: "label",
  title: null,
  text: null,
  id: null,
  class: null,
  disabled: null,
  skeleton: null,
  label_direction: null,
  vertical: null,
  sr_only: null,
  className: null,
  children: null
};

 false ? 0 : void 0;


/***/ }),

/***/ 1530:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ FormRow),
/* harmony export */   "eI": () => (/* binding */ prepareFormRowContext)
/* harmony export */ });
/* unused harmony exports formRowPropTypes, formRowDefaultProps */
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3086);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4973);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(225);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(855);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6357);
/* harmony import */ var _shared_AlignmentHelper__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2294);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3898);
/* harmony import */ var _shared_libs_HashSum__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8704);
/* harmony import */ var _form_label_FormLabel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6799);
/* harmony import */ var _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3039);








var _AlignmentHelper, _span;


function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}









var formRowPropTypes = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
  id: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  label: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.func, prop_types__WEBPACK_IMPORTED_MODULE_6__.node]),
  label_direction: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOf(["vertical", "horizontal"]),
  label_sr_only: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  label_id: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  label_class: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  no_label: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  no_fieldset: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  indent: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  wrap: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  direction: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOf(["vertical", "horizontal"]),
  vertical: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  centered: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  indent_offset: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  section_style: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  section_spacing: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  global_status_id: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  responsive: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  skeleton: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.bool]),
  class: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  skipContentWrapperIfNested: prop_types__WEBPACK_IMPORTED_MODULE_6__.bool
}, _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_9__/* .spacingPropTypes */ .Xj, {
  className: prop_types__WEBPACK_IMPORTED_MODULE_6__.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_6__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6__.string, prop_types__WEBPACK_IMPORTED_MODULE_6__.func, prop_types__WEBPACK_IMPORTED_MODULE_6__.node]),
  custom_element: prop_types__WEBPACK_IMPORTED_MODULE_6__.object,
  custom_method: prop_types__WEBPACK_IMPORTED_MODULE_6__.func
});
var formRowDefaultProps = {
  id: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  label_id: null,
  label_class: null,
  no_label: false,
  no_fieldset: null,
  indent: null,
  wrap: null,
  direction: null,
  vertical: null,
  centered: null,
  indent_offset: null,
  section_style: null,
  section_spacing: null,
  global_status_id: null,
  responsive: null,
  disabled: null,
  skeleton: null,
  class: null,
  skipContentWrapperIfNested: false,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null
};
var FormRow = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(FormRow2, _React$PureComponent);
  var _super = _createSuper(FormRow2);
  function FormRow2(props) {
    var _this;
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(this, FormRow2);
    _this = _super.call(this, props);
    _this._id = props.id || (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .makeUniqueId */ .Xo)();
    return _this;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)(FormRow2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      var props = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .extendPropsWithContext */ .Xw)(this.props, FormRow2.defaultProps, this.context.FormRow);
      var label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, label_id = props.label_id, label_class = props.label_class, no_fieldset = props.no_fieldset, no_label = props.no_label, indent = props.indent, direction = props.direction, vertical = props.vertical, centered = props.centered, indent_offset = props.indent_offset, section_style = props.section_style, section_spacing = props.section_spacing, global_status_id = props.global_status_id, responsive = props.responsive, disabled = props.disabled, skeleton = props.skeleton, wrap = props.wrap, _id = props.id, className = props.className, _className = props.class, skipContentWrapperIfNested = props.skipContentWrapperIfNested, attributes = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_14__/* .default */ .Z)(props, ["label", "label_direction", "label_sr_only", "label_id", "label_class", "no_fieldset", "no_label", "indent", "direction", "vertical", "centered", "indent_offset", "section_style", "section_spacing", "global_status_id", "responsive", "disabled", "skeleton", "wrap", "id", "className", "class", "skipContentWrapperIfNested"]);
      var isNested = this.context.FormRow && this.context.FormRow.itsMeAgain;
      var _FormRow$getContent = FormRow2.getContent(this.props), nestedLabel = _FormRow$getContent.label, children = _FormRow$getContent.children;
      if (!label && nestedLabel) {
        label = nestedLabel;
      }
      var hasLabel = typeof label === "string" && label.length > 0 || label ? true : false;
      var id = this._id;
      var params = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
        className: classnames__WEBPACK_IMPORTED_MODULE_7__("dnb-form-row", ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) || direction) && "dnb-form-row--".concat((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) ? "vertical" : direction), ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) || label_direction) && "dnb-form-row--".concat((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) ? "vertical" : label_direction, "-label"), (0,_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_9__/* .createSpacingClasses */ .HU)(props), className, _className, indent && !(isNested && this.context.FormRow.hasLabel && this.context.FormRow.indent) && "dnb-form-row__indent--".concat((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(indent) ? "default" : indent), centered && "dnb-form-row--centered", isNested && "dnb-form-row--nested", section_style && "dnb-section dnb-section--".concat(section_style), section_spacing && "dnb-section--spacing-".concat((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(section_spacing) ? "default" : section_spacing))
      }, attributes);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .validateDOMAttributes */ .L_)(this.props, params);
      if (this._cachedContext !== (0,_shared_libs_HashSum__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(this.context, false) || this._cachedProps !== (0,_shared_libs_HashSum__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(this.props, false)) {
        this._cachedContext = (0,_shared_libs_HashSum__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(this.context, false);
        this._cachedProps = (0,_shared_libs_HashSum__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(this.props, false);
        var _FormRow2 = {
          useId: function useId() {
            if (_this2.isIsUsed) {
              return (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .makeUniqueId */ .Xo)();
            }
            _this2.isIsUsed = true;
            return id;
          },
          itsMeAgain: true,
          hasLabel,
          indent,
          global_status_id,
          direction,
          vertical,
          label_direction: (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) ? "vertical" : label_direction,
          responsive,
          disabled,
          skeleton
        };
        this._contextWeUse = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .extend */ .l7)(this.context, {
          FormRow: _FormRow2
        });
      }
      var useFieldset = !(0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(no_fieldset) && hasLabel;
      return react__WEBPACK_IMPORTED_MODULE_5__.createElement(_shared_Context__WEBPACK_IMPORTED_MODULE_16__/* .default.Provider */ .Z.Provider, {
        value: this._contextWeUse
      }, react__WEBPACK_IMPORTED_MODULE_5__.createElement(Fieldset, {
        useFieldset
      }, react__WEBPACK_IMPORTED_MODULE_5__.createElement("div", params, _AlignmentHelper || (_AlignmentHelper = react__WEBPACK_IMPORTED_MODULE_5__.createElement(_shared_AlignmentHelper__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z, null)), label && react__WEBPACK_IMPORTED_MODULE_5__.createElement(_form_label_FormLabel__WEBPACK_IMPORTED_MODULE_18__/* .default */ .Z, {
        className: classnames__WEBPACK_IMPORTED_MODULE_7__("dnb-form-row__label", label_class),
        id: label_id ? label_id : id + "-label",
        for_id: useFieldset ? null : id,
        text: label,
        element: useFieldset ? "legend" : "label",
        label_direction,
        sr_only: label_sr_only,
        disabled,
        skeleton
      }), (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(no_label) && (_span || (_span = react__WEBPACK_IMPORTED_MODULE_5__.createElement("span", {
        className: "dnb-form-label dnb-form-row__label-dummy",
        "aria-hidden": true
      }))), isNested && skipContentWrapperIfNested ? children : react__WEBPACK_IMPORTED_MODULE_5__.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7__("dnb-form-row__content", (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(wrap) && "dnb-form-row__content--wrap", label && !(0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(vertical) && direction !== "vertical" && "dnb-form-row__content--".concat(indent_offset || "default"), responsive && "dnb-responsive-component"),
        ref: this._contentRef
      }, children))));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_19__/* .registerElement */ .ui)(FormRow2.tagName, FormRow2, FormRow2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      var label = null;
      var children = typeof props.children === "function" ? props.children(props) : props.children;
      if (Array.isArray(props.children)) {
        children = children.reduce(function(pV, cV) {
          if (cV && cV.type && cV.type.name === "FormLabel") {
            label = cV.props.children;
          } else {
            pV.push(cV);
          }
          return pV;
        }, []);
      }
      return {
        label,
        children
      };
    }
  }]);
  return FormRow2;
}(react__WEBPACK_IMPORTED_MODULE_5__.PureComponent);
FormRow.tagName = "dnb-form-row";
FormRow.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z;
FormRow.defaultProps = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({}, formRowDefaultProps);

 false ? 0 : void 0;
var Fieldset = function Fieldset2(_ref) {
  var useFieldset = _ref.useFieldset, className = _ref.className, children = _ref.children, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_14__/* .default */ .Z)(_ref, ["useFieldset", "className", "children"]);
  if (useFieldset) {
    return react__WEBPACK_IMPORTED_MODULE_5__.createElement("fieldset", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
      className: classnames__WEBPACK_IMPORTED_MODULE_7__("dnb-form-row__fieldset", className)
    }, props), children);
  }
  return react__WEBPACK_IMPORTED_MODULE_5__.createElement("div", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
    className: classnames__WEBPACK_IMPORTED_MODULE_7__("dnb-form-row__fieldset", className)
  }, props), children);
};
 false ? 0 : void 0;
Fieldset.defaultProps = {
  children: null,
  useFieldset: false,
  className: null
};
var prepareFormRowContext = function prepareFormRowContext2(props) {
  if (typeof props.label_direction === "undefined") {
    props.label_direction = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .isTrue */ .oA)(props.vertical) ? "vertical" : props.label_direction;
  }
  return props;
};


/***/ }),

/***/ 3427:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ FormStatus)
/* harmony export */ });
/* unused harmony exports ErrorIcon, WarnIcon, InfoIcon, setMaxWidthToElement */
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3086);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6091);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1733);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6306);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(855);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3898);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6357);
/* harmony import */ var _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3039);
/* harmony import */ var _icon_Icon__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3231);
/* harmony import */ var _global_status_GlobalStatusProvider__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4225);
/* harmony import */ var _skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5818);








var _path, _path2, _path3, _path4, _path5, _path6, _path7, _circle, _path8;





function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}









var FormStatus = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(FormStatus2, _React$PureComponent);
  var _super = _createSuper(FormStatus2);
  function FormStatus2(props) {
    var _this;
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)(this, FormStatus2);
    _this = _super.call(this, props);
    _this.state = {
      id: null
    };
    _this.init = function() {
      if (_this._isMounted) {
        if (_this.gsProvider) {
          _this.gsProvider.isReady();
        }
        _this.updateWidth();
      }
    };
    _this.state.id = props.id || (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .makeUniqueId */ .Xo)();
    if (props.status !== "info") {
      _this.gsProvider = _global_status_GlobalStatusProvider__WEBPACK_IMPORTED_MODULE_14__/* .default.init */ .Z.init(props.global_status_id || "main", function(provider) {
        var _this$props = _this.props, state = _this$props.state, text = _this$props.text, label = _this$props.label;
        provider.add({
          state,
          status_id: "".concat(_this.state.id, "-gs"),
          item: {
            status_id: _this.state.id,
            text,
            status_anchor_label: label,
            status_anchor_url: true
          }
        });
      });
    }
    _this._ref = react__WEBPACK_IMPORTED_MODULE_8__.createRef();
    return _this;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(FormStatus2, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this._isMounted = true;
      if (document.readyState === "complete") {
        this.init();
      } else if (typeof window !== "undefined") {
        window.addEventListener("load", this.init);
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this._isMounted = false;
      if (this.gsProvider) {
        var status_id = "".concat(this.state.id, "-gs");
        this.gsProvider.remove(status_id);
      }
      if (typeof window !== "undefined") {
        window.removeEventListener("load", this.init);
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if (this.gsProvider && (prevProps.text !== this.props.text || prevProps.state !== this.props.state)) {
        var _this$props2 = this.props, state = _this$props2.state, text = _this$props2.text, label = _this$props2.label;
        var status_id = "".concat(this.state.id, "-gs");
        this.gsProvider.update(status_id, {
          state,
          item: {
            status_id: this.state.id,
            text,
            status_anchor_label: label,
            status_anchor_url: true
          }
        }, {
          preventRestack: true
        });
      }
      this.updateWidth();
    }
  }, {
    key: "correctStatus",
    value: function correctStatus(state) {
      switch (state) {
        case "information":
          state = "info";
          break;
        case "warning":
          state = "warn";
          break;
      }
      return state;
    }
  }, {
    key: "updateWidth",
    value: function updateWidth() {
      if (this._ref.current) {
        var _this$props3 = this.props, width_element = _this$props3.width_element, width_selector = _this$props3.width_selector;
        setMaxWidthToElement({
          element: this._ref.current,
          widthElement: width_element && width_element.current,
          widthSelector: width_selector
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var props = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .extendPropsWithContext */ .Xw)(this.props, FormStatus2.defaultProps, {
        skeleton: this.context && this.context.skeleton
      }, this.context.FormRow, this.context.FormStatus);
      var title = props.title, rawStatus = props.status, rawState = props.state, size = props.size, variant = props.variant, hidden = props.hidden, className = props.className, animation = props.animation, _className = props.class, text_id = props.text_id, status_id = props.status_id, id = props.id, text = props.text, icon = props.icon, icon_size = props.icon_size, skeleton = props.skeleton, children = props.children, attributes = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)(props, ["title", "status", "state", "size", "variant", "hidden", "className", "animation", "class", "text_id", "status_id", "id", "text", "icon", "icon_size", "skeleton", "children"]);
      var state = this.correctStatus(rawStatus || rawState);
      var iconToRender = FormStatus2.getIcon({
        state,
        icon,
        icon_size
      });
      var contentToRender = FormStatus2.getContent(this.props);
      if (contentToRender === null) {
        return react__WEBPACK_IMPORTED_MODULE_8__.createElement(react__WEBPACK_IMPORTED_MODULE_8__.Fragment, null);
      }
      var hasStringContent = typeof contentToRender === "string" && contentToRender.length > 0;
      var params = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z)({
        id: this.state.id,
        hidden,
        className: classnames__WEBPACK_IMPORTED_MODULE_10__("dnb-form-status dnb-form-status--".concat(state, " dnb-form-status__size--").concat(size), (0,_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_18__/* .createSpacingClasses */ .HU)(props), className, _className, variant && "dnb-form-status__variant--".concat(variant), animation && "dnb-form-status__animation--".concat(animation), hasStringContent && "dnb-form-status--has-content"),
        title
      }, attributes);
      var textParams = {
        className: classnames__WEBPACK_IMPORTED_MODULE_10__("dnb-form-status__text", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_19__/* .createSkeletonClass */ .BD)("font", skeleton, this.context)),
        id: text_id
      };
      if (hidden) {
        params["aria-hidden"] = hidden;
      }
      (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_19__/* .skeletonDOMAttributes */ .rZ)(params, skeleton, this.context);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .validateDOMAttributes */ .L_)(this.props, params);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .validateDOMAttributes */ .L_)(null, textParams);
      return react__WEBPACK_IMPORTED_MODULE_8__.createElement("span", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z)({}, params, {
        ref: this._ref
      }), react__WEBPACK_IMPORTED_MODULE_8__.createElement("span", {
        className: "dnb-form-status__shell"
      }, iconToRender, react__WEBPACK_IMPORTED_MODULE_8__.createElement("span", textParams, contentToRender)));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_20__/* .registerElement */ .ui)(FormStatus2.tagName, FormStatus2, FormStatus2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      if (props.text) {
        if ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .isTrue */ .oA)(props.text)) {
          return null;
        }
        return props.text;
      }
      return (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_13__/* .processChildren */ .Ob)(props);
    }
  }, {
    key: "getIcon",
    value: function getIcon(_ref) {
      var state = _ref.state, icon = _ref.icon, icon_size = _ref.icon_size;
      if (typeof icon === "string") {
        var IconToLoad = icon;
        switch (state) {
          case "info":
          case "information":
            IconToLoad = InfoIcon;
            break;
          case "warn":
          case "warning":
            IconToLoad = WarnIcon;
            break;
          case "error":
          default:
            IconToLoad = ErrorIcon;
        }
        icon = react__WEBPACK_IMPORTED_MODULE_8__.createElement(_icon_Icon__WEBPACK_IMPORTED_MODULE_21__/* .default */ .ZP, {
          icon: react__WEBPACK_IMPORTED_MODULE_8__.createElement(IconToLoad, {
            title: null
          }),
          size: icon_size,
          inherit_color: false
        });
      }
      return icon;
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._id !== props.id) {
        state.id = props.id;
      }
      state._id = props.id;
      return state;
    }
  }]);
  return FormStatus2;
}(react__WEBPACK_IMPORTED_MODULE_8__.PureComponent);
FormStatus.tagName = "dnb-form-status";
FormStatus.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_22__/* .default */ .Z;
FormStatus.defaultProps = {
  id: null,
  title: null,
  text: null,
  label: null,
  icon: "error",
  icon_size: "medium",
  size: "default",
  variant: null,
  state: "error",
  status: null,
  global_status_id: null,
  hidden: false,
  text_id: null,
  width_selector: null,
  width_element: null,
  class: null,
  animation: null,
  skeleton: null,
  className: null,
  children: null
};

 false ? 0 : void 0;
var ErrorIcon = function ErrorIcon2(props) {
  return react__WEBPACK_IMPORTED_MODULE_8__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z)({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react__WEBPACK_IMPORTED_MODULE_8__.createElement("title", null, props.title), _path || (_path = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M23.625 17.864A3.547 3.547 0 0120.45 23H3.548a3.546 3.546 0 01-3.172-5.136l8.45-14.902a3.548 3.548 0 016.347 0l8.452 14.902z",
    fill: "#DC2A2A"
  })), _path2 || (_path2 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M12 16.286a1.286 1.286 0 100 2.572 1.286 1.286 0 000-2.572z",
    fill: "#fff"
  })), _path3 || (_path3 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M12 13.818v-5",
    stroke: "#fff",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};
 false ? 0 : void 0;
ErrorIcon.defaultProps = {
  title: "error"
};
var WarnIcon = function WarnIcon2(props) {
  return react__WEBPACK_IMPORTED_MODULE_8__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z)({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react__WEBPACK_IMPORTED_MODULE_8__.createElement("title", null, props.title), _path4 || (_path4 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M23.625 17.864A3.547 3.547 0 0120.45 23H3.548a3.546 3.546 0 01-3.172-5.136l8.45-14.902a3.548 3.548 0 016.347 0l8.452 14.902z",
    fill: "#FDBB31"
  })), _path5 || (_path5 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M12 16.286a1.286 1.286 0 100 2.572 1.286 1.286 0 000-2.572z",
    fill: "#333"
  })), _path6 || (_path6 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M12 13.818v-5",
    stroke: "#333",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};
 false ? 0 : void 0;
WarnIcon.defaultProps = {
  title: "error"
};
var InfoIcon = function InfoIcon2(props) {
  return react__WEBPACK_IMPORTED_MODULE_8__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z)({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    role: "presentation"
  }, props), props && props.title && react__WEBPACK_IMPORTED_MODULE_8__.createElement("title", null, props.title), _path7 || (_path7 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M11.268 0a11.25 11.25 0 105.566 21.017l6.112 2.91a.75.75 0 001-1l-2.911-6.112A11.234 11.234 0 0011.268 0z",
    fill: "#007272"
  })), _circle || (_circle = react__WEBPACK_IMPORTED_MODULE_8__.createElement("circle", {
    cx: "11",
    cy: "6.5",
    r: ".5",
    fill: "#fff",
    stroke: "#fff"
  })), _path8 || (_path8 = react__WEBPACK_IMPORTED_MODULE_8__.createElement("path", {
    d: "M13.75 16H13a1.5 1.5 0 01-1.5-1.5v-3.75a.75.75 0 00-.75-.75H10",
    stroke: "#fff",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};
 false ? 0 : void 0;
InfoIcon.defaultProps = {
  title: "info"
};
function setMaxWidthToElement(_ref2) {
  var element = _ref2.element, _ref2$id = _ref2.id, id = _ref2$id === void 0 ? null : _ref2$id, _ref2$widthElement = _ref2.widthElement, widthElement = _ref2$widthElement === void 0 ? null : _ref2$widthElement, _ref2$widthSelector = _ref2.widthSelector, widthSelector = _ref2$widthSelector === void 0 ? null : _ref2$widthSelector;
  if (!(element && typeof window !== "undefined")) {
    return;
  }
  try {
    if (!id && !widthSelector) {
      id = element.getAttribute("id");
    }
    var width = sumElementWidth({
      widthElement,
      widthSelector: widthSelector || id.replace("-form-status", "") || id
    });
    if (width > 40) {
      var minWidth = 12 * 16;
      if (width < minWidth) {
        width = minWidth;
      }
      var remWidth = "".concat(width / 16, "rem");
      var cS = window.getComputedStyle(element);
      var hasCustomWidth = element.style.maxWidth ? false : cS.minWidth !== "" && cS.minWidth !== "auto" || cS.maxWidth !== "" && cS.maxWidth !== "none";
      if (!hasCustomWidth) {
        element.style.maxWidth = remWidth;
      }
    }
  } catch (e) {
  }
}
function sumElementWidth(_ref3) {
  var widthElement = _ref3.widthElement, widthSelector = _ref3.widthSelector;
  var width = 0;
  if (typeof document === "undefined") {
    return width;
  }
  try {
    var ids = widthElement ? [widthElement] : widthSelector.split(/, |,/g);
    width = ids.reduce(function(acc, cur) {
      var elem = typeof cur === "string" ? cur[0] === "." ? document.querySelector(cur) : document.getElementById(cur) : cur;
      var width2 = elem && elem.offsetWidth || window.getComputedStyle(elem).width;
      if (/em|rem/.test(width2)) {
        width2 = parseFloat(width2) * 16;
      }
      if (width2 > 0) {
        if (acc > 0) {
          acc += 16;
        }
        acc += width2;
      }
      return acc;
    }, width);
  } catch (e) {
  }
  return width;
}


/***/ }),

/***/ 4225:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7817);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6849);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(520);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1698);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1362);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8381);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7298);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1218);












var GlobalStatusProvider = function() {
  function GlobalStatusProvider2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(this, GlobalStatusProvider2);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(GlobalStatusProvider2, null, [{
    key: "init",
    value: function init() {
      var id = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "main";
      var onReady = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      var props = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
      var existingStatus = GlobalStatusProvider2.get(id);
      if (existingStatus) {
        if (props) {
          existingStatus.add(props);
        }
        if (typeof onReady === "function") {
          onReady(existingStatus);
        }
        return existingStatus;
      }
      var newStatus = GlobalStatusProvider2.create(id, props);
      if (onReady) {
        newStatus.addOnReady(newStatus, onReady);
      }
      if (id !== "main") {
        (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .warn */ .ZK)("No <GlobalStatus ".concat('id="'.concat(id, '"'), " /> found."));
      }
      return newStatus;
    }
  }, {
    key: "get",
    value: function get() {
      var id = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "main";
      return GlobalStatusProvider2.providers[id] || null;
    }
  }, {
    key: "remove",
    value: function remove() {
      var id = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "main";
      if (GlobalStatusProvider2.providers[id]) {
        delete GlobalStatusProvider2.providers[id];
      }
    }
  }, {
    key: "prepareItemWithStatusId",
    value: function prepareItemWithStatusId(item) {
      var status_id = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      if (typeof item === "string") {
        item = {
          text: item
        };
      }
      if (!item.status_id) {
        item.status_id = status_id && status_id !== "status-main" ? status_id : slugify(JSON.stringify(item));
      }
      return item;
    }
  }, {
    key: "combineMessages",
    value: function combineMessages(stack) {
      var globalStatus = stack.reduce(function(acc, _cur) {
        var cur = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({}, _cur);
        if (typeof cur.items === "string" && cur.items[0] === "[") {
          cur.items = JSON.parse(cur.items);
        }
        if (cur.item) {
          if (typeof cur.item === "string" && cur.item[0] === "{") {
            cur.item = JSON.parse(cur.item);
          }
          cur.items = cur.items || [];
          cur.items.push(cur.item);
        }
        if (cur.items) {
          cur.items = cur.items.reduce(function(acc2, item) {
            item = GlobalStatusProvider2.prepareItemWithStatusId(item);
            var foundAtIndex = acc2.findIndex(function(_ref) {
              var status_id = _ref.status_id;
              return status_id === item.status_id;
            });
            if (foundAtIndex > -1) {
              acc2[foundAtIndex] = item;
            } else {
              acc2.push(item);
            }
            return acc2;
          }, acc.items || []);
        }
        (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(acc, cur);
        return acc;
      }, {});
      return globalStatus;
    }
  }]);
  return GlobalStatusProvider2;
}();
GlobalStatusProvider.providers = {};
GlobalStatusProvider.create = function() {
  var id = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "main";
  var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  return GlobalStatusProvider.providers[id] = new GlobalStatusProviderItem(id, props);
};
var GlobalStatusProviderItem = function() {
  function GlobalStatusProviderItem2(id) {
    var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(this, GlobalStatusProviderItem2);
    this.stack = [];
    this.globalStatus = {};
    this._onUpdateEvents = [];
    this._onReadyEvents = [];
    this.internal_id = id;
    if (props) {
      this.add(props);
    }
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(GlobalStatusProviderItem2, [{
    key: "onUpdate",
    value: function onUpdate(event) {
      if (this._onUpdateEvents.filter(function(cb) {
        return cb === event;
      }).length === 0) {
        this._onUpdateEvents.push(event);
      }
    }
  }, {
    key: "forceRerender",
    value: function forceRerender(globalStatus, props) {
      var _this = this;
      var _ref2 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, _ref2$buffer_delay = _ref2.buffer_delay, buffer_delay = _ref2$buffer_delay === void 0 ? 0 : _ref2$buffer_delay, _ref2$isEmpty = _ref2.isEmpty, isEmpty = _ref2$isEmpty === void 0 ? false : _ref2$isEmpty;
      var run = function run2() {
        _this._onUpdateEvents.forEach(function(event) {
          if (typeof event === "function") {
            event(globalStatus, props, {
              isEmpty
            });
          }
        });
      };
      if (buffer_delay > 0) {
        clearTimeout(this._bufferDelayId);
        this._bufferDelayId = setTimeout(run, buffer_delay);
      } else {
        run();
      }
    }
  }, {
    key: "init",
    value: function init(props) {
      return this.add(props, {
        preventRerender: true
      });
    }
  }, {
    key: "add",
    value: function add(props) {
      var opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      this.remove("internal-close", {
        preventRerender: true
      });
      var newProps = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({}, props);
      if (!newProps.status_id) {
        newProps.status_id = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_10__/* .makeUniqueId */ .Xo)();
      }
      if (typeof newProps.show === "undefined") {
        newProps.show = true;
      }
      if (newProps.children) {
        newProps.text = newProps.children;
        delete newProps.children;
      }
      var stackIndex = this.stack.findIndex(function(cur) {
        return cur.status_id === newProps.status_id;
      });
      if (stackIndex > -1) {
        this.stack[stackIndex] = newProps;
      } else {
        this.stack.push(newProps);
      }
      var globalStatus = GlobalStatusProvider.combineMessages(this.stack);
      if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
        this.forceRerender(globalStatus, props, {
          buffer_delay: (props === null || props === void 0 ? void 0 : props.buffer_delay) > -1 ? props.buffer_delay : 0
        });
      }
      return globalStatus;
    }
  }, {
    key: "get",
    value: function get(status_id) {
      return this.stack.find(function(cur) {
        return cur.status_id === status_id;
      });
    }
  }, {
    key: "update",
    value: function update(status_id, newProps) {
      var opts = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      if (status_id) {
        var item = this.get(status_id);
        if (!item) {
          this.add(newProps);
        }
      }
      this.stack = this.stack.map(function(cur, i, arr) {
        if (!status_id ? i === arr.length - 1 : cur.status_id === status_id) {
          if (!status_id) {
            newProps = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({}, newProps);
            delete newProps.status_id;
          }
          return (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({}, cur, newProps);
        }
        return cur;
      });
      if (!(opts !== null && opts !== void 0 && opts.preventRestack)) {
        this.restack(status_id);
      }
      var globalStatus = GlobalStatusProvider.combineMessages(this.stack);
      if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
        var _newProps;
        this.forceRerender(globalStatus, null, {
          buffer_delay: ((_newProps = newProps) === null || _newProps === void 0 ? void 0 : _newProps.buffer_delay) > -1 ? newProps.buffer_delay : 0
        });
      }
    }
  }, {
    key: "restack",
    value: function restack(status_id) {
      var item = this.get(status_id);
      if (item) {
        this.stack = this.stack.filter(function(cur) {
          return cur.status_id !== status_id;
        });
        this.stack.push(item);
      }
    }
  }, {
    key: "remove",
    value: function remove(status_id) {
      var opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      if (status_id) {
        this.stack = this.stack.filter(function(cur) {
          return cur.status_id !== status_id;
        });
        var globalStatus = GlobalStatusProvider.combineMessages(this.stack);
        if (!(opts !== null && opts !== void 0 && opts.preventRerender)) {
          this.forceRerender(globalStatus, null, {
            buffer_delay: (opts === null || opts === void 0 ? void 0 : opts.buffer_delay) > -1 ? opts.buffer_delay : 10
          });
        }
      }
    }
  }, {
    key: "empty",
    value: function empty() {
      var _this2 = this;
      this._onUpdateEvents.forEach(function(cb, i) {
        _this2._onUpdateEvents[i] = null;
      });
      this._onUpdateEvents = [];
      this._onReadyEvents.forEach(function(cb, i) {
        _this2._onReadyEvents[i] = null;
      });
      this._onReadyEvents = [];
    }
  }, {
    key: "unbind",
    value: function unbind() {
      this.empty();
      GlobalStatusProvider.remove(this.internal_id);
    }
  }, {
    key: "isReady",
    value: function isReady() {
      var _this3 = this;
      this._onReadyEvents = this._onReadyEvents.filter(function(_ref3, i) {
        var status = _ref3.status, cb = _ref3.cb;
        if (typeof cb === "function") {
          cb(status);
        }
        _this3._onReadyEvents[i] = null;
        return false;
      });
      return true;
    }
  }, {
    key: "addOnReady",
    value: function addOnReady(status, cb) {
      this._onReadyEvents.push({
        status,
        cb
      });
    }
  }]);
  return GlobalStatusProviderItem2;
}();
if (typeof window !== "undefined") {
  window.GlobalStatusProvider = GlobalStatusProvider;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalStatusProvider);
var slugify = function slugify2(s) {
  return s.toLowerCase().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
};


/***/ }),

/***/ 6336:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ IconPrimary)
});

// UNUSED EXPORTS: DefaultIconSize

// NAMESPACE OBJECT: ../node_modules/@dnb/eufemia/icons/primary_icons.js
var primary_icons_namespaceObject = {};
__webpack_require__.r(primary_icons_namespaceObject);
__webpack_require__.d(primary_icons_namespaceObject, {
  "add": () => (add/* default */.Z),
  "arrow_down": () => (icons_arrow_down),
  "arrow_left": () => (icons_arrow_left),
  "arrow_right": () => (arrow_right/* default */.Z),
  "arrow_up": () => (icons_arrow_up),
  "bell": () => (icons_bell),
  "calendar": () => (icons_calendar),
  "check": () => (icons_check),
  "chevron_down": () => (chevron_down/* default */.Z),
  "chevron_left": () => (icons_chevron_left),
  "chevron_right": () => (icons_chevron_right),
  "chevron_up": () => (chevron_up/* default */.Z),
  "close": () => (icons_close),
  "download": () => (download/* default */.Z),
  "exclamation": () => (icons_exclamation),
  "information": () => (icons_information),
  "loupe": () => (icons_loupe),
  "more": () => (icons_more),
  "question": () => (icons_question),
  "reset": () => (icons_reset),
  "save": () => (icons_save),
  "subtract": () => (icons_subtract)
});

// NAMESPACE OBJECT: ../node_modules/@dnb/eufemia/icons/primary_icons_medium.js
var primary_icons_medium_namespaceObject = {};
__webpack_require__.r(primary_icons_medium_namespaceObject);
__webpack_require__.d(primary_icons_medium_namespaceObject, {
  "add_medium": () => (icons_add_medium),
  "arrow_down_medium": () => (icons_arrow_down_medium),
  "arrow_left_medium": () => (icons_arrow_left_medium),
  "arrow_right_medium": () => (icons_arrow_right_medium),
  "arrow_up_medium": () => (icons_arrow_up_medium),
  "bell_medium": () => (icons_bell_medium),
  "calendar_medium": () => (icons_calendar_medium),
  "check_medium": () => (icons_check_medium),
  "chevron_down_medium": () => (icons_chevron_down_medium),
  "chevron_left_medium": () => (icons_chevron_left_medium),
  "chevron_right_medium": () => (icons_chevron_right_medium),
  "chevron_up_medium": () => (icons_chevron_up_medium),
  "close_medium": () => (icons_close_medium),
  "download_medium": () => (icons_download_medium),
  "exclamation_medium": () => (icons_exclamation_medium),
  "information_medium": () => (icons_information_medium),
  "loupe_medium": () => (icons_loupe_medium),
  "more_medium": () => (icons_more_medium),
  "question_medium": () => (icons_question_medium),
  "reset_medium": () => (icons_reset_medium),
  "save_medium": () => (icons_save_medium),
  "subtract_medium": () => (icons_subtract_medium)
});

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/prop-types/index.js
var prop_types = __webpack_require__(6050);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Context.js + 3 modules
var Context = __webpack_require__(3898);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/icon/Icon.js
var Icon = __webpack_require__(3231);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/add.js
var add = __webpack_require__(43);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_down.js

var _path;

function arrow_down(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react.createElement("path", {
    d: "M3.53033 9.21967C3.23744 8.92678 2.76256 8.92678 2.46967 9.21967C2.17678 9.51256 2.17678 9.98744 2.46967 10.2803L3.53033 9.21967ZM8 14.75L7.46967 15.2803C7.76256 15.5732 8.23744 15.5732 8.53033 15.2803L8 14.75ZM13.5303 10.2803C13.8232 9.98744 13.8232 9.51256 13.5303 9.21967C13.2374 8.92678 12.7626 8.92678 12.4697 9.21967L13.5303 10.2803ZM8.75 1.25C8.75 0.835786 8.41421 0.5 8 0.5C7.58579 0.5 7.25 0.835786 7.25 1.25H8.75ZM2.46967 10.2803L7.46967 15.2803L8.53033 14.2197L3.53033 9.21967L2.46967 10.2803ZM8.53033 15.2803L13.5303 10.2803L12.4697 9.21967L7.46967 14.2197L8.53033 15.2803ZM7.25 1.25V14.75H8.75V1.25H7.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_arrow_down = (arrow_down);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_left.js

var arrow_left_path;

function arrow_left(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_left_path || (arrow_left_path = react.createElement("path", {
    d: "M14.5 8H1M6 3L1 8M1 8L6 13",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_arrow_left = (arrow_left);

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/arrow_right.js
var arrow_right = __webpack_require__(2296);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_up.js

var arrow_up_path;

function arrow_up(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_up_path || (arrow_up_path = react.createElement("path", {
    d: "M2.46967 5.71967C2.17678 6.01256 2.17678 6.48744 2.46967 6.78033C2.76256 7.07322 3.23744 7.07322 3.53033 6.78033L2.46967 5.71967ZM8 1.25L8.53033 0.71967C8.23744 0.426777 7.76256 0.426777 7.46967 0.71967L8 1.25ZM12.4697 6.78033C12.7626 7.07322 13.2374 7.07322 13.5303 6.78033C13.8232 6.48744 13.8232 6.01256 13.5303 5.71967L12.4697 6.78033ZM7.25 14.75C7.25 15.1642 7.58579 15.5 8 15.5C8.41421 15.5 8.75 15.1642 8.75 14.75H7.25ZM3.53033 6.78033L8.53033 1.78033L7.46967 0.71967L2.46967 5.71967L3.53033 6.78033ZM7.46967 1.78033L12.4697 6.78033L13.5303 5.71967L8.53033 0.71967L7.46967 1.78033ZM8.75 14.75V1.25H7.25V14.75H8.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_arrow_up = (arrow_up);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/bell.js

var bell_path;

function bell(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), bell_path || (bell_path = react.createElement("path", {
    d: "M6.75574 14.0672C6.83478 14.3364 6.99889 14.5728 7.22352 14.741C7.44814 14.9091 7.72119 15 8.00179 15C8.28239 15 8.55544 14.9091 8.78006 14.741C9.00469 14.5728 9.1688 14.3364 9.24784 14.0672M8.00023 2.40005C9.23796 2.40005 10.425 2.89174 11.3002 3.76694C12.1754 4.64214 12.6671 5.82917 12.6671 7.06689C12.6671 11.4512 13.6004 12.2004 13.6004 12.2004H2.40002C2.40002 12.2004 3.33339 11.0082 3.33339 7.06689C3.33339 5.82917 3.82508 4.64214 4.70028 3.76694C5.57548 2.89174 6.76251 2.40005 8.00023 2.40005ZM8.00023 2.40005V1",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_bell = (bell);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/calendar.js

var calendar_path;

function calendar(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), calendar_path || (calendar_path = react.createElement("path", {
    d: "M6.00581 1C6.00581 0.585786 5.67003 0.25 5.25581 0.25C4.8416 0.25 4.50581 0.585786 4.50581 1H6.00581ZM4.50581 4.25581C4.50581 4.67003 4.8416 5.00581 5.25581 5.00581C5.67003 5.00581 6.00581 4.67003 6.00581 4.25581H4.50581ZM11.5 1C11.5 0.585786 11.1642 0.25 10.75 0.25C10.3358 0.25 10 0.585786 10 1H11.5ZM10 4.25581C10 4.67003 10.3358 5.00581 10.75 5.00581C11.1642 5.00581 11.5 4.67003 11.5 4.25581H10ZM2 15.75H14V14.25H2V15.75ZM4.50581 1V4.25581H6.00581V1H4.50581ZM10 1V4.25581H11.5V1H10ZM14 1.87791H2V3.37791H14V1.87791ZM0.25 3.62791V7.5H1.75V3.62791H0.25ZM0.25 7.5V14H1.75V7.5H0.25ZM15.75 14V7.5H14.25V14H15.75ZM15.75 7.5V3.62791H14.25V7.5H15.75ZM1 8.25H15V6.75H1V8.25ZM14 3.37791C14.1381 3.37791 14.25 3.48984 14.25 3.62791H15.75C15.75 2.66141 14.9665 1.87791 14 1.87791V3.37791ZM14 15.75C14.9665 15.75 15.75 14.9665 15.75 14H14.25C14.25 14.1381 14.1381 14.25 14 14.25V15.75ZM2 14.25C1.86193 14.25 1.75 14.1381 1.75 14H0.25C0.25 14.9665 1.0335 15.75 2 15.75V14.25ZM2 1.87791C1.0335 1.87791 0.25 2.66141 0.25 3.62791H1.75C1.75 3.48984 1.86193 3.37791 2 3.37791V1.87791Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_calendar = (calendar);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/check.js

var check_path;

function check(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), check_path || (check_path = react.createElement("path", {
    d: "M1 10L5 14L15 2",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_check = (check);

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down.js
var chevron_down = __webpack_require__(9444);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_left.js

var chevron_left_path;

function chevron_left(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_left_path || (chevron_left_path = react.createElement("path", {
    d: "M10 3L5 8L10 13",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_left = (chevron_left);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_right.js

var chevron_right_path;

function chevron_right(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_right_path || (chevron_right_path = react.createElement("path", {
    d: "M6 13L11 8L6 3",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_right = (chevron_right);

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up.js
var chevron_up = __webpack_require__(1);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/close.js

var close_path;

function close_close(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), close_path || (close_path = react.createElement("path", {
    d: "M3 13L13 3M13 13L3 3",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_close = (close_close);

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/download.js
var download = __webpack_require__(6889);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/exclamation.js

var exclamation_path;

function exclamation(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), exclamation_path || (exclamation_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M8.75 2C8.75 1.58579 8.41421 1.25 8 1.25C7.58579 1.25 7.25 1.58579 7.25 2V10.412C7.25 10.8262 7.58579 11.162 8 11.162C8.41421 11.162 8.75 10.8262 8.75 10.412V2ZM7.44443 12.6685C7.60888 12.5586 7.80222 12.5 8 12.5C8.26522 12.5 8.51957 12.6054 8.70711 12.7929C8.89464 12.9804 9 13.2348 9 13.5C9 13.6978 8.94135 13.8911 8.83147 14.0556C8.72159 14.22 8.56541 14.3482 8.38268 14.4239C8.19996 14.4996 7.99889 14.5194 7.80491 14.4808C7.61093 14.4422 7.43274 14.347 7.29289 14.2071C7.15304 14.0673 7.0578 13.8891 7.01922 13.6951C6.98063 13.5011 7.00043 13.3 7.07612 13.1173C7.15181 12.9346 7.27998 12.7784 7.44443 12.6685Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_exclamation = (exclamation);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/information.js

var information_path;

function information(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), information_path || (information_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M7.16603 3.66532C7.71799 3.66532 8.16544 3.21787 8.16544 2.66591C8.16544 2.11395 7.71799 1.6665 7.16603 1.6665C6.61408 1.6665 6.16663 2.11395 6.16663 2.66591C6.16663 3.21787 6.61408 3.66532 7.16603 3.66532ZM6.16663 5.41384C5.75241 5.41384 5.41663 5.74963 5.41663 6.16384C5.41663 6.57805 5.75241 6.91384 6.16663 6.91384H6.91574V12.0007C6.91574 13.2428 7.9227 14.2498 9.16485 14.2498H9.91441C10.3286 14.2498 10.6644 13.914 10.6644 13.4998C10.6644 13.0856 10.3286 12.7498 9.91441 12.7498H9.16485C8.75113 12.7498 8.41574 12.4144 8.41574 12.0007V6.9134C8.41574 6.08522 7.74436 5.41384 6.91618 5.41384H6.16663Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_information = (information);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/loupe.js

var loupe_path;

function loupe(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), loupe_path || (loupe_path = react.createElement("path", {
    d: "M12.0303 10.9697C11.7374 10.6768 11.2626 10.6768 10.9697 10.9697C10.6768 11.2626 10.6768 11.7374 10.9697 12.0303L12.0303 10.9697ZM14.4697 15.5303C14.7626 15.8232 15.2374 15.8232 15.5303 15.5303C15.8232 15.2374 15.8232 14.7626 15.5303 14.4697L14.4697 15.5303ZM10.9697 12.0303L14.4697 15.5303L15.5303 14.4697L12.0303 10.9697L10.9697 12.0303ZM11.0682 6.40909C11.0682 8.98224 8.98224 11.0682 6.40909 11.0682V12.5682C9.81066 12.5682 12.5682 9.81066 12.5682 6.40909H11.0682ZM6.40909 11.0682C3.83595 11.0682 1.75 8.98224 1.75 6.40909H0.25C0.25 9.81066 3.00752 12.5682 6.40909 12.5682V11.0682ZM1.75 6.40909C1.75 3.83595 3.83595 1.75 6.40909 1.75V0.25C3.00752 0.25 0.25 3.00752 0.25 6.40909H1.75ZM6.40909 1.75C8.98224 1.75 11.0682 3.83595 11.0682 6.40909H12.5682C12.5682 3.00752 9.81066 0.25 6.40909 0.25V1.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_loupe = (loupe);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/more.js

var more_path, _path2, _path3;

function more(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), more_path || (more_path = react.createElement("path", {
    d: "M4.5 8C4.5 8.69036 3.94036 9.25 3.25 9.25C2.55964 9.25 2 8.69036 2 8C2 7.30964 2.55964 6.75 3.25 6.75C3.94036 6.75 4.5 7.30964 4.5 8Z",
    fill: "black"
  })), _path2 || (_path2 = react.createElement("path", {
    d: "M8 9.25C8.69036 9.25 9.25 8.69036 9.25 8C9.25 7.30964 8.69036 6.75 8 6.75C7.30964 6.75 6.75 7.30964 6.75 8C6.75 8.69036 7.30964 9.25 8 9.25Z",
    fill: "black"
  })), _path3 || (_path3 = react.createElement("path", {
    d: "M12.75 9.25C13.4404 9.25 14 8.69036 14 8C14 7.30964 13.4404 6.75 12.75 6.75C12.0596 6.75 11.5 7.30964 11.5 8C11.5 8.69036 12.0596 9.25 12.75 9.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_more = (more);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/question.js

var question_path;

function question(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), question_path || (question_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M6.14209 4.87551C6.14232 3.67087 7.22313 2.67293 8.41439 2.7553C9.61616 2.83839 10.5374 3.98528 10.3733 5.16806C10.2669 5.93479 9.70614 6.622 8.97633 6.88003C8.01504 7.2199 7.663 8.0029 7.55047 8.70632C7.49611 9.04614 7.49129 9.39066 7.49667 9.69131C7.49941 9.84464 7.50394 9.97113 7.5081 10.0873C7.51321 10.2303 7.51777 10.3576 7.51777 10.5002C7.51777 10.9144 7.85356 11.2502 8.26777 11.2502C8.68199 11.2502 9.01777 10.9144 9.01777 10.5002C9.01777 10.3504 9.01151 10.1615 9.00563 9.98422L9.00563 9.98418C9.00177 9.86783 8.99807 9.75649 8.99643 9.66448C8.99154 9.39108 8.99836 9.15128 9.03164 8.94327C9.09438 8.55103 9.22163 8.38429 9.47633 8.29424C10.7347 7.84936 11.6756 6.69619 11.8591 5.37421C12.1418 3.33617 10.5922 1.40229 8.51785 1.25887C6.4652 1.11695 4.64249 2.79596 4.64209 4.87522C4.64201 5.28944 4.97773 5.62529 5.39195 5.62537C5.80616 5.62545 6.14201 5.28972 6.14209 4.87551ZM8.25 14.5C8.80228 14.5 9.25 14.0523 9.25 13.5C9.25 12.9477 8.80228 12.5 8.25 12.5C7.69772 12.5 7.25 12.9477 7.25 13.5C7.25 14.0523 7.69772 14.5 8.25 14.5Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_question = (question);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/reset.js

var reset_path;

function reset_reset(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), reset_path || (reset_path = react.createElement("path", {
    d: "M5.33333 14.4741L5.96679 14.0726L5.83933 13.8715L5.61924 13.7808L5.33333 14.4741ZM6.41667 10.6667C6.41667 10.2525 6.08088 9.91667 5.66667 9.91667C5.25245 9.91667 4.91667 10.2525 4.91667 10.6667H6.41667ZM5.66667 15V15.75C6.08088 15.75 6.41667 15.4142 6.41667 15H5.66667ZM1.33333 14.25C0.91912 14.25 0.583333 14.5858 0.583333 15C0.583333 15.4142 0.91912 15.75 1.33333 15.75V14.25ZM9.34002 14.1062C8.93534 14.1945 8.67891 14.5942 8.76726 14.9989C8.85561 15.4036 9.25529 15.66 9.65998 15.5717L9.34002 14.1062ZM1.75 8C1.75 4.54822 4.54822 1.75 8 1.75V0.25C3.71979 0.25 0.25 3.71979 0.25 8H1.75ZM8 1.75C11.4518 1.75 14.25 4.54822 14.25 8H15.75C15.75 3.71979 12.2802 0.25 8 0.25V1.75ZM5.61924 13.7808C3.34704 12.8439 1.75 10.6075 1.75 8H0.25C0.25 11.236 2.23311 14.0071 5.04743 15.1675L5.61924 13.7808ZM4.91667 10.6667V15H6.41667V10.6667H4.91667ZM5.66667 14.25H1.33333V15.75H5.66667V14.25ZM4.69988 14.8757L5.03321 15.4015L6.30012 14.5985L5.96679 14.0726L4.69988 14.8757ZM14.25 8C14.25 10.9911 12.148 13.4931 9.34002 14.1062L9.65998 15.5717C13.1423 14.8114 15.75 11.7111 15.75 8H14.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_reset = (reset_reset);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/save.js

var save_path;

function save(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), save_path || (save_path = react.createElement("path", {
    d: "M6.13333 5.2L8 7.06667M8 7.06667L9.86667 5.2M8 7.06667V1M8.5 12.5H4M12.0444 12.5H11.4222M1.93333 15H14.0667C14.5821 15 15 14.5821 15 14.0667V10.3333C15 9.81787 14.5821 9.4 14.0667 9.4H1.93333C1.41787 9.4 1 9.81787 1 10.3333V14.0667C1 14.5821 1.41787 15 1.93333 15Z",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_save = (save);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/subtract.js

var subtract_path;

function subtract(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), subtract_path || (subtract_path = react.createElement("path", {
    d: "M14 8.75C14.4142 8.75 14.75 8.41421 14.75 8C14.75 7.58579 14.4142 7.25 14 7.25V8.75ZM2 7.25C1.58579 7.25 1.25 7.58579 1.25 8C1.25 8.41421 1.58579 8.75 2 8.75V7.25ZM14 7.25H2V8.75H14V7.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_subtract = (subtract);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/primary_icons.js
























;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/add_medium.js

var add_medium_path;

function add_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), add_medium_path || (add_medium_path = react.createElement("path", {
    d: "M11.25 21C11.25 21.4142 11.5858 21.75 12 21.75C12.4142 21.75 12.75 21.4142 12.75 21H11.25ZM12.75 3C12.75 2.58579 12.4142 2.25 12 2.25C11.5858 2.25 11.25 2.58579 11.25 3H12.75ZM21 12.75C21.4142 12.75 21.75 12.4142 21.75 12C21.75 11.5858 21.4142 11.25 21 11.25V12.75ZM3 11.25C2.58579 11.25 2.25 11.5858 2.25 12C2.25 12.4142 2.58579 12.75 3 12.75V11.25ZM12.75 21V3H11.25V21H12.75ZM21 11.25H3V12.75H21V11.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_add_medium = (add_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_down_medium.js

var arrow_down_medium_path;

function arrow_down_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_down_medium_path || (arrow_down_medium_path = react.createElement("path", {
    d: "M5.03033 14.0947C4.73744 13.8018 4.26256 13.8018 3.96967 14.0947C3.67678 14.3876 3.67678 14.8624 3.96967 15.1553L5.03033 14.0947ZM12 22.125L11.4697 22.6553C11.7626 22.9482 12.2374 22.9482 12.5303 22.6553L12 22.125ZM20.0303 15.1553C20.3232 14.8624 20.3232 14.3876 20.0303 14.0947C19.7374 13.8018 19.2626 13.8018 18.9697 14.0947L20.0303 15.1553ZM12.75 1.875C12.75 1.46079 12.4142 1.125 12 1.125C11.5858 1.125 11.25 1.46079 11.25 1.875H12.75ZM3.96967 15.1553L11.4697 22.6553L12.5303 21.5947L5.03033 14.0947L3.96967 15.1553ZM12.5303 22.6553L20.0303 15.1553L18.9697 14.0947L11.4697 21.5947L12.5303 22.6553ZM11.25 1.875V22.125H12.75V1.875H11.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_arrow_down_medium = (arrow_down_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_left_medium.js

var arrow_left_medium_path;

function arrow_left_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_left_medium_path || (arrow_left_medium_path = react.createElement("path", {
    d: "M22.25 11.5H2M9.5 4L2 11.5M2 11.5L9.5 19",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_arrow_left_medium = (arrow_left_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_right_medium.js

var arrow_right_medium_path;

function arrow_right_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_right_medium_path || (arrow_right_medium_path = react.createElement("path", {
    d: "M2.25 12H22.5M15 19.5L22.5 12M22.5 12L15 4.5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_arrow_right_medium = (arrow_right_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/arrow_up_medium.js

var arrow_up_medium_path;

function arrow_up_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), arrow_up_medium_path || (arrow_up_medium_path = react.createElement("path", {
    d: "M3.96967 8.84467C3.67678 9.13756 3.67678 9.61244 3.96967 9.90533C4.26256 10.1982 4.73744 10.1982 5.03033 9.90533L3.96967 8.84467ZM12 1.875L12.5303 1.34467C12.2374 1.05178 11.7626 1.05178 11.4697 1.34467L12 1.875ZM18.9697 9.90533C19.2626 10.1982 19.7374 10.1982 20.0303 9.90533C20.3232 9.61244 20.3232 9.13756 20.0303 8.84467L18.9697 9.90533ZM11.25 22.125C11.25 22.5392 11.5858 22.875 12 22.875C12.4142 22.875 12.75 22.5392 12.75 22.125H11.25ZM5.03033 9.90533L12.5303 2.40533L11.4697 1.34467L3.96967 8.84467L5.03033 9.90533ZM11.4697 2.40533L18.9697 9.90533L20.0303 8.84467L12.5303 1.34467L11.4697 2.40533ZM12.75 22.125V1.875H11.25V22.125H12.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_arrow_up_medium = (arrow_up_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/bell_medium.js

var bell_medium_path;

function bell_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), bell_medium_path || (bell_medium_path = react.createElement("path", {
    d: "M10 21.75C10.127 22.1827 10.3908 22.5626 10.7518 22.8328C11.1127 23.1031 11.5516 23.2492 12.0025 23.2492C12.4534 23.2492 12.8923 23.1031 13.2532 22.8328C13.6142 22.5626 13.878 22.1827 14.005 21.75M12 3C13.9891 3 15.8968 3.79018 17.3033 5.1967C18.7098 6.60322 19.5 8.51088 19.5 10.5C19.5 17.546 21 18.75 21 18.75H3C3 18.75 4.5 16.834 4.5 10.5C4.5 8.51088 5.29018 6.60322 6.6967 5.1967C8.10322 3.79018 10.0109 3 12 3ZM12 3V0.75",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_bell_medium = (bell_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/calendar_medium.js

var calendar_medium_path;

function calendar_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), calendar_medium_path || (calendar_medium_path = react.createElement("path", {
    d: "M7.25 1C7.25 0.585786 6.91421 0.25 6.5 0.25C6.08579 0.25 5.75 0.585786 5.75 1H7.25ZM5.75 6C5.75 6.41421 6.08579 6.75 6.5 6.75C6.91421 6.75 7.25 6.41421 7.25 6H5.75ZM18.25 1C18.25 0.585786 17.9142 0.25 17.5 0.25C17.0858 0.25 16.75 0.585786 16.75 1H18.25ZM16.75 6C16.75 6.41421 17.0858 6.75 17.5 6.75C17.9142 6.75 18.25 6.41421 18.25 6H16.75ZM2.5 23.25H21.5V21.75H2.5V23.25ZM5.75 1V6H7.25V1H5.75ZM16.75 1V6H18.25V1H16.75ZM21.5 2.75H2.5V4.25H21.5V2.75ZM0.75 4.5V9.5H2.25V4.5H0.75ZM0.75 9.5V21.5H2.25V9.5H0.75ZM23.25 21.5V9.5H21.75V21.5H23.25ZM23.25 9.5V4.5H21.75V9.5H23.25ZM22.5 8.75H1.5V10.25H22.5V8.75ZM21.5 4.25C21.6381 4.25 21.75 4.36193 21.75 4.5H23.25C23.25 3.5335 22.4665 2.75 21.5 2.75V4.25ZM21.5 23.25C22.4665 23.25 23.25 22.4665 23.25 21.5H21.75C21.75 21.6381 21.6381 21.75 21.5 21.75V23.25ZM2.5 21.75C2.36193 21.75 2.25 21.6381 2.25 21.5H0.75C0.75 22.4665 1.5335 23.25 2.5 23.25V21.75ZM2.5 2.75C1.5335 2.75 0.75 3.5335 0.75 4.5H2.25C2.25 4.36193 2.36193 4.25 2.5 4.25V2.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_calendar_medium = (calendar_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/check_medium.js

var check_medium_path;

function check_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), check_medium_path || (check_medium_path = react.createElement("path", {
    d: "M1.5 15L7.5 21L22.5 3",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_check_medium = (check_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down_medium.js

var chevron_down_medium_path;

function chevron_down_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_down_medium_path || (chevron_down_medium_path = react.createElement("path", {
    d: "M19 8.5L12 15.5L5 8.5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_down_medium = (chevron_down_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_left_medium.js

var chevron_left_medium_path;

function chevron_left_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_left_medium_path || (chevron_left_medium_path = react.createElement("path", {
    d: "M15 5L8 12L15 19",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_left_medium = (chevron_left_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_right_medium.js

var chevron_right_medium_path;

function chevron_right_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_right_medium_path || (chevron_right_medium_path = react.createElement("path", {
    d: "M9 19L16 12L9 5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_right_medium = (chevron_right_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up_medium.js

var chevron_up_medium_path;

function chevron_up_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), chevron_up_medium_path || (chevron_up_medium_path = react.createElement("path", {
    d: "M5 15.5L12 8.5L19 15.5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_chevron_up_medium = (chevron_up_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/close_medium.js

var close_medium_path;

function close_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), close_medium_path || (close_medium_path = react.createElement("path", {
    d: "M5 19L19 5M19 19L5 5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_close_medium = (close_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/download_medium.js

var download_medium_path;

function download_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), download_medium_path || (download_medium_path = react.createElement("path", {
    d: "M8.28033 11.7197C7.98744 11.4268 7.51256 11.4268 7.21967 11.7197C6.92678 12.0126 6.92678 12.4874 7.21967 12.7803L8.28033 11.7197ZM12 16.5L11.4697 17.0303C11.7626 17.3232 12.2374 17.3232 12.5303 17.0303L12 16.5ZM16.7803 12.7803C17.0732 12.4874 17.0732 12.0126 16.7803 11.7197C16.4874 11.4268 16.0126 11.4268 15.7197 11.7197L16.7803 12.7803ZM12.75 3C12.75 2.58579 12.4142 2.25 12 2.25C11.5858 2.25 11.25 2.58579 11.25 3H12.75ZM4 20.5C3.58579 20.5 3.25 20.8358 3.25 21.25C3.25 21.6642 3.58579 22 4 22V20.5ZM20 22C20.4142 22 20.75 21.6642 20.75 21.25C20.75 20.8358 20.4142 20.5 20 20.5V22ZM7.21967 12.7803L11.4697 17.0303L12.5303 15.9697L8.28033 11.7197L7.21967 12.7803ZM12.5303 17.0303L16.7803 12.7803L15.7197 11.7197L11.4697 15.9697L12.5303 17.0303ZM11.25 3V16.5H12.75V3H11.25ZM4 22H20V20.5H4V22Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_download_medium = (download_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/exclamation_medium.js

var exclamation_medium_path;

function exclamation_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), exclamation_medium_path || (exclamation_medium_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M12.75 3.25C12.75 2.83579 12.4142 2.5 12 2.5C11.5858 2.5 11.25 2.83579 11.25 3.25V15.1177C11.25 15.5319 11.5858 15.8677 12 15.8677C12.4142 15.8677 12.75 15.5319 12.75 15.1177V3.25ZM11.1666 18.7528C11.4133 18.588 11.7033 18.5 12 18.5C12.3978 18.5 12.7794 18.658 13.0607 18.9393C13.342 19.2206 13.5 19.6022 13.5 20C13.5 20.2967 13.412 20.5867 13.2472 20.8334C13.0824 21.08 12.8481 21.2723 12.574 21.3858C12.2999 21.4994 11.9983 21.5291 11.7074 21.4712C11.4164 21.4133 11.1491 21.2704 10.9393 21.0607C10.7296 20.8509 10.5867 20.5836 10.5288 20.2926C10.4709 20.0017 10.5006 19.7001 10.6142 19.426C10.7277 19.1519 10.92 18.9176 11.1666 18.7528Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_exclamation_medium = (exclamation_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/information_medium.js

var information_medium_path;

function information_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), information_medium_path || (information_medium_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M10.7491 5.99822C11.577 5.99822 12.2482 5.32705 12.2482 4.49911C12.2482 3.67118 11.577 3 10.7491 3C9.92118 3 9.25 3.67118 9.25 4.49911C9.25 5.32705 9.92118 5.99822 10.7491 5.99822ZM9.25 8.99602C8.83579 8.99602 8.5 9.3318 8.5 9.74602C8.5 10.1602 8.83579 10.496 9.25 10.496H10.3743C10.5811 10.496 10.7487 10.6636 10.7487 10.8703V18.492C10.7487 20.1481 12.0912 21.4907 13.7473 21.4907H14.8717C15.2859 21.4907 15.6217 21.1549 15.6217 20.7407C15.6217 20.3265 15.2859 19.9907 14.8717 19.9907H13.7473C12.9196 19.9907 12.2487 19.3197 12.2487 18.492V10.8703C12.2487 9.83518 11.4095 8.99602 10.3743 8.99602H9.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_information_medium = (information_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/loupe_medium.js

var loupe_medium_path;

function loupe_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), loupe_medium_path || (loupe_medium_path = react.createElement("path", {
    d: "M18.0303 16.9697C17.7374 16.6768 17.2626 16.6768 16.9697 16.9697C16.6768 17.2626 16.6768 17.7374 16.9697 18.0303L18.0303 16.9697ZM22.4697 23.5303C22.7626 23.8232 23.2374 23.8232 23.5303 23.5303C23.8232 23.2374 23.8232 22.7626 23.5303 22.4697L22.4697 23.5303ZM16.9697 18.0303L22.4697 23.5303L23.5303 22.4697L18.0303 16.9697L16.9697 18.0303ZM17.25 9.5C17.25 13.7802 13.7802 17.25 9.5 17.25V18.75C14.6086 18.75 18.75 14.6086 18.75 9.5H17.25ZM9.5 17.25C5.21979 17.25 1.75 13.7802 1.75 9.5H0.25C0.25 14.6086 4.39137 18.75 9.5 18.75V17.25ZM1.75 9.5C1.75 5.21979 5.21979 1.75 9.5 1.75V0.25C4.39137 0.25 0.25 4.39137 0.25 9.5H1.75ZM9.5 1.75C13.7802 1.75 17.25 5.21979 17.25 9.5H18.75C18.75 4.39137 14.6086 0.25 9.5 0.25V1.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_loupe_medium = (loupe_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/more_medium.js

var more_medium_path, more_medium_path2, more_medium_path3;

function more_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), more_medium_path || (more_medium_path = react.createElement("path", {
    d: "M8 12C8 13.1046 7.10457 14 6 14C4.89543 14 4 13.1046 4 12C4 10.8954 4.89543 10 6 10C7.10457 10 8 10.8954 8 12Z",
    fill: "black"
  })), more_medium_path2 || (more_medium_path2 = react.createElement("path", {
    d: "M12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14Z",
    fill: "black"
  })), more_medium_path3 || (more_medium_path3 = react.createElement("path", {
    d: "M18 14C19.1046 14 20 13.1046 20 12C20 10.8954 19.1046 10 18 10C16.8954 10 16 10.8954 16 12C16 13.1046 16.8954 14 18 14Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_more_medium = (more_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/question_medium.js

var question_medium_path;

function question_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), question_medium_path || (question_medium_path = react.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M8.5 7.42848C8.50037 5.47652 10.2348 3.87483 12.1655 4.00832C14.1128 4.14296 15.5914 5.98343 15.3254 7.90039C15.1514 9.1544 14.2656 10.24 13.072 10.662C12.4944 10.8662 12.0603 11.2041 11.7553 11.6382C11.458 12.0612 11.309 12.5388 11.2323 12.9938C11.1558 13.4475 11.1458 13.9139 11.1516 14.3359C11.1546 14.553 11.1606 14.7361 11.1662 14.9076L11.1662 14.9076C11.1729 15.1091 11.179 15.2946 11.179 15.5002C11.179 15.9144 11.5148 16.2502 11.929 16.2502C12.3432 16.2502 12.679 15.9144 12.679 15.5002C12.679 15.299 12.6714 15.0501 12.6641 14.8097L12.6641 14.8096V14.8096C12.6587 14.6329 12.6534 14.4607 12.6514 14.3153C12.6461 13.9223 12.6575 13.5626 12.7114 13.2431C12.7651 12.9248 12.8553 12.6818 12.9826 12.5005C13.1022 12.3303 13.278 12.1802 13.572 12.0762C15.2941 11.4674 16.5602 9.9158 16.8112 8.10654C17.1959 5.33395 15.0884 2.70684 12.269 2.5119C9.47647 2.31882 7.00054 4.60197 7 7.42819C6.99992 7.84241 7.33564 8.17826 7.74986 8.17834C8.16407 8.17842 8.49992 7.84269 8.5 7.42848ZM12 21.5C12.8284 21.5 13.5 20.8284 13.5 20C13.5 19.1716 12.8284 18.5 12 18.5C11.1716 18.5 10.5 19.1716 10.5 20C10.5 20.8284 11.1716 21.5 12 21.5Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_question_medium = (question_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/reset_medium.js

var reset_medium_path;

function reset_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), reset_medium_path || (reset_medium_path = react.createElement("path", {
    d: "M13.6276 21.6149C13.2191 21.6835 12.9436 22.0702 13.0122 22.4787C13.0808 22.8872 13.4675 23.1628 13.876 23.0942L13.6276 21.6149ZM8 21.7112L8.63345 21.3097L8.506 21.1086L8.2859 21.0179L8 21.7112ZM9.25 16C9.25 15.5858 8.91421 15.25 8.5 15.25C8.08579 15.25 7.75 15.5858 7.75 16H9.25ZM8.5 22.5V23.25C8.91421 23.25 9.25 22.9142 9.25 22.5H8.5ZM2 21.75C1.58579 21.75 1.25 22.0858 1.25 22.5C1.25 22.9142 1.58579 23.25 2 23.25V21.75ZM2.25 12C2.25 6.61522 6.61522 2.25 12 2.25V0.75C5.7868 0.75 0.75 5.7868 0.75 12H2.25ZM12 2.25C17.3848 2.25 21.75 6.61522 21.75 12H23.25C23.25 5.7868 18.2132 0.75 12 0.75V2.25ZM21.75 12C21.75 16.8298 18.2375 20.8407 13.6276 21.6149L13.876 23.0942C19.1964 22.2006 23.25 17.5744 23.25 12H21.75ZM8.2859 21.0179C4.74208 19.5566 2.25 16.0684 2.25 12H0.75C0.75 16.6969 3.62815 20.7198 7.7141 22.4046L8.2859 21.0179ZM7.75 16V22.5H9.25V16H7.75ZM8.5 21.75H2V23.25H8.5V21.75ZM7.36655 22.1128L7.86655 22.9015L9.13345 22.0985L8.63345 21.3097L7.36655 22.1128Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_reset_medium = (reset_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/save_medium.js

var save_medium_path;

function save_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), save_medium_path || (save_medium_path = react.createElement("path", {
    d: "M9 7.5L12 10.5M12 10.5L15 7.5M12 10.5V0.75M19.5 20.25H4.5M18.5 17.25H17.5M2.25 23.25H21.75C22.5784 23.25 23.25 22.5784 23.25 21.75V15.75C23.25 14.9216 22.5784 14.25 21.75 14.25H2.25C1.42157 14.25 0.75 14.9216 0.75 15.75V21.75C0.75 22.5784 1.42157 23.25 2.25 23.25Z",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const icons_save_medium = (save_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/subtract_medium.js

var subtract_medium_path;

function subtract_medium(props) {
  return react.createElement("svg", (0,esm_extends/* default */.Z)({
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), subtract_medium_path || (subtract_medium_path = react.createElement("path", {
    d: "M21 12.75C21.4142 12.75 21.75 12.4142 21.75 12C21.75 11.5858 21.4142 11.25 21 11.25V12.75ZM3 11.25C2.58579 11.25 2.25 11.5858 2.25 12C2.25 12.4142 2.58579 12.75 3 12.75V11.25ZM21 11.25H3V12.75H21V11.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const icons_subtract_medium = (subtract_medium);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/icons/primary_icons_medium.js
























;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/icon-primary/IconPrimary.js







function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}







var icons = (0,esm_extends/* default */.Z)({}, primary_icons_namespaceObject, primary_icons_medium_namespaceObject);

var IconPrimary = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(IconPrimary2, _React$PureComponent);
  var _super = _createSuper(IconPrimary2);
  function IconPrimary2() {
    (0,classCallCheck/* default */.Z)(this, IconPrimary2);
    return _super.apply(this, arguments);
  }
  (0,createClass/* default */.Z)(IconPrimary2, [{
    key: "render",
    value: function render() {
      var _this$context;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, IconPrimary2.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.FormRow, this.context.Icon, this.context.IconPrimary);
      var _prepareIcon = (0,Icon/* prepareIcon */.PS)(props, this.context), icon = _prepareIcon.icon, size = _prepareIcon.size, wrapperParams = _prepareIcon.wrapperParams, iconParams = _prepareIcon.iconParams, alt = _prepareIcon.alt;
      var IconContainer = (0,Icon/* prerenderIcon */.rj)({
        icon,
        size,
        alt,
        listOfIcons: icons
      });
      if (!IconContainer)
        return react.createElement(react.Fragment, null);
      return react.createElement("span", wrapperParams, react.createElement(IconContainer, iconParams));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      Icon/* default.enableWebComponent */.ZP.enableWebComponent(IconPrimary2.tagName, IconPrimary2);
    }
  }, {
    key: "getIcon",
    value: function getIcon(props) {
      return Icon/* default.getIcon */.ZP.getIcon(props);
    }
  }]);
  return IconPrimary2;
}(react.PureComponent);
IconPrimary.tagName = "dnb-icon-primary";
IconPrimary.contextType = Context/* default */.Z;
IconPrimary.defaultProps = (0,esm_extends/* default */.Z)({}, Icon/* default.defaultProps */.ZP.defaultProps);

 false ? 0 : void 0;


/***/ }),

/***/ 3231:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ Icon),
/* harmony export */   "PS": () => (/* binding */ prepareIcon),
/* harmony export */   "rj": () => (/* binding */ prerenderIcon)
/* harmony export */ });
/* unused harmony exports DefaultIconSize, DefaultIconSizes, ListDefaultIconSizes, ValidIconSizes, iconPropTypes, getIconNameFromComponent, calcSize, iconCase */
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9840);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3086);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4973);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(225);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1733);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8731);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(520);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6654);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9332);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6091);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(855);
/* harmony import */ var _shared_error_helper__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2333);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6357);
/* harmony import */ var _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3039);
/* harmony import */ var _skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(5818);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3898);



















function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}








var DefaultIconSize = 16;
var DefaultIconSizes = {
  default: 16,
  medium: 24
};
var ListDefaultIconSizes = [["default", 16], ["medium", 24]];
var ValidIconSizes = ["small", "default", "medium", "large", "x-large", "xx-large"];
var iconPropTypes = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
  icon: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.node, prop_types__WEBPACK_IMPORTED_MODULE_14__.func]),
  modifier: prop_types__WEBPACK_IMPORTED_MODULE_14__.string,
  size: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOf(["default", "medium", "large"])])
}, _space_SpacingHelper__WEBPACK_IMPORTED_MODULE_17__/* .spacingPropTypes */ .Xj, {
  width: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number]),
  border: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  color: prop_types__WEBPACK_IMPORTED_MODULE_14__.string,
  inherit_color: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  alt: prop_types__WEBPACK_IMPORTED_MODULE_14__.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_14__.string,
  skeleton: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.object]),
  className: prop_types__WEBPACK_IMPORTED_MODULE_14__.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.node, prop_types__WEBPACK_IMPORTED_MODULE_14__.func])
});
var Icon = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_18__/* .default */ .Z)(Icon2, _React$PureComponent);
  var _super = _createSuper(Icon2);
  function Icon2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_19__/* .default */ .Z)(this, Icon2);
    return _super.apply(this, arguments);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_20__/* .default */ .Z)(Icon2, [{
    key: "render",
    value: function render() {
      var _this$context;
      var props = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .extendPropsWithContext */ .Xw)(this.props, Icon2.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.FormRow, this.context.Icon);
      var _prepareIcon = prepareIcon(props, this.context), icon = _prepareIcon.icon, size = _prepareIcon.size, wrapperParams = _prepareIcon.wrapperParams, iconParams = _prepareIcon.iconParams, alt = _prepareIcon.alt;
      if (!icon) {
        return null;
      }
      var IconContainer = prerenderIcon({
        icon,
        size,
        alt
      });
      if (!IconContainer)
        return react__WEBPACK_IMPORTED_MODULE_13__.createElement(react__WEBPACK_IMPORTED_MODULE_13__.Fragment, null);
      return react__WEBPACK_IMPORTED_MODULE_13__.createElement("span", wrapperParams, react__WEBPACK_IMPORTED_MODULE_13__.createElement(IconContainer, iconParams));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      var tag = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Icon2.tagName;
      var inst = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Icon2;
      var props = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Icon2.defaultProps;
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_22__/* .registerElement */ .ui)(tag, inst, props);
    }
  }, {
    key: "getIcon",
    value: function getIcon(props) {
      if (props.icon) {
        return props.icon;
      }
      return (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .processChildren */ .Ob)(props);
    }
  }]);
  return Icon2;
}(react__WEBPACK_IMPORTED_MODULE_13__.PureComponent);
Icon.tagName = "dnb-icon";
Icon.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_23__/* .default */ .Z;
Icon.defaultProps = {
  icon: null,
  modifier: null,
  size: null,
  width: null,
  height: null,
  border: null,
  color: null,
  inherit_color: true,
  alt: null,
  title: null,
  skeleton: null,
  attributes: null,
  className: null,
  children: null
};

 false ? 0 : void 0;
var getIconNameFromComponent = function getIconNameFromComponent2(icon) {
  var name = typeof icon === "string" ? icon : icon && (icon.displayName || icon.name);
  if (/^data:image\//.test(name)) {
    return null;
  }
  return name;
};
var calcSize = function calcSize2(props) {
  var icon = props.icon, size = props.size, width = props.width, height = props.height;
  var sizeAsInt = -1;
  var sizeAsString = null;
  if (!size || size === DefaultIconSize) {
    var name = getIconNameFromComponent(icon);
    var nameParts = String(name || "").split("_");
    if (nameParts.length > 1) {
      var lastPartOfIconName = nameParts.reverse()[0];
      var potentialSize = ListDefaultIconSizes.filter(function(_ref) {
        var _ref2 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref, 1), key = _ref2[0];
        return key === lastPartOfIconName;
      }).reduce(function(acc, _ref3) {
        var _ref4 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref3, 2), key = _ref4[0], value = _ref4[1];
        return key && value;
      }, null);
      if (potentialSize) {
        sizeAsInt = potentialSize;
      }
      if (ValidIconSizes.includes(lastPartOfIconName)) {
        sizeAsString = lastPartOfIconName;
      }
    } else {
      if (typeof icon === "function") {
        var elem = icon();
        if (elem.props) {
          var _potentialSize = -1;
          if (elem.props.width) {
            _potentialSize = elem.props.width;
          }
          if (!_potentialSize && elem.props.viewBox) {
            _potentialSize = /[0-9]+ [0-9]+ ([0-9]+)/.exec(elem.props.viewBox)[1];
          }
          if (_potentialSize) {
            sizeAsInt = _potentialSize;
          }
        }
      }
    }
  } else if (typeof size === "string" && !(parseFloat(size) > 0)) {
    sizeAsInt = ListDefaultIconSizes.filter(function(_ref5) {
      var _ref6 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref5, 1), key = _ref6[0];
      return key === size;
    }).reduce(function(acc, _ref7) {
      var _ref8 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref7, 2), key = _ref8[0], value = _ref8[1];
      return key && value;
    }, -1);
    if (ValidIconSizes.includes(size)) {
      sizeAsString = size;
    }
  } else if (parseFloat(size) > 0) {
    sizeAsInt = ListDefaultIconSizes.filter(function(_ref9) {
      var _ref10 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref9, 2), key = _ref10[0], value = _ref10[1];
      return key && value === parseFloat(size);
    }).reduce(function(acc, _ref11) {
      var _ref12 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref11, 2), key = _ref12[0], value = _ref12[1];
      if (key && value)
        return value;
      return acc;
    }, -1);
    if (sizeAsInt === -1) {
      sizeAsInt = parseFloat(size);
      sizeAsString = "custom-size";
    }
  }
  if (!sizeAsString && sizeAsInt > 0) {
    var potentialSizeAsString = ListDefaultIconSizes.reduce(function(acc, _ref13) {
      var _ref14 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_24__/* .default */ .Z)(_ref13, 2), key = _ref14[0], value = _ref14[1];
      if (key && value === sizeAsInt) {
        return key;
      }
      return acc;
    }, null);
    if (potentialSizeAsString) {
      sizeAsString = potentialSizeAsString;
    }
  }
  var _prepareIconParams = prepareIconParams({
    sizeAsString,
    sizeAsInt,
    size,
    width,
    height
  }), isCustomSize = _prepareIconParams.sizeAsString, iconParams = _prepareIconParams.params;
  if (isCustomSize) {
    sizeAsString = isCustomSize;
  }
  if (!(sizeAsInt > 0)) {
    sizeAsInt = DefaultIconSize;
  }
  if (size === "auto") {
    iconParams.width = "100%";
    iconParams.height = "100%";
    sizeAsString = "auto";
  }
  return {
    iconParams,
    sizeAsInt,
    sizeAsString
  };
};
var prepareIconParams = function prepareIconParams2(_ref15) {
  var sizeAsString = _ref15.sizeAsString, rest = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_25__/* .default */ .Z)(_ref15, ["sizeAsString"]);
  var size = rest.size, width = rest.width, height = rest.height, sizeAsInt = rest.sizeAsInt;
  var params = {};
  if (!sizeAsString && !(sizeAsInt > 0) && parseFloat(size) > -1) {
    params.width = params.height = parseFloat(size);
  } else if (sizeAsString === "custom-size") {
    params.width = params.height = parseFloat(sizeAsInt);
  }
  if (parseFloat(width) > -1) {
    sizeAsString = "custom-size";
    params.width = parseFloat(width);
  }
  if (parseFloat(height) > -1) {
    sizeAsString = "custom-size";
    params.height = parseFloat(height);
  }
  (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .validateDOMAttributes */ .L_)({}, params);
  return {
    params,
    sizeAsString
  };
};
var prepareIcon = function prepareIcon2(props, context) {
  var icon = props.icon, size = props.size, width = props.width, height = props.height, border = props.border, color = props.color, inherit_color = props.inherit_color, modifier = props.modifier, alt = props.alt, title = props.title, skeleton = props.skeleton, _className = props.class, className = props.className, attributes = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_25__/* .default */ .Z)(props, ["icon", "size", "width", "height", "border", "color", "inherit_color", "modifier", "alt", "title", "skeleton", "class", "className"]);
  var _calcSize = calcSize({
    icon,
    size,
    width,
    height
  }), sizeAsString = _calcSize.sizeAsString, iconParams = _calcSize.iconParams;
  if (color) {
    iconParams.color = color;
  }
  var label = icon ? getIconNameFromComponent(icon) : null;
  var wrapperParams = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .validateDOMAttributes */ .L_)(props, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
    role: alt ? "img" : "presentation",
    alt,
    "aria-label": label && !label.includes("default") ? label.replace(/_/g, " ") + " icon" : null,
    title
  }, attributes));
  if (!alt && typeof wrapperParams["aria-hidden"] === "undefined") {
    wrapperParams["aria-hidden"] = true;
  }
  if (wrapperParams["aria-hidden"]) {
    if (typeof process !== "undefined" && "production" === "test") {
      wrapperParams["data-test-id"] = wrapperParams["aria-label"];
    }
    delete wrapperParams["aria-label"];
  }
  wrapperParams.className = classnames__WEBPACK_IMPORTED_MODULE_15__("dnb-icon", sizeAsString ? "dnb-icon--".concat(sizeAsString) : "dnb-icon--default", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_26__/* .createSkeletonClass */ .BD)(null, skeleton, context), (0,_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_17__/* .createSpacingClasses */ .HU)(props), _className, className, modifier && "dnb-icon--".concat(modifier), (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .isTrue */ .oA)(border) && "dnb-icon--border", (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .isTrue */ .oA)(inherit_color) && "dnb-icon--inherit-color");
  var iconToRender = Icon.getIcon(props);
  if (iconToRender && typeof iconToRender.defaultProps !== "undefined") {
    iconToRender = react__WEBPACK_IMPORTED_MODULE_13__.createElement(iconToRender, (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_21__/* .validateDOMAttributes */ .L_)({}, {
      color,
      icon,
      size,
      width,
      height
    }));
  }
  return (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({}, props, {
    icon: iconToRender,
    alt,
    iconParams,
    wrapperParams
  });
};
var prerenderIcon = function prerenderIcon2() {
  var _ref16 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, icon = _ref16.icon, _ref16$size = _ref16.size, size = _ref16$size === void 0 ? null : _ref16$size, _ref16$listOfIcons = _ref16.listOfIcons, listOfIcons = _ref16$listOfIcons === void 0 ? null : _ref16$listOfIcons, _ref16$alt = _ref16.alt, alt = _ref16$alt === void 0 ? null : _ref16$alt;
  if (typeof icon === "string" && /^data:image\//.test(icon)) {
    return function() {
      return react__WEBPACK_IMPORTED_MODULE_13__.createElement("img", {
        src: icon,
        alt: alt || "no-alt"
      });
    };
  }
  if (typeof icon === "function") {
    var elem = icon();
    if (react__WEBPACK_IMPORTED_MODULE_13__.isValidElement(elem)) {
      return icon;
    }
    return elem;
  }
  if (react__WEBPACK_IMPORTED_MODULE_13__.isValidElement(icon) || Array.isArray(icon)) {
    return function() {
      return icon;
    };
  }
  try {
    icon = iconCase(icon);
    if (size && DefaultIconSizes[size] && size !== "default" && !(parseFloat(size) > 0) && !icon.includes(size)) {
      icon = "".concat(icon, "_").concat(size);
    }
    var mod = (listOfIcons.dnbIcons ? listOfIcons.dnbIcons : listOfIcons)[icon];
    return mod && mod.default ? mod.default : mod;
  } catch (e) {
    new _shared_error_helper__WEBPACK_IMPORTED_MODULE_27__/* .ErrorHandler */ .qL("Icon '".concat(icon, "' did not exist!"));
    return null;
  }
};
var iconCase = function iconCase2(name) {
  return name.replace(/((?!^)[A-Z])/g, "_$1").toLowerCase().replace(/^[0-9]/g, "$1").replace(/[^a-z0-9_]/gi, "_");
};


/***/ }),

/***/ 5818:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "rZ": () => (/* binding */ skeletonDOMAttributes),
/* harmony export */   "BD": () => (/* binding */ createSkeletonClass)
/* harmony export */ });
/* unused harmony export AutoSize */
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(691);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3086);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7110);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6050);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1218);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(855);
/* harmony import */ var _shared_helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6620);










function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var skeletonDOMAttributes = function skeletonDOMAttributes2(params, skeleton) {
  var context = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
  if ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .isTrue */ .oA)(skeleton) || skeleton !== false && context !== null && context !== void 0 && context.skeleton) {
    var _context$translation, _context$translation$;
    params.disabled = true;
    params["aria-disabled"] = true;
    params["aria-label"] = context === null || context === void 0 ? void 0 : (_context$translation = context.translation) === null || _context$translation === void 0 ? void 0 : (_context$translation$ = _context$translation.Skeleton) === null || _context$translation$ === void 0 ? void 0 : _context$translation$.aria_bussy;
  }
  return params;
};
var createSkeletonClass = function createSkeletonClass2(method, skeleton) {
  var context = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
  if ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .isTrue */ .oA)(skeleton) || skeleton !== false && context !== null && context !== void 0 && context.skeleton) {
    return "dnb-skeleton" + (method ? " dnb-skeleton--".concat(method) : "");
  }
  return null;
};
var AutoSize = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(AutoSize2, _React$PureComponent);
  var _super = _createSuper(AutoSize2);
  function AutoSize2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(this, AutoSize2);
    return _super.apply(this, arguments);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(AutoSize2, [{
    key: "render",
    value: function render() {
      var _this$props = this.props, className = _this$props.className, children = _this$props.children, Comp = _this$props.__element, style = _this$props.style, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(_this$props, ["className", "children", "__element", "style"]);
      var string = (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .convertJsxToString */ .F4)(children);
      if (typeof string === "string") {
        var countChars = string.trim().length;
        if (countChars > 0) {
          return react__WEBPACK_IMPORTED_MODULE_4__.createElement(Comp, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)({
            className: classnames__WEBPACK_IMPORTED_MODULE_6__("dnb-skeleton dnb-skeleton--font", className),
            "data-skeleton-chars": String(countChars),
            style: (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)({}, style || {}, (0,_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)({}, _shared_helpers__WEBPACK_IMPORTED_MODULE_14__/* .IS_IE11 */ .cW ? "maxWidth" : "--skeleton-chars", "".concat(countChars, "ch")))
          }, props), children);
        }
      }
      return react__WEBPACK_IMPORTED_MODULE_4__.createElement(Comp, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z)({}, props, {
        className,
        style
      }));
    }
  }]);
  return AutoSize2;
}(react__WEBPACK_IMPORTED_MODULE_4__.PureComponent);
AutoSize.defaultProps = {
  __element: null,
  children: null,
  className: null,
  style: null
};
 false ? 0 : void 0;


/***/ }),

/***/ 7171:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Space)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3086);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(855);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1218);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6357);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3898);
/* harmony import */ var _SpacingHelper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3039);
/* harmony import */ var _skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5818);








function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}








var Space = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(Space2, _React$PureComponent);
  var _super = _createSuper(Space2);
  function Space2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(this, Space2);
    return _super.apply(this, arguments);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(Space2, [{
    key: "render",
    value: function render() {
      var _this$context;
      var props = this.context.space ? (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .extendPropsWithContext */ .Xw)(this.props, Space2.defaultProps, {
        skeleton: (_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton
      }, this.context.space) : this.props;
      var element = props.element, inline = props.inline, no_collapse = props.no_collapse, top = props.top, right = props.right, bottom = props.bottom, left = props.left, space = props.space, skeleton = props.skeleton, _id = props.id, className = props.className, _className = props.class, attributes = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(props, ["element", "inline", "no_collapse", "top", "right", "bottom", "left", "space", "skeleton", "id", "className", "class"]);
      var children = Space2.getContent(this.props);
      var params = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({
        className: classnames__WEBPACK_IMPORTED_MODULE_5__("dnb-space", (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__/* .createSkeletonClass */ .BD)(null, skeleton), (0,_SpacingHelper__WEBPACK_IMPORTED_MODULE_13__/* .createSpacingClasses */ .HU)({
          top,
          right,
          bottom,
          left,
          space
        }), className, _className, (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .isTrue */ .oA)(inline) && "dnb-space--inline")
      }, attributes);
      (0,_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_12__/* .skeletonDOMAttributes */ .rZ)(params, skeleton);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .validateDOMAttributes */ .L_)(this.props, params);
      return react__WEBPACK_IMPORTED_MODULE_3__.createElement(Element, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({
        element,
        no_collapse
      }, params), children);
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_14__/* .registerElement */ .ui)(Space2.tagName, Space2, Space2.defaultProps);
    }
  }, {
    key: "getContent",
    value: function getContent(props) {
      return (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .processChildren */ .Ob)(props);
    }
  }]);
  return Space2;
}(react__WEBPACK_IMPORTED_MODULE_3__.PureComponent);
Space.tagName = "dnb-space";
Space.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z;
Space.defaultProps = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)({
  id: null,
  element: "div",
  inline: null,
  no_collapse: null
}, _SpacingHelper__WEBPACK_IMPORTED_MODULE_13__/* .spacingDefaultProps */ .lM, {
  skeleton: null,
  class: null,
  className: null,
  children: null
});

 false ? 0 : void 0;
var Element = function Element2(_ref) {
  var E = _ref.element, no_collapse = _ref.no_collapse, children = _ref.children, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(_ref, ["element", "no_collapse", "children"]);
  if ((0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .isTrue */ .oA)(no_collapse)) {
    var R = E === "span" || (0,_SpacingHelper__WEBPACK_IMPORTED_MODULE_13__/* .isInline */ .CZ)(Element2) ? "span" : "div";
    return react__WEBPACK_IMPORTED_MODULE_3__.createElement(R, {
      className: "dnb-space--no-collapse" + ((0,_SpacingHelper__WEBPACK_IMPORTED_MODULE_13__/* .isInline */ .CZ)(Element2) ? " dnb-space--inline" : "")
    }, react__WEBPACK_IMPORTED_MODULE_3__.createElement(E, props, children));
  }
  return react__WEBPACK_IMPORTED_MODULE_3__.createElement(E, props, children);
};
 false ? 0 : void 0;
Element.defaultProps = {
  children: null,
  element: "div",
  no_collapse: true
};


/***/ }),

/***/ 3039:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xj": () => (/* binding */ spacingPropTypes),
/* harmony export */   "lM": () => (/* binding */ spacingDefaultProps),
/* harmony export */   "HU": () => (/* binding */ createSpacingClasses),
/* harmony export */   "CZ": () => (/* binding */ isInline)
/* harmony export */ });
/* unused harmony exports spacePatterns, translateSpace, splitTypes, sumTypes, createTypeModifyers, findType, findNearestTypes, isValidSpaceProp, removeSpaceProps, createStyleObject */
/* harmony import */ var _babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2707);
/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9840);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1733);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(520);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8381);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1698);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1362);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5982);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8731);
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5860);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6091);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6654);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3070);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6050);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1218);



















var spacingPropTypes = {
  space: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool, prop_types__WEBPACK_IMPORTED_MODULE_14__.shape({
    top: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
    right: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
    bottom: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
    left: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool])
  })]),
  top: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  right: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  bottom: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool]),
  left: prop_types__WEBPACK_IMPORTED_MODULE_14__.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_14__.string, prop_types__WEBPACK_IMPORTED_MODULE_14__.number, prop_types__WEBPACK_IMPORTED_MODULE_14__.bool])
};
var spacingDefaultProps = {
  space: null,
  top: null,
  right: null,
  bottom: null,
  left: null
};
var spacePatterns = {
  "xx-small": 0.25,
  "x-small": 0.5,
  small: 1,
  medium: 1.5,
  large: 2,
  "x-large": 3,
  "xx-large": 3.5,
  "xx-large-x2": 7
};
var translateSpace = function translateSpace2(type) {
  if (/-x2$/.test(type)) {
    return spacePatterns[type.replace(/-x2$/, "")] * 2;
  }
  return spacePatterns[type] || 0;
};
var splitTypes = function splitTypes2(types) {
  if (typeof types === "string") {
    types = types.split(/ /g);
  } else if (typeof types === "boolean") {
    return ["small"];
  } else if (typeof types === "number") {
    return [types];
  }
  return types ? types.filter(function(r) {
    return r && r.length > 0;
  }) : null;
};
var sumTypes = function sumTypes2(types) {
  return splitTypes(types).map(function(type) {
    return translateSpace(type);
  }).reduce(function(acc, cur) {
    if (cur > 0) {
      acc += cur;
    } else if (cur < 0) {
      acc -= cur;
    }
    return acc;
  }, 0);
};
var createTypeModifyers = function createTypeModifyers2(types) {
  if (typeof types === "number") {
    types = String(types);
  }
  return (splitTypes(types) || []).reduce(function(acc, type) {
    if (type) {
      var firstLetter = type[0];
      if (parseFloat(firstLetter) > -1) {
        var num = parseFloat(type);
        if (num >= 8 && /[0-9]px/.test(type)) {
          num = num / 16;
        }
        var foundType = findType(num);
        if (foundType) {
          type = foundType;
        } else {
          findNearestTypes(num).forEach(function(type2) {
            if (type2) {
              acc.push(type2);
            }
          });
        }
      }
      if (!(parseFloat(type) > 0)) {
        acc.push(type);
      }
    }
    return acc;
  }, []);
};
var findType = function findType2(num) {
  var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$returnObject = _ref.returnObject, returnObject = _ref$returnObject === void 0 ? false : _ref$returnObject;
  var found = Object.entries(spacePatterns).find(function(_ref2) {
    var _ref3 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(_ref2, 2), k = _ref3[0], v = _ref3[1];
    return k && v === num;
  }) || null;
  if (returnObject) {
    return found;
  }
  if (found) {
    return found[0];
  }
  return found;
};
var findNearestTypes = function findNearestTypes2(num) {
  var res = [];
  var near = Object.entries(spacePatterns).reverse().find(function(_ref4) {
    var _ref5 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(_ref4, 2), k = _ref5[0], v = _ref5[1];
    return k && num >= v;
  });
  var nearNum = near && near[1] || num;
  var typeObject = findType(nearNum, {
    returnObject: true
  });
  if (typeObject) {
    var nearType = typeObject[0];
    res.push(nearType);
    var leftOver = num - parseFloat(typeObject[1]);
    var foundMoreTypes = findNearestTypes2(leftOver);
    foundMoreTypes.forEach(function(type) {
      var index = res.indexOf(type);
      if (index !== -1) {
        res[index] = "".concat(type, "-x2");
      }
    });
    res = [].concat((0,_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)(res), (0,_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)(foundMoreTypes));
  }
  return res;
};
var isValidSpaceProp = function isValidSpaceProp2(prop) {
  return prop && ["top", "right", "bottom", "left"].includes(prop);
};
var removeSpaceProps = function removeSpaceProps2(_ref6) {
  var props = _extends({}, _ref6);
  for (var i in props) {
    if (isValidSpaceProp(i)) {
      delete props[i];
    }
  }
  return props;
};
var createSpacingClasses = function createSpacingClasses2(props) {
  var Element = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  if (typeof props.space !== "undefined") {
    if (typeof props.space === "string" || typeof props.space === "number" || typeof props.space === "boolean" && props.space) {
      props.top = props.right = props.bottom = props.left = props.space;
    }
    for (var i in props.space) {
      if (!props[i] && isValidSpaceProp(i)) {
        props[i] = props.space[i];
      }
    }
    delete props.space;
  }
  return Object.entries(props).reduce(function(acc, _ref7) {
    var _ref8 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)(_ref7, 2), direction = _ref8[0], cur = _ref8[1];
    if (isValidSpaceProp(direction)) {
      if (String(cur) === "0" || String(cur) === "false") {
        acc.push("dnb-space__".concat(direction, "--zero"));
      } else if (cur) {
        var typeModifyers = createTypeModifyers(cur);
        var sum = sumTypes(typeModifyers);
        if (sum > 10) {
          (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_17__/* .warn */ .ZK)("Spacing of more than 10rem is not supported! You used ".concat(sum, " / (").concat(typeModifyers.join(","), ")"));
        } else {
          var nearestTypes = findNearestTypes(sum);
          acc = [].concat((0,_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)(acc), (0,_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)(nearestTypes.map(function(type) {
            return "dnb-space__".concat(direction, "--").concat(type);
          })));
        }
      }
    } else if (direction === "no_collapse") {
      acc.push("dnb-space--no-collapse");
      if (Element && isInline(Element)) {
        acc.push("dnb-space--inline");
      }
    }
    return acc;
  }, []);
};
var createStyleObject = function createStyleObject2(props) {
  if (props.top && !(parseFloat(props.top) > 0)) {
    props.top = sumTypes(props.top);
  }
  if (props.bottom && !(parseFloat(props.bottom) > 0)) {
    props.bottom = sumTypes(props.bottom);
  }
  if (props.left && !(parseFloat(props.left) > 0)) {
    props.left = sumTypes(props.left);
  }
  if (props.right && !(parseFloat(props.right) > 0)) {
    props.right = sumTypes(props.right);
  }
  return Object.entries({
    marginTop: props.top && "".concat(props.top, "rem"),
    marginBottom: props.bottom && "".concat(props.bottom, "rem"),
    maxWidth: props.maxWidth && "".concat(props.maxWidth, "rem"),
    maxHeight: props.maxHeight && "".concat(props.maxHeight, "rem"),
    width: props.width && "".concat(props.width, "rem"),
    height: props.height && "".concat(props.height, "rem")
  }).reduce(function(acc, _ref9) {
    var _ref10 = _slicedToArray(_ref9, 2), key = _ref10[0], val = _ref10[1];
    if (typeof val !== "undefined") {
      acc[key] = val;
    }
    return acc;
  }, {});
};
var isInline = function isInline2(Element) {
  var inline = false;
  switch (Element) {
    case "h1":
    case "h2":
    case "h3":
    case "h4":
    case "h5":
    case "h6":
    case "p":
      inline = true;
      break;
  }
  return inline;
};


/***/ }),

/***/ 5857:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3086);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6944);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(855);
/* harmony import */ var _shared_Context__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3898);
/* harmony import */ var _shared_component_helper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1218);
/* harmony import */ var _components_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3039);
/* harmony import */ var _components_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5818);











function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}







var Elem = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(Elem2, _React$PureComponent);
  var _super = _createSuper(Elem2);
  function Elem2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z)(this, Elem2);
    return _super.apply(this, arguments);
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(Elem2, [{
    key: "render",
    value: function render() {
      var _this$context, _this$context2;
      var props = this.props.skeleton !== false && typeof ((_this$context = this.context) === null || _this$context === void 0 ? void 0 : _this$context.skeleton) !== "undefined" ? (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .extendPropsWithContext */ .Xw)(this.props, Elem2.defaultProps, {
        skeleton: (_this$context2 = this.context) === null || _this$context2 === void 0 ? void 0 : _this$context2.skeleton
      }) : this.props;
      var className = props.className, _className = props.class, internalClass = props.internalClass, css = props.css, Tag = props.is, inner_ref = props.inner_ref, skeleton = props.skeleton, skeleton_method = props.skeleton_method, rest = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)(props, ["className", "class", "internalClass", "css", "is", "inner_ref", "skeleton", "skeleton_method"]);
      var tagClass = internalClass || "dnb-".concat(Tag);
      rest.className = classnames__WEBPACK_IMPORTED_MODULE_8__(className, _className, css, (0,_components_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__/* .createSkeletonClass */ .BD)(skeleton_method, skeleton, this.context), (0,_components_space_SpacingHelper__WEBPACK_IMPORTED_MODULE_15__/* .createSpacingClasses */ .HU)(rest, Tag), !new RegExp("".concat(tagClass, "(\\s|$)")).test(String(className)) && tagClass);
      (0,_shared_component_helper__WEBPACK_IMPORTED_MODULE_12__/* .validateDOMAttributes */ .L_)(null, rest);
      (0,_components_skeleton_SkeletonHelper__WEBPACK_IMPORTED_MODULE_14__/* .skeletonDOMAttributes */ .rZ)(rest, skeleton, this.context);
      return react__WEBPACK_IMPORTED_MODULE_6__.createElement(Tag, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
        ref: inner_ref
      }, rest));
    }
  }]);
  return Elem2;
}(react__WEBPACK_IMPORTED_MODULE_6__.PureComponent);
Elem.contextType = _shared_Context__WEBPACK_IMPORTED_MODULE_17__/* .default */ .Z;
Elem.defaultProps = {
  skeleton: null,
  skeleton_method: "font",
  className: null,
  class: null,
  internalClass: null,
  css: null,
  inner_ref: null,
  children: null
};
 false ? 0 : void 0;
var Element = react__WEBPACK_IMPORTED_MODULE_6__.forwardRef(function(props, ref) {
  return react__WEBPACK_IMPORTED_MODULE_6__.createElement(Elem, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_16__/* .default */ .Z)({
    inner_ref: ref
  }, props));
});
 false ? 0 : void 0;
Element.defaultProps = Elem.defaultProps;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Element);


/***/ }),

/***/ 3731:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8802);
/* harmony import */ var core_js_modules_es_string_small_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2409);
/* harmony import */ var core_js_modules_es_string_bold_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2736);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1733);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(520);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6654);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6091);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(855);
/* harmony import */ var _Element__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5857);















var P = function P2(_ref) {
  var style_type = _ref.style_type, modifier = _ref.modifier, element = _ref.element, className = _ref.className, small = _ref.small, medium = _ref.medium, bold = _ref.bold, size = _ref.size, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(_ref, ["style_type", "modifier", "element", "className", "small", "medium", "bold", "size"]);
  if (typeof modifier === "string" && / /.test(modifier)) {
    modifier = modifier.split(/ /g);
  } else if (!Array.isArray(modifier)) {
    modifier = [modifier];
  }
  if (style_type) {
    modifier.push(style_type);
  }
  if (medium === true) {
    modifier.push("medium");
  } else if (bold === true) {
    modifier.push("bold");
  }
  modifier = modifier.filter(Boolean).reduce(function(acc, cur) {
    if (["x-small", "small"].includes(cur)) {
      return "".concat(acc, " dnb-p__size--").concat(cur);
    }
    return "".concat(acc, " dnb-p--").concat(cur);
  }, "");
  if (size) {
    className = classnames__WEBPACK_IMPORTED_MODULE_10__(className, "dnb-p__size--".concat(size));
  } else if (small === true) {
    className = classnames__WEBPACK_IMPORTED_MODULE_10__(className, "dnb-p__size--small");
  }
  return react__WEBPACK_IMPORTED_MODULE_8__.createElement(_Element__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z)({
    is: element
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_10__("dnb-p", modifier, className)
  }));
};
P.tagName = "dnb-p";
 false ? 0 : void 0;
P.defaultProps = {
  element: "p",
  className: null,
  small: null,
  medium: null,
  bold: null,
  size: null,
  style_type: null,
  modifier: null,
  children: null
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (P);


/***/ }),

/***/ 43:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

var _path;

function add(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M7.25 14C7.25 14.4142 7.58579 14.75 8 14.75C8.41421 14.75 8.75 14.4142 8.75 14H7.25ZM8.75 2C8.75 1.58579 8.41421 1.25 8 1.25C7.58579 1.25 7.25 1.58579 7.25 2H8.75ZM14 8.75C14.4142 8.75 14.75 8.41421 14.75 8C14.75 7.58579 14.4142 7.25 14 7.25V8.75ZM2 7.25C1.58579 7.25 1.25 7.58579 1.25 8C1.25 8.41421 1.58579 8.75 2 8.75V7.25ZM8.75 14V2H7.25V14H8.75ZM14 7.25H2V8.75H14V7.25Z",
    fill: "black"
  })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (add);


/***/ }),

/***/ 2296:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

var _path;

function arrow_right(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M1.5 8H15M10 13L15 8M15 8L10 3",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (arrow_right);


/***/ }),

/***/ 9444:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

var _path;

function chevron_down(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M13 5.5L8 10.5L3 5.5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (chevron_down);


/***/ }),

/***/ 1:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

var _path;

function chevron_up(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M3 10.5L8 5.5L13 10.5",
    stroke: "black",
    strokeWidth: 1.5,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (chevron_up);


/***/ }),

/***/ 6889:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4973);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

var _path;

function download(props) {
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
    width: 16,
    height: 16,
    viewBox: "0 0 16 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M5.87408 7.75092C5.58119 7.45803 5.10631 7.45803 4.81342 7.75092C4.52053 8.04381 4.52053 8.51869 4.81342 8.81158L5.87408 7.75092ZM8 10.9375L7.46967 11.4678C7.76256 11.7607 8.23744 11.7607 8.53033 11.4678L8 10.9375ZM11.1866 8.81158C11.4795 8.51869 11.4795 8.04381 11.1866 7.75092C10.8937 7.45803 10.4188 7.45803 10.1259 7.75092L11.1866 8.81158ZM8.75 2.5C8.75 2.08579 8.41421 1.75 8 1.75C7.58579 1.75 7.25 2.08579 7.25 2.5H8.75ZM3 13.25C2.58579 13.25 2.25 13.5858 2.25 14C2.25 14.4142 2.58579 14.75 3 14.75V13.25ZM13 14.75C13.4142 14.75 13.75 14.4142 13.75 14C13.75 13.5858 13.4142 13.25 13 13.25V14.75ZM4.81342 8.81158L7.46967 11.4678L8.53033 10.4072L5.87408 7.75092L4.81342 8.81158ZM8.53033 11.4678L11.1866 8.81158L10.1259 7.75092L7.46967 10.4072L8.53033 11.4678ZM7.25 2.5V10.9375H8.75V2.5H7.25ZM3 14.75H13V13.25H3V14.75Z",
    fill: "black"
  })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (download);


/***/ }),

/***/ 2294:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AlignmentHelper)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8802);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(855);





function AlignmentHelper(_ref) {
  var className = _ref.className, children = _ref.children, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(_ref, ["className", "children"]);
  return react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)({
    className: classnames__WEBPACK_IMPORTED_MODULE_2__("dnb-alignment-helper", className),
    "aria-hidden": true
  }, props), children);
}
 false ? 0 : void 0;
AlignmentHelper.defaultProps = {
  children: null,
  className: null
};


/***/ }),

/***/ 3898:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ shared_Context),
  "h": () => (/* binding */ prepareContext)
});

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__(1733);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(7298);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(6654);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(9332);
// EXTERNAL MODULE: ../node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(1698);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/defaults.js
var defaults = __webpack_require__(7609);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/locales/nb-NO.js
/* harmony default export */ const nb_NO = ({
  "nb-NO": {
    DatePicker: {
      day: "dag",
      month: "m\xE5ned",
      year: "\xE5r",
      start: "fra",
      end: "til",
      selected_date: "Valgt dato: %s",
      selected_month: "Valgt m\xE5ned %s",
      selected_year: "Valgt \xE5r %s",
      next_month: "Neste m\xE5ned %s",
      prev_month: "Forrige m\xE5ned %s",
      next_year: "Neste \xE5r %s",
      prev_year: "Forrige \xE5r %s",
      open_picker_text: "\xE5pne datovelger",
      mask_order: "dd/mm/yyyy",
      mask_placeholder: "dd.mm.\xE5\xE5\xE5\xE5",
      date_format: "yyyy-MM-dd",
      return_format: "yyyy-MM-dd",
      submit_button_text: "Ok",
      cancel_button_text: "Avbryt",
      reset_button_text: "Tilbakestill"
    },
    Anchor: {
      target_blank_title: "\xC5pner et nytt vindu"
    },
    GlobalStatus: {
      default_title: "En feil har skjedd",
      close_text: "Lukk",
      status_anchor_text: "G\xE5 til %s"
    },
    GlobalError: {
      404: {
        title: "Oisann! Vi finner ikke siden du leter etter \u2026",
        text: "Sikker p\xE5 at du har skrevet riktig adresse? Eller har vi rotet med lenkene? Pr\xF8v p\xE5 nytt, eller [g\xE5 tilbake der du kom fra](/back).",
        alt: "Dame s\xF8ker i tom eske"
      },
      500: {
        title: "Oops, her ble det en teknisk feil!",
        text: "Tjenesten fungerer ikke slik den skal for \xF8yeblikket, men pr\xF8v igjen senere.",
        alt: "Mann leter etter spor"
      }
    },
    ProgressIndicator: {
      indicator_label: "Vennligst vent ..."
    },
    Dropdown: {
      title: "Valgmeny"
    },
    Autocomplete: {
      title: "Skriv og velg",
      submit_button_title: "Vis alternativer",
      no_options: "Ingen alternativer",
      show_all: "Vis alt",
      aria_live_options: "%s alternativer",
      indicator_label: "Henter data ..."
    },
    Modal: {
      close_title: "Lukk"
    },
    NumberFormat: {
      clipboard_copy: "Kopiert"
    },
    HelpButton: {
      title: "Hjelpetekst",
      aria_role: "Hjelp-knapp"
    },
    Input: {
      submit_button_title: "Send knapp",
      show_password: "Vis passord",
      hide_password: "Skjul passord"
    },
    Pagination: {
      button_title: "Side %s",
      next_title: "Neste side",
      prev_title: "Forrige side",
      more_pages: "%s flere sider",
      is_loading_text: "Laster nytt innhold",
      load_button_text: "Vis mer innhold"
    },
    Skeleton: {
      aria_bussy: "Behandler data ...",
      aria_ready: "Klar til \xE5 samhandle"
    },
    StepIndicator: {
      step_title: "Steg %step av %count"
    },
    Slider: {
      add_title: "\xD8k (%s)",
      subtract_title: "Reduser (%s)"
    },
    PaymentCard: {
      text_card_number: "Kortnummer",
      text_expired: "Utg\xE5tt",
      text_blocked: "Sperret"
    },
    Logo: {
      alt: "DNB Logo"
    }
  }
});

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/locales/en-GB.js
/* harmony default export */ const en_GB = ({
  "en-GB": {
    DatePicker: {
      day: "Day",
      month: "Month",
      year: "Year",
      start: "from",
      end: "to",
      selected_date: "Selected date: %s",
      selected_month: "Selected month %s",
      selected_year: "Selected year %s",
      next_month: "Next month %s",
      prev_month: "Previous month %s",
      next_year: "Next year %s",
      prev_year: "Previous year %s",
      open_picker_text: "Open date picker",
      mask_order: "dd/mm/yyyy",
      mask_placeholder: "dd/mm/yyyy",
      date_format: "yyyy-MM-dd",
      return_format: "yyyy-MM-dd",
      submit_button_text: "OK",
      cancel_button_text: "Cancel",
      reset_button_text: "Reset"
    },
    Anchor: {
      target_blank_title: "Opens a new Window"
    },
    GlobalStatus: {
      default_title: "An error has occurred",
      close_text: "Close",
      status_anchor_text: "Go to %s"
    },
    GlobalError: {
      404: {
        title: "Oops! We can't find the page you're looking for \u2026",
        text: "Did we messed with the links? Try again, or [go back where you came from](/back).",
        alt: "Lady searching in empty box"
      },
      500: {
        title: "Ohh, a technical error happened!",
        text: "The service is not working properly at the moment, but try again later.",
        alt: "Man looking for clues"
      }
    },
    ProgressIndicator: {
      indicator_label: "Please wait ..."
    },
    Dropdown: {
      title: "Option Menu"
    },
    Autocomplete: {
      title: "Type and select",
      submit_button_title: "Show options",
      no_options: "No option",
      show_all: "Show everything",
      aria_live_options: "%s options",
      indicator_label: "Getting data ..."
    },
    Modal: {
      close_title: "Close"
    },
    NumberFormat: {
      clipboard_copy: "Copied"
    },
    HelpButton: {
      title: "Help text",
      aria_role: "Help button"
    },
    Skeleton: {
      aria_bussy: "In progress ...",
      aria_ready: "Ready to interact"
    },
    Input: {
      submit_button_title: "Submit button",
      show_password: "Show password",
      hide_password: "Hide password"
    },
    Pagination: {
      button_title: "Page %s",
      next_title: "Next page",
      prev_title: "Previous page",
      more_pages: "%s more pages",
      is_loading_text: "Loading new content",
      load_button_text: "Show more content"
    },
    StepIndicator: {
      step_title: "Step %step of %count"
    },
    Slider: {
      add_title: "Increase (%s)",
      subtract_title: "Decrease (%s)"
    },
    PaymentCard: {
      text_card_number: "Card number",
      text_expired: "Expired",
      text_blocked: "Blocked"
    },
    Logo: {
      alt: "DNB Logo"
    }
  }
});

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/locales/index.js



/* harmony default export */ const shared_locales = ((0,esm_extends/* default */.Z)({}, nb_NO, en_GB));

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/Context.js










var prepareContext = function prepareContext2() {
  var props = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  var locales = props.locales ? (0,component_helper/* extend */.l7)(shared_locales, props.locales) : shared_locales;
  if (props.__newContext) {
    (0,esm_extends/* default */.Z)(props, props.__newContext);
    delete props.__newContext;
  }
  var key = handleLocaleFallbacks(props.locale || defaults/* LOCALE */.MV, locales);
  var translation = locales[key] || shared_locales[defaults/* LOCALE */.MV] || {};
  if (locales[key]) {
    locales[key] = destruct(locales[key], translation);
  }
  var context = (0,esm_extends/* default */.Z)({
    updateTranslation: function updateTranslation(locale, translation2) {
      context.translation = context.locales[locale] = translation2;
    },
    getTranslation: function getTranslation(props2) {
      if (props2) {
        var lang = props2.lang || props2.locale;
        if (lang && context.locales[lang] && lang !== key) {
          return context.locales[lang];
        }
      }
      return context.translation;
    },
    locales
  }, props, {
    translation
  });
  return context;
};
function handleLocaleFallbacks(locale, locales) {
  if (!locales[locale]) {
    if (locale === "en" || locale.split("-")[0] === "en") {
      return "en-GB";
    }
  }
  return locale;
}
var Context = react.createContext(prepareContext({
  locale: defaults/* LOCALE */.MV,
  currency: defaults/* CURRENCY */.wA,
  currency_display: defaults/* CURRENCY_DISPLAY */.XI
}));
/* harmony default export */ const shared_Context = (Context);
function destruct(source, validKeys) {
  for (var k in source) {
    if (String(k).includes(".")) {
      var list = k.split(".");
      if (validKeys[list[0]]) {
        (function() {
          var val = source[k];
          var last = list.length - 1;
          list.forEach(function(k2, i) {
            source[k2] = i === last ? val : source[k2];
            source = source[k2] || {};
          });
        })();
      }
    }
  }
  return source;
}


/***/ }),

/***/ 4024:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Provider)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_reflect_construct_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6346);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8802);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7198);
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8465);
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3086);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6050);
/* harmony import */ var _Context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3898);
/* harmony import */ var _component_helper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1218);
/* harmony import */ var _components_form_row_FormRow__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1530);








function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}





var Provider = function(_React$PureComponent) {
  (0,_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(Provider2, _React$PureComponent);
  var _super = _createSuper(Provider2);
  function Provider2(props, context) {
    var _this;
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(this, Provider2);
    _this = _super.call(this, props);
    var children = props.children, value = props.value, startupProps = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(props, ["children", "value"]);
    if (typeof startupProps.formRow !== "undefined") {
      startupProps.FormRow = startupProps.formRow;
    }
    var newContext = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({}, value, context, startupProps);
    var isRoot = !(newContext && newContext.__providerId);
    newContext.__providerId = (0,_component_helper__WEBPACK_IMPORTED_MODULE_9__/* .makeUniqueId */ .Xo)();
    var pC = isRoot ? (0,_Context__WEBPACK_IMPORTED_MODULE_10__/* .prepareContext */ .h)(newContext) : newContext;
    pC.updateCurrent = function(props2) {
      return _this.setNewContext(props2);
    };
    pC.setCurrentLocale = function(locale) {
      return _this.setNewContext({
        locale
      });
    };
    pC.update = function(props2) {
      if (typeof context.update === "function") {
        context.update(props2);
      }
      _this.setNewContext(props2);
    };
    pC.setLocale = function(locale) {
      if (typeof context.update === "function") {
        context.update({
          locale
        });
      }
      _this.setNewContext({
        locale
      });
    };
    _this.state = pC;
    _this.state.isRoot = isRoot;
    _this.state._listenForPropChanges = true;
    _this.state._startupProps = startupProps;
    return _this;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z)(Provider2, [{
    key: "setNewContext",
    value: function setNewContext(__newContext) {
      this.setState({
        _listenForPropChanges: false
      });
      this.setState({
        __newContext
      });
    }
  }, {
    key: "render",
    value: function render() {
      var children = this.props.children;
      var context = !this.state.isRoot ? (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({}, this.context, this.state) : this.state;
      this.context.updateTranslation(context.locale, context.translation);
      return react__WEBPACK_IMPORTED_MODULE_3__.createElement(_Context__WEBPACK_IMPORTED_MODULE_10__/* .default.Provider */ .Z.Provider, {
        value: context
      }, children);
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        var children = props.children, updatedProps = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(props, ["children"]);
        var newContext = state;
        if (state._startupProps !== updatedProps) {
          var hasChanges = false;
          for (var i in updatedProps) {
            if (state._startupProps[i] !== updatedProps[i] || typeof updatedProps[i] === "boolean") {
              hasChanges = true;
              break;
            }
          }
          if (hasChanges) {
            newContext = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(state, updatedProps);
            state._startupProps = updatedProps;
          }
        }
        if (newContext.FormRow) {
          newContext.FormRow = (0,_components_form_row_FormRow__WEBPACK_IMPORTED_MODULE_12__/* .prepareFormRowContext */ .eI)(newContext.FormRow);
        }
        state = newContext;
      }
      state._listenForPropChanges = true;
      return (0,_Context__WEBPACK_IMPORTED_MODULE_10__/* .prepareContext */ .h)(state);
    }
  }]);
  return Provider2;
}(react__WEBPACK_IMPORTED_MODULE_3__.PureComponent);
Provider.contextType = _Context__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z;
Provider.defaultProps = {};

 false ? 0 : void 0;


/***/ }),

/***/ 1218:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lS": () => (/* binding */ PLATFORM_MAC),
/* harmony export */   "JQ": () => (/* binding */ PLATFORM_WIN),
/* harmony export */   "OK": () => (/* binding */ PLATFORM_LINUX),
/* harmony export */   "Y9": () => (/* binding */ PLATFORM_IOS),
/* harmony export */   "L_": () => (/* binding */ validateDOMAttributes),
/* harmony export */   "Ob": () => (/* binding */ processChildren),
/* harmony export */   "l7": () => (/* binding */ extend),
/* harmony export */   "Xw": () => (/* binding */ extendPropsWithContext),
/* harmony export */   "oA": () => (/* binding */ isTrue),
/* harmony export */   "RW": () => (/* binding */ dispatchCustomElementEvent),
/* harmony export */   "J3": () => (/* binding */ detectOutsideClick),
/* harmony export */   "b": () => (/* binding */ checkIfHasScrollbar),
/* harmony export */   "Xo": () => (/* binding */ makeUniqueId),
/* harmony export */   "U": () => (/* binding */ getPreviousSibling),
/* harmony export */   "m0": () => (/* binding */ isChildOfElement),
/* harmony export */   "Nm": () => (/* binding */ roundToNearest),
/* harmony export */   "e0": () => (/* binding */ isInsideScrollView),
/* harmony export */   "ZK": () => (/* binding */ warn),
/* harmony export */   "F4": () => (/* binding */ convertJsxToString),
/* harmony export */   "Bx": () => (/* binding */ getStatusState),
/* harmony export */   "u5": () => (/* binding */ combineDescribedBy)
/* harmony export */ });
/* unused harmony exports isTouchDevice, defineNavigator, toCamelCase, toPascalCase, toSnakeCase, toKebabCase, DetectOutsideClickClass, filterProps, slugify, matchAll, InteractionInvalidation, AnimateHeight, convertStatusToStateOnly, combineLabelledBy */
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(1295);
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(7817);
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(691);
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(9840);
/* harmony import */ var _babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(4687);
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6679);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6944);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1698);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5982);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(520);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8381);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8731);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6654);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9332);
/* harmony import */ var core_js_modules_es_object_is_frozen_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5496);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3070);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2478);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1733);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9043);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4565);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2945);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5781);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6091);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4339);
/* harmony import */ var keycode__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1984);
/* harmony import */ var what_input__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9930);

































var PLATFORM_MAC = "Mac|iPad|iPhone|iPod";
var PLATFORM_WIN = "Win";
var PLATFORM_LINUX = "Linux";
var PLATFORM_IOS = "iOS|iPhone|iPad|iPod";
if (typeof process !== "undefined" && "production" === "test" && typeof window !== "undefined") {
  window.IS_TEST = true;
}
what_input__WEBPACK_IMPORTED_MODULE_24__.specificKeys([9]);
defineNavigator();
function isTouchDevice() {
  if (typeof document !== "undefined") {
    var intent = false;
    try {
      intent = document.documentElement.getAttribute("data-whatintent");
    } catch (e) {
    }
    return intent === "touch";
  }
  return false;
}
function defineNavigator() {
  var handleNavigator = function handleNavigator2() {
    if (typeof document === "undefined" || typeof window === "undefined" || typeof navigator === "undefined") {
      return;
    }
    try {
      if (!(typeof window !== "undefined" && window.IS_TEST)) {
        if (navigator.platform.match(new RegExp(PLATFORM_MAC)) !== null) {
          document.documentElement.setAttribute("data-os", "mac");
        } else if (navigator.platform.match(new RegExp(PLATFORM_WIN)) !== null) {
          document.documentElement.setAttribute("data-os", "win");
        } else if (navigator.platform.match(new RegExp(PLATFORM_LINUX)) !== null) {
          document.documentElement.setAttribute("data-os", "linux");
        }
      } else {
        document.documentElement.setAttribute("data-os", "other");
      }
    } catch (e) {
      warn(e);
    }
    document.removeEventListener("DOMContentLoaded", handleNavigator2);
  };
  if (typeof document !== "undefined" && document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", handleNavigator);
  } else {
    handleNavigator();
  }
}
var validateDOMAttributes = function validateDOMAttributes2(props, params) {
  if (props && props.attributes) {
    var attr = props.attributes;
    if (attr) {
      if (attr[0] === "{")
        attr = JSON.parse(attr);
      if (attr && (0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_25__/* .default */ .Z)(attr) === "object") {
        Object.entries(attr).forEach(function(_ref) {
          var _ref2 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_26__/* .default */ .Z)(_ref, 2), key = _ref2[0], value = _ref2[1];
          (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)(params, (0,_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_28__/* .default */ .Z)({}, key, value));
        });
      }
    }
  }
  if (params.disabled === null || params.disabled === "false") {
    delete params.disabled;
  }
  if (typeof params.space !== "undefined") {
    delete params.space;
  }
  if (typeof params.top !== "undefined") {
    delete params.top;
  }
  if (typeof params.right !== "undefined") {
    delete params.right;
  }
  if (typeof params.bottom !== "undefined") {
    delete params.bottom;
  }
  if (typeof params.left !== "undefined") {
    delete params.left;
  }
  if (typeof params.no_collapse !== "undefined") {
    delete params.no_collapse;
  } else if (params.disabled === "true") {
    params.disabled = true;
  }
  if (params.disabled === true) {
    params["aria-disabled"] = true;
  }
  if (props && props.tabindex) {
    var tabIndex = props.tabindex;
    if (tabIndex === "off") {
      tabIndex = "-1";
    }
    params["tabIndex"] = tabIndex;
  }
  if (params && (0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_25__/* .default */ .Z)(params) === "object") {
    for (var i in params) {
      if (typeof params[i] === "function" && !/(^[a-z]{1,}[A-Z]{1})/.test(i)) {
        delete params[i];
      } else if (params[i] === null || /[^a-z-]/i.test(i)) {
        delete params[i];
      }
    }
  }
  return params;
};
var processChildren = function processChildren2(props) {
  if (!props) {
    return null;
  }
  if (typeof global !== "undefined" && Array.isArray(global.registeredElements) && global.registeredElements.length > 0) {
    var cache = null;
    Object.entries(props).reverse().map(function(_ref3) {
      var _ref4 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_26__/* .default */ .Z)(_ref3, 2), key = _ref4[0], cb = _ref4[1];
      if (key.includes("render_") && /^render_/.test(key)) {
        if (typeof cb === "function") {
          if (cache) {
            if (Object.isFrozen(props)) {
              props = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, props);
            }
            props.children = cache;
          }
          return cache = react__WEBPACK_IMPORTED_MODULE_22__.createElement(react__WEBPACK_IMPORTED_MODULE_22__.Fragment, {
            key
          }, cb(props));
        }
      }
      return null;
    }).filter(Boolean);
    if (cache) {
      return cache;
    }
  }
  var res = typeof props.children === "function" ? props.children(props) : props.children;
  if (Array.isArray(res)) {
    var onlyTexts = res.reduce(function(pV, cV) {
      if (typeof cV === "string" || typeof cV === "number") {
        pV.push(cV);
      }
      return pV;
    }, []);
    if (onlyTexts.length === res.length && onlyTexts.length > 0) {
      return onlyTexts.join("");
    }
  }
  return res;
};
var extend = function extend2() {
  var first = {};
  for (var _len = arguments.length, objects = new Array(_len), _key = 0; _key < _len; _key++) {
    objects[_key] = arguments[_key];
  }
  var keepRef = objects[0];
  if (keepRef === true || keepRef === false) {
    objects.shift();
    if (keepRef) {
      first = objects.shift();
    }
  }
  return objects.reduce(function(acc1, object) {
    if (object) {
      acc1 = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)(acc1, Object.entries(object).reduce(function(acc2, _ref5) {
        var _ref6 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_26__/* .default */ .Z)(_ref5, 2), key = _ref6[0], value = _ref6[1];
        if (value !== null) {
          if ((0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_25__/* .default */ .Z)(value) === "object") {
            value = extend2(acc1[key] || {}, value);
            if (Object.keys(value).length > 0) {
              acc2[key] = value;
            }
          } else {
            acc2[key] = value;
          }
        }
        return acc2;
      }, {}));
    }
    return acc1;
  }, first);
};
var extendPropsWithContext = function extendPropsWithContext2(props) {
  var defaults = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  for (var _len2 = arguments.length, contexts = new Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
    contexts[_key2 - 2] = arguments[_key2];
  }
  var context = contexts.reduce(function(acc, cur) {
    if (cur) {
      acc = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, acc, cur);
    }
    return acc;
  }, {});
  return (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, props, Object.entries(context).reduce(function(acc, _ref7) {
    var _ref8 = (0,_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_26__/* .default */ .Z)(_ref7, 2), key = _ref8[0], value = _ref8[1];
    if (typeof props[key] !== "undefined" && props[key] === defaults[key]) {
      acc[key] = value;
    }
    return acc;
  }, {}));
};
var isTrue = function isTrue2(value) {
  if (value !== null && typeof value !== "undefined" && (String(value) === "true" || String(value) === "1")) {
    return true;
  }
  return false;
};
var dispatchCustomElementEvent = function dispatchCustomElementEvent2(src, eventName, eventObjectOrig) {
  var ret = void 0;
  var eventObject = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, eventObjectOrig && eventObjectOrig.event || {}, eventObjectOrig);
  if (eventObject && eventObject.attributes && eventObject.event) {
    var currentTarget = eventObject.event.currentTarget;
    if (currentTarget) {
      try {
        var dataset = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, currentTarget.dataset || {});
        var attributes = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_27__/* .default */ .Z)({}, eventObject.attributes);
        for (var i in attributes) {
          if (/^data-/.test(i)) {
            dataset[String(i).replace(/^data-/, "")] = attributes[i];
          }
        }
        for (var _i in dataset) {
          if (eventObject.event.currentTarget.dataset) {
            eventObject.event.currentTarget.dataset[_i] = dataset[_i];
          }
          if (eventObject.event.target && eventObject.event.target.dataset) {
            eventObject.event.target.dataset[_i] = dataset[_i];
          }
        }
      } catch (e) {
        warn("Error on handling dataset:", e);
      }
    }
  }
  var props = src && src.props || src;
  if (props.custom_element) {
    if (typeof props.custom_element.fireEvent === "function") {
      ret = props.custom_element.fireEvent(eventName, eventObject);
    }
  }
  if (eventName.includes("_")) {
    if (typeof props[eventName] === "function") {
      var r = props[eventName].apply(src, [eventObject]);
      if (typeof r !== "undefined") {
        ret = r;
      }
    }
    eventName = toCamelCase(eventName);
    if (typeof props[eventName] === "function") {
      var _r = props[eventName].apply(src, [eventObject]);
      if (typeof _r !== "undefined") {
        ret = _r;
      }
    }
  } else {
    if (typeof props[eventName] === "function") {
      var _r2 = props[eventName].apply(src, [eventObject]);
      if (typeof _r2 !== "undefined") {
        ret = _r2;
      }
    }
    eventName = toSnakeCase(eventName);
    if (typeof props[eventName] === "function") {
      var _r3 = props[eventName].apply(src, [eventObject]);
      if (typeof _r3 !== "undefined") {
        ret = _r3;
      }
    }
  }
  return ret;
};
var toCamelCase = function toCamelCase2(s) {
  return s.split(/_/g).reduce(function(acc, cur, i) {
    return acc + (i === 0 ? cur : cur.replace(/(\w)(\w*)/g, function(g0, g1, g2) {
      return g1.toUpperCase() + g2.toLowerCase();
    }));
  }, "");
};
var toPascalCase = function toPascalCase2(s) {
  return s.split(/_/g).reduce(function(acc, cur) {
    return acc + cur.replace(/(\w)(\w*)/g, function(g0, g1, g2) {
      return g1.toUpperCase() + g2.toLowerCase();
    });
  }, "");
};
var toSnakeCase = function toSnakeCase2(str) {
  return str.replace(/\B[A-Z]/g, function(letter) {
    return "_".concat(letter);
  }).toLowerCase();
};
var toKebabCase = function toKebabCase2(str) {
  return str.replace(/\B[A-Z]/g, function(letter) {
    return "-".concat(letter);
  }).toLowerCase();
};
var detectOutsideClick = function detectOutsideClick2(ignoreElements, onSuccess, options) {
  return new DetectOutsideClickClass(ignoreElements, onSuccess, options);
};
var DetectOutsideClickClass = function() {
  function DetectOutsideClickClass2(_ignoreElements, _onSuccess) {
    var _this = this;
    var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_29__/* .default */ .Z)(this, DetectOutsideClickClass2);
    this.checkOutsideClick = function(_ref9) {
      var currentElement = _ref9.currentElement, ignoreElements = _ref9.ignoreElements;
      var onSuccess = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      try {
        if (typeof currentElement.tagName === "undefined" || /html/i.test(currentElement.tagName)) {
          return;
        }
        if (checkIfHasScrollbar(currentElement)) {
          return;
        }
        for (var i = 0, elem, l = ignoreElements.length; i < l; ++i) {
          elem = currentElement;
          if (!ignoreElements[i]) {
            continue;
          }
          do {
            if (elem === ignoreElements[i]) {
              return;
            }
            elem = elem && elem.parentNode;
          } while (elem);
        }
        if (typeof onSuccess === "function") {
          onSuccess();
        }
      } catch (e) {
        warn(e);
      }
    };
    if (!this.handleClickOutside && typeof document !== "undefined" && typeof window !== "undefined") {
      if (!Array.isArray(_ignoreElements)) {
        _ignoreElements = [_ignoreElements];
      }
      this.handleClickOutside = function(event) {
        _this.checkOutsideClick({
          currentElement: event.target,
          ignoreElements: _ignoreElements
        }, function() {
          return typeof _onSuccess === "function" && _onSuccess({
            event
          });
        });
      };
      document.addEventListener("mousedown", this.handleClickOutside);
      this.keydownCallback = function(event) {
        var keyCode = keycode__WEBPACK_IMPORTED_MODULE_23__(event);
        if (keyCode === "esc") {
          window.removeEventListener("keydown", _this.keydownCallback);
          if (typeof _onSuccess === "function") {
            _onSuccess({
              event
            });
          }
        }
      };
      window.addEventListener("keydown", this.keydownCallback);
      if (options.includedKeys) {
        this.keyupCallback = function(event) {
          var keyCode = keycode__WEBPACK_IMPORTED_MODULE_23__(event);
          if (options.includedKeys.includes(keyCode) && typeof _this.handleClickOutside === "function") {
            _this.handleClickOutside(event, function() {
              if (_this.keyupCallback)
                window.removeEventListener("keyup", _this.keyupCallback);
            });
          }
        };
        window.addEventListener("keyup", this.keyupCallback);
      }
    }
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_30__/* .default */ .Z)(DetectOutsideClickClass2, [{
    key: "remove",
    value: function remove() {
      if (this.handleClickOutside && typeof document !== "undefined") {
        document.removeEventListener("mousedown", this.handleClickOutside);
        this.handleClickOutside = null;
      }
      if (this.keydownCallback && typeof window !== "undefined") {
        window.removeEventListener("keydown", this.keydownCallback);
        this.keydownCallback = null;
      }
      if (this.keyupCallback && typeof window !== "undefined") {
        window.removeEventListener("keyup", this.keyupCallback);
        this.keyupCallback = null;
      }
    }
  }]);
  return DetectOutsideClickClass2;
}();
var checkIfHasScrollbar = function checkIfHasScrollbar2(elem) {
  return elem && (elem.scrollHeight > elem.offsetHeight || elem.scrollWidth > elem.offsetWidth) && overflowIsScrollable(elem);
};
var overflowIsScrollable = function overflowIsScrollable2(elem) {
  var style = window.getComputedStyle(elem);
  return /scroll|auto/i.test(style.overflow + (style.overflowX || "") + (style.overflowY || ""));
};
var filterProps = function filterProps2(props) {
  var remove = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  var allowed = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
  if (Array.isArray(remove)) {
    remove = remove.reduce(function(acc, key) {
      acc[key] = true;
      return acc;
    }, {});
  }
  if (Array.isArray(allowed)) {
    allowed = allowed.reduce(function(acc, key) {
      acc[key] = true;
      return acc;
    }, {});
  }
  return Object.entries(props).reduce(function(acc, _ref10) {
    var _ref11 = _slicedToArray(_ref10, 2), k = _ref11[0], v = _ref11[1];
    if (remove && typeof remove[k] === "undefined" || allowed && typeof allowed[k] !== "undefined") {
      acc[k] = v;
    }
    return acc;
  }, {});
};
var makeUniqueId = function makeUniqueId2() {
  var prefix = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
  var length = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 8;
  return prefix + String(Math.random().toString(36).substr(2, length) + idIncrement++).slice(-length);
};
var idIncrement = 0;
var slugify = function slugify2(s) {
  return String(s).toLowerCase().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
};
var matchAll = function matchAll2(string, regex) {
  if (typeof string.matchAll === "function") {
    return Array.from(string.matchAll(regex));
  }
  var matches = [];
  var match;
  while (match = regex.exec(string)) {
    matches.push(match);
  }
  return matches;
};
var getPreviousSibling = function getPreviousSibling2(className, element) {
  try {
    var contains = function contains2(element2) {
      return element2 && element2.classList.contains(className);
    };
    if (contains(element)) {
      return element;
    }
    while ((element = element && element.parentElement) && !contains(element)) {
      ;
    }
  } catch (e) {
    warn(e);
  }
  return element;
};
var isChildOfElement = function isChildOfElement2(element, target) {
  var cb = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
  try {
    var contains = function contains2(element2) {
      if (cb) {
        var res = cb(element2);
        if (typeof res === "boolean") {
          return res;
        }
      }
      return element2 && element2 === target;
    };
    if (contains(element)) {
      return element;
    }
    while ((element = element && element.parentElement) && !contains(element)) {
      ;
    }
  } catch (e) {
  }
  return element;
};
var roundToNearest = function roundToNearest2(num, target) {
  var diff = num % target;
  return diff > target / 2 ? num - diff + target : num - diff;
};
var isInsideScrollView = function isInsideScrollView2(currentElement) {
  var returnElement = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
  var elem = getPreviousSibling("dnb-scroll-view", currentElement);
  if (returnElement) {
    return elem == window ? null : elem;
  }
  return elem == window ? false : Boolean(elem);
};
var warn = function warn2() {
  if (typeof process !== "undefined" && "production" !== "production" && typeof console !== "undefined" && typeof console.log === "function") {
    var _console;
    for (var _len3 = arguments.length, e = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      e[_key3] = arguments[_key3];
    }
    (_console = console).log.apply(_console, ["Eufemia:"].concat(e));
  }
};
var convertJsxToString = function convertJsxToString2(elements) {
  var separator = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : void 0;
  if (!Array.isArray(elements)) {
    elements = [elements];
  }
  var process2 = function process3(word) {
    if (react__WEBPACK_IMPORTED_MODULE_22__.isValidElement(word)) {
      if (typeof word.props.children === "string") {
        word = word.props.children;
      } else if (Array.isArray(word.props.children)) {
        word = word.props.children.reduce(function(acc, word2) {
          if (typeof word2 !== "string") {
            word2 = process3(word2);
          }
          if (typeof word2 === "string") {
            acc = acc + word2;
          }
          return acc;
        }, "");
      } else {
        return null;
      }
    }
    return word;
  };
  return elements.map(function(word) {
    return process2(word);
  }).filter(Boolean).join(separator);
};
var InteractionInvalidation = function() {
  function InteractionInvalidation2() {
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_29__/* .default */ .Z)(this, InteractionInvalidation2);
    this.bypassElement = null;
    this.bypassSelectors = [];
    return this;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_30__/* .default */ .Z)(InteractionInvalidation2, [{
    key: "setBypassElement",
    value: function setBypassElement(bypassElement) {
      if (bypassElement instanceof HTMLElement) {
        this.bypassElement = bypassElement;
      }
      return this;
    }
  }, {
    key: "setBypassSelector",
    value: function setBypassSelector(bypassSelector) {
      if (!Array.isArray(bypassSelector)) {
        bypassSelector = [bypassSelector];
      }
      this.bypassSelectors = bypassSelector;
      return this;
    }
  }, {
    key: "activate",
    value: function activate() {
      var targetElement = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      if (!this.nodesToInvalidate) {
        this._runInvalidaiton(targetElement);
      }
    }
  }, {
    key: "revert",
    value: function revert() {
      this._revertInvalidation();
      this.nodesToInvalidate = null;
    }
  }, {
    key: "_runInvalidaiton",
    value: function _runInvalidaiton(targetElement) {
      if (typeof document === "undefined") {
        return;
      }
      this.nodesToInvalidate = this.getNodesToInvalidate(targetElement);
      if (Array.isArray(this.nodesToInvalidate)) {
        this.nodesToInvalidate.forEach(function(node) {
          try {
            if (node && typeof node._orig_tabindex === "undefined" && node.hasAttribute("tabindex")) {
              node._orig_tabindex = node.getAttribute("tabindex");
            }
            if (node && typeof node._orig_ariahidden === "undefined" && node.hasAttribute("aria-hidden")) {
              node._orig_ariahidden = node.getAttribute("aria-hidden");
            }
            node.setAttribute("tabindex", "-1");
            node.setAttribute("aria-hidden", "true");
          } catch (e) {
          }
        });
      }
    }
  }, {
    key: "_revertInvalidation",
    value: function _revertInvalidation() {
      if (!this.nodesToInvalidate) {
        return;
      }
      this.nodesToInvalidate.forEach(function(node) {
        try {
          if (node && typeof node._orig_tabindex !== "undefined") {
            node.setAttribute("tabindex", node._orig_tabindex);
            node._orig_tabindex = null;
            delete node._orig_tabindex;
          } else {
            node.removeAttribute("tabindex");
          }
          if (node && typeof node._orig_ariahidden !== "undefined") {
            node.setAttribute("aria-hidden", node._orig_ariahidden);
            node._orig_ariahidden = null;
            delete node._orig_ariahidden;
          } else {
            node.removeAttribute("aria-hidden");
          }
        } catch (e) {
        }
      });
    }
  }, {
    key: "getNodesToInvalidate",
    value: function getNodesToInvalidate() {
      var targetElement = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      if (typeof document === "undefined") {
        return;
      }
      if (typeof targetElement === "string") {
        targetElement = document.querySelector(targetElement);
      }
      var skipTheseNodes = this.bypassSelectors && this.bypassSelectors.length > 0 ? Array.from((this.bypassElement || document).querySelectorAll(this.bypassSelectors ? this.bypassSelectors.map(function(s) {
        return "".concat(s, " *");
      }).join(", ") : "*")) : [];
      var rootSelector = targetElement ? "*" : "html *";
      var elementSelector = this.bypassSelectors.map(function(s) {
        return ":not(".concat(s, ")");
      }).join("");
      var selector = "".concat(rootSelector, " ").concat(elementSelector, ":not(script):not(style):not(path)");
      return Array.from((targetElement || document.documentElement).querySelectorAll(selector)).filter(function(node) {
        return !skipTheseNodes.includes(node);
      });
    }
  }]);
  return InteractionInvalidation2;
}();
var AnimateHeight = function() {
  function AnimateHeight2() {
    var opts = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    (0,_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_29__/* .default */ .Z)(this, AnimateHeight2);
    this.state = "init";
    this.onStartStack = [];
    this.onEndStack = [];
    this.opts = opts;
  }
  (0,_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_30__/* .default */ .Z)(AnimateHeight2, [{
    key: "setElem",
    value: function setElem(elem) {
      var _this$elem, _this2 = this;
      var container = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      this.elem = elem || typeof document !== "undefined" && document.createElement("div");
      if (String((_this$elem = this.elem) === null || _this$elem === void 0 ? void 0 : _this$elem.nodeName).toLowerCase() === "td") {
        this.elem = this.elem.parentElement;
      }
      this.container = container;
      if (this.container) {
        this.onResize = function() {
          clearTimeout(_this2.resizeTimeout);
          _this2.resizeTimeout = setTimeout(function() {
            return _this2.setContainerHeight();
          }, 300);
        };
        window.addEventListener("resize", this.onResize);
      }
    }
  }, {
    key: "removeEndEvents",
    value: function removeEndEvents() {
      if (this.onOpenEnd) {
        this.elem.removeEventListener("transitionend", this.onOpenEnd);
        this.onOpenEnd = null;
      }
      if (this.onAdjustEnd) {
        this.elem.removeEventListener("transitionend", this.onAdjustEnd);
        this.onAdjustEnd = null;
      }
      if (this.onCloseEnd) {
        this.elem.removeEventListener("transitionend", this.onCloseEnd);
        this.onCloseEnd = null;
      }
    }
  }, {
    key: "remove",
    value: function remove() {
      this.removeEndEvents();
      this.isAnimating = false;
      this.onStartStack = null;
      this.onEndStack = null;
      this.stop();
      this.elem = null;
      this.state = "init";
      if (this.onResize) {
        clearTimeout(this.resizeTimeout);
        window.removeEventListener("resize", this.onResize);
      }
    }
  }, {
    key: "getCloseHeight",
    value: function getCloseHeight() {
      return parseFloat(this.elem.clientHeight);
    }
  }, {
    key: "getOpenHeight",
    value: function getOpenHeight(state) {
      var currentHeight = window.getComputedStyle(this.elem).height;
      this.elem.parentElement.style.position = "relative";
      this.elem.style.position = "absolute";
      this.elem.style.visibility = "hidden";
      this.elem.style.height = "auto";
      var height = parseFloat(this.elem.clientHeight);
      this.elem.parentElement.style.position = "";
      this.elem.style.position = "";
      this.elem.style.visibility = "";
      switch (state) {
        case "open":
          this.elem.style.height = this.state === "init" ? "0" : currentHeight;
          break;
      }
      return height;
    }
  }, {
    key: "onStart",
    value: function onStart(fn) {
      this.onStartStack.push(fn);
    }
  }, {
    key: "onEnd",
    value: function onEnd(fn) {
      this.onEndStack.push(fn);
    }
  }, {
    key: "callOnStart",
    value: function callOnStart() {
      var _this3 = this;
      this.onStartStack.forEach(function(fn) {
        if (typeof fn === "function") {
          fn(_this3.state);
        }
      });
    }
  }, {
    key: "callOnEnd",
    value: function callOnEnd() {
      var _this4 = this;
      this.isAnimating = false;
      this.removeEndEvents();
      this.resetSuppressAnimation();
      this.onEndStack.forEach(function(fn) {
        if (typeof fn === "function") {
          fn(_this4.state);
        }
      });
    }
  }, {
    key: "start",
    value: function start(fromHeight, toHeight, _ref12) {
      var _this$opts, _this5 = this;
      var animate = _ref12.animate;
      if (animate === false || ((_this$opts = this.opts) === null || _this$opts === void 0 ? void 0 : _this$opts.animate) === false) {
        this.elem.style.height = "".concat(toHeight, "px");
        this.callOnStart();
        try {
          var event = new CustomEvent("transitionend");
          this.elem.dispatchEvent(event);
        } catch (e) {
          warn(e);
        }
        return;
      }
      if (typeof window !== "undefined" && window.requestAnimationFrame) {
        this.stop();
        this.isAnimating = true;
        if (animate === false) {
          this.suppressAnimation();
        }
        this.callOnStart();
        this.reqId1 = window.requestAnimationFrame(function() {
          _this5.elem.style.height = "".concat(fromHeight, "px");
          if (_this5.container) {
            _this5.container.style.minHeight = "".concat(fromHeight, "px");
          }
          _this5.reqId2 = window.requestAnimationFrame(function() {
            _this5.elem.style.height = "".concat(toHeight, "px");
            _this5.setContainerHeight();
          });
        });
      }
    }
  }, {
    key: "setContainerHeight",
    value: function setContainerHeight() {
      if (this.container) {
        var contentElem = this.elem;
        if (contentElem.offsetHeight > 0) {
          this.container.style.minHeight = "".concat(contentElem.offsetHeight + contentElem.offsetTop, "px");
        }
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      if (typeof window !== "undefined" && window.requestAnimationFrame) {
        window.cancelAnimationFrame(this.reqId1);
        window.cancelAnimationFrame(this.reqId2);
      }
    }
  }, {
    key: "suppressAnimation",
    value: function suppressAnimation() {
      this.transitionDuration = window.getComputedStyle(this.elem).transitionDuration;
      this.elem.style.transitionDuration = "1ms";
    }
  }, {
    key: "resetSuppressAnimation",
    value: function resetSuppressAnimation() {
      if (this.transitionDuration) {
        this.elem.style.transitionDuration = this.transitionDuration;
        this.transitionDuration = null;
      }
    }
  }, {
    key: "adjustFrom",
    value: function adjustFrom() {
      if (!this.elem) {
        return;
      }
      var height = this.getCloseHeight();
      this.elem.style.height = "".concat(height, "px");
      return height;
    }
  }, {
    key: "adjustTo",
    value: function adjustTo(fromHeight) {
      var _this6 = this;
      var _ref13 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref13$animate = _ref13.animate, animate = _ref13$animate === void 0 ? true : _ref13$animate;
      if (!this.elem) {
        return;
      }
      var toHeight = this.getOpenHeight("open");
      this.state = "adjusting";
      this.removeEndEvents();
      if (!this.onAdjustEnd) {
        this.elem.addEventListener("transitionend", this.onAdjustEnd = function() {
          if (_this6.elem) {
            _this6.elem.style.height = "auto";
          }
          _this6.state = "adjusted";
          _this6.callOnEnd();
          _this6.setContainerHeight();
        });
      }
      this.start(fromHeight, toHeight, {
        animate
      });
    }
  }, {
    key: "open",
    value: function open() {
      var _this7 = this;
      var _ref14 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref14$animate = _ref14.animate, animate = _ref14$animate === void 0 ? true : _ref14$animate;
      if (!this.elem || this.state === "opened" || this.state === "opening") {
        return;
      }
      var height = this.getOpenHeight("open");
      this.state = "opening";
      this.removeEndEvents();
      if (!this.onOpenEnd) {
        this.elem.addEventListener("transitionend", this.onOpenEnd = function() {
          if (_this7.elem) {
            _this7.elem.style.height = "auto";
          }
          _this7.state = "opened";
          _this7.callOnEnd();
          _this7.setContainerHeight();
        });
      }
      this.start(0, height, {
        animate
      });
    }
  }, {
    key: "close",
    value: function close() {
      var _this8 = this;
      var _ref15 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref15$animate = _ref15.animate, animate = _ref15$animate === void 0 ? true : _ref15$animate;
      if (!this.elem || this.state === "closed" || this.state === "closing") {
        return;
      }
      var height = this.getCloseHeight();
      if (this.state === "init") {
        height = this.getOpenHeight();
      }
      this.state = "closing";
      this.removeEndEvents();
      if (!this.onCloseEnd) {
        this.elem.addEventListener("transitionend", this.onCloseEnd = function() {
          if (_this8.elem) {
            _this8.elem.style.visibility = "hidden";
          }
          _this8.state = "closed";
          _this8.callOnEnd();
        });
      }
      this.start(height, 0, {
        animate
      });
    }
  }]);
  return AnimateHeight2;
}();
function convertStatusToStateOnly(status, state) {
  return status ? state : null;
}
function getStatusState(status) {
  return status && status !== "error" && status !== "warn" && status !== "info";
}
function combineLabelledBy() {
  for (var _len4 = arguments.length, params = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    params[_key4] = arguments[_key4];
  }
  return combineAriaBy("aria-labelledby", params);
}
function combineDescribedBy() {
  for (var _len5 = arguments.length, params = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    params[_key5] = arguments[_key5];
  }
  return combineAriaBy("aria-describedby", params);
}
function combineAriaBy(type, params) {
  params = params.map(function(cur) {
    if (cur && params.includes(cur[type])) {
      return null;
    }
    if (cur && typeof cur[type] !== "undefined") {
      cur = cur[type];
    }
    if (typeof cur !== "string") {
      cur = null;
    }
    return cur;
  });
  params = params.filter(Boolean).join(" ");
  if (params === "") {
    params = void 0;
  }
  return params;
}


/***/ }),

/***/ 6357:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ui": () => (/* binding */ registerElement)
});

// UNUSED EXPORTS: prepareDefaultProps, registeredElements

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(691);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__(9840);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/toConsumableArray.js + 3 modules
var toConsumableArray = __webpack_require__(2707);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js
var setPrototypeOf = __webpack_require__(2618);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/isNativeFunction.js
function _isNativeFunction(fn) {
  return Function.toString.call(fn).indexOf("[native code]") !== -1;
}

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/construct.js + 1 modules
var construct = __webpack_require__(8504);
;// CONCATENATED MODULE: ../node_modules/@babel/runtime/helpers/esm/wrapNativeSuper.js




function _wrapNativeSuper(Class) {
  var _cache = typeof Map === "function" ? new Map() : void 0;
  _wrapNativeSuper = function _wrapNativeSuper2(Class2) {
    if (Class2 === null || !_isNativeFunction(Class2))
      return Class2;
    if (typeof Class2 !== "function") {
      throw new TypeError("Super expression must either be null or a function");
    }
    if (typeof _cache !== "undefined") {
      if (_cache.has(Class2))
        return _cache.get(Class2);
      _cache.set(Class2, Wrapper);
    }
    function Wrapper() {
      return (0,construct/* default */.Z)(Class2, arguments, (0,getPrototypeOf/* default */.Z)(this).constructor);
    }
    Wrapper.prototype = Object.create(Class2.prototype, {
      constructor: {
        value: Wrapper,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    return (0,setPrototypeOf/* default */.Z)(Wrapper, Class2);
  };
  return _wrapNativeSuper(Class);
}

// EXTERNAL MODULE: ../node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(225);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.index-of.js
var es_array_index_of = __webpack_require__(5860);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(6091);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__(1733);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(7298);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(520);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(8381);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.entries.js
var es_object_entries = __webpack_require__(5982);
// EXTERNAL MODULE: ../node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(1698);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.reduce.js
var es_array_reduce = __webpack_require__(6306);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__(5812);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(7888);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/error-helper.js
var error_helper = __webpack_require__(2333);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__(4687);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.map.js
var es_map = __webpack_require__(47);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(4565);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(5781);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(4185);
// EXTERNAL MODULE: ../node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(395);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.promise.js
var es_promise = __webpack_require__(8599);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__(4348);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/custom-element-polyfill.js












function installCustomElements(window, polyfill) {
  "use strict";
  var document = window.document, Object = window.Object;
  var htmlClass = function(info) {
    var catchClass = /^[A-Z]+[a-z]/, filterBy = function filterBy2(re) {
      var arr = [], tag;
      for (tag in register) {
        if (re.test(tag))
          arr.push(tag);
      }
      return arr;
    }, add = function add2(Class2, tag) {
      tag = tag.toLowerCase();
      if (!(tag in register)) {
        register[Class2] = (register[Class2] || []).concat(tag);
        register[tag] = register[tag.toUpperCase()] = Class2;
      }
    }, register = (Object.create || Object)(null), htmlClass2 = {}, i, section, tags, Class;
    for (section in info) {
      for (Class in info[section]) {
        tags = info[section][Class];
        register[Class] = tags;
        for (i = 0; i < tags.length; i++) {
          register[tags[i].toLowerCase()] = register[tags[i].toUpperCase()] = Class;
        }
      }
    }
    htmlClass2.get = function get2(tagOrClass) {
      return typeof tagOrClass === "string" ? register[tagOrClass] || (catchClass.test(tagOrClass) ? [] : "") : filterBy(tagOrClass);
    };
    htmlClass2.set = function set(tag, Class2) {
      return catchClass.test(tag) ? add(tag, Class2) : add(Class2, tag), htmlClass2;
    };
    return htmlClass2;
  }({
    collections: {
      HTMLAllCollection: ["all"],
      HTMLCollection: ["forms"],
      HTMLFormControlsCollection: ["elements"],
      HTMLOptionsCollection: ["options"]
    },
    elements: {
      Element: ["element"],
      HTMLAnchorElement: ["a"],
      HTMLAppletElement: ["applet"],
      HTMLAreaElement: ["area"],
      HTMLAttachmentElement: ["attachment"],
      HTMLAudioElement: ["audio"],
      HTMLBRElement: ["br"],
      HTMLBaseElement: ["base"],
      HTMLBodyElement: ["body"],
      HTMLButtonElement: ["button"],
      HTMLCanvasElement: ["canvas"],
      HTMLContentElement: ["content"],
      HTMLDListElement: ["dl"],
      HTMLDataElement: ["data"],
      HTMLDataListElement: ["datalist"],
      HTMLDetailsElement: ["details"],
      HTMLDialogElement: ["dialog"],
      HTMLDirectoryElement: ["dir"],
      HTMLDivElement: ["div"],
      HTMLDocument: ["document"],
      HTMLElement: ["element", "abbr", "address", "article", "aside", "b", "bdi", "bdo", "cite", "code", "command", "dd", "dfn", "dt", "em", "figcaption", "figure", "footer", "header", "i", "kbd", "mark", "nav", "noscript", "rp", "rt", "ruby", "s", "samp", "section", "small", "strong", "sub", "summary", "sup", "u", "var", "wbr"],
      HTMLEmbedElement: ["embed"],
      HTMLFieldSetElement: ["fieldset"],
      HTMLFontElement: ["font"],
      HTMLFormElement: ["form"],
      HTMLFrameElement: ["frame"],
      HTMLFrameSetElement: ["frameset"],
      HTMLHRElement: ["hr"],
      HTMLHeadElement: ["head"],
      HTMLHeadingElement: ["h1", "h2", "h3", "h4", "h5", "h6"],
      HTMLHtmlElement: ["html"],
      HTMLIFrameElement: ["iframe"],
      HTMLImageElement: ["img"],
      HTMLInputElement: ["input"],
      HTMLKeygenElement: ["keygen"],
      HTMLLIElement: ["li"],
      HTMLLabelElement: ["label"],
      HTMLLegendElement: ["legend"],
      HTMLLinkElement: ["link"],
      HTMLMapElement: ["map"],
      HTMLMarqueeElement: ["marquee"],
      HTMLMediaElement: ["media"],
      HTMLMenuElement: ["menu"],
      HTMLMenuItemElement: ["menuitem"],
      HTMLMetaElement: ["meta"],
      HTMLMeterElement: ["meter"],
      HTMLModElement: ["del", "ins"],
      HTMLOListElement: ["ol"],
      HTMLObjectElement: ["object"],
      HTMLOptGroupElement: ["optgroup"],
      HTMLOptionElement: ["option"],
      HTMLOutputElement: ["output"],
      HTMLParagraphElement: ["p"],
      HTMLParamElement: ["param"],
      HTMLPictureElement: ["picture"],
      HTMLPreElement: ["pre"],
      HTMLProgressElement: ["progress"],
      HTMLQuoteElement: ["blockquote", "q", "quote"],
      HTMLScriptElement: ["script"],
      HTMLSelectElement: ["select"],
      HTMLShadowElement: ["shadow"],
      HTMLSlotElement: ["slot"],
      HTMLSourceElement: ["source"],
      HTMLSpanElement: ["span"],
      HTMLStyleElement: ["style"],
      HTMLTableCaptionElement: ["caption"],
      HTMLTableCellElement: ["td", "th"],
      HTMLTableColElement: ["col", "colgroup"],
      HTMLTableElement: ["table"],
      HTMLTableRowElement: ["tr"],
      HTMLTableSectionElement: ["thead", "tbody", "tfoot"],
      HTMLTemplateElement: ["template"],
      HTMLTextAreaElement: ["textarea"],
      HTMLTimeElement: ["time"],
      HTMLTitleElement: ["title"],
      HTMLTrackElement: ["track"],
      HTMLUListElement: ["ul"],
      HTMLUnknownElement: ["unknown", "vhgroupv", "vkeygen"],
      HTMLVideoElement: ["video"]
    },
    nodes: {
      Attr: ["node"],
      Audio: ["audio"],
      CDATASection: ["node"],
      CharacterData: ["node"],
      Comment: ["#comment"],
      Document: ["#document"],
      DocumentFragment: ["#document-fragment"],
      DocumentType: ["node"],
      HTMLDocument: ["#document"],
      Image: ["img"],
      Option: ["option"],
      ProcessingInstruction: ["node"],
      ShadowRoot: ["#shadow-root"],
      Text: ["#text"],
      XMLDocument: ["xml"]
    }
  });
  if ((0,esm_typeof/* default */.Z)(polyfill) !== "object")
    polyfill = {
      type: polyfill || "auto"
    };
  var REGISTER_ELEMENT = "registerElement", EXPANDO_UID = "__" + REGISTER_ELEMENT + (window.Math.random() * 1e5 >> 0), ADD_EVENT_LISTENER = "addEventListener", ATTACHED = "attached", CALLBACK = "Callback", DETACHED = "detached", EXTENDS = "extends", ATTRIBUTE_CHANGED_CALLBACK = "attributeChanged" + CALLBACK, ATTACHED_CALLBACK = ATTACHED + CALLBACK, CONNECTED_CALLBACK = "connected" + CALLBACK, DISCONNECTED_CALLBACK = "disconnected" + CALLBACK, CREATED_CALLBACK = "created" + CALLBACK, DETACHED_CALLBACK = DETACHED + CALLBACK, ADDITION = "ADDITION", MODIFICATION = "MODIFICATION", REMOVAL = "REMOVAL", DOM_ATTR_MODIFIED = "DOMAttrModified", DOM_CONTENT_LOADED = "DOMContentLoaded", DOM_SUBTREE_MODIFIED = "DOMSubtreeModified", PREFIX_TAG = "<", PREFIX_IS = "=", validName = /^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$/, invalidNames = ["ANNOTATION-XML", "COLOR-PROFILE", "FONT-FACE", "FONT-FACE-SRC", "FONT-FACE-URI", "FONT-FACE-FORMAT", "FONT-FACE-NAME", "MISSING-GLYPH"], types = [], protos = [], query = "", documentElement = document.documentElement, indexOf = types.indexOf || function(v) {
    for (var i = this.length; i-- && this[i] !== v; ) {
    }
    return i;
  }, OP = Object.prototype, hOP = OP.hasOwnProperty, iPO = OP.isPrototypeOf, defineProperty = Object.defineProperty, empty = [], gOPD = Object.getOwnPropertyDescriptor, gOPN = Object.getOwnPropertyNames, gPO = Object.getPrototypeOf, sPO = Object.setPrototypeOf, hasProto = !!Object.__proto__, fixGetClass = false, DRECEV1 = "__dreCEv1", customElements = window.customElements, usableCustomElements = !/^force/.test(polyfill.type) && !!(customElements && customElements.define && customElements.get && customElements.whenDefined), Dict = Object.create || Object, Map = window.Map || function Map2() {
    var K = [], V = [], i;
    return {
      get: function get2(k) {
        return V[indexOf.call(K, k)];
      },
      set: function set(k, v) {
        i = indexOf.call(K, k);
        if (i < 0)
          V[K.push(k) - 1] = v;
        else
          V[i] = v;
      }
    };
  }, Promise = window.Promise || function(fn) {
    var notify = [], done = false, p = {
      catch: function _catch() {
        return p;
      },
      then: function then(cb) {
        notify.push(cb);
        if (done)
          setTimeout(resolve, 1);
        return p;
      }
    };
    function resolve(value) {
      done = true;
      while (notify.length) {
        notify.shift()(value);
      }
    }
    fn(resolve);
    return p;
  }, justCreated = false, constructors = Dict(null), waitingList = Dict(null), nodeNames = new Map(), secondArgument = function secondArgument2(is) {
    return is.toLowerCase();
  }, create = Object.create || function Bridge(proto) {
    return proto ? (Bridge.prototype = proto, new Bridge()) : this;
  }, setPrototype = sPO || (hasProto ? function(o, p) {
    o.__proto__ = p;
    return o;
  } : gOPN && gOPD ? function() {
    function setProperties(o, p) {
      for (var key, names = gOPN(p), i = 0, length = names.length; i < length; i++) {
        key = names[i];
        if (!hOP.call(o, key)) {
          defineProperty(o, key, gOPD(p, key));
        }
      }
    }
    return function(o, p) {
      do {
        setProperties(o, p);
      } while ((p = gPO(p)) && !iPO.call(p, o));
      return o;
    };
  }() : function(o, p) {
    for (var key in p) {
      o[key] = p[key];
    }
    return o;
  }), MutationObserver = window.MutationObserver || window.WebKitMutationObserver, HTMLElementPrototype = (window.HTMLElement || window.Element || window.Node).prototype, IE8 = !iPO.call(HTMLElementPrototype, documentElement), safeProperty = IE8 ? function(o, k, d) {
    o[k] = d.value;
    return o;
  } : defineProperty, isValidNode = IE8 ? function(node) {
    return node.nodeType === 1;
  } : function(node) {
    return iPO.call(HTMLElementPrototype, node);
  }, targets = IE8 && [], attachShadow = HTMLElementPrototype.attachShadow, cloneNode = HTMLElementPrototype.cloneNode, dispatchEvent = HTMLElementPrototype.dispatchEvent, getAttribute = HTMLElementPrototype.getAttribute, hasAttribute = HTMLElementPrototype.hasAttribute, removeAttribute = HTMLElementPrototype.removeAttribute, setAttribute = HTMLElementPrototype.setAttribute, createElement = document.createElement, patchedCreateElement = createElement, attributesObserver = MutationObserver && {
    attributes: true,
    characterData: true,
    attributeOldValue: true
  }, DOMAttrModified = MutationObserver || function(e) {
    doesNotSupportDOMAttrModified = false;
    documentElement.removeEventListener(DOM_ATTR_MODIFIED, DOMAttrModified);
  }, asapQueue, asapTimer = 0, V0 = REGISTER_ELEMENT in document && !/^force-all/.test(polyfill.type), setListener = true, justSetup = false, doesNotSupportDOMAttrModified = true, dropDomContentLoaded = true, notFromInnerHTMLHelper = true, onSubtreeModified, callDOMAttrModified, getAttributesMirror, observer, observe, patchIfNotAlready, patch, tmp;
  if (MutationObserver) {
    tmp = document.createElement("div");
    tmp.innerHTML = "<div><div></div></div>";
    new MutationObserver(function(mutations, observer2) {
      if (mutations[0] && mutations[0].type == "childList" && !mutations[0].removedNodes[0].childNodes.length) {
        tmp = gOPD(HTMLElementPrototype, "innerHTML");
        var _set = tmp && tmp.set;
        if (_set)
          defineProperty(HTMLElementPrototype, "innerHTML", {
            set: function set(value) {
              while (this.lastChild) {
                this.removeChild(this.lastChild);
              }
              _set.call(this, value);
            }
          });
      }
      observer2.disconnect();
      tmp = null;
    }).observe(tmp, {
      childList: true,
      subtree: true
    });
    tmp.innerHTML = "";
  }
  if (!V0) {
    if (sPO || hasProto) {
      patchIfNotAlready = function patchIfNotAlready2(node, proto) {
        if (!iPO.call(proto, node)) {
          setupNode(node, proto);
        }
      };
      patch = setupNode;
    } else {
      patchIfNotAlready = function patchIfNotAlready2(node, proto) {
        if (!node[EXPANDO_UID]) {
          node[EXPANDO_UID] = Object(true);
          setupNode(node, proto);
        }
      };
      patch = patchIfNotAlready;
    }
    if (IE8) {
      doesNotSupportDOMAttrModified = false;
      (function() {
        var descriptor = gOPD(HTMLElementPrototype, ADD_EVENT_LISTENER), addEventListener = descriptor.value, patchedRemoveAttribute = function patchedRemoveAttribute2(name) {
          var e = new CustomEvent(DOM_ATTR_MODIFIED, {
            bubbles: true
          });
          e.attrName = name;
          e.prevValue = getAttribute.call(this, name);
          e.newValue = null;
          e[REMOVAL] = e.attrChange = 2;
          removeAttribute.call(this, name);
          dispatchEvent.call(this, e);
        }, patchedSetAttribute2 = function patchedSetAttribute3(name, value) {
          var had = hasAttribute.call(this, name), old = had && getAttribute.call(this, name), e = new CustomEvent(DOM_ATTR_MODIFIED, {
            bubbles: true
          });
          setAttribute.call(this, name, value);
          e.attrName = name;
          e.prevValue = had ? old : null;
          e.newValue = value;
          if (had) {
            e[MODIFICATION] = e.attrChange = 1;
          } else {
            e[ADDITION] = e.attrChange = 0;
          }
          dispatchEvent.call(this, e);
        }, onPropertyChange = function onPropertyChange2(e) {
          var node = e.currentTarget, superSecret = node[EXPANDO_UID], propertyName = e.propertyName, event;
          if (superSecret.hasOwnProperty(propertyName)) {
            superSecret = superSecret[propertyName];
            event = new CustomEvent(DOM_ATTR_MODIFIED, {
              bubbles: true
            });
            event.attrName = superSecret.name;
            event.prevValue = superSecret.value || null;
            event.newValue = superSecret.value = node[propertyName] || null;
            if (event.prevValue == null) {
              event[ADDITION] = event.attrChange = 0;
            } else {
              event[MODIFICATION] = event.attrChange = 1;
            }
            dispatchEvent.call(node, event);
          }
        };
        descriptor.value = function(type, handler, capture) {
          if (type === DOM_ATTR_MODIFIED && this[ATTRIBUTE_CHANGED_CALLBACK] && this.setAttribute !== patchedSetAttribute2) {
            this[EXPANDO_UID] = {
              className: {
                name: "class",
                value: this.className
              }
            };
            this.setAttribute = patchedSetAttribute2;
            this.removeAttribute = patchedRemoveAttribute;
            addEventListener.call(this, "propertychange", onPropertyChange);
          }
          addEventListener.call(this, type, handler, capture);
        };
        defineProperty(HTMLElementPrototype, ADD_EVENT_LISTENER, descriptor);
      })();
    } else if (!MutationObserver) {
      documentElement[ADD_EVENT_LISTENER](DOM_ATTR_MODIFIED, DOMAttrModified);
      documentElement.setAttribute(EXPANDO_UID, 1);
      documentElement.removeAttribute(EXPANDO_UID);
      if (doesNotSupportDOMAttrModified) {
        onSubtreeModified = function onSubtreeModified2(e) {
          var node = this, oldAttributes, newAttributes, key;
          if (node === e.target) {
            oldAttributes = node[EXPANDO_UID];
            node[EXPANDO_UID] = newAttributes = getAttributesMirror(node);
            for (key in newAttributes) {
              if (!(key in oldAttributes)) {
                return callDOMAttrModified(0, node, key, oldAttributes[key], newAttributes[key], ADDITION);
              } else if (newAttributes[key] !== oldAttributes[key]) {
                return callDOMAttrModified(1, node, key, oldAttributes[key], newAttributes[key], MODIFICATION);
              }
            }
            for (key in oldAttributes) {
              if (!(key in newAttributes)) {
                return callDOMAttrModified(2, node, key, oldAttributes[key], newAttributes[key], REMOVAL);
              }
            }
          }
        };
        callDOMAttrModified = function callDOMAttrModified2(attrChange, currentTarget, attrName, prevValue, newValue, action) {
          var e = {
            attrChange,
            currentTarget,
            attrName,
            prevValue,
            newValue
          };
          e[action] = attrChange;
          onDOMAttrModified(e);
        };
        getAttributesMirror = function getAttributesMirror2(node) {
          for (var attr, name, result = {}, attributes = node.attributes, i = 0, length = attributes.length; i < length; i++) {
            attr = attributes[i];
            name = attr.name;
            if (name !== "setAttribute") {
              result[name] = attr.value;
            }
          }
          return result;
        };
      }
    }
    document[REGISTER_ELEMENT] = function registerElement(type, options) {
      upperType = type.toUpperCase();
      if (setListener) {
        setListener = false;
        if (MutationObserver) {
          observer = function(attached, detached) {
            function checkEmAll(list, callback) {
              for (var i2 = 0, length = list.length; i2 < length; callback(list[i2++])) {
              }
            }
            return new MutationObserver(function(records) {
              for (var current, node, newValue, i2 = 0, length = records.length; i2 < length; i2++) {
                current = records[i2];
                if (current.type === "childList") {
                  checkEmAll(current.addedNodes, attached);
                  checkEmAll(current.removedNodes, detached);
                } else {
                  node = current.target;
                  if (notFromInnerHTMLHelper && node[ATTRIBUTE_CHANGED_CALLBACK] && current.attributeName !== "style") {
                    newValue = getAttribute.call(node, current.attributeName);
                    if (newValue !== current.oldValue) {
                      node[ATTRIBUTE_CHANGED_CALLBACK](current.attributeName, current.oldValue, newValue);
                    }
                  }
                }
              }
            });
          }(executeAction(ATTACHED), executeAction(DETACHED));
          observe = function observe2(node) {
            observer.observe(node, {
              childList: true,
              subtree: true
            });
            return node;
          };
          observe(document);
          if (attachShadow) {
            HTMLElementPrototype.attachShadow = function() {
              return observe(attachShadow.apply(this, arguments));
            };
          }
        } else {
          asapQueue = [];
          document[ADD_EVENT_LISTENER]("DOMNodeInserted", onDOMNode(ATTACHED));
          document[ADD_EVENT_LISTENER]("DOMNodeRemoved", onDOMNode(DETACHED));
        }
        document[ADD_EVENT_LISTENER](DOM_CONTENT_LOADED, onReadyStateChange);
        document[ADD_EVENT_LISTENER]("readystatechange", onReadyStateChange);
        HTMLElementPrototype.cloneNode = function(deep) {
          var node = cloneNode.call(this, !!deep), i2 = getTypeIndex(node);
          if (-1 < i2)
            patch(node, protos[i2]);
          if (deep && query.length)
            loopAndSetup(node.querySelectorAll(query));
          return node;
        };
      }
      if (justSetup)
        return justSetup = false;
      if (-2 < indexOf.call(types, PREFIX_IS + upperType) + indexOf.call(types, PREFIX_TAG + upperType)) {
        throwTypeError(type);
      }
      if (!validName.test(upperType) || -1 < indexOf.call(invalidNames, upperType)) {
        throw new Error("The type " + type + " is invalid");
      }
      var constructor = function constructor2() {
        return extending ? document.createElement(nodeName, upperType) : document.createElement(nodeName);
      }, opt = options || OP, extending = hOP.call(opt, EXTENDS), nodeName = extending ? options[EXTENDS].toUpperCase() : upperType, upperType, i;
      if (extending && -1 < indexOf.call(types, PREFIX_TAG + nodeName)) {
        throwTypeError(nodeName);
      }
      i = types.push((extending ? PREFIX_IS : PREFIX_TAG) + upperType) - 1;
      query = query.concat(query.length ? "," : "", extending ? nodeName + '[is="' + type.toLowerCase() + '"]' : nodeName);
      constructor.prototype = protos[i] = hOP.call(opt, "prototype") ? opt.prototype : create(HTMLElementPrototype);
      if (query.length)
        loopAndVerify(document.querySelectorAll(query), ATTACHED);
      return constructor;
    };
    document.createElement = patchedCreateElement = function patchedCreateElement2(localName, typeExtension) {
      var is = getIs(typeExtension), node = is ? createElement.call(document, localName, secondArgument(is)) : createElement.call(document, localName), name = "" + localName, i = indexOf.call(types, (is ? PREFIX_IS : PREFIX_TAG) + (is || name).toUpperCase()), setup = -1 < i;
      if (is) {
        node.setAttribute("is", is = is.toLowerCase());
        if (setup) {
          setup = isInQSA(name.toUpperCase(), is);
        }
      }
      notFromInnerHTMLHelper = !document.createElement.innerHTMLHelper;
      if (setup)
        patch(node, protos[i]);
      return node;
    };
  }
  function ASAP() {
    var queue = asapQueue.splice(0, asapQueue.length);
    asapTimer = 0;
    while (queue.length) {
      queue.shift().call(null, queue.shift());
    }
  }
  function loopAndVerify(list, action) {
    for (var i = 0, length = list.length; i < length; i++) {
      verifyAndSetupAndAction(list[i], action);
    }
  }
  function loopAndSetup(list) {
    for (var i = 0, length = list.length, node; i < length; i++) {
      node = list[i];
      patch(node, protos[getTypeIndex(node)]);
    }
  }
  function executeAction(action) {
    return function(node) {
      if (isValidNode(node)) {
        verifyAndSetupAndAction(node, action);
        if (query.length)
          loopAndVerify(node.querySelectorAll(query), action);
      }
    };
  }
  function getTypeIndex(target) {
    var is = getAttribute.call(target, "is"), nodeName = target.nodeName.toUpperCase(), i = indexOf.call(types, is ? PREFIX_IS + is.toUpperCase() : PREFIX_TAG + nodeName);
    return is && -1 < i && !isInQSA(nodeName, is) ? -1 : i;
  }
  function isInQSA(name, type) {
    return -1 < query.indexOf(name + '[is="' + type + '"]');
  }
  function onDOMAttrModified(e) {
    var node = e.currentTarget, attrChange = e.attrChange, attrName = e.attrName, target = e.target, addition = e[ADDITION] || 2, removal = e[REMOVAL] || 3;
    if (notFromInnerHTMLHelper && (!target || target === node) && node[ATTRIBUTE_CHANGED_CALLBACK] && attrName !== "style" && (e.prevValue !== e.newValue || e.newValue === "" && (attrChange === addition || attrChange === removal))) {
      node[ATTRIBUTE_CHANGED_CALLBACK](attrName, attrChange === addition ? null : e.prevValue, attrChange === removal ? null : e.newValue);
    }
  }
  function onDOMNode(action) {
    var executor = executeAction(action);
    return function(e) {
      asapQueue.push(executor, e.target);
      if (asapTimer)
        clearTimeout(asapTimer);
      asapTimer = setTimeout(ASAP, 1);
    };
  }
  function onReadyStateChange(e) {
    if (dropDomContentLoaded) {
      dropDomContentLoaded = false;
      e.currentTarget.removeEventListener(DOM_CONTENT_LOADED, onReadyStateChange);
    }
    if (query.length)
      loopAndVerify((e.target || document).querySelectorAll(query), e.detail === DETACHED ? DETACHED : ATTACHED);
    if (IE8)
      purge();
  }
  function patchedSetAttribute(name, value) {
    var self = this;
    setAttribute.call(self, name, value);
    onSubtreeModified.call(self, {
      target: self
    });
  }
  function setupNode(node, proto) {
    setPrototype(node, proto);
    if (observer) {
      observer.observe(node, attributesObserver);
    } else {
      if (doesNotSupportDOMAttrModified) {
        node.setAttribute = patchedSetAttribute;
        node[EXPANDO_UID] = getAttributesMirror(node);
        node[ADD_EVENT_LISTENER](DOM_SUBTREE_MODIFIED, onSubtreeModified);
      }
      node[ADD_EVENT_LISTENER](DOM_ATTR_MODIFIED, onDOMAttrModified);
    }
    if (node[CREATED_CALLBACK] && notFromInnerHTMLHelper) {
      node.created = true;
      node[CREATED_CALLBACK]();
      node.created = false;
    }
  }
  function purge() {
    for (var node, i = 0, length = targets.length; i < length; i++) {
      node = targets[i];
      if (!documentElement.contains(node)) {
        length--;
        targets.splice(i--, 1);
        verifyAndSetupAndAction(node, DETACHED);
      }
    }
  }
  function throwTypeError(type) {
    throw new Error("A " + type + " type is already registered");
  }
  function verifyAndSetupAndAction(node, action) {
    var fn, i = getTypeIndex(node), counterAction;
    if (-1 < i) {
      patchIfNotAlready(node, protos[i]);
      i = 0;
      if (action === ATTACHED && !node[ATTACHED]) {
        node[DETACHED] = false;
        node[ATTACHED] = true;
        counterAction = "connected";
        i = 1;
        if (IE8 && indexOf.call(targets, node) < 0) {
          targets.push(node);
        }
      } else if (action === DETACHED && !node[DETACHED]) {
        node[ATTACHED] = false;
        node[DETACHED] = true;
        counterAction = "disconnected";
        i = 1;
      }
      if (i && (fn = node[action + CALLBACK] || node[counterAction + CALLBACK]))
        fn.call(node);
    }
  }
  function CustomElementRegistry() {
  }
  CustomElementRegistry.prototype = {
    constructor: CustomElementRegistry,
    define: usableCustomElements ? function(name, Class, options) {
      if (options) {
        CERDefine(name, Class, options);
      } else {
        var NAME = name.toUpperCase();
        constructors[NAME] = {
          constructor: Class,
          create: [NAME]
        };
        nodeNames.set(Class, NAME);
        customElements.define(name, Class);
      }
    } : CERDefine,
    get: usableCustomElements ? function(name) {
      return customElements.get(name) || get(name);
    } : get,
    whenDefined: usableCustomElements ? function(name) {
      return Promise.race([customElements.whenDefined(name), whenDefined(name)]);
    } : whenDefined
  };
  function CERDefine(name, Class, options) {
    var is = options && options[EXTENDS] || "", CProto = Class.prototype, proto = create(CProto), attributes = Class.observedAttributes || empty, definition = {
      prototype: proto
    };
    safeProperty(proto, CREATED_CALLBACK, {
      value: function value() {
        if (justCreated)
          justCreated = false;
        else if (!this[DRECEV1]) {
          this[DRECEV1] = true;
          new Class(this);
          if (CProto[CREATED_CALLBACK])
            CProto[CREATED_CALLBACK].call(this);
          var info = constructors[nodeNames.get(Class)];
          if (!usableCustomElements || info.create.length > 1) {
            notifyAttributes(this);
          }
        }
      }
    });
    safeProperty(proto, ATTRIBUTE_CHANGED_CALLBACK, {
      value: function value(name2) {
        if (-1 < indexOf.call(attributes, name2))
          CProto[ATTRIBUTE_CHANGED_CALLBACK].apply(this, arguments);
      }
    });
    if (CProto[CONNECTED_CALLBACK]) {
      safeProperty(proto, ATTACHED_CALLBACK, {
        value: CProto[CONNECTED_CALLBACK]
      });
    }
    if (CProto[DISCONNECTED_CALLBACK]) {
      safeProperty(proto, DETACHED_CALLBACK, {
        value: CProto[DISCONNECTED_CALLBACK]
      });
    }
    if (is)
      definition[EXTENDS] = is;
    name = name.toUpperCase();
    constructors[name] = {
      constructor: Class,
      create: is ? [is, secondArgument(name)] : [name]
    };
    nodeNames.set(Class, name);
    document[REGISTER_ELEMENT](name.toLowerCase(), definition);
    whenDefined(name);
    waitingList[name].r();
  }
  function get(name) {
    var info = constructors[name.toUpperCase()];
    return info && info.constructor;
  }
  function getIs(options) {
    return typeof options === "string" ? options : options && options.is || "";
  }
  function notifyAttributes(self) {
    var callback = self[ATTRIBUTE_CHANGED_CALLBACK], attributes = callback ? self.attributes : empty, i = attributes.length, attribute;
    while (i--) {
      attribute = attributes[i];
      callback.call(self, attribute.name || attribute.nodeName, null, attribute.value || attribute.nodeValue);
    }
  }
  function whenDefined(name) {
    name = name.toUpperCase();
    if (!(name in waitingList)) {
      waitingList[name] = {};
      waitingList[name].p = new Promise(function(resolve) {
        waitingList[name].r = resolve;
      });
    }
    return waitingList[name].p;
  }
  function polyfillV1() {
    if (customElements)
      delete window.customElements;
    defineProperty(window, "customElements", {
      configurable: true,
      value: new CustomElementRegistry()
    });
    defineProperty(window, "CustomElementRegistry", {
      configurable: true,
      value: CustomElementRegistry
    });
    for (var patchClass = function patchClass2(name) {
      var Class = window[name];
      if (Class) {
        window[name] = function CustomElementsV1(self) {
          var info, isNative;
          if (!self)
            self = this;
          if (!self[DRECEV1]) {
            justCreated = true;
            info = constructors[nodeNames.get(self.constructor)];
            isNative = usableCustomElements && info.create.length === 1;
            self = isNative ? Reflect.construct(Class, empty, info.constructor) : document.createElement.apply(document, info.create);
            self[DRECEV1] = true;
            justCreated = false;
            if (!isNative)
              notifyAttributes(self);
          }
          return self;
        };
        window[name].prototype = Class.prototype;
        try {
          Class.prototype.constructor = window[name];
        } catch (WebKit) {
          fixGetClass = true;
          defineProperty(Class, DRECEV1, {
            value: window[name]
          });
        }
      }
    }, Classes = htmlClass.get(/^HTML[A-Z]*[a-z]/), i = Classes.length; i--; patchClass(Classes[i])) {
    }
    document.createElement = function(name, options) {
      var is = getIs(options);
      return is ? patchedCreateElement.call(this, name, secondArgument(is)) : patchedCreateElement.call(this, name);
    };
    if (!V0) {
      justSetup = true;
      document[REGISTER_ELEMENT]("");
    }
  }
  if (!customElements || /^force/.test(polyfill.type))
    polyfillV1();
  else if (!polyfill.noBuiltIn) {
    try {
      ;
      (function(DRE, options, name) {
        options[EXTENDS] = "a";
        DRE.prototype = create(HTMLAnchorElement.prototype);
        DRE.prototype.constructor = DRE;
        window.customElements.define(name, DRE, options);
        if (getAttribute.call(document.createElement("a", {
          is: name
        }), "is") !== name || usableCustomElements && getAttribute.call(new DRE(), "is") !== name) {
          throw options;
        }
      })(function DRE() {
        return Reflect.construct(HTMLAnchorElement, [], DRE);
      }, {}, "document-register-element-a");
    } catch (o_O) {
      polyfillV1();
    }
  }
  if (!polyfill.noBuiltIn) {
    try {
      createElement.call(document, "a", "a");
    } catch (FireFox) {
      secondArgument = function secondArgument2(is) {
        return {
          is: is.toLowerCase()
        };
      };
    }
  }
}
/* harmony default export */ const custom_element_polyfill = (installCustomElements);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/shared/custom-element.js











function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}















var isTest = typeof process !== "undefined" && "production" === "test";
var hasPolyfill = isTest;
var registeredElements = typeof window !== "undefined" && (window.registeredElements = window.registeredElements || []) || [];
var registerElement = function registerElement2(tagName, ReactComponent) {
  var propNames = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
  var _ref = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}, _ref$attributesExclud = _ref.attributesExcludelist, attributesExcludelist = _ref$attributesExclud === void 0 ? ["id"] : _ref$attributesExclud;
  if (!tagName)
    tagName = ReactComponent.displayName || ReactComponent.name;
  if (registeredElements.indexOf(tagName) !== -1)
    return;
  registeredElements.push(tagName);
  if (typeof document === "undefined" || typeof window === "undefined") {
    return null;
  }
  if (!hasPolyfill) {
    hasPolyfill = true;
    custom_element_polyfill(window);
  }
  if (propNames) {
    propNames = prepareDefaultProps(propNames);
  }
  var HtmlClass = function(_HTMLElement) {
    (0,inherits/* default */.Z)(HtmlClass2, _HTMLElement);
    var _super = _createSuper(HtmlClass2);
    function HtmlClass2(props) {
      var _this;
      (0,classCallCheck/* default */.Z)(this, HtmlClass2);
      _this = _super.call(this, props);
      _this._elementRef = react.createRef();
      _this._customMethodes = {};
      _this._customEvents = [];
      _this._isConnected = false;
      _this._props = {};
      return _this;
    }
    (0,createClass/* default */.Z)(HtmlClass2, [{
      key: "connectedCallback",
      value: function connectedCallback() {
        this.updateChildren();
        this.renderElement();
        this._isConnected = true;
      }
    }, {
      key: "attributeChangedCallback",
      value: function attributeChangedCallback(attrName, oldAttr, newAttr) {
        if (!this._isConnected || oldAttr === newAttr) {
          return false;
        }
        this.renderElement();
        return newAttr;
      }
    }, {
      key: "disconnectedCallback",
      value: function disconnectedCallback() {
        if (!isTest) {
          react_dom.unmountComponentAtNode(this);
        }
        if (this._children)
          delete this._children;
        if (this._isConnected)
          delete this._isConnected;
        if (this._elementRef)
          delete this._elementRef;
        if (this._customMethodes)
          delete this._customMethodes;
        if (this._customEvents)
          delete this._customEvents;
        this._props = null;
        this._ref = null;
      }
    }, {
      key: "updateChildren",
      value: function updateChildren() {
        this._children = [];
        var i, cn = this.childNodes, v;
        for (i = cn.length; i--; ) {
          v = toVdom(cn[i]);
          if (v) {
            this._children.push(v);
          }
        }
      }
    }, {
      key: "connectEvents",
      value: function connectEvents() {
        var props = {};
        for (var i = this.attributes.length; i--; ) {
          props[this.attributes[i].name] = this.attributes[i].value;
        }
        if (props.events) {
          props.event = props.events;
          delete props.events;
        }
        var events = [].concat((0,toConsumableArray/* default */.Z)(props.event ? props.event.split(",") : []), (0,toConsumableArray/* default */.Z)(Object.entries(props).map(function(_ref2) {
          var _ref3 = (0,slicedToArray/* default */.Z)(_ref2, 2), key = _ref3[0], value = _ref3[1];
          if (key && /^(on_|on[A-Z]|render_)/.test(key)) {
            return key + "=" + value;
          }
          return null;
        }).filter(Boolean)));
        if (events.length > 0) {
          events.forEach(function(eventDef) {
            var _eventDef$split = eventDef.split("="), _eventDef$split2 = (0,slicedToArray/* default */.Z)(_eventDef$split, 2), type = _eventDef$split2[0], func = _eventDef$split2[1];
            type = EVENT_TRANSLATIONS[type] || type;
            props[type] = function() {
              try {
                var _func$split = func.split("."), _func$split2 = (0,slicedToArray/* default */.Z)(_func$split, 2), scope = _func$split2[0], fn = _func$split2[1];
                fn = fn ? window[scope][fn] : window[scope];
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                  args[_key] = arguments[_key];
                }
                var component = fn.apply(scope, [].concat(args));
                if (component instanceof HTMLElement) {
                  var children = [], cn = component.childNodes, a = component.attributes, _props = {};
                  for (var _i = cn.length; _i--; ) {
                    children.push(toVdom(cn[_i]));
                  }
                  for (var _i2 = a.length; _i2--; ) {
                    _props[PROP_TRANSLATIONS[a[_i2].name] || a[_i2].name] = a[_i2].value;
                  }
                  var nodeName = component.nodeName.toLowerCase();
                  component.remove();
                  return react.createElement(nodeName, _props, children);
                }
                return component;
              } catch (error) {
                new error_helper/* ErrorHandler */.qL("The '".concat(type, "' event has failed. '").concat(func, "' has to exist on a 'window' scope!"), error);
              }
            };
          });
          delete props.event;
        }
        return props;
      }
    }, {
      key: "setProps",
      value: function setProps(props, value) {
        if (typeof props === "string") {
          props = (0,defineProperty/* default */.Z)({}, props, value);
        }
        return this.renderElement(props);
      }
    }, {
      key: "getRef",
      value: function getRef() {
        return this._ref;
      }
    }, {
      key: "addEvent",
      value: function addEvent(eventName, eventCallback) {
        var _this2 = this, _this$_customEvents;
        var eventWrapper = function eventWrapper2(event) {
          return eventCallback.apply(_this2, [event]);
        };
        (_this$_customEvents = this._customEvents) === null || _this$_customEvents === void 0 ? void 0 : _this$_customEvents.push({
          eventName,
          eventCallback,
          eventWrapper
        });
        return eventWrapper;
      }
    }, {
      key: "removeEvent",
      value: function removeEvent(eventId) {
        var removeCallback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
        this._customEvents = this._customEvents.reduce(function(accumulator, current) {
          if (removeCallback) {
            var eventWrapper = current.eventCallback;
            if (eventWrapper !== removeCallback) {
              accumulator.push(current);
            }
          } else {
            var _eventWrapper = current.eventWrapper;
            if (_eventWrapper !== eventId) {
              accumulator.push(current);
            }
          }
          return accumulator;
        }, []);
      }
    }, {
      key: "fireEvent",
      value: function fireEvent(eventName) {
        var _this3 = this;
        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }
        this._customEvents.forEach(function(_ref4) {
          var name = _ref4.eventName, eventCallback = _ref4.eventCallback;
          if (name === eventName && typeof eventCallback === "function") {
            eventCallback.apply(_this3, [].concat(args));
          }
        });
      }
    }, {
      key: "renderElement",
      value: function renderElement() {
        var _this4 = this;
        var props = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        props = (0,esm_extends/* default */.Z)({}, this._props, this.connectEvents(), props);
        for (var p in props) {
          if (props[p] === "true") {
            props[p] = true;
          } else if (props[p] === "false") {
            props[p] = false;
          } else if (typeof props[p] !== "undefined" && props[p] !== null && !isNaN(Number(props[p]))) {
            props[p] = Number(props[p]);
          }
        }
        for (var i = attributesExcludelist.length; i--; ) {
          if (props[attributesExcludelist[i]]) {
            this.removeAttribute(attributesExcludelist[i]);
          }
        }
        if (this._children && this._children.length > 0) {
          props.children = this._children;
        }
        if (this._elementRef) {
          props.ref = this._elementRef;
        }
        if (!props.custom_element) {
          props.custom_element = this;
        }
        if (!props.custom_method) {
          props.custom_method = function(methodName, methodFunc) {
            _this4[methodName] = _this4._customMethodes[methodName] = methodFunc;
          };
        }
        this._props = props;
        this._ref = react.createElement(ReactComponent, props);
        react_dom.render(this._ref, this);
        return this;
      }
    }], [{
      key: "observedAttributes",
      get: function get() {
        return propNames || [];
      }
    }]);
    return HtmlClass2;
  }(_wrapNativeSuper(HTMLElement));
  return window.customElements.define(tagName, HtmlClass);
};
var filterProps = function filterProps2(key) {
  return key && !/[A-Z]/.test(key) && !/children/.test(key);
};
var prepareDefaultProps = function prepareDefaultProps2(defaultProps) {
  return Array.isArray(defaultProps) ? defaultProps.filter(filterProps) : Object.entries(defaultProps || {}).reduce(function(props, _ref5) {
    var _ref6 = (0,slicedToArray/* default */.Z)(_ref5, 1), key = _ref6[0];
    props.push(key);
    return props;
  }, []).filter(filterProps);
};
var toVdom = function toVdom2(elem) {
  var name = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  if (elem.nodeType === 3)
    return elem.nodeValue;
  if (elem.nodeType !== 1)
    return null;
  var children = [], props = {}, i = 0, a = elem.attributes, cn = elem.childNodes;
  for (i = a.length; i--; ) {
    props[a[i].name] = a[i].value;
  }
  for (i = cn.length; i--; ) {
    children[i] = toVdom2(cn[i]);
  }
  props.key = "key".concat(Math.random() * 1e3);
  return react.createElement(name || elem.nodeName.toLowerCase(), props, children);
};
var PROP_TRANSLATIONS = {
  class: "className",
  for: "htmlFor"
};
var EVENT_TRANSLATIONS = {
  onclick: "onClick"
};


/***/ }),

/***/ 7609:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MV": () => (/* binding */ LOCALE),
/* harmony export */   "wA": () => (/* binding */ CURRENCY),
/* harmony export */   "XI": () => (/* binding */ CURRENCY_DISPLAY)
/* harmony export */ });
var LOCALE = "nb-NO";
var CURRENCY = "NOK";
var CURRENCY_DISPLAY = "narrowSymbol";


/***/ }),

/***/ 2333:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "qL": () => (/* binding */ ErrorHandler)
/* harmony export */ });
/* unused harmony exports ERROR_HARMLESS, ERROR_FATAL */
/* harmony import */ var _babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4687);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6091);


var ERROR_HARMLESS = 100;
var ERROR_FATAL = 500;
function ErrorHandler(error) {
  var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
    message: null
  }, message = _ref.message;
  var code = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : ERROR_HARMLESS;
  if ((0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(error) === "object") {
    message = error.message;
  }
  this.err = new Error("".concat(error, "\n\n").concat(message));
  if (code === ERROR_FATAL) {
    throw this.err;
  } else {
    console.log(this.err);
  }
}


/***/ }),

/***/ 6620:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cW": () => (/* binding */ IS_IE11),
/* harmony export */   "oJ": () => (/* binding */ getOffsetTop),
/* harmony export */   "pB": () => (/* binding */ getOffsetLeft),
/* harmony export */   "qF": () => (/* binding */ hasSelectedText),
/* harmony export */   "BP": () => (/* binding */ getSelectedElement)
/* harmony export */ });
/* unused harmony exports IS_EDGE, IS_IOS, IS_SAFARI, IS_WIN, IS_MAC, IS_LINUX, isMac, isWin, isLinux, isiOS, isSafari, isIE11, isEdge, setPageFocusElement, applyPageFocus, scrollToLocationHashId, debounce, insertElementBeforeSelection, getSelectedText, copyToClipboard */
/* harmony import */ var _babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4687);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9096);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6944);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6654);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6915);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4565);
/* harmony import */ var _component_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1218);











var IS_IE11 = false;
var IS_EDGE = false;
var IS_IOS = false;
var IS_SAFARI = false;
var IS_WIN = false;
var IS_MAC = false;
var IS_LINUX = false;
var isMac = function isMac2() {
  var _navigator;
  return IS_MAC = typeof navigator !== "undefined" && new RegExp(_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .PLATFORM_MAC */ .lS, "i").test((_navigator = navigator) === null || _navigator === void 0 ? void 0 : _navigator.platform);
};
var isWin = function isWin2() {
  var _navigator2;
  return IS_WIN = typeof navigator !== "undefined" && new RegExp(_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .PLATFORM_WIN */ .JQ, "i").test((_navigator2 = navigator) === null || _navigator2 === void 0 ? void 0 : _navigator2.platform);
};
var isLinux = function isLinux2() {
  var _navigator3;
  return IS_LINUX = typeof navigator !== "undefined" && new RegExp(_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .PLATFORM_LINUX */ .OK, "i").test((_navigator3 = navigator) === null || _navigator3 === void 0 ? void 0 : _navigator3.platform);
};
var isiOS = function isiOS2() {
  var _navigator4;
  return IS_IOS = typeof navigator !== "undefined" && new RegExp(_component_helper__WEBPACK_IMPORTED_MODULE_7__/* .PLATFORM_IOS */ .Y9, "i").test((_navigator4 = navigator) === null || _navigator4 === void 0 ? void 0 : _navigator4.platform);
};
var isSafari = function isSafari2() {
  var _navigator5, _navigator6;
  return IS_SAFARI = typeof navigator !== "undefined" && /safari/i.test((_navigator5 = navigator) === null || _navigator5 === void 0 ? void 0 : _navigator5.userAgent) && !/chrome/i.test((_navigator6 = navigator) === null || _navigator6 === void 0 ? void 0 : _navigator6.userAgent);
};
var isIE11 = function isIE112() {
  return IS_IE11 = typeof window !== "undefined" && typeof document !== "undefined" ? !!window.MSInputMethodContext && !!document.documentMode : false;
};
var isEdge = function isEdge2() {
  var _navigator7;
  return IS_EDGE = typeof navigator !== "undefined" && /edge/i.test((_navigator7 = navigator) === null || _navigator7 === void 0 ? void 0 : _navigator7.userAgent);
};
isIE11();
isEdge();
isiOS();
isSafari();
isWin();
isMac();
isLinux();
var pageFocusElements = {};
function setPageFocusElement(selectorOrElement) {
  var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "default";
  return pageFocusElements[key] = selectorOrElement;
}
function applyPageFocus() {
  var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "default";
  var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  try {
    var element = pageFocusElements[key];
    if (typeof element === "string" && typeof document !== "undefined") {
      element = document.querySelector(element);
    } else if (!element && typeof document !== "undefined") {
      element = document.querySelector(".dnb-no-focus");
    }
    if (element instanceof HTMLElement) {
      if (["h1", "h2", "h3", "h4", "h5", "h6", "p", "div", "main", "nav", "header", "footer", "aside", "section", "article"].includes(String(element.nodeName).toLowerCase())) {
        if (!element.hasAttribute("tabindex")) {
          element.setAttribute("tabindex", "-1");
        }
        if (element.classList && !element.classList.contains("dnb-no-focus")) {
          element.classList.add("dnb-no-focus");
        }
      }
      element.focus({
        preventScroll: true
      });
      if (typeof callback === "function") {
        callback(element);
      }
    }
  } catch (e) {
    warn("Error on applyPageFocus:", e);
  }
}
function getOffsetTop(elem) {
  var offsetTop = 0;
  if (elem) {
    do {
      if (!isNaN(elem.offsetTop)) {
        offsetTop += elem.offsetTop;
      }
    } while (elem = elem.offsetParent);
  }
  return offsetTop;
}
function getOffsetLeft(elem) {
  var offsetLeft = 0;
  if (elem) {
    do {
      if (!isNaN(elem.offsetLeft)) {
        offsetLeft += elem.offsetLeft;
      }
    } while (elem = elem.offsetParent);
  }
  return offsetLeft;
}
function scrollToLocationHashId() {
  var _ref = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref$offset = _ref.offset, offset = _ref$offset === void 0 ? 0 : _ref$offset, _ref$delay = _ref.delay, delay = _ref$delay === void 0 ? null : _ref$delay, _ref$onCompletion = _ref.onCompletion, onCompletion = _ref$onCompletion === void 0 ? null : _ref$onCompletion;
  if (typeof document !== "undefined" && typeof window !== "undefined" && window.location) {
    try {
      var _timeout;
      var id = String(window.location.hash).replace("#", "");
      if (id.length > 0) {
        var handleScroll = function handleScroll2() {
          var runScroll = function runScroll2() {
            var top = getOffsetTop(elem) - offset;
            try {
              if (typeof IntersectionObserver !== "undefined") {
                var intersectionObserver = new IntersectionObserver(function(entries) {
                  var _entries = _slicedToArray(entries, 1), entry = _entries[0];
                  if (entry.isIntersecting) {
                    intersectionObserver.unobserve(elem);
                    if (typeof onCompletion === "function") {
                      onCompletion(elem);
                    }
                  }
                });
                intersectionObserver.observe(elem);
              }
              if (window.scrollTo) {
                window.scrollTo({
                  top,
                  behavior: "smooth"
                });
              } else {
                window.scrollTop = top;
              }
            } catch (e) {
              warn("Error on scrollToLocationHashId:", e);
            }
          };
          if (delay > 0) {
            clearTimeout(_timeout);
            _timeout = setTimeout(runScroll, delay);
          } else {
            runScroll();
          }
        };
        var elem = document.getElementById(id);
        if (elem instanceof HTMLElement) {
          window.addEventListener("beforeunload", function() {
            return clearTimeout(_timeout);
          });
          if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", handleScroll);
          } else {
            handleScroll();
          }
        }
        return elem;
      }
    } catch (e) {
      warn("Error on scrollToLocationHashId:", e);
    }
  }
}
function debounce(func) {
  var wait = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 250;
  var _ref2 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, _ref2$immediate = _ref2.immediate, immediate = _ref2$immediate === void 0 ? false : _ref2$immediate, _ref2$context = _ref2.context, context = _ref2$context === void 0 ? null : _ref2$context;
  var timeout;
  var recall;
  return function executedFunction() {
    var ctx = context || this;
    var args = arguments;
    if (typeof recall === "function") {
      recall();
    }
    var later = function later2() {
      timeout = null;
      if (!immediate) {
        recall = func.apply(ctx, args);
      }
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) {
      recall = func.apply(ctx, args);
    }
  };
}
function insertElementBeforeSelection(elem) {
  try {
    var selection = window.getSelection();
    var range = selection.getRangeAt(0);
    range.cloneRange().insertNode(elem);
    selection.addRange(range);
  } catch (e) {
  }
}
function getSelectedText() {
  try {
    return window.getSelection().toString();
  } catch (e) {
  }
  return "";
}
function hasSelectedText() {
  return getSelectedText().length > 0;
}
function getSelectedElement() {
  try {
    var selection = window.getSelection();
    if (selection.rangeCount > 0) {
      var elem = selection.getRangeAt(0).startContainer;
      if (elem && (0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(elem) === "object") {
        elem = elem.parentNode;
      }
      return elem;
    }
  } catch (e) {
  }
  return null;
}
function copyToClipboard(_x) {
  return _copyToClipboard.apply(this, arguments);
}
function _copyToClipboard() {
  _copyToClipboard = _asyncToGenerator(_regeneratorRuntime.mark(function _callee(string) {
    var _navigator8;
    var selection, range, resetSelection, copyFallback, success, newTry;
    return _regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(typeof window === "undefined" || typeof document === "undefined")) {
              _context.next = 2;
              break;
            }
            return _context.abrupt("return", false);
          case 2:
            selection = window.getSelection();
            range = selection.rangeCount > 0 ? selection.getRangeAt(0) : false;
            resetSelection = function resetSelection2() {
              try {
                selection.removeAllRanges();
                selection.addRange(range);
              } catch (e) {
              }
            };
            copyFallback = function copyFallback2() {
              try {
                var elem = document.createElement("textarea");
                elem.value = String(string);
                elem.contentEditable = true;
                elem.readOnly = false;
                elem.style.position = "fixed";
                elem.style.top = "-1000px";
                document.body.appendChild(elem);
                var _success = document.execCommand("copy");
                document.body.removeChild(elem);
                resetSelection();
                if (_success) {
                  return true;
                }
              } catch (e) {
                return e;
              }
              return "Could not copy! Unknown reason. ".concat(string);
            };
            if (!(typeof navigator !== "undefined" && (_navigator8 = navigator) !== null && _navigator8 !== void 0 && _navigator8.clipboard)) {
              _context.next = 21;
              break;
            }
            _context.prev = 7;
            _context.next = 10;
            return navigator.clipboard.writeText(String(string));
          case 10:
            success = true;
            resetSelection();
            _context.next = 19;
            break;
          case 14:
            _context.prev = 14;
            _context.t0 = _context["catch"](7);
            success = _context.t0;
            newTry = copyFallback();
            if (newTry === true) {
              success = newTry;
            }
          case 19:
            _context.next = 22;
            break;
          case 21:
            success = copyFallback();
          case 22:
            return _context.abrupt("return", success);
          case 23:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[7, 14]]);
  }));
  return _copyToClipboard.apply(this, arguments);
}


/***/ }),

/***/ 8231:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export SuffixContext */
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4973);
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8802);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(855);





var SuffixContext = react__WEBPACK_IMPORTED_MODULE_0__.createContext();
var Suffix = function Suffix2(_ref) {
  var className = _ref.className, children = _ref.children, context = _ref.context, props = (0,_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(_ref, ["className", "children", "context"]);
  var content = react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)({
    className: classnames__WEBPACK_IMPORTED_MODULE_2__("dnb-suffix", className)
  }, props), children);
  if (typeof children !== "string" && context) {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement(SuffixContext.Provider, {
      value: context
    }, content);
  }
  return content;
};
 false ? 0 : void 0;
Suffix.defaultProps = {
  className: null,
  children: null
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Suffix);


/***/ }),

/***/ 8704:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ sum)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4687);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6306);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5042);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2478);
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5860);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4565);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2325);







function pad(hash, len) {
  while (hash.length < len) {
    hash = "0" + hash;
  }
  return hash;
}
function fold(hash, text) {
  var i;
  var chr;
  var len;
  if (text.length === 0) {
    return hash;
  }
  for (i = 0, len = text.length; i < len; i++) {
    chr = text.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }
  return hash < 0 ? hash * -2 : hash;
}
function foldObject(hash, o, seen, deep) {
  return Object.keys(o).sort().reduce(foldKey, hash);
  function foldKey(hash2, key) {
    if (deep === false && ((0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(o[key]) === "object" || typeof o[key] === "function")) {
      return hash2;
    }
    return foldValue(hash2, o[key], key, seen, deep);
  }
}
function foldValue(input, value, key, seen, deep) {
  var hash = fold(fold(fold(input, key), toString(value)), (0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(value));
  if (value === null) {
    return fold(hash, "null");
  }
  if (value === void 0) {
    return fold(hash, "undefined");
  }
  if ((0,_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(value) === "object" || typeof value === "function") {
    if (seen.indexOf(value) !== -1) {
      return fold(hash, "[Circular]" + key);
    }
    seen.push(value);
    var objHash = foldObject(hash, value, seen, deep);
    if (!("valueOf" in value) || typeof value.valueOf !== "function") {
      return objHash;
    }
    try {
      return fold(objHash, String(value.valueOf()));
    } catch (err) {
      return fold(objHash, "[valueOf exception]" + (err.stack || err.message));
    }
  }
  return fold(hash, value.toString());
}
function toString(o) {
  return Object.prototype.toString.call(o);
}
function sum(o) {
  var deep = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
  return pad(foldValue(0, o, "", [], deep).toString(16), 8);
}


/***/ }),

/***/ 7927:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Qp": () => (/* binding */ disableBodyScroll),
/* harmony export */   "tG": () => (/* binding */ enableBodyScroll)
/* harmony export */ });
/* unused harmony export clearAllBodyScrollLocks */
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4973);
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6679);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7298);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3070);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1362);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1698);
/* harmony import */ var core_js_modules_es_array_index_of_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5860);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4348);
/* harmony import */ var _component_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1218);









var isServer = function isServer2() {
  return typeof window === "undefined";
};
var detectOS = function detectOS2(ua) {
  ua = ua || navigator.userAgent;
  var ipad = /(iPad).*OS\s([\d_]+)/.test(ua);
  var iphone = !ipad && /(iPhone\sOS)\s([\d_]+)/.test(ua);
  var android = /(Android);?[\s/]+([\d.]+)?/.test(ua);
  var ios = iphone || ipad;
  return {
    ios,
    android
  };
};
var detectiOSVersion = function detectiOSVersion2() {
  var match = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
  var version;
  if (match !== void 0 && match !== null) {
    version = [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3] || 0, 10)];
    return parseFloat(version.join("."));
  }
  return false;
};
var lockedNum = 0;
var initialClientY = 0;
var initialClientX = 0;
var unLockCallback = null;
var documentListenerAdded = false;
var lockedElements = [];
var eventListenerOptions = getEventListenerOptions({
  passive: false
});
function getEventListenerOptions(options) {
  if (isServer()) {
    return;
  }
  var isSupportOptions = true;
  var capture = options.capture;
  return isSupportOptions ? options : typeof capture !== "undefined" ? capture : false;
}
var setOverflowHiddenPc = function setOverflowHiddenPc2() {
  try {
    var $html = document.documentElement;
    var $body = document.body;
    var htmlStyle = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({}, $html.style);
    var bodyStyle = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({}, $body.style);
    var scrollBarWidth = window.innerWidth - $body.clientWidth;
    $html.style.height = "auto";
    $html.style.overflow = "hidden";
    $html.style.setProperty("--scrollbar-width", "".concat(scrollBarWidth, "px"));
    $body.style.overflow = "hidden";
    $body.style.height = "auto";
    $body.style.boxSizing = "border-box";
    $body.style.paddingRight = "".concat(scrollBarWidth, "px");
    return function() {
      try {
        ;
        ["height", "overflow"].forEach(function(x) {
          $html.style[x] = htmlStyle[x] || "";
        });
        ["overflow", "height", "boxSizing", "paddingRight"].forEach(function(x) {
          $body.style[x] = bodyStyle[x] || "";
        });
        $html.style.removeProperty("--scrollbar-width");
      } catch (e) {
      }
    };
  } catch (e) {
  }
};
var setOverflowHiddenMobile = function setOverflowHiddenMobile2() {
  try {
    var $html = document.documentElement;
    var $body = document.body;
    var scrollTop = $html.scrollTop || $body.scrollTop;
    var htmlStyle = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({}, $html.style);
    var bodyStyle = (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({}, $body.style);
    $html.style.height = "100%";
    $html.style.overflow = "hidden";
    $body.style.top = "-".concat(scrollTop, "px");
    $body.style.width = "100%";
    $body.style.height = "auto";
    $body.style.position = "fixed";
    $body.style.overflow = "hidden";
    return function() {
      try {
        ;
        ["height", "overflow"].forEach(function(x) {
          $html.style[x] = htmlStyle[x] || "";
        });
        ["top", "width", "height", "overflow", "position"].forEach(function(x) {
          $body.style[x] = bodyStyle[x] || "";
        });
        var scrollBehavior = window.getComputedStyle($html).scrollBehavior;
        $html.style.scrollBehavior = "auto";
        $html.scrollTop = scrollTop;
        $html.style.scrollBehavior = scrollBehavior;
      } catch (e) {
      }
    };
  } catch (e) {
  }
};
var preventDefault = function preventDefault2(event) {
  var found = lockedElements.find(function(targetElement) {
    return (0,_component_helper__WEBPACK_IMPORTED_MODULE_8__/* .isChildOfElement */ .m0)(event.target, targetElement);
  });
  if (found || !event.cancelable) {
    return;
  }
  event.preventDefault();
};
var handleScroll = function handleScroll2(event, targetElement) {
  try {
    if (targetElement) {
      var scrollTop = targetElement.scrollTop, scrollLeft = targetElement.scrollLeft, scrollWidth = targetElement.scrollWidth, scrollHeight = targetElement.scrollHeight, clientWidth = targetElement.clientWidth, clientHeight = targetElement.clientHeight;
      var clientX = event.targetTouches[0].clientX - initialClientX;
      var clientY = event.targetTouches[0].clientY - initialClientY;
      var isVertical = Math.abs(clientY) > Math.abs(clientX);
      var isOnTop = clientY > 0 && scrollTop === 0;
      var isOnLeft = clientX > 0 && scrollLeft === 0;
      var isOnRight = clientX < 0 && scrollLeft + clientWidth + 1 >= scrollWidth;
      var isOnBottom = clientY < 0 && scrollTop + clientHeight + 1 >= scrollHeight;
      if (isVertical && (isOnTop || isOnBottom) || !isVertical && (isOnLeft || isOnRight)) {
        var hasScrollbar = (0,_component_helper__WEBPACK_IMPORTED_MODULE_8__/* .isChildOfElement */ .m0)(event.target, targetElement, _component_helper__WEBPACK_IMPORTED_MODULE_8__/* .checkIfHasScrollbar */ .b);
        if (hasScrollbar && hasScrollbar !== targetElement) {
          return true;
        }
        return event.cancelable && event.preventDefault();
      }
    }
    event.stopPropagation();
    return true;
  } catch (e) {
  }
};
var checkTargetElement = function checkTargetElement2(targetElement) {
  if (targetElement)
    return;
  if (targetElement === null)
    return;
  console.warn("If scrolling is also required in the floating layer, the target element must be provided.");
};
var disableBodyScroll = function disableBodyScroll2(targetElement) {
  if (isServer()) {
    return;
  }
  checkTargetElement(targetElement);
  try {
    if (detectOS().ios) {
      if (detectiOSVersion() >= 14) {
        if (lockedNum <= 0) {
          unLockCallback = setOverflowHiddenMobile();
        }
      } else {
        if (targetElement) {
          var elementArray = Array.isArray(targetElement) ? targetElement : [targetElement];
          elementArray.forEach(function(element) {
            if (element && lockedElements.indexOf(element) === -1) {
              element.ontouchstart = function(event) {
                initialClientY = event.targetTouches[0].clientY;
                initialClientX = event.targetTouches[0].clientX;
              };
              element.ontouchmove = function(event) {
                if (event.targetTouches.length !== 1) {
                  return;
                }
                handleScroll(event, element);
              };
              lockedElements.push(element);
            }
          });
        }
        if (!documentListenerAdded) {
          document.addEventListener("touchmove", preventDefault, eventListenerOptions);
          documentListenerAdded = true;
        }
      }
    } else if (lockedNum <= 0) {
      unLockCallback = detectOS().android ? setOverflowHiddenMobile() : setOverflowHiddenPc();
    }
    lockedNum += 1;
  } catch (e) {
  }
};
var enableBodyScroll = function enableBodyScroll2(targetElement) {
  if (isServer()) {
    return;
  }
  checkTargetElement(targetElement);
  try {
    lockedNum -= 1;
    if (lockedNum > 0) {
      return;
    }
    if (typeof unLockCallback === "function") {
      unLockCallback();
    }
    if (detectOS().ios && !(detectiOSVersion() >= 14)) {
      if (targetElement) {
        var elementArray = Array.isArray(targetElement) ? targetElement : [targetElement];
        elementArray.forEach(function(element) {
          var index = lockedElements.indexOf(element);
          if (index !== -1) {
            element.ontouchmove = null;
            element.ontouchstart = null;
            lockedElements.splice(index, 1);
          }
        });
      }
      if (documentListenerAdded) {
        document.removeEventListener("touchmove", preventDefault, eventListenerOptions);
        documentListenerAdded = false;
      }
    }
  } catch (e) {
  }
};
var clearAllBodyScrollLocks = function clearAllBodyScrollLocks2() {
  if (isServer()) {
    return;
  }
  try {
    lockedNum = 0;
    if (!detectOS().ios && typeof unLockCallback === "function") {
      unLockCallback();
    }
    if (detectOS().ios && !(detectiOSVersion() >= 14)) {
      if (lockedElements && lockedElements.length) {
        var element = lockedElements.pop();
        while (element) {
          element.ontouchmove = null;
          element.ontouchstart = null;
          element = lockedElements.pop();
        }
      }
    }
    if (documentListenerAdded) {
      document.removeEventListener("touchmove", preventDefault, eventListenerOptions);
      documentListenerAdded = false;
    }
  } catch (e) {
  }
};


/***/ }),

/***/ 7034:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  "--font-family-default": "'DNB', sans-serif",
  "--font-family-monospace": "'DNBMono', 'Menlo', 'Consolas', 'Roboto Mono',",
  "--font-weight-default": "normal",
  "--font-weight-basis": "normal",
  "--font-weight-regular": "normal",
  "--font-weight-medium": "500",
  "--font-weight-bold": "600",
  "--font-size-x-small": "0.875rem",
  "--font-size-small": "1rem",
  "--font-size-basis": "1.125rem",
  "--font-size-basis--em": "1em",
  "--font-size-medium": "1.25rem",
  "--font-size-large": "1.625rem",
  "--font-size-x-large": "2.125rem",
  "--font-size-xx-large": "3rem",
  "--line-height-xx-small--em": "1em",
  "--line-height-x-small": "1.125rem",
  "--line-height-small": "1.25rem",
  "--line-height-basis": "1.5rem",
  "--line-height-basis--em": "1.333em",
  "--line-height-medium": "2rem",
  "--line-height-large": "2.5rem",
  "--line-height-x-large": "3.5rem",
  "--color-mint-green-50": "#d2f0e9",
  "--color-mint-green-25": "#e9f8f4",
  "--color-mint-green-12": "#f4fbf9",
  "--color-sea-green-30": "#b3dada",
  "--color-accent-yellow-30": "#feebc1",
  "--color-signal-orange": "#ff5400",
  "--color-fire-red": "#dc2a2a",
  "--color-success-green": "#008000",
  "--color-fire-red-8": "#fdeeee",
  "--color-black": "#000",
  "--color-black-80": "#333",
  "--color-black-55": "#737373",
  "--color-black-20": "#ccc",
  "--color-black-8": "#ebebeb",
  "--color-black-3": "#f8f8f8",
  "--color-white": "#fff",
  "--color-black-border": "#cdcdcd",
  "--color-black-background": "#fafafa",
  "--color-sea-green": "#007272",
  "--color-mint-green": "#a5e1d2",
  "--color-summer-green": "#28b482",
  "--color-emerald-green": "#14555a",
  "--color-ocean-green": "#00343e",
  "--color-accent-yellow": "#fdbb31",
  "--color-indigo": "#23195a",
  "--color-violet": "#6e2382",
  "--color-sky-blue": "#4bbed2",
  "--color-lavender": "#f2f2f5",
  "--color-sand-yellow": "#fbf6ec",
  "--color-pistachio": "#f2f4ec",
  "--color-mint-green-alt": "#ebfffa",
  "--color-indigo-medium": "#6e6491",
  "--color-indigo-light": "#b9afc8",
  "--color-violet-medium": "#a06eaf",
  "--color-violet-light": "#cfb9d7",
  "--color-sky-blue-medium": "#87d2e1",
  "--color-sky-blue-light": "#c3ebf0",
  "--spacing-xx-small": "0.25rem",
  "--spacing-x-small": "0.5rem",
  "--spacing-small": "1rem",
  "--spacing-medium": "1.5rem",
  "--spacing-large": "2rem",
  "--spacing-x-large": "3rem",
  "--spacing-xx-large": "3.5rem",
  "--layout-small": "40em",
  "--layout-medium": "50em",
  "--layout-large": "60em",
  "--layout-x-large": "72em",
  "--layout-xx-large": "80em",
  "--layout-xxx-large": "90em"
});


/***/ }),

/***/ 7985:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ emotion_cache_browser_esm)
});

// EXTERNAL MODULE: ../node_modules/@emotion/sheet/dist/emotion-sheet.browser.esm.js
var emotion_sheet_browser_esm = __webpack_require__(7594);
;// CONCATENATED MODULE: ../node_modules/stylis/src/Utility.js
var abs = Math.abs;
var Utility_from = String.fromCharCode;
function hash(value, length) {
  return (((length << 2 ^ Utility_charat(value, 0)) << 2 ^ Utility_charat(value, 1)) << 2 ^ Utility_charat(value, 2)) << 2 ^ Utility_charat(value, 3);
}
function trim(value) {
  return value.trim();
}
function match(value, pattern) {
  return (value = pattern.exec(value)) ? value[0] : value;
}
function replace(value, pattern, replacement) {
  return value.replace(pattern, replacement);
}
function indexof(value, search) {
  return value.indexOf(search);
}
function Utility_charat(value, index) {
  return value.charCodeAt(index) | 0;
}
function Utility_substr(value, begin, end) {
  return value.slice(begin, end);
}
function Utility_strlen(value) {
  return value.length;
}
function Utility_sizeof(value) {
  return value.length;
}
function Utility_append(value, array) {
  return array.push(value), value;
}
function Utility_combine(array, callback) {
  return array.map(callback).join("");
}

;// CONCATENATED MODULE: ../node_modules/stylis/src/Tokenizer.js

var line = 1;
var column = 1;
var Tokenizer_length = 0;
var position = 0;
var character = 0;
var characters = "";
function node(value, root, parent, type, props, children, length2) {
  return {value, root, parent, type, props, children, line, column, length: length2, return: ""};
}
function copy(value, root, type) {
  return node(value, root.root, root.parent, type, root.props, root.children, 0);
}
function Tokenizer_char() {
  return character;
}
function prev() {
  character = position > 0 ? Utility_charat(characters, --position) : 0;
  if (column--, character === 10)
    column = 1, line--;
  return character;
}
function next() {
  character = position < Tokenizer_length ? Utility_charat(characters, position++) : 0;
  if (column++, character === 10)
    column = 1, line++;
  return character;
}
function peek() {
  return Utility_charat(characters, position);
}
function caret() {
  return position;
}
function slice(begin, end) {
  return Utility_substr(characters, begin, end);
}
function token(type) {
  switch (type) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function alloc(value) {
  return line = column = 1, Tokenizer_length = Utility_strlen(characters = value), position = 0, [];
}
function dealloc(value) {
  return characters = "", value;
}
function delimit(type) {
  return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
function Tokenizer_tokenize(value) {
  return dealloc(tokenizer(alloc(value)));
}
function whitespace(type) {
  while (character = peek())
    if (character < 33)
      next();
    else
      break;
  return token(type) > 2 || token(character) > 3 ? "" : " ";
}
function tokenizer(children) {
  while (next())
    switch (token(character)) {
      case 0:
        append(identifier(position - 1), children);
        break;
      case 2:
        append(delimit(character), children);
        break;
      default:
        append(from(character), children);
    }
  return children;
}
function delimiter(type) {
  while (next())
    switch (character) {
      case type:
        return position;
      case 34:
      case 39:
        return delimiter(type === 34 || type === 39 ? type : character);
      case 40:
        if (type === 41)
          delimiter(type);
        break;
      case 92:
        next();
        break;
    }
  return position;
}
function commenter(type, index) {
  while (next())
    if (type + character === 47 + 10)
      break;
    else if (type + character === 42 + 42 && peek() === 47)
      break;
  return "/*" + slice(index, position - 1) + "*" + Utility_from(type === 47 ? type : next());
}
function identifier(index) {
  while (!token(peek()))
    next();
  return slice(index, position);
}

;// CONCATENATED MODULE: ../node_modules/stylis/src/Enum.js
var MS = "-ms-";
var MOZ = "-moz-";
var WEBKIT = "-webkit-";
var COMMENT = "comm";
var Enum_RULESET = "rule";
var DECLARATION = "decl";
var PAGE = "@page";
var MEDIA = "@media";
var IMPORT = "@import";
var CHARSET = "@charset";
var VIEWPORT = "@viewport";
var SUPPORTS = "@supports";
var DOCUMENT = "@document";
var NAMESPACE = "@namespace";
var KEYFRAMES = "@keyframes";
var FONT_FACE = "@font-face";
var COUNTER_STYLE = "@counter-style";
var FONT_FEATURE_VALUES = "@font-feature-values";

;// CONCATENATED MODULE: ../node_modules/stylis/src/Serializer.js


function serialize(children, callback) {
  var output = "";
  var length = Utility_sizeof(children);
  for (var i = 0; i < length; i++)
    output += callback(children[i], i, children, callback) || "";
  return output;
}
function stringify(element, index, children, callback) {
  switch (element.type) {
    case IMPORT:
    case DECLARATION:
      return element.return = element.return || element.value;
    case COMMENT:
      return "";
    case Enum_RULESET:
      element.value = element.props.join(",");
  }
  return Utility_strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
}

;// CONCATENATED MODULE: ../node_modules/stylis/src/Prefixer.js


function prefix(value, length) {
  switch (hash(value, length)) {
    case 5103:
      return WEBKIT + "print-" + value + value;
    case 5737:
    case 4201:
    case 3177:
    case 3433:
    case 1641:
    case 4457:
    case 2921:
    case 5572:
    case 6356:
    case 5844:
    case 3191:
    case 6645:
    case 3005:
    case 6391:
    case 5879:
    case 5623:
    case 6135:
    case 4599:
    case 4855:
    case 4215:
    case 6389:
    case 5109:
    case 5365:
    case 5621:
    case 3829:
      return WEBKIT + value + value;
    case 5349:
    case 4246:
    case 4810:
    case 6968:
    case 2756:
      return WEBKIT + value + MOZ + value + MS + value + value;
    case 6828:
    case 4268:
      return WEBKIT + value + MS + value + value;
    case 6165:
      return WEBKIT + value + MS + "flex-" + value + value;
    case 5187:
      return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + "box-$1$2" + MS + "flex-$1$2") + value;
    case 5443:
      return WEBKIT + value + MS + "flex-item-" + replace(value, /flex-|-self/, "") + value;
    case 4675:
      return WEBKIT + value + MS + "flex-line-pack" + replace(value, /align-content|flex-|-self/, "") + value;
    case 5548:
      return WEBKIT + value + MS + replace(value, "shrink", "negative") + value;
    case 5292:
      return WEBKIT + value + MS + replace(value, "basis", "preferred-size") + value;
    case 6060:
      return WEBKIT + "box-" + replace(value, "-grow", "") + WEBKIT + value + MS + replace(value, "grow", "positive") + value;
    case 4554:
      return WEBKIT + replace(value, /([^-])(transform)/g, "$1" + WEBKIT + "$2") + value;
    case 6187:
      return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + "$1"), /(image-set)/, WEBKIT + "$1"), value, "") + value;
    case 5495:
    case 3959:
      return replace(value, /(image-set\([^]*)/, WEBKIT + "$1$`$1");
    case 4968:
      return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + "box-pack:$3" + MS + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + WEBKIT + value + value;
    case 4095:
    case 3583:
    case 4068:
    case 2532:
      return replace(value, /(.+)-inline(.+)/, WEBKIT + "$1$2") + value;
    case 8116:
    case 7059:
    case 5753:
    case 5535:
    case 5445:
    case 5701:
    case 4933:
    case 4677:
    case 5533:
    case 5789:
    case 5021:
    case 4765:
      if (Utility_strlen(value) - 1 - length > 6)
        switch (Utility_charat(value, length + 1)) {
          case 109:
            if (Utility_charat(value, length + 4) !== 45)
              break;
          case 102:
            return replace(value, /(.+:)(.+)-([^]+)/, "$1" + WEBKIT + "$2-$3$1" + MOZ + (Utility_charat(value, length + 3) == 108 ? "$3" : "$2-$3")) + value;
          case 115:
            return ~indexof(value, "stretch") ? prefix(replace(value, "stretch", "fill-available"), length) + value : value;
        }
      break;
    case 4949:
      if (Utility_charat(value, length + 1) !== 115)
        break;
    case 6444:
      switch (Utility_charat(value, Utility_strlen(value) - 3 - (~indexof(value, "!important") && 10))) {
        case 107:
          return replace(value, ":", ":" + WEBKIT) + value;
        case 101:
          return replace(value, /(.+:)([^;!]+)(;|!.+)?/, "$1" + WEBKIT + (Utility_charat(value, 14) === 45 ? "inline-" : "") + "box$3$1" + WEBKIT + "$2$3$1" + MS + "$2box$3") + value;
      }
      break;
    case 5936:
      switch (Utility_charat(value, length + 11)) {
        case 114:
          return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb") + value;
        case 108:
          return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb-rl") + value;
        case 45:
          return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "lr") + value;
      }
      return WEBKIT + value + MS + value + value;
  }
  return value;
}

;// CONCATENATED MODULE: ../node_modules/stylis/src/Middleware.js





function middleware(collection) {
  var length = Utility_sizeof(collection);
  return function(element, index, children, callback) {
    var output = "";
    for (var i = 0; i < length; i++)
      output += collection[i](element, index, children, callback) || "";
    return output;
  };
}
function rulesheet(callback) {
  return function(element) {
    if (!element.root) {
      if (element = element.return)
        callback(element);
    }
  };
}
function prefixer(element, index, children, callback) {
  if (!element.return)
    switch (element.type) {
      case DECLARATION:
        element.return = prefix(element.value, element.length);
        break;
      case KEYFRAMES:
        return serialize([copy(replace(element.value, "@", "@" + WEBKIT), element, "")], callback);
      case Enum_RULESET:
        if (element.length)
          return Utility_combine(element.props, function(value) {
            switch (match(value, /(::plac\w+|:read-\w+)/)) {
              case ":read-only":
              case ":read-write":
                return serialize([copy(replace(value, /:(read-\w+)/, ":" + MOZ + "$1"), element, "")], callback);
              case "::placeholder":
                return serialize([
                  copy(replace(value, /:(plac\w+)/, ":" + WEBKIT + "input-$1"), element, ""),
                  copy(replace(value, /:(plac\w+)/, ":" + MOZ + "$1"), element, ""),
                  copy(replace(value, /:(plac\w+)/, MS + "input-$1"), element, "")
                ], callback);
            }
            return "";
          });
    }
}
function namespace(element) {
  switch (element.type) {
    case RULESET:
      element.props = element.props.map(function(value) {
        return combine(tokenize(value), function(value2, index, children) {
          switch (charat(value2, 0)) {
            case 12:
              return substr(value2, 1, strlen(value2));
            case 0:
            case 40:
            case 43:
            case 62:
            case 126:
              return value2;
            case 58:
              if (children[++index] === "global")
                children[index] = "", children[++index] = "\f" + substr(children[index], index = 1, -1);
            case 32:
              return index === 1 ? "" : value2;
            default:
              switch (index) {
                case 0:
                  element = value2;
                  return sizeof(children) > 1 ? "" : value2;
                case (index = sizeof(children) - 1):
                case 2:
                  return index === 2 ? value2 + element + element : value2 + element;
                default:
                  return value2;
              }
          }
        });
      });
  }
}

;// CONCATENATED MODULE: ../node_modules/stylis/src/Parser.js



function compile(value) {
  return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
}
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
  var index = 0;
  var offset = 0;
  var length = pseudo;
  var atrule = 0;
  var property = 0;
  var previous = 0;
  var variable = 1;
  var scanning = 1;
  var ampersand = 1;
  var character = 0;
  var type = "";
  var props = rules;
  var children = rulesets;
  var reference = rule;
  var characters = type;
  while (scanning)
    switch (previous = character, character = next()) {
      case 34:
      case 39:
      case 91:
      case 40:
        characters += delimit(character);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        characters += whitespace(previous);
        break;
      case 47:
        switch (peek()) {
          case 42:
          case 47:
            Utility_append(comment(commenter(next(), caret()), root, parent), declarations);
            break;
          default:
            characters += "/";
        }
        break;
      case 123 * variable:
        points[index++] = Utility_strlen(characters) * ampersand;
      case 125 * variable:
      case 59:
      case 0:
        switch (character) {
          case 0:
          case 125:
            scanning = 0;
          case 59 + offset:
            if (property > 0 && Utility_strlen(characters) - length)
              Utility_append(property > 32 ? declaration(characters + ";", rule, parent, length - 1) : declaration(replace(characters, " ", "") + ";", rule, parent, length - 2), declarations);
            break;
          case 59:
            characters += ";";
          default:
            Utility_append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length), rulesets);
            if (character === 123)
              if (offset === 0)
                parse(characters, root, reference, reference, props, rulesets, length, points, children);
              else
                switch (atrule) {
                  case 100:
                  case 109:
                  case 115:
                    parse(value, reference, reference, rule && Utility_append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length), children), rules, children, length, points, rule ? props : children);
                    break;
                  default:
                    parse(characters, reference, reference, reference, [""], children, length, points, children);
                }
        }
        index = offset = property = 0, variable = ampersand = 1, type = characters = "", length = pseudo;
        break;
      case 58:
        length = 1 + Utility_strlen(characters), property = previous;
      default:
        if (variable < 1) {
          if (character == 123) {
            --variable;
          } else if (character == 125 && variable++ == 0 && prev() == 125) {
            continue;
          }
        }
        switch (characters += Utility_from(character), character * variable) {
          case 38:
            ampersand = offset > 0 ? 1 : (characters += "\f", -1);
            break;
          case 44:
            points[index++] = (Utility_strlen(characters) - 1) * ampersand, ampersand = 1;
            break;
          case 64:
            if (peek() === 45)
              characters += delimit(next());
            atrule = peek(), offset = Utility_strlen(type = characters += identifier(caret())), character++;
            break;
          case 45:
            if (previous === 45 && Utility_strlen(characters) == 2)
              variable = 0;
        }
    }
  return rulesets;
}
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length) {
  var post = offset - 1;
  var rule = offset === 0 ? rules : [""];
  var size = Utility_sizeof(rule);
  for (var i = 0, j = 0, k = 0; i < index; ++i)
    for (var x = 0, y = Utility_substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x)
      if (z = trim(j > 0 ? rule[x] + " " + y : replace(y, /&\f/g, rule[x])))
        props[k++] = z;
  return node(value, root, parent, offset === 0 ? Enum_RULESET : type, props, children, length);
}
function comment(value, root, parent) {
  return node(value, root, parent, COMMENT, Utility_from(Tokenizer_char()), Utility_substr(value, 2, -2), 0);
}
function declaration(value, root, parent, length) {
  return node(value, root, parent, DECLARATION, Utility_substr(value, 0, length), Utility_substr(value, length + 1, -1), length);
}

;// CONCATENATED MODULE: ../node_modules/@emotion/cache/dist/emotion-cache.browser.esm.js




var last = function last2(arr) {
  return arr.length ? arr[arr.length - 1] : null;
};
var toRules = function toRules2(parsed, points) {
  var index = -1;
  var character = 44;
  do {
    switch (token(character)) {
      case 0:
        if (character === 38 && peek() === 12) {
          points[index] = 1;
        }
        parsed[index] += identifier(position - 1);
        break;
      case 2:
        parsed[index] += delimit(character);
        break;
      case 4:
        if (character === 44) {
          parsed[++index] = peek() === 58 ? "&\f" : "";
          points[index] = parsed[index].length;
          break;
        }
      default:
        parsed[index] += Utility_from(character);
    }
  } while (character = next());
  return parsed;
};
var getRules = function getRules2(value, points) {
  return dealloc(toRules(alloc(value), points));
};
var fixedElements = /* @__PURE__ */ new WeakMap();
var compat = function compat2(element) {
  if (element.type !== "rule" || !element.parent || !element.length) {
    return;
  }
  var value = element.value, parent = element.parent;
  var isImplicitRule = element.column === parent.column && element.line === parent.line;
  while (parent.type !== "rule") {
    parent = parent.parent;
    if (!parent)
      return;
  }
  if (element.props.length === 1 && value.charCodeAt(0) !== 58 && !fixedElements.get(parent)) {
    return;
  }
  if (isImplicitRule) {
    return;
  }
  fixedElements.set(element, true);
  var points = [];
  var rules = getRules(value, points);
  var parentRules = parent.props;
  for (var i = 0, k = 0; i < rules.length; i++) {
    for (var j = 0; j < parentRules.length; j++, k++) {
      element.props[k] = points[i] ? rules[i].replace(/&\f/g, parentRules[j]) : parentRules[j] + " " + rules[i];
    }
  }
};
var removeLabel = function removeLabel2(element) {
  if (element.type === "decl") {
    var value = element.value;
    if (value.charCodeAt(0) === 108 && value.charCodeAt(2) === 98) {
      element["return"] = "";
      element.value = "";
    }
  }
};
var ignoreFlag = "emotion-disable-server-rendering-unsafe-selector-warning-please-do-not-use-this-the-warning-exists-for-a-reason";
var isIgnoringComment = function isIgnoringComment2(element) {
  return !!element && element.type === "comm" && element.children.indexOf(ignoreFlag) > -1;
};
var createUnsafeSelectorsAlarm = function createUnsafeSelectorsAlarm2(cache) {
  return function(element, index, children) {
    if (element.type !== "rule")
      return;
    var unsafePseudoClasses = element.value.match(/(:first|:nth|:nth-last)-child/g);
    if (unsafePseudoClasses && cache.compat !== true) {
      var prevElement = index > 0 ? children[index - 1] : null;
      if (prevElement && isIgnoringComment(last(prevElement.children))) {
        return;
      }
      unsafePseudoClasses.forEach(function(unsafePseudoClass) {
        console.error('The pseudo class "' + unsafePseudoClass + '" is potentially unsafe when doing server-side rendering. Try changing it to "' + unsafePseudoClass.split("-child")[0] + '-of-type".');
      });
    }
  };
};
var isImportRule = function isImportRule2(element) {
  return element.type.charCodeAt(1) === 105 && element.type.charCodeAt(0) === 64;
};
var isPrependedWithRegularRules = function isPrependedWithRegularRules2(index, children) {
  for (var i = index - 1; i >= 0; i--) {
    if (!isImportRule(children[i])) {
      return true;
    }
  }
  return false;
};
var nullifyElement = function nullifyElement2(element) {
  element.type = "";
  element.value = "";
  element["return"] = "";
  element.children = "";
  element.props = "";
};
var incorrectImportAlarm = function incorrectImportAlarm2(element, index, children) {
  if (!isImportRule(element)) {
    return;
  }
  if (element.parent) {
    console.error("`@import` rules can't be nested inside other rules. Please move it to the top level and put it before regular rules. Keep in mind that they can only be used within global styles.");
    nullifyElement(element);
  } else if (isPrependedWithRegularRules(index, children)) {
    console.error("`@import` rules can't be after other rules. Please put your `@import` rules before your other rules.");
    nullifyElement(element);
  }
};
var defaultStylisPlugins = [prefixer];
var createCache = function createCache2(options) {
  var key = options.key;
  if (false) {}
  if (key === "css") {
    var ssrStyles = document.querySelectorAll("style[data-emotion]:not([data-s])");
    Array.prototype.forEach.call(ssrStyles, function(node) {
      document.head.appendChild(node);
      node.setAttribute("data-s", "");
    });
  }
  var stylisPlugins = options.stylisPlugins || defaultStylisPlugins;
  if (false) {}
  var inserted = {};
  var container;
  var nodesToHydrate = [];
  {
    container = options.container || document.head;
    Array.prototype.forEach.call(document.querySelectorAll("style[data-emotion]"), function(node) {
      var attrib = node.getAttribute("data-emotion").split(" ");
      if (attrib[0] !== key) {
        return;
      }
      for (var i = 1; i < attrib.length; i++) {
        inserted[attrib[i]] = true;
      }
      nodesToHydrate.push(node);
    });
  }
  var _insert;
  var omnipresentPlugins = [compat, removeLabel];
  if (false) {}
  {
    var currentSheet;
    var finalizingPlugins = [stringify,  false ? 0 : rulesheet(function(rule) {
      currentSheet.insert(rule);
    })];
    var serializer = middleware(omnipresentPlugins.concat(stylisPlugins, finalizingPlugins));
    var stylis = function stylis2(styles) {
      return serialize(compile(styles), serializer);
    };
    _insert = function insert(selector, serialized, sheet, shouldCache) {
      currentSheet = sheet;
      if (false) {}
      stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);
      if (shouldCache) {
        cache.inserted[serialized.name] = true;
      }
    };
  }
  var cache = {
    key,
    sheet: new emotion_sheet_browser_esm/* StyleSheet */.m({
      key,
      container,
      nonce: options.nonce,
      speedy: options.speedy,
      prepend: options.prepend
    }),
    nonce: options.nonce,
    inserted,
    registered: {},
    insert: _insert
  };
  cache.sheet.hydrate(nodesToHydrate);
  return cache;
};
/* harmony default export */ const emotion_cache_browser_esm = (createCache);


/***/ }),

/***/ 2892:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function memoize(fn) {
  var cache = Object.create(null);
  return function(arg) {
    if (cache[arg] === void 0)
      cache[arg] = fn(arg);
    return cache[arg];
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (memoize);


/***/ }),

/***/ 279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ ThemeContext),
/* harmony export */   "w": () => (/* binding */ withEmotionCache)
/* harmony export */ });
/* unused harmony exports C, E, a, b, c, h, u */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7985);
/* harmony import */ var _emotion_serialize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(623);







var hasOwnProperty = Object.prototype.hasOwnProperty;
var EmotionCacheContext = /* @__PURE__ */ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(typeof HTMLElement !== "undefined" ? /* @__PURE__ */ (0,_emotion_cache__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)({
  key: "css"
}) : null);
var CacheProvider = EmotionCacheContext.Provider;
var withEmotionCache = function withEmotionCache2(func) {
  return /* @__PURE__ */ (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function(props, ref) {
    var cache = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(EmotionCacheContext);
    return func(props, cache, ref);
  });
};
var ThemeContext = /* @__PURE__ */ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
var useTheme = function useTheme2() {
  return useContext(ThemeContext);
};
var getTheme = function getTheme2(outerTheme, theme) {
  if (typeof theme === "function") {
    var mergedTheme = theme(outerTheme);
    if (false) {}
    return mergedTheme;
  }
  if (false) {}
  return _extends({}, outerTheme, {}, theme);
};
var createCacheWithTheme = /* @__PURE__ */ (/* unused pure expression or super */ null && (weakMemoize(function(outerTheme) {
  return weakMemoize(function(theme) {
    return getTheme(outerTheme, theme);
  });
})));
var ThemeProvider = function ThemeProvider2(props) {
  var theme = useContext(ThemeContext);
  if (props.theme !== theme) {
    theme = createCacheWithTheme(theme)(props.theme);
  }
  return /* @__PURE__ */ createElement(ThemeContext.Provider, {
    value: theme
  }, props.children);
};
function withTheme(Component) {
  var componentName = Component.displayName || Component.name || "Component";
  var render = function render2(props, ref) {
    var theme = useContext(ThemeContext);
    return /* @__PURE__ */ createElement(Component, _extends({
      theme,
      ref
    }, props));
  };
  var WithTheme = /* @__PURE__ */ forwardRef(render);
  WithTheme.displayName = "WithTheme(" + componentName + ")";
  return hoistNonReactStatics(WithTheme, Component);
}
var sanitizeIdentifier = function sanitizeIdentifier2(identifier) {
  return identifier.replace(/\$/g, "-");
};
var typePropName = "__EMOTION_TYPE_PLEASE_DO_NOT_USE__";
var labelPropName = "__EMOTION_LABEL_PLEASE_DO_NOT_USE__";
var createEmotionProps = function createEmotionProps2(type, props) {
  if (false) {}
  var newProps = {};
  for (var key in props) {
    if (hasOwnProperty.call(props, key)) {
      newProps[key] = props[key];
    }
  }
  newProps[typePropName] = type;
  if (false) { var match, error; }
  return newProps;
};
var Emotion = /* @__PURE__ */ (/* unused pure expression or super */ null && (withEmotionCache(function(props, cache, ref) {
  var cssProp = props.css;
  if (typeof cssProp === "string" && cache.registered[cssProp] !== void 0) {
    cssProp = cache.registered[cssProp];
  }
  var type = props[typePropName];
  var registeredStyles = [cssProp];
  var className = "";
  if (typeof props.className === "string") {
    className = getRegisteredStyles(cache.registered, registeredStyles, props.className);
  } else if (props.className != null) {
    className = props.className + " ";
  }
  var serialized = serializeStyles(registeredStyles, void 0, typeof cssProp === "function" || Array.isArray(cssProp) ? useContext(ThemeContext) : void 0);
  if (false) { var labelFromStack; }
  var rules = insertStyles(cache, serialized, typeof type === "string");
  className += cache.key + "-" + serialized.name;
  var newProps = {};
  for (var key in props) {
    if (hasOwnProperty.call(props, key) && key !== "css" && key !== typePropName && ( true || 0)) {
      newProps[key] = props[key];
    }
  }
  newProps.ref = ref;
  newProps.className = className;
  var ele = /* @__PURE__ */ createElement(type, newProps);
  return ele;
})));
if (false) {}



/***/ }),

/***/ 623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "O": () => (/* binding */ serializeStyles)
});

;// CONCATENATED MODULE: ../node_modules/@emotion/hash/dist/hash.browser.esm.js
function murmur2(str) {
  var h = 0;
  var k, i = 0, len = str.length;
  for (; len >= 4; ++i, len -= 4) {
    k = str.charCodeAt(i) & 255 | (str.charCodeAt(++i) & 255) << 8 | (str.charCodeAt(++i) & 255) << 16 | (str.charCodeAt(++i) & 255) << 24;
    k = (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16);
    k ^= k >>> 24;
    h = (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16) ^ (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  }
  switch (len) {
    case 3:
      h ^= (str.charCodeAt(i + 2) & 255) << 16;
    case 2:
      h ^= (str.charCodeAt(i + 1) & 255) << 8;
    case 1:
      h ^= str.charCodeAt(i) & 255;
      h = (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  }
  h ^= h >>> 13;
  h = (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
  return ((h ^ h >>> 15) >>> 0).toString(36);
}
/* harmony default export */ const hash_browser_esm = (murmur2);

;// CONCATENATED MODULE: ../node_modules/@emotion/unitless/dist/unitless.browser.esm.js
var unitlessKeys = {
  animationIterationCount: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};
/* harmony default export */ const unitless_browser_esm = (unitlessKeys);

// EXTERNAL MODULE: ../node_modules/@emotion/memoize/dist/emotion-memoize.browser.esm.js
var emotion_memoize_browser_esm = __webpack_require__(2892);
;// CONCATENATED MODULE: ../node_modules/@emotion/serialize/dist/emotion-serialize.browser.esm.js



var ILLEGAL_ESCAPE_SEQUENCE_ERROR = (/* unused pure expression or super */ null && (`You have illegal escape sequence in your template literal, most likely inside content's property value.
Because you write your CSS inside a JavaScript string you actually have to do double escaping, so for example "content: '\\00d7';" should become "content: '\\\\00d7';".
You can read more about this here:
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#ES2018_revision_of_illegal_escape_sequences`));
var UNDEFINED_AS_OBJECT_KEY_ERROR = "You have passed in falsy value as style object's key (can happen when in example you pass unexported component as computed key).";
var hyphenateRegex = /[A-Z]|^ms/g;
var animationRegex = /_EMO_([^_]+?)_([^]*?)_EMO_/g;
var isCustomProperty = function isCustomProperty2(property) {
  return property.charCodeAt(1) === 45;
};
var isProcessableValue = function isProcessableValue2(value) {
  return value != null && typeof value !== "boolean";
};
var processStyleName = /* @__PURE__ */ (0,emotion_memoize_browser_esm/* default */.Z)(function(styleName) {
  return isCustomProperty(styleName) ? styleName : styleName.replace(hyphenateRegex, "-$&").toLowerCase();
});
var processStyleValue = function processStyleValue2(key, value) {
  switch (key) {
    case "animation":
    case "animationName": {
      if (typeof value === "string") {
        return value.replace(animationRegex, function(match, p1, p2) {
          cursor = {
            name: p1,
            styles: p2,
            next: cursor
          };
          return p1;
        });
      }
    }
  }
  if (unitless_browser_esm[key] !== 1 && !isCustomProperty(key) && typeof value === "number" && value !== 0) {
    return value + "px";
  }
  return value;
};
if (false) { var hyphenatedCache, hyphenPattern, msPattern, oldProcessStyleValue, contentValues, contentValuePattern; }
function handleInterpolation(mergedProps, registered, interpolation) {
  if (interpolation == null) {
    return "";
  }
  if (interpolation.__emotion_styles !== void 0) {
    if (false) {}
    return interpolation;
  }
  switch (typeof interpolation) {
    case "boolean": {
      return "";
    }
    case "object": {
      if (interpolation.anim === 1) {
        cursor = {
          name: interpolation.name,
          styles: interpolation.styles,
          next: cursor
        };
        return interpolation.name;
      }
      if (interpolation.styles !== void 0) {
        var next = interpolation.next;
        if (next !== void 0) {
          while (next !== void 0) {
            cursor = {
              name: next.name,
              styles: next.styles,
              next: cursor
            };
            next = next.next;
          }
        }
        var styles = interpolation.styles + ";";
        if (false) {}
        return styles;
      }
      return createStringFromObject(mergedProps, registered, interpolation);
    }
    case "function": {
      if (mergedProps !== void 0) {
        var previousCursor = cursor;
        var result = interpolation(mergedProps);
        cursor = previousCursor;
        return handleInterpolation(mergedProps, registered, result);
      } else if (false) {}
      break;
    }
    case "string":
      if (false) { var replaced, matched; }
      break;
  }
  if (registered == null) {
    return interpolation;
  }
  var cached = registered[interpolation];
  return cached !== void 0 ? cached : interpolation;
}
function createStringFromObject(mergedProps, registered, obj) {
  var string = "";
  if (Array.isArray(obj)) {
    for (var i = 0; i < obj.length; i++) {
      string += handleInterpolation(mergedProps, registered, obj[i]) + ";";
    }
  } else {
    for (var _key in obj) {
      var value = obj[_key];
      if (typeof value !== "object") {
        if (registered != null && registered[value] !== void 0) {
          string += _key + "{" + registered[value] + "}";
        } else if (isProcessableValue(value)) {
          string += processStyleName(_key) + ":" + processStyleValue(_key, value) + ";";
        }
      } else {
        if (_key === "NO_COMPONENT_SELECTOR" && "production" !== "production") {
          throw new Error("Component selectors can only be used in conjunction with @emotion/babel-plugin.");
        }
        if (Array.isArray(value) && typeof value[0] === "string" && (registered == null || registered[value[0]] === void 0)) {
          for (var _i = 0; _i < value.length; _i++) {
            if (isProcessableValue(value[_i])) {
              string += processStyleName(_key) + ":" + processStyleValue(_key, value[_i]) + ";";
            }
          }
        } else {
          var interpolated = handleInterpolation(mergedProps, registered, value);
          switch (_key) {
            case "animation":
            case "animationName": {
              string += processStyleName(_key) + ":" + interpolated + ";";
              break;
            }
            default: {
              if (false) {}
              string += _key + "{" + interpolated + "}";
            }
          }
        }
      }
    }
  }
  return string;
}
var labelPattern = /label:\s*([^\s;\n{]+)\s*;/g;
var sourceMapPattern;
if (false) {}
var cursor;
var serializeStyles = function serializeStyles2(args, registered, mergedProps) {
  if (args.length === 1 && typeof args[0] === "object" && args[0] !== null && args[0].styles !== void 0) {
    return args[0];
  }
  var stringMode = true;
  var styles = "";
  cursor = void 0;
  var strings = args[0];
  if (strings == null || strings.raw === void 0) {
    stringMode = false;
    styles += handleInterpolation(mergedProps, registered, strings);
  } else {
    if (false) {}
    styles += strings[0];
  }
  for (var i = 1; i < args.length; i++) {
    styles += handleInterpolation(mergedProps, registered, args[i]);
    if (stringMode) {
      if (false) {}
      styles += strings[i];
    }
  }
  var sourceMap;
  if (false) {}
  labelPattern.lastIndex = 0;
  var identifierName = "";
  var match;
  while ((match = labelPattern.exec(styles)) !== null) {
    identifierName += "-" + match[1];
  }
  var name = hash_browser_esm(styles) + identifierName;
  if (false) {}
  return {
    name,
    styles,
    next: cursor
  };
};



/***/ }),

/***/ 7594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ StyleSheet)
/* harmony export */ });
function sheetForTag(tag) {
  if (tag.sheet) {
    return tag.sheet;
  }
  for (var i = 0; i < document.styleSheets.length; i++) {
    if (document.styleSheets[i].ownerNode === tag) {
      return document.styleSheets[i];
    }
  }
}
function createStyleElement(options) {
  var tag = document.createElement("style");
  tag.setAttribute("data-emotion", options.key);
  if (options.nonce !== void 0) {
    tag.setAttribute("nonce", options.nonce);
  }
  tag.appendChild(document.createTextNode(""));
  tag.setAttribute("data-s", "");
  return tag;
}
var StyleSheet = /* @__PURE__ */ function() {
  function StyleSheet2(options) {
    var _this = this;
    this._insertTag = function(tag) {
      var before;
      if (_this.tags.length === 0) {
        before = _this.prepend ? _this.container.firstChild : _this.before;
      } else {
        before = _this.tags[_this.tags.length - 1].nextSibling;
      }
      _this.container.insertBefore(tag, before);
      _this.tags.push(tag);
    };
    this.isSpeedy = options.speedy === void 0 ? "production" === "production" : options.speedy;
    this.tags = [];
    this.ctr = 0;
    this.nonce = options.nonce;
    this.key = options.key;
    this.container = options.container;
    this.prepend = options.prepend;
    this.before = null;
  }
  var _proto = StyleSheet2.prototype;
  _proto.hydrate = function hydrate(nodes) {
    nodes.forEach(this._insertTag);
  };
  _proto.insert = function insert(rule) {
    if (this.ctr % (this.isSpeedy ? 65e3 : 1) === 0) {
      this._insertTag(createStyleElement(this));
    }
    var tag = this.tags[this.tags.length - 1];
    if (false) { var isImportRule; }
    if (this.isSpeedy) {
      var sheet = sheetForTag(tag);
      try {
        sheet.insertRule(rule, sheet.cssRules.length);
      } catch (e) {
        if (false) {}
      }
    } else {
      tag.appendChild(document.createTextNode(rule));
    }
    this.ctr++;
  };
  _proto.flush = function flush() {
    this.tags.forEach(function(tag) {
      return tag.parentNode.removeChild(tag);
    });
    this.tags = [];
    this.ctr = 0;
    if (false) {}
  };
  return StyleSheet2;
}();



/***/ }),

/***/ 5462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ emotion_styled_browser_esm)
});

// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/@emotion/memoize/dist/emotion-memoize.browser.esm.js
var emotion_memoize_browser_esm = __webpack_require__(2892);
;// CONCATENATED MODULE: ../node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.browser.esm.js

var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;
var isPropValid = /* @__PURE__ */ (0,emotion_memoize_browser_esm/* default */.Z)(function(prop) {
  return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110 && prop.charCodeAt(2) < 91;
});
/* harmony default export */ const emotion_is_prop_valid_browser_esm = (isPropValid);

// EXTERNAL MODULE: ../node_modules/@emotion/react/dist/emotion-element-4fbd89c5.browser.esm.js
var emotion_element_4fbd89c5_browser_esm = __webpack_require__(279);
// EXTERNAL MODULE: ../node_modules/@emotion/utils/dist/emotion-utils.browser.esm.js
var emotion_utils_browser_esm = __webpack_require__(4070);
// EXTERNAL MODULE: ../node_modules/@emotion/serialize/dist/emotion-serialize.browser.esm.js + 2 modules
var emotion_serialize_browser_esm = __webpack_require__(623);
;// CONCATENATED MODULE: ../node_modules/@emotion/styled/base/dist/emotion-styled-base.browser.esm.js






var testOmitPropsOnStringTag = emotion_is_prop_valid_browser_esm;
var testOmitPropsOnComponent = function testOmitPropsOnComponent2(key) {
  return key !== "theme";
};
var getDefaultShouldForwardProp = function getDefaultShouldForwardProp2(tag) {
  return typeof tag === "string" && tag.charCodeAt(0) > 96 ? testOmitPropsOnStringTag : testOmitPropsOnComponent;
};
var composeShouldForwardProps = function composeShouldForwardProps2(tag, options, isReal) {
  var shouldForwardProp;
  if (options) {
    var optionsShouldForwardProp = options.shouldForwardProp;
    shouldForwardProp = tag.__emotion_forwardProp && optionsShouldForwardProp ? function(propName) {
      return tag.__emotion_forwardProp(propName) && optionsShouldForwardProp(propName);
    } : optionsShouldForwardProp;
  }
  if (typeof shouldForwardProp !== "function" && isReal) {
    shouldForwardProp = tag.__emotion_forwardProp;
  }
  return shouldForwardProp;
};
var ILLEGAL_ESCAPE_SEQUENCE_ERROR = (/* unused pure expression or super */ null && (`You have illegal escape sequence in your template literal, most likely inside content's property value.
Because you write your CSS inside a JavaScript string you actually have to do double escaping, so for example "content: '\\00d7';" should become "content: '\\\\00d7';".
You can read more about this here:
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#ES2018_revision_of_illegal_escape_sequences`));
var createStyled = function createStyled2(tag, options) {
  if (false) {}
  var isReal = tag.__emotion_real === tag;
  var baseTag = isReal && tag.__emotion_base || tag;
  var identifierName;
  var targetClassName;
  if (options !== void 0) {
    identifierName = options.label;
    targetClassName = options.target;
  }
  var shouldForwardProp = composeShouldForwardProps(tag, options, isReal);
  var defaultShouldForwardProp = shouldForwardProp || getDefaultShouldForwardProp(baseTag);
  var shouldUseAs = !defaultShouldForwardProp("as");
  return function() {
    var args = arguments;
    var styles = isReal && tag.__emotion_styles !== void 0 ? tag.__emotion_styles.slice(0) : [];
    if (identifierName !== void 0) {
      styles.push("label:" + identifierName + ";");
    }
    if (args[0] == null || args[0].raw === void 0) {
      styles.push.apply(styles, args);
    } else {
      if (false) {}
      styles.push(args[0][0]);
      var len = args.length;
      var i = 1;
      for (; i < len; i++) {
        if (false) {}
        styles.push(args[i], args[0][i]);
      }
    }
    var Styled = (0,emotion_element_4fbd89c5_browser_esm.w)(function(props, cache, ref) {
      var finalTag = shouldUseAs && props.as || baseTag;
      var className = "";
      var classInterpolations = [];
      var mergedProps = props;
      if (props.theme == null) {
        mergedProps = {};
        for (var key in props) {
          mergedProps[key] = props[key];
        }
        mergedProps.theme = (0,react.useContext)(emotion_element_4fbd89c5_browser_esm.T);
      }
      if (typeof props.className === "string") {
        className = (0,emotion_utils_browser_esm/* getRegisteredStyles */.f)(cache.registered, classInterpolations, props.className);
      } else if (props.className != null) {
        className = props.className + " ";
      }
      var serialized = (0,emotion_serialize_browser_esm/* serializeStyles */.O)(styles.concat(classInterpolations), cache.registered, mergedProps);
      var rules = (0,emotion_utils_browser_esm/* insertStyles */.M)(cache, serialized, typeof finalTag === "string");
      className += cache.key + "-" + serialized.name;
      if (targetClassName !== void 0) {
        className += " " + targetClassName;
      }
      var finalShouldForwardProp = shouldUseAs && shouldForwardProp === void 0 ? getDefaultShouldForwardProp(finalTag) : defaultShouldForwardProp;
      var newProps = {};
      for (var _key in props) {
        if (shouldUseAs && _key === "as")
          continue;
        if (finalShouldForwardProp(_key)) {
          newProps[_key] = props[_key];
        }
      }
      newProps.className = className;
      newProps.ref = ref;
      var ele = /* @__PURE__ */ (0,react.createElement)(finalTag, newProps);
      return ele;
    });
    Styled.displayName = identifierName !== void 0 ? identifierName : "Styled(" + (typeof baseTag === "string" ? baseTag : baseTag.displayName || baseTag.name || "Component") + ")";
    Styled.defaultProps = tag.defaultProps;
    Styled.__emotion_real = Styled;
    Styled.__emotion_base = baseTag;
    Styled.__emotion_styles = styles;
    Styled.__emotion_forwardProp = shouldForwardProp;
    Object.defineProperty(Styled, "toString", {
      value: function value() {
        if (targetClassName === void 0 && "production" !== "production") {
          return "NO_COMPONENT_SELECTOR";
        }
        return "." + targetClassName;
      }
    });
    Styled.withComponent = function(nextTag, nextOptions) {
      return createStyled2(nextTag, (0,esm_extends/* default */.Z)({}, options, {}, nextOptions, {
        shouldForwardProp: composeShouldForwardProps(Styled, nextOptions, true)
      })).apply(void 0, styles);
    };
    return Styled;
  };
};
/* harmony default export */ const emotion_styled_base_browser_esm = (createStyled);

;// CONCATENATED MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js







var tags = [
  "a",
  "abbr",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "menuitem",
  "meta",
  "meter",
  "nav",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "u",
  "ul",
  "var",
  "video",
  "wbr",
  "circle",
  "clipPath",
  "defs",
  "ellipse",
  "foreignObject",
  "g",
  "image",
  "line",
  "linearGradient",
  "mask",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialGradient",
  "rect",
  "stop",
  "svg",
  "text",
  "tspan"
];
var newStyled = emotion_styled_base_browser_esm.bind();
tags.forEach(function(tagName) {
  newStyled[tagName] = newStyled(tagName);
});
/* harmony default export */ const emotion_styled_browser_esm = (newStyled);


/***/ }),

/***/ 4070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ getRegisteredStyles),
/* harmony export */   "M": () => (/* binding */ insertStyles)
/* harmony export */ });
var isBrowser = true;
function getRegisteredStyles(registered, registeredStyles, classNames) {
  var rawClassName = "";
  classNames.split(" ").forEach(function(className) {
    if (registered[className] !== void 0) {
      registeredStyles.push(registered[className] + ";");
    } else {
      rawClassName += className + " ";
    }
  });
  return rawClassName;
}
var insertStyles = function insertStyles2(cache, serialized, isStringTag) {
  var className = cache.key + "-" + serialized.name;
  if ((isStringTag === false || isBrowser === false) && cache.registered[className] === void 0) {
    cache.registered[className] = serialized.styles;
  }
  if (cache.inserted[serialized.name] === void 0) {
    var current = serialized;
    do {
      var maybeStyles = cache.insert(serialized === current ? "." + className : "", current, cache.sheet, true);
      current = current.next;
    } while (current !== void 0);
  }
};



/***/ }),

/***/ 855:
/***/ ((module, exports) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
(function() {
  "use strict";
  var hasOwn = {}.hasOwnProperty;
  function classNames() {
    var classes = [];
    for (var i = 0; i < arguments.length; i++) {
      var arg = arguments[i];
      if (!arg)
        continue;
      var argType = typeof arg;
      if (argType === "string" || argType === "number") {
        classes.push(arg);
      } else if (Array.isArray(arg)) {
        if (arg.length) {
          var inner = classNames.apply(null, arg);
          if (inner) {
            classes.push(inner);
          }
        }
      } else if (argType === "object") {
        if (arg.toString === Object.prototype.toString) {
          for (var key in arg) {
            if (hasOwn.call(arg, key) && arg[key]) {
              classes.push(key);
            }
          }
        } else {
          classes.push(arg.toString());
        }
      }
    }
    return classes.join(" ");
  }
  if ( true && module.exports) {
    classNames.default = classNames;
    module.exports = classNames;
  } else if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function() {
      return classNames;
    }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else {}
})();


/***/ }),

/***/ 1758:
/***/ ((module) => {

module.exports = function(it) {
  if (typeof it != "function") {
    throw TypeError(String(it) + " is not a function");
  }
  return it;
};


/***/ }),

/***/ 9497:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
module.exports = function(it) {
  if (!isObject(it) && it !== null) {
    throw TypeError("Can't set " + String(it) + " as a prototype");
  }
  return it;
};


/***/ }),

/***/ 4164:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(4354);
var create = __webpack_require__(6474);
var definePropertyModule = __webpack_require__(2826);
var UNSCOPABLES = wellKnownSymbol("unscopables");
var ArrayPrototype = Array.prototype;
if (ArrayPrototype[UNSCOPABLES] == void 0) {
  definePropertyModule.f(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: create(null)
  });
}
module.exports = function(key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};


/***/ }),

/***/ 9679:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var charAt = __webpack_require__(9209).charAt;
module.exports = function(S, index, unicode) {
  return index + (unicode ? charAt(S, index).length : 1);
};


/***/ }),

/***/ 7089:
/***/ ((module) => {

module.exports = function(it, Constructor, name) {
  if (!(it instanceof Constructor)) {
    throw TypeError("Incorrect " + (name ? name + " " : "") + "invocation");
  }
  return it;
};


/***/ }),

/***/ 5675:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
module.exports = function(it) {
  if (!isObject(it)) {
    throw TypeError(String(it) + " is not an object");
  }
  return it;
};


/***/ }),

/***/ 4947:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $forEach = __webpack_require__(8184).forEach;
var arrayMethodIsStrict = __webpack_require__(2759);
var STRICT_METHOD = arrayMethodIsStrict("forEach");
module.exports = !STRICT_METHOD ? function forEach(callbackfn) {
  return $forEach(this, callbackfn, arguments.length > 1 ? arguments[1] : void 0);
} : [].forEach;


/***/ }),

/***/ 992:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var bind = __webpack_require__(3754);
var toObject = __webpack_require__(1734);
var callWithSafeIterationClosing = __webpack_require__(1140);
var isArrayIteratorMethod = __webpack_require__(9140);
var toLength = __webpack_require__(9944);
var createProperty = __webpack_require__(9246);
var getIteratorMethod = __webpack_require__(3513);
module.exports = function from(arrayLike) {
  var O = toObject(arrayLike);
  var C = typeof this == "function" ? this : Array;
  var argumentsLength = arguments.length;
  var mapfn = argumentsLength > 1 ? arguments[1] : void 0;
  var mapping = mapfn !== void 0;
  var iteratorMethod = getIteratorMethod(O);
  var index = 0;
  var length, result, step, iterator, next, value;
  if (mapping)
    mapfn = bind(mapfn, argumentsLength > 2 ? arguments[2] : void 0, 2);
  if (iteratorMethod != void 0 && !(C == Array && isArrayIteratorMethod(iteratorMethod))) {
    iterator = iteratorMethod.call(O);
    next = iterator.next;
    result = new C();
    for (; !(step = next.call(iterator)).done; index++) {
      value = mapping ? callWithSafeIterationClosing(iterator, mapfn, [step.value, index], true) : step.value;
      createProperty(result, index, value);
    }
  } else {
    length = toLength(O.length);
    result = new C(length);
    for (; length > index; index++) {
      value = mapping ? mapfn(O[index], index) : O[index];
      createProperty(result, index, value);
    }
  }
  result.length = index;
  return result;
};


/***/ }),

/***/ 8170:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIndexedObject = __webpack_require__(4362);
var toLength = __webpack_require__(9944);
var toAbsoluteIndex = __webpack_require__(4052);
var createMethod = function(IS_INCLUDES) {
  return function($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    if (IS_INCLUDES && el != el)
      while (length > index) {
        value = O[index++];
        if (value != value)
          return true;
      }
    else
      for (; length > index; index++) {
        if ((IS_INCLUDES || index in O) && O[index] === el)
          return IS_INCLUDES || index || 0;
      }
    return !IS_INCLUDES && -1;
  };
};
module.exports = {
  includes: createMethod(true),
  indexOf: createMethod(false)
};


/***/ }),

/***/ 8184:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3754);
var IndexedObject = __webpack_require__(5940);
var toObject = __webpack_require__(1734);
var toLength = __webpack_require__(9944);
var arraySpeciesCreate = __webpack_require__(6523);
var push = [].push;
var createMethod = function(TYPE) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var IS_FILTER_OUT = TYPE == 7;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  return function($this, callbackfn, that, specificCreate) {
    var O = toObject($this);
    var self = IndexedObject(O);
    var boundFunction = bind(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var create = specificCreate || arraySpeciesCreate;
    var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_OUT ? create($this, 0) : void 0;
    var value, result;
    for (; length > index; index++)
      if (NO_HOLES || index in self) {
        value = self[index];
        result = boundFunction(value, index, O);
        if (TYPE) {
          if (IS_MAP)
            target[index] = result;
          else if (result)
            switch (TYPE) {
              case 3:
                return true;
              case 5:
                return value;
              case 6:
                return index;
              case 2:
                push.call(target, value);
            }
          else
            switch (TYPE) {
              case 4:
                return false;
              case 7:
                push.call(target, value);
            }
        }
      }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
  };
};
module.exports = {
  forEach: createMethod(0),
  map: createMethod(1),
  filter: createMethod(2),
  some: createMethod(3),
  every: createMethod(4),
  find: createMethod(5),
  findIndex: createMethod(6),
  filterOut: createMethod(7)
};


/***/ }),

/***/ 2014:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
var wellKnownSymbol = __webpack_require__(4354);
var V8_VERSION = __webpack_require__(9470);
var SPECIES = wellKnownSymbol("species");
module.exports = function(METHOD_NAME) {
  return V8_VERSION >= 51 || !fails(function() {
    var array = [];
    var constructor = array.constructor = {};
    constructor[SPECIES] = function() {
      return {foo: 1};
    };
    return array[METHOD_NAME](Boolean).foo !== 1;
  });
};


/***/ }),

/***/ 2759:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(3665);
module.exports = function(METHOD_NAME, argument) {
  var method = [][METHOD_NAME];
  return !!method && fails(function() {
    method.call(null, argument || function() {
      throw 1;
    }, 1);
  });
};


/***/ }),

/***/ 8575:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var aFunction = __webpack_require__(1758);
var toObject = __webpack_require__(1734);
var IndexedObject = __webpack_require__(5940);
var toLength = __webpack_require__(9944);
var createMethod = function(IS_RIGHT) {
  return function(that, callbackfn, argumentsLength, memo) {
    aFunction(callbackfn);
    var O = toObject(that);
    var self = IndexedObject(O);
    var length = toLength(O.length);
    var index = IS_RIGHT ? length - 1 : 0;
    var i = IS_RIGHT ? -1 : 1;
    if (argumentsLength < 2)
      while (true) {
        if (index in self) {
          memo = self[index];
          index += i;
          break;
        }
        index += i;
        if (IS_RIGHT ? index < 0 : length <= index) {
          throw TypeError("Reduce of empty array with no initial value");
        }
      }
    for (; IS_RIGHT ? index >= 0 : length > index; index += i)
      if (index in self) {
        memo = callbackfn(memo, self[index], index, O);
      }
    return memo;
  };
};
module.exports = {
  left: createMethod(false),
  right: createMethod(true)
};


/***/ }),

/***/ 6523:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
var isArray = __webpack_require__(4548);
var wellKnownSymbol = __webpack_require__(4354);
var SPECIES = wellKnownSymbol("species");
module.exports = function(originalArray, length) {
  var C;
  if (isArray(originalArray)) {
    C = originalArray.constructor;
    if (typeof C == "function" && (C === Array || isArray(C.prototype)))
      C = void 0;
    else if (isObject(C)) {
      C = C[SPECIES];
      if (C === null)
        C = void 0;
    }
  }
  return new (C === void 0 ? Array : C)(length === 0 ? 0 : length);
};


/***/ }),

/***/ 1140:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var iteratorClose = __webpack_require__(5263);
module.exports = function(iterator, fn, value, ENTRIES) {
  try {
    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
  } catch (error) {
    iteratorClose(iterator);
    throw error;
  }
};


/***/ }),

/***/ 8158:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(4354);
var ITERATOR = wellKnownSymbol("iterator");
var SAFE_CLOSING = false;
try {
  var called = 0;
  var iteratorWithReturn = {
    next: function() {
      return {done: !!called++};
    },
    return: function() {
      SAFE_CLOSING = true;
    }
  };
  iteratorWithReturn[ITERATOR] = function() {
    return this;
  };
  Array.from(iteratorWithReturn, function() {
    throw 2;
  });
} catch (error) {
}
module.exports = function(exec, SKIP_CLOSING) {
  if (!SKIP_CLOSING && !SAFE_CLOSING)
    return false;
  var ITERATION_SUPPORT = false;
  try {
    var object = {};
    object[ITERATOR] = function() {
      return {
        next: function() {
          return {done: ITERATION_SUPPORT = true};
        }
      };
    };
    exec(object);
  } catch (error) {
  }
  return ITERATION_SUPPORT;
};


/***/ }),

/***/ 1409:
/***/ ((module) => {

var toString = {}.toString;
module.exports = function(it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),

/***/ 4605:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var TO_STRING_TAG_SUPPORT = __webpack_require__(8779);
var classofRaw = __webpack_require__(1409);
var wellKnownSymbol = __webpack_require__(4354);
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var CORRECT_ARGUMENTS = classofRaw(function() {
  return arguments;
}()) == "Arguments";
var tryGet = function(it, key) {
  try {
    return it[key];
  } catch (error) {
  }
};
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function(it) {
  var O, tag, result;
  return it === void 0 ? "Undefined" : it === null ? "Null" : typeof (tag = tryGet(O = Object(it), TO_STRING_TAG)) == "string" ? tag : CORRECT_ARGUMENTS ? classofRaw(O) : (result = classofRaw(O)) == "Object" && typeof O.callee == "function" ? "Arguments" : result;
};


/***/ }),

/***/ 6787:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var defineProperty = __webpack_require__(2826).f;
var create = __webpack_require__(6474);
var redefineAll = __webpack_require__(1557);
var bind = __webpack_require__(3754);
var anInstance = __webpack_require__(7089);
var iterate = __webpack_require__(9682);
var defineIterator = __webpack_require__(7499);
var setSpecies = __webpack_require__(68);
var DESCRIPTORS = __webpack_require__(582);
var fastKey = __webpack_require__(9005).fastKey;
var InternalStateModule = __webpack_require__(7125);
var setInternalState = InternalStateModule.set;
var internalStateGetterFor = InternalStateModule.getterFor;
module.exports = {
  getConstructor: function(wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER) {
    var C = wrapper(function(that, iterable) {
      anInstance(that, C, CONSTRUCTOR_NAME);
      setInternalState(that, {
        type: CONSTRUCTOR_NAME,
        index: create(null),
        first: void 0,
        last: void 0,
        size: 0
      });
      if (!DESCRIPTORS)
        that.size = 0;
      if (iterable != void 0)
        iterate(iterable, that[ADDER], {that, AS_ENTRIES: IS_MAP});
    });
    var getInternalState = internalStateGetterFor(CONSTRUCTOR_NAME);
    var define = function(that, key, value) {
      var state = getInternalState(that);
      var entry = getEntry(that, key);
      var previous, index;
      if (entry) {
        entry.value = value;
      } else {
        state.last = entry = {
          index: index = fastKey(key, true),
          key,
          value,
          previous: previous = state.last,
          next: void 0,
          removed: false
        };
        if (!state.first)
          state.first = entry;
        if (previous)
          previous.next = entry;
        if (DESCRIPTORS)
          state.size++;
        else
          that.size++;
        if (index !== "F")
          state.index[index] = entry;
      }
      return that;
    };
    var getEntry = function(that, key) {
      var state = getInternalState(that);
      var index = fastKey(key);
      var entry;
      if (index !== "F")
        return state.index[index];
      for (entry = state.first; entry; entry = entry.next) {
        if (entry.key == key)
          return entry;
      }
    };
    redefineAll(C.prototype, {
      clear: function clear() {
        var that = this;
        var state = getInternalState(that);
        var data = state.index;
        var entry = state.first;
        while (entry) {
          entry.removed = true;
          if (entry.previous)
            entry.previous = entry.previous.next = void 0;
          delete data[entry.index];
          entry = entry.next;
        }
        state.first = state.last = void 0;
        if (DESCRIPTORS)
          state.size = 0;
        else
          that.size = 0;
      },
      delete: function(key) {
        var that = this;
        var state = getInternalState(that);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.next;
          var prev = entry.previous;
          delete state.index[entry.index];
          entry.removed = true;
          if (prev)
            prev.next = next;
          if (next)
            next.previous = prev;
          if (state.first == entry)
            state.first = next;
          if (state.last == entry)
            state.last = prev;
          if (DESCRIPTORS)
            state.size--;
          else
            that.size--;
        }
        return !!entry;
      },
      forEach: function forEach(callbackfn) {
        var state = getInternalState(this);
        var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : void 0, 3);
        var entry;
        while (entry = entry ? entry.next : state.first) {
          boundFunction(entry.value, entry.key, this);
          while (entry && entry.removed)
            entry = entry.previous;
        }
      },
      has: function has(key) {
        return !!getEntry(this, key);
      }
    });
    redefineAll(C.prototype, IS_MAP ? {
      get: function get(key) {
        var entry = getEntry(this, key);
        return entry && entry.value;
      },
      set: function set(key, value) {
        return define(this, key === 0 ? 0 : key, value);
      }
    } : {
      add: function add(value) {
        return define(this, value = value === 0 ? 0 : value, value);
      }
    });
    if (DESCRIPTORS)
      defineProperty(C.prototype, "size", {
        get: function() {
          return getInternalState(this).size;
        }
      });
    return C;
  },
  setStrong: function(C, CONSTRUCTOR_NAME, IS_MAP) {
    var ITERATOR_NAME = CONSTRUCTOR_NAME + " Iterator";
    var getInternalCollectionState = internalStateGetterFor(CONSTRUCTOR_NAME);
    var getInternalIteratorState = internalStateGetterFor(ITERATOR_NAME);
    defineIterator(C, CONSTRUCTOR_NAME, function(iterated, kind) {
      setInternalState(this, {
        type: ITERATOR_NAME,
        target: iterated,
        state: getInternalCollectionState(iterated),
        kind,
        last: void 0
      });
    }, function() {
      var state = getInternalIteratorState(this);
      var kind = state.kind;
      var entry = state.last;
      while (entry && entry.removed)
        entry = entry.previous;
      if (!state.target || !(state.last = entry = entry ? entry.next : state.state.first)) {
        state.target = void 0;
        return {value: void 0, done: true};
      }
      if (kind == "keys")
        return {value: entry.key, done: false};
      if (kind == "values")
        return {value: entry.value, done: false};
      return {value: [entry.key, entry.value], done: false};
    }, IS_MAP ? "entries" : "values", !IS_MAP, true);
    setSpecies(CONSTRUCTOR_NAME);
  }
};


/***/ }),

/***/ 468:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var global = __webpack_require__(5215);
var isForced = __webpack_require__(7315);
var redefine = __webpack_require__(2573);
var InternalMetadataModule = __webpack_require__(9005);
var iterate = __webpack_require__(9682);
var anInstance = __webpack_require__(7089);
var isObject = __webpack_require__(4963);
var fails = __webpack_require__(3665);
var checkCorrectnessOfIteration = __webpack_require__(8158);
var setToStringTag = __webpack_require__(8907);
var inheritIfRequired = __webpack_require__(9427);
module.exports = function(CONSTRUCTOR_NAME, wrapper, common) {
  var IS_MAP = CONSTRUCTOR_NAME.indexOf("Map") !== -1;
  var IS_WEAK = CONSTRUCTOR_NAME.indexOf("Weak") !== -1;
  var ADDER = IS_MAP ? "set" : "add";
  var NativeConstructor = global[CONSTRUCTOR_NAME];
  var NativePrototype = NativeConstructor && NativeConstructor.prototype;
  var Constructor = NativeConstructor;
  var exported = {};
  var fixMethod = function(KEY) {
    var nativeMethod = NativePrototype[KEY];
    redefine(NativePrototype, KEY, KEY == "add" ? function add(value) {
      nativeMethod.call(this, value === 0 ? 0 : value);
      return this;
    } : KEY == "delete" ? function(key) {
      return IS_WEAK && !isObject(key) ? false : nativeMethod.call(this, key === 0 ? 0 : key);
    } : KEY == "get" ? function get(key) {
      return IS_WEAK && !isObject(key) ? void 0 : nativeMethod.call(this, key === 0 ? 0 : key);
    } : KEY == "has" ? function has(key) {
      return IS_WEAK && !isObject(key) ? false : nativeMethod.call(this, key === 0 ? 0 : key);
    } : function set(key, value) {
      nativeMethod.call(this, key === 0 ? 0 : key, value);
      return this;
    });
  };
  var REPLACE = isForced(CONSTRUCTOR_NAME, typeof NativeConstructor != "function" || !(IS_WEAK || NativePrototype.forEach && !fails(function() {
    new NativeConstructor().entries().next();
  })));
  if (REPLACE) {
    Constructor = common.getConstructor(wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER);
    InternalMetadataModule.REQUIRED = true;
  } else if (isForced(CONSTRUCTOR_NAME, true)) {
    var instance = new Constructor();
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    var THROWS_ON_PRIMITIVES = fails(function() {
      instance.has(1);
    });
    var ACCEPT_ITERABLES = checkCorrectnessOfIteration(function(iterable) {
      new NativeConstructor(iterable);
    });
    var BUGGY_ZERO = !IS_WEAK && fails(function() {
      var $instance = new NativeConstructor();
      var index = 5;
      while (index--)
        $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      Constructor = wrapper(function(dummy, iterable) {
        anInstance(dummy, Constructor, CONSTRUCTOR_NAME);
        var that = inheritIfRequired(new NativeConstructor(), dummy, Constructor);
        if (iterable != void 0)
          iterate(iterable, that[ADDER], {that, AS_ENTRIES: IS_MAP});
        return that;
      });
      Constructor.prototype = NativePrototype;
      NativePrototype.constructor = Constructor;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod("delete");
      fixMethod("has");
      IS_MAP && fixMethod("get");
    }
    if (BUGGY_ZERO || HASNT_CHAINING)
      fixMethod(ADDER);
    if (IS_WEAK && NativePrototype.clear)
      delete NativePrototype.clear;
  }
  exported[CONSTRUCTOR_NAME] = Constructor;
  $({global: true, forced: Constructor != NativeConstructor}, exported);
  setToStringTag(Constructor, CONSTRUCTOR_NAME);
  if (!IS_WEAK)
    common.setStrong(Constructor, CONSTRUCTOR_NAME, IS_MAP);
  return Constructor;
};


/***/ }),

/***/ 5291:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var has = __webpack_require__(2450);
var ownKeys = __webpack_require__(2667);
var getOwnPropertyDescriptorModule = __webpack_require__(7599);
var definePropertyModule = __webpack_require__(2826);
module.exports = function(target, source) {
  var keys = ownKeys(source);
  var defineProperty = definePropertyModule.f;
  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!has(target, key))
      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
  }
};


/***/ }),

/***/ 6174:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(4354);
var MATCH = wellKnownSymbol("match");
module.exports = function(METHOD_NAME) {
  var regexp = /./;
  try {
    "/./"[METHOD_NAME](regexp);
  } catch (error1) {
    try {
      regexp[MATCH] = false;
      return "/./"[METHOD_NAME](regexp);
    } catch (error2) {
    }
  }
  return false;
};


/***/ }),

/***/ 9744:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
module.exports = !fails(function() {
  function F() {
  }
  F.prototype.constructor = null;
  return Object.getPrototypeOf(new F()) !== F.prototype;
});


/***/ }),

/***/ 802:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var requireObjectCoercible = __webpack_require__(6213);
var quot = /"/g;
module.exports = function(string, tag, attribute, value) {
  var S = String(requireObjectCoercible(string));
  var p1 = "<" + tag;
  if (attribute !== "")
    p1 += " " + attribute + '="' + String(value).replace(quot, "&quot;") + '"';
  return p1 + ">" + S + "</" + tag + ">";
};


/***/ }),

/***/ 3307:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var IteratorPrototype = __webpack_require__(2384).IteratorPrototype;
var create = __webpack_require__(6474);
var createPropertyDescriptor = __webpack_require__(2011);
var setToStringTag = __webpack_require__(8907);
var Iterators = __webpack_require__(2341);
var returnThis = function() {
  return this;
};
module.exports = function(IteratorConstructor, NAME, next) {
  var TO_STRING_TAG = NAME + " Iterator";
  IteratorConstructor.prototype = create(IteratorPrototype, {next: createPropertyDescriptor(1, next)});
  setToStringTag(IteratorConstructor, TO_STRING_TAG, false, true);
  Iterators[TO_STRING_TAG] = returnThis;
  return IteratorConstructor;
};


/***/ }),

/***/ 9465:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var definePropertyModule = __webpack_require__(2826);
var createPropertyDescriptor = __webpack_require__(2011);
module.exports = DESCRIPTORS ? function(object, key, value) {
  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function(object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),

/***/ 2011:
/***/ ((module) => {

module.exports = function(bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value
  };
};


/***/ }),

/***/ 9246:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toPrimitive = __webpack_require__(7197);
var definePropertyModule = __webpack_require__(2826);
var createPropertyDescriptor = __webpack_require__(2011);
module.exports = function(object, key, value) {
  var propertyKey = toPrimitive(key);
  if (propertyKey in object)
    definePropertyModule.f(object, propertyKey, createPropertyDescriptor(0, value));
  else
    object[propertyKey] = value;
};


/***/ }),

/***/ 7499:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var createIteratorConstructor = __webpack_require__(3307);
var getPrototypeOf = __webpack_require__(9947);
var setPrototypeOf = __webpack_require__(1982);
var setToStringTag = __webpack_require__(8907);
var createNonEnumerableProperty = __webpack_require__(9465);
var redefine = __webpack_require__(2573);
var wellKnownSymbol = __webpack_require__(4354);
var IS_PURE = __webpack_require__(726);
var Iterators = __webpack_require__(2341);
var IteratorsCore = __webpack_require__(2384);
var IteratorPrototype = IteratorsCore.IteratorPrototype;
var BUGGY_SAFARI_ITERATORS = IteratorsCore.BUGGY_SAFARI_ITERATORS;
var ITERATOR = wellKnownSymbol("iterator");
var KEYS = "keys";
var VALUES = "values";
var ENTRIES = "entries";
var returnThis = function() {
  return this;
};
module.exports = function(Iterable, NAME, IteratorConstructor, next, DEFAULT, IS_SET, FORCED) {
  createIteratorConstructor(IteratorConstructor, NAME, next);
  var getIterationMethod = function(KIND) {
    if (KIND === DEFAULT && defaultIterator)
      return defaultIterator;
    if (!BUGGY_SAFARI_ITERATORS && KIND in IterablePrototype)
      return IterablePrototype[KIND];
    switch (KIND) {
      case KEYS:
        return function keys() {
          return new IteratorConstructor(this, KIND);
        };
      case VALUES:
        return function values() {
          return new IteratorConstructor(this, KIND);
        };
      case ENTRIES:
        return function entries() {
          return new IteratorConstructor(this, KIND);
        };
    }
    return function() {
      return new IteratorConstructor(this);
    };
  };
  var TO_STRING_TAG = NAME + " Iterator";
  var INCORRECT_VALUES_NAME = false;
  var IterablePrototype = Iterable.prototype;
  var nativeIterator = IterablePrototype[ITERATOR] || IterablePrototype["@@iterator"] || DEFAULT && IterablePrototype[DEFAULT];
  var defaultIterator = !BUGGY_SAFARI_ITERATORS && nativeIterator || getIterationMethod(DEFAULT);
  var anyNativeIterator = NAME == "Array" ? IterablePrototype.entries || nativeIterator : nativeIterator;
  var CurrentIteratorPrototype, methods, KEY;
  if (anyNativeIterator) {
    CurrentIteratorPrototype = getPrototypeOf(anyNativeIterator.call(new Iterable()));
    if (IteratorPrototype !== Object.prototype && CurrentIteratorPrototype.next) {
      if (!IS_PURE && getPrototypeOf(CurrentIteratorPrototype) !== IteratorPrototype) {
        if (setPrototypeOf) {
          setPrototypeOf(CurrentIteratorPrototype, IteratorPrototype);
        } else if (typeof CurrentIteratorPrototype[ITERATOR] != "function") {
          createNonEnumerableProperty(CurrentIteratorPrototype, ITERATOR, returnThis);
        }
      }
      setToStringTag(CurrentIteratorPrototype, TO_STRING_TAG, true, true);
      if (IS_PURE)
        Iterators[TO_STRING_TAG] = returnThis;
    }
  }
  if (DEFAULT == VALUES && nativeIterator && nativeIterator.name !== VALUES) {
    INCORRECT_VALUES_NAME = true;
    defaultIterator = function values() {
      return nativeIterator.call(this);
    };
  }
  if ((!IS_PURE || FORCED) && IterablePrototype[ITERATOR] !== defaultIterator) {
    createNonEnumerableProperty(IterablePrototype, ITERATOR, defaultIterator);
  }
  Iterators[NAME] = defaultIterator;
  if (DEFAULT) {
    methods = {
      values: getIterationMethod(VALUES),
      keys: IS_SET ? defaultIterator : getIterationMethod(KEYS),
      entries: getIterationMethod(ENTRIES)
    };
    if (FORCED)
      for (KEY in methods) {
        if (BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME || !(KEY in IterablePrototype)) {
          redefine(IterablePrototype, KEY, methods[KEY]);
        }
      }
    else
      $({target: NAME, proto: true, forced: BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME}, methods);
  }
  return methods;
};


/***/ }),

/***/ 582:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
module.exports = !fails(function() {
  return Object.defineProperty({}, 1, {get: function() {
    return 7;
  }})[1] != 7;
});


/***/ }),

/***/ 7249:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var isObject = __webpack_require__(4963);
var document = global.document;
var EXISTS = isObject(document) && isObject(document.createElement);
module.exports = function(it) {
  return EXISTS ? document.createElement(it) : {};
};


/***/ }),

/***/ 8839:
/***/ ((module) => {

module.exports = {
  CSSRuleList: 0,
  CSSStyleDeclaration: 0,
  CSSValueList: 0,
  ClientRectList: 0,
  DOMRectList: 0,
  DOMStringList: 0,
  DOMTokenList: 1,
  DataTransferItemList: 0,
  FileList: 0,
  HTMLAllCollection: 0,
  HTMLCollection: 0,
  HTMLFormElement: 0,
  HTMLSelectElement: 0,
  MediaList: 0,
  MimeTypeArray: 0,
  NamedNodeMap: 0,
  NodeList: 1,
  PaintRequestList: 0,
  Plugin: 0,
  PluginArray: 0,
  SVGLengthList: 0,
  SVGNumberList: 0,
  SVGPathSegList: 0,
  SVGPointList: 0,
  SVGStringList: 0,
  SVGTransformList: 0,
  SourceBufferList: 0,
  StyleSheetList: 0,
  TextTrackCueList: 0,
  TextTrackList: 0,
  TouchList: 0
};


/***/ }),

/***/ 241:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(7175);
module.exports = /(iphone|ipod|ipad).*applewebkit/i.test(userAgent);


/***/ }),

/***/ 779:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(1409);
var global = __webpack_require__(5215);
module.exports = classof(global.process) == "process";


/***/ }),

/***/ 5289:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(7175);
module.exports = /web0s(?!.*chrome)/i.test(userAgent);


/***/ }),

/***/ 7175:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(5408);
module.exports = getBuiltIn("navigator", "userAgent") || "";


/***/ }),

/***/ 9470:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var userAgent = __webpack_require__(7175);
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8;
var match, version;
if (v8) {
  match = v8.split(".");
  version = match[0] + match[1];
} else if (userAgent) {
  match = userAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = userAgent.match(/Chrome\/(\d+)/);
    if (match)
      version = match[1];
  }
}
module.exports = version && +version;


/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = [
  "constructor",
  "hasOwnProperty",
  "isPrototypeOf",
  "propertyIsEnumerable",
  "toLocaleString",
  "toString",
  "valueOf"
];


/***/ }),

/***/ 3298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var getOwnPropertyDescriptor = __webpack_require__(7599).f;
var createNonEnumerableProperty = __webpack_require__(9465);
var redefine = __webpack_require__(2573);
var setGlobal = __webpack_require__(8140);
var copyConstructorProperties = __webpack_require__(5291);
var isForced = __webpack_require__(7315);
module.exports = function(options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = global;
  } else if (STATIC) {
    target = global[TARGET] || setGlobal(TARGET, {});
  } else {
    target = (global[TARGET] || {}).prototype;
  }
  if (target)
    for (key in source) {
      sourceProperty = source[key];
      if (options.noTargetGet) {
        descriptor = getOwnPropertyDescriptor(target, key);
        targetProperty = descriptor && descriptor.value;
      } else
        targetProperty = target[key];
      FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? "." : "#") + key, options.forced);
      if (!FORCED && targetProperty !== void 0) {
        if (typeof sourceProperty === typeof targetProperty)
          continue;
        copyConstructorProperties(sourceProperty, targetProperty);
      }
      if (options.sham || targetProperty && targetProperty.sham) {
        createNonEnumerableProperty(sourceProperty, "sham", true);
      }
      redefine(target, key, sourceProperty, options);
    }
};


/***/ }),

/***/ 3665:
/***/ ((module) => {

module.exports = function(exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};


/***/ }),

/***/ 1052:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

__webpack_require__(7298);
var redefine = __webpack_require__(2573);
var fails = __webpack_require__(3665);
var wellKnownSymbol = __webpack_require__(4354);
var regexpExec = __webpack_require__(9403);
var createNonEnumerableProperty = __webpack_require__(9465);
var SPECIES = wellKnownSymbol("species");
var REPLACE_SUPPORTS_NAMED_GROUPS = !fails(function() {
  var re = /./;
  re.exec = function() {
    var result = [];
    result.groups = {a: "7"};
    return result;
  };
  return "".replace(re, "$<a>") !== "7";
});
var REPLACE_KEEPS_$0 = function() {
  return "a".replace(/./, "$0") === "$0";
}();
var REPLACE = wellKnownSymbol("replace");
var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = function() {
  if (/./[REPLACE]) {
    return /./[REPLACE]("a", "$0") === "";
  }
  return false;
}();
var SPLIT_WORKS_WITH_OVERWRITTEN_EXEC = !fails(function() {
  var re = /(?:)/;
  var originalExec = re.exec;
  re.exec = function() {
    return originalExec.apply(this, arguments);
  };
  var result = "ab".split(re);
  return result.length !== 2 || result[0] !== "a" || result[1] !== "b";
});
module.exports = function(KEY, length, exec, sham) {
  var SYMBOL = wellKnownSymbol(KEY);
  var DELEGATES_TO_SYMBOL = !fails(function() {
    var O = {};
    O[SYMBOL] = function() {
      return 7;
    };
    return ""[KEY](O) != 7;
  });
  var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL && !fails(function() {
    var execCalled = false;
    var re = /a/;
    if (KEY === "split") {
      re = {};
      re.constructor = {};
      re.constructor[SPECIES] = function() {
        return re;
      };
      re.flags = "";
      re[SYMBOL] = /./[SYMBOL];
    }
    re.exec = function() {
      execCalled = true;
      return null;
    };
    re[SYMBOL]("");
    return !execCalled;
  });
  if (!DELEGATES_TO_SYMBOL || !DELEGATES_TO_EXEC || KEY === "replace" && !(REPLACE_SUPPORTS_NAMED_GROUPS && REPLACE_KEEPS_$0 && !REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE) || KEY === "split" && !SPLIT_WORKS_WITH_OVERWRITTEN_EXEC) {
    var nativeRegExpMethod = /./[SYMBOL];
    var methods = exec(SYMBOL, ""[KEY], function(nativeMethod, regexp, str, arg2, forceStringMethod) {
      if (regexp.exec === regexpExec) {
        if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
          return {done: true, value: nativeRegExpMethod.call(regexp, str, arg2)};
        }
        return {done: true, value: nativeMethod.call(str, regexp, arg2)};
      }
      return {done: false};
    }, {
      REPLACE_KEEPS_$0,
      REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE
    });
    var stringMethod = methods[0];
    var regexMethod = methods[1];
    redefine(String.prototype, KEY, stringMethod);
    redefine(RegExp.prototype, SYMBOL, length == 2 ? function(string, arg) {
      return regexMethod.call(string, this, arg);
    } : function(string) {
      return regexMethod.call(string, this);
    });
  }
  if (sham)
    createNonEnumerableProperty(RegExp.prototype[SYMBOL], "sham", true);
};


/***/ }),

/***/ 6655:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
module.exports = !fails(function() {
  return Object.isExtensible(Object.preventExtensions({}));
});


/***/ }),

/***/ 3754:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var aFunction = __webpack_require__(1758);
module.exports = function(fn, that, length) {
  aFunction(fn);
  if (that === void 0)
    return fn;
  switch (length) {
    case 0:
      return function() {
        return fn.call(that);
      };
    case 1:
      return function(a) {
        return fn.call(that, a);
      };
    case 2:
      return function(a, b) {
        return fn.call(that, a, b);
      };
    case 3:
      return function(a, b, c) {
        return fn.call(that, a, b, c);
      };
  }
  return function() {
    return fn.apply(that, arguments);
  };
};


/***/ }),

/***/ 3143:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var aFunction = __webpack_require__(1758);
var isObject = __webpack_require__(4963);
var slice = [].slice;
var factories = {};
var construct = function(C, argsLength, args) {
  if (!(argsLength in factories)) {
    for (var list = [], i = 0; i < argsLength; i++)
      list[i] = "a[" + i + "]";
    factories[argsLength] = Function("C,a", "return new C(" + list.join(",") + ")");
  }
  return factories[argsLength](C, args);
};
module.exports = Function.bind || function bind(that) {
  var fn = aFunction(this);
  var partArgs = slice.call(arguments, 1);
  var boundFunction = function bound() {
    var args = partArgs.concat(slice.call(arguments));
    return this instanceof boundFunction ? construct(fn, args.length, args) : fn.apply(that, args);
  };
  if (isObject(fn.prototype))
    boundFunction.prototype = fn.prototype;
  return boundFunction;
};


/***/ }),

/***/ 5408:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var path = __webpack_require__(7698);
var global = __webpack_require__(5215);
var aFunction = function(variable) {
  return typeof variable == "function" ? variable : void 0;
};
module.exports = function(namespace, method) {
  return arguments.length < 2 ? aFunction(path[namespace]) || aFunction(global[namespace]) : path[namespace] && path[namespace][method] || global[namespace] && global[namespace][method];
};


/***/ }),

/***/ 3513:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(4605);
var Iterators = __webpack_require__(2341);
var wellKnownSymbol = __webpack_require__(4354);
var ITERATOR = wellKnownSymbol("iterator");
module.exports = function(it) {
  if (it != void 0)
    return it[ITERATOR] || it["@@iterator"] || Iterators[classof(it)];
};


/***/ }),

/***/ 2992:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toObject = __webpack_require__(1734);
var floor = Math.floor;
var replace = "".replace;
var SUBSTITUTION_SYMBOLS = /\$([$&'`]|\d{1,2}|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&'`]|\d{1,2})/g;
module.exports = function(matched, str, position, captures, namedCaptures, replacement) {
  var tailPos = position + matched.length;
  var m = captures.length;
  var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
  if (namedCaptures !== void 0) {
    namedCaptures = toObject(namedCaptures);
    symbols = SUBSTITUTION_SYMBOLS;
  }
  return replace.call(replacement, symbols, function(match, ch) {
    var capture;
    switch (ch.charAt(0)) {
      case "$":
        return "$";
      case "&":
        return matched;
      case "`":
        return str.slice(0, position);
      case "'":
        return str.slice(tailPos);
      case "<":
        capture = namedCaptures[ch.slice(1, -1)];
        break;
      default:
        var n = +ch;
        if (n === 0)
          return match;
        if (n > m) {
          var f = floor(n / 10);
          if (f === 0)
            return match;
          if (f <= m)
            return captures[f - 1] === void 0 ? ch.charAt(1) : captures[f - 1] + ch.charAt(1);
          return match;
        }
        capture = captures[n - 1];
    }
    return capture === void 0 ? "" : capture;
  });
};


/***/ }),

/***/ 5215:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var check = function(it) {
  return it && it.Math == Math && it;
};
module.exports = check(typeof globalThis == "object" && globalThis) || check(typeof window == "object" && window) || check(typeof self == "object" && self) || check(typeof __webpack_require__.g == "object" && __webpack_require__.g) || function() {
  return this;
}() || Function("return this")();


/***/ }),

/***/ 2450:
/***/ ((module) => {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function(it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),

/***/ 6625:
/***/ ((module) => {

module.exports = {};


/***/ }),

/***/ 9506:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
module.exports = function(a, b) {
  var console = global.console;
  if (console && console.error) {
    arguments.length === 1 ? console.error(a) : console.error(a, b);
  }
};


/***/ }),

/***/ 5881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(5408);
module.exports = getBuiltIn("document", "documentElement");


/***/ }),

/***/ 6237:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var fails = __webpack_require__(3665);
var createElement = __webpack_require__(7249);
module.exports = !DESCRIPTORS && !fails(function() {
  return Object.defineProperty(createElement("div"), "a", {
    get: function() {
      return 7;
    }
  }).a != 7;
});


/***/ }),

/***/ 5940:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
var classof = __webpack_require__(1409);
var split = "".split;
module.exports = fails(function() {
  return !Object("z").propertyIsEnumerable(0);
}) ? function(it) {
  return classof(it) == "String" ? split.call(it, "") : Object(it);
} : Object;


/***/ }),

/***/ 9427:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
var setPrototypeOf = __webpack_require__(1982);
module.exports = function($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (setPrototypeOf && typeof (NewTarget = dummy.constructor) == "function" && NewTarget !== Wrapper && isObject(NewTargetPrototype = NewTarget.prototype) && NewTargetPrototype !== Wrapper.prototype)
    setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ 2549:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var store = __webpack_require__(5204);
var functionToString = Function.toString;
if (typeof store.inspectSource != "function") {
  store.inspectSource = function(it) {
    return functionToString.call(it);
  };
}
module.exports = store.inspectSource;


/***/ }),

/***/ 9005:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var hiddenKeys = __webpack_require__(6625);
var isObject = __webpack_require__(4963);
var has = __webpack_require__(2450);
var defineProperty = __webpack_require__(2826).f;
var uid = __webpack_require__(657);
var FREEZING = __webpack_require__(6655);
var METADATA = uid("meta");
var id = 0;
var isExtensible = Object.isExtensible || function() {
  return true;
};
var setMetadata = function(it) {
  defineProperty(it, METADATA, {value: {
    objectID: "O" + ++id,
    weakData: {}
  }});
};
var fastKey = function(it, create) {
  if (!isObject(it))
    return typeof it == "symbol" ? it : (typeof it == "string" ? "S" : "P") + it;
  if (!has(it, METADATA)) {
    if (!isExtensible(it))
      return "F";
    if (!create)
      return "E";
    setMetadata(it);
  }
  return it[METADATA].objectID;
};
var getWeakData = function(it, create) {
  if (!has(it, METADATA)) {
    if (!isExtensible(it))
      return true;
    if (!create)
      return false;
    setMetadata(it);
  }
  return it[METADATA].weakData;
};
var onFreeze = function(it) {
  if (FREEZING && meta.REQUIRED && isExtensible(it) && !has(it, METADATA))
    setMetadata(it);
  return it;
};
var meta = module.exports = {
  REQUIRED: false,
  fastKey,
  getWeakData,
  onFreeze
};
hiddenKeys[METADATA] = true;


/***/ }),

/***/ 7125:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_WEAK_MAP = __webpack_require__(3904);
var global = __webpack_require__(5215);
var isObject = __webpack_require__(4963);
var createNonEnumerableProperty = __webpack_require__(9465);
var objectHas = __webpack_require__(2450);
var shared = __webpack_require__(5204);
var sharedKey = __webpack_require__(7429);
var hiddenKeys = __webpack_require__(6625);
var WeakMap = global.WeakMap;
var set, get, has;
var enforce = function(it) {
  return has(it) ? get(it) : set(it, {});
};
var getterFor = function(TYPE) {
  return function(it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw TypeError("Incompatible receiver, " + TYPE + " required");
    }
    return state;
  };
};
if (NATIVE_WEAK_MAP) {
  var store = shared.state || (shared.state = new WeakMap());
  var wmget = store.get;
  var wmhas = store.has;
  var wmset = store.set;
  set = function(it, metadata) {
    metadata.facade = it;
    wmset.call(store, it, metadata);
    return metadata;
  };
  get = function(it) {
    return wmget.call(store, it) || {};
  };
  has = function(it) {
    return wmhas.call(store, it);
  };
} else {
  var STATE = sharedKey("state");
  hiddenKeys[STATE] = true;
  set = function(it, metadata) {
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function(it) {
    return objectHas(it, STATE) ? it[STATE] : {};
  };
  has = function(it) {
    return objectHas(it, STATE);
  };
}
module.exports = {
  set,
  get,
  has,
  enforce,
  getterFor
};


/***/ }),

/***/ 9140:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(4354);
var Iterators = __webpack_require__(2341);
var ITERATOR = wellKnownSymbol("iterator");
var ArrayPrototype = Array.prototype;
module.exports = function(it) {
  return it !== void 0 && (Iterators.Array === it || ArrayPrototype[ITERATOR] === it);
};


/***/ }),

/***/ 4548:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(1409);
module.exports = Array.isArray || function isArray(arg) {
  return classof(arg) == "Array";
};


/***/ }),

/***/ 7315:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
var replacement = /#|\.prototype\./;
var isForced = function(feature, detection) {
  var value = data[normalize(feature)];
  return value == POLYFILL ? true : value == NATIVE ? false : typeof detection == "function" ? fails(detection) : !!detection;
};
var normalize = isForced.normalize = function(string) {
  return String(string).replace(replacement, ".").toLowerCase();
};
var data = isForced.data = {};
var NATIVE = isForced.NATIVE = "N";
var POLYFILL = isForced.POLYFILL = "P";
module.exports = isForced;


/***/ }),

/***/ 4963:
/***/ ((module) => {

module.exports = function(it) {
  return typeof it === "object" ? it !== null : typeof it === "function";
};


/***/ }),

/***/ 726:
/***/ ((module) => {

module.exports = false;


/***/ }),

/***/ 8844:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
var classof = __webpack_require__(1409);
var wellKnownSymbol = __webpack_require__(4354);
var MATCH = wellKnownSymbol("match");
module.exports = function(it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== void 0 ? !!isRegExp : classof(it) == "RegExp");
};


/***/ }),

/***/ 9682:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var isArrayIteratorMethod = __webpack_require__(9140);
var toLength = __webpack_require__(9944);
var bind = __webpack_require__(3754);
var getIteratorMethod = __webpack_require__(3513);
var iteratorClose = __webpack_require__(5263);
var Result = function(stopped, result) {
  this.stopped = stopped;
  this.result = result;
};
module.exports = function(iterable, unboundFunction, options) {
  var that = options && options.that;
  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
  var INTERRUPTED = !!(options && options.INTERRUPTED);
  var fn = bind(unboundFunction, that, 1 + AS_ENTRIES + INTERRUPTED);
  var iterator, iterFn, index, length, result, next, step;
  var stop = function(condition) {
    if (iterator)
      iteratorClose(iterator);
    return new Result(true, condition);
  };
  var callFn = function(value) {
    if (AS_ENTRIES) {
      anObject(value);
      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
    }
    return INTERRUPTED ? fn(value, stop) : fn(value);
  };
  if (IS_ITERATOR) {
    iterator = iterable;
  } else {
    iterFn = getIteratorMethod(iterable);
    if (typeof iterFn != "function")
      throw TypeError("Target is not iterable");
    if (isArrayIteratorMethod(iterFn)) {
      for (index = 0, length = toLength(iterable.length); length > index; index++) {
        result = callFn(iterable[index]);
        if (result && result instanceof Result)
          return result;
      }
      return new Result(false);
    }
    iterator = iterFn.call(iterable);
  }
  next = iterator.next;
  while (!(step = next.call(iterator)).done) {
    try {
      result = callFn(step.value);
    } catch (error) {
      iteratorClose(iterator);
      throw error;
    }
    if (typeof result == "object" && result && result instanceof Result)
      return result;
  }
  return new Result(false);
};


/***/ }),

/***/ 5263:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
module.exports = function(iterator) {
  var returnMethod = iterator["return"];
  if (returnMethod !== void 0) {
    return anObject(returnMethod.call(iterator)).value;
  }
};


/***/ }),

/***/ 2384:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(3665);
var getPrototypeOf = __webpack_require__(9947);
var createNonEnumerableProperty = __webpack_require__(9465);
var has = __webpack_require__(2450);
var wellKnownSymbol = __webpack_require__(4354);
var IS_PURE = __webpack_require__(726);
var ITERATOR = wellKnownSymbol("iterator");
var BUGGY_SAFARI_ITERATORS = false;
var returnThis = function() {
  return this;
};
var IteratorPrototype, PrototypeOfArrayIteratorPrototype, arrayIterator;
if ([].keys) {
  arrayIterator = [].keys();
  if (!("next" in arrayIterator))
    BUGGY_SAFARI_ITERATORS = true;
  else {
    PrototypeOfArrayIteratorPrototype = getPrototypeOf(getPrototypeOf(arrayIterator));
    if (PrototypeOfArrayIteratorPrototype !== Object.prototype)
      IteratorPrototype = PrototypeOfArrayIteratorPrototype;
  }
}
var NEW_ITERATOR_PROTOTYPE = IteratorPrototype == void 0 || fails(function() {
  var test = {};
  return IteratorPrototype[ITERATOR].call(test) !== test;
});
if (NEW_ITERATOR_PROTOTYPE)
  IteratorPrototype = {};
if ((!IS_PURE || NEW_ITERATOR_PROTOTYPE) && !has(IteratorPrototype, ITERATOR)) {
  createNonEnumerableProperty(IteratorPrototype, ITERATOR, returnThis);
}
module.exports = {
  IteratorPrototype,
  BUGGY_SAFARI_ITERATORS
};


/***/ }),

/***/ 2341:
/***/ ((module) => {

module.exports = {};


/***/ }),

/***/ 5650:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var getOwnPropertyDescriptor = __webpack_require__(7599).f;
var macrotask = __webpack_require__(6195).set;
var IS_IOS = __webpack_require__(241);
var IS_WEBOS_WEBKIT = __webpack_require__(5289);
var IS_NODE = __webpack_require__(779);
var MutationObserver = global.MutationObserver || global.WebKitMutationObserver;
var document = global.document;
var process = global.process;
var Promise = global.Promise;
var queueMicrotaskDescriptor = getOwnPropertyDescriptor(global, "queueMicrotask");
var queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;
var flush, head, last, notify, toggle, node, promise, then;
if (!queueMicrotask) {
  flush = function() {
    var parent, fn;
    if (IS_NODE && (parent = process.domain))
      parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (error) {
        if (head)
          notify();
        else
          last = void 0;
        throw error;
      }
    }
    last = void 0;
    if (parent)
      parent.enter();
  };
  if (!IS_IOS && !IS_NODE && !IS_WEBOS_WEBKIT && MutationObserver && document) {
    toggle = true;
    node = document.createTextNode("");
    new MutationObserver(flush).observe(node, {characterData: true});
    notify = function() {
      node.data = toggle = !toggle;
    };
  } else if (Promise && Promise.resolve) {
    promise = Promise.resolve(void 0);
    then = promise.then;
    notify = function() {
      then.call(promise, flush);
    };
  } else if (IS_NODE) {
    notify = function() {
      process.nextTick(flush);
    };
  } else {
    notify = function() {
      macrotask.call(global, flush);
    };
  }
}
module.exports = queueMicrotask || function(fn) {
  var task = {fn, next: void 0};
  if (last)
    last.next = task;
  if (!head) {
    head = task;
    notify();
  }
  last = task;
};


/***/ }),

/***/ 9846:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
module.exports = global.Promise;


/***/ }),

/***/ 2726:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var IS_NODE = __webpack_require__(779);
var V8_VERSION = __webpack_require__(9470);
var fails = __webpack_require__(3665);
module.exports = !!Object.getOwnPropertySymbols && !fails(function() {
  return !Symbol.sham && (IS_NODE ? V8_VERSION === 38 : V8_VERSION > 37 && V8_VERSION < 41);
});


/***/ }),

/***/ 3904:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var inspectSource = __webpack_require__(2549);
var WeakMap = global.WeakMap;
module.exports = typeof WeakMap === "function" && /native code/.test(inspectSource(WeakMap));


/***/ }),

/***/ 6335:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var aFunction = __webpack_require__(1758);
var PromiseCapability = function(C) {
  var resolve, reject;
  this.promise = new C(function($$resolve, $$reject) {
    if (resolve !== void 0 || reject !== void 0)
      throw TypeError("Bad Promise constructor");
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
};
module.exports.f = function(C) {
  return new PromiseCapability(C);
};


/***/ }),

/***/ 4755:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isRegExp = __webpack_require__(8844);
module.exports = function(it) {
  if (isRegExp(it)) {
    throw TypeError("The method doesn't accept regular expressions");
  }
  return it;
};


/***/ }),

/***/ 6474:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var defineProperties = __webpack_require__(6328);
var enumBugKeys = __webpack_require__(6368);
var hiddenKeys = __webpack_require__(6625);
var html = __webpack_require__(5881);
var documentCreateElement = __webpack_require__(7249);
var sharedKey = __webpack_require__(7429);
var GT = ">";
var LT = "<";
var PROTOTYPE = "prototype";
var SCRIPT = "script";
var IE_PROTO = sharedKey("IE_PROTO");
var EmptyConstructor = function() {
};
var scriptTag = function(content) {
  return LT + SCRIPT + GT + content + LT + "/" + SCRIPT + GT;
};
var NullProtoObjectViaActiveX = function(activeXDocument2) {
  activeXDocument2.write(scriptTag(""));
  activeXDocument2.close();
  var temp = activeXDocument2.parentWindow.Object;
  activeXDocument2 = null;
  return temp;
};
var NullProtoObjectViaIFrame = function() {
  var iframe = documentCreateElement("iframe");
  var JS = "java" + SCRIPT + ":";
  var iframeDocument;
  iframe.style.display = "none";
  html.appendChild(iframe);
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag("document.F=Object"));
  iframeDocument.close();
  return iframeDocument.F;
};
var activeXDocument;
var NullProtoObject = function() {
  try {
    activeXDocument = document.domain && new ActiveXObject("htmlfile");
  } catch (error) {
  }
  NullProtoObject = activeXDocument ? NullProtoObjectViaActiveX(activeXDocument) : NullProtoObjectViaIFrame();
  var length = enumBugKeys.length;
  while (length--)
    delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};
hiddenKeys[IE_PROTO] = true;
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    result[IE_PROTO] = O;
  } else
    result = NullProtoObject();
  return Properties === void 0 ? result : defineProperties(result, Properties);
};


/***/ }),

/***/ 6328:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var definePropertyModule = __webpack_require__(2826);
var anObject = __webpack_require__(5675);
var objectKeys = __webpack_require__(4944);
module.exports = DESCRIPTORS ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index)
    definePropertyModule.f(O, key = keys[index++], Properties[key]);
  return O;
};


/***/ }),

/***/ 2826:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var IE8_DOM_DEFINE = __webpack_require__(6237);
var anObject = __webpack_require__(5675);
var toPrimitive = __webpack_require__(7197);
var $defineProperty = Object.defineProperty;
exports.f = DESCRIPTORS ? $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE)
    try {
      return $defineProperty(O, P, Attributes);
    } catch (error) {
    }
  if ("get" in Attributes || "set" in Attributes)
    throw TypeError("Accessors not supported");
  if ("value" in Attributes)
    O[P] = Attributes.value;
  return O;
};


/***/ }),

/***/ 7599:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var propertyIsEnumerableModule = __webpack_require__(1991);
var createPropertyDescriptor = __webpack_require__(2011);
var toIndexedObject = __webpack_require__(4362);
var toPrimitive = __webpack_require__(7197);
var has = __webpack_require__(2450);
var IE8_DOM_DEFINE = __webpack_require__(6237);
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE)
    try {
      return $getOwnPropertyDescriptor(O, P);
    } catch (error) {
    }
  if (has(O, P))
    return createPropertyDescriptor(!propertyIsEnumerableModule.f.call(O, P), O[P]);
};


/***/ }),

/***/ 8265:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var internalObjectKeys = __webpack_require__(355);
var enumBugKeys = __webpack_require__(6368);
var hiddenKeys = enumBugKeys.concat("length", "prototype");
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return internalObjectKeys(O, hiddenKeys);
};


/***/ }),

/***/ 258:
/***/ ((__unused_webpack_module, exports) => {

exports.f = Object.getOwnPropertySymbols;


/***/ }),

/***/ 9947:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var has = __webpack_require__(2450);
var toObject = __webpack_require__(1734);
var sharedKey = __webpack_require__(7429);
var CORRECT_PROTOTYPE_GETTER = __webpack_require__(9744);
var IE_PROTO = sharedKey("IE_PROTO");
var ObjectPrototype = Object.prototype;
module.exports = CORRECT_PROTOTYPE_GETTER ? Object.getPrototypeOf : function(O) {
  O = toObject(O);
  if (has(O, IE_PROTO))
    return O[IE_PROTO];
  if (typeof O.constructor == "function" && O instanceof O.constructor) {
    return O.constructor.prototype;
  }
  return O instanceof Object ? ObjectPrototype : null;
};


/***/ }),

/***/ 355:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var has = __webpack_require__(2450);
var toIndexedObject = __webpack_require__(4362);
var indexOf = __webpack_require__(8170).indexOf;
var hiddenKeys = __webpack_require__(6625);
module.exports = function(object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O)
    !has(hiddenKeys, key) && has(O, key) && result.push(key);
  while (names.length > i)
    if (has(O, key = names[i++])) {
      ~indexOf(result, key) || result.push(key);
    }
  return result;
};


/***/ }),

/***/ 4944:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var internalObjectKeys = __webpack_require__(355);
var enumBugKeys = __webpack_require__(6368);
module.exports = Object.keys || function keys(O) {
  return internalObjectKeys(O, enumBugKeys);
};


/***/ }),

/***/ 1991:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

var $propertyIsEnumerable = {}.propertyIsEnumerable;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({1: 2}, 1);
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;


/***/ }),

/***/ 1982:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var aPossiblePrototype = __webpack_require__(9497);
module.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
  var CORRECT_SETTER = false;
  var test = {};
  var setter;
  try {
    setter = Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set;
    setter.call(test, []);
    CORRECT_SETTER = test instanceof Array;
  } catch (error) {
  }
  return function setPrototypeOf(O, proto) {
    anObject(O);
    aPossiblePrototype(proto);
    if (CORRECT_SETTER)
      setter.call(O, proto);
    else
      O.__proto__ = proto;
    return O;
  };
}() : void 0);


/***/ }),

/***/ 3004:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var objectKeys = __webpack_require__(4944);
var toIndexedObject = __webpack_require__(4362);
var propertyIsEnumerable = __webpack_require__(1991).f;
var createMethod = function(TO_ENTRIES) {
  return function(it) {
    var O = toIndexedObject(it);
    var keys = objectKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) {
      key = keys[i++];
      if (!DESCRIPTORS || propertyIsEnumerable.call(O, key)) {
        result.push(TO_ENTRIES ? [key, O[key]] : O[key]);
      }
    }
    return result;
  };
};
module.exports = {
  entries: createMethod(true),
  values: createMethod(false)
};


/***/ }),

/***/ 9766:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var TO_STRING_TAG_SUPPORT = __webpack_require__(8779);
var classof = __webpack_require__(4605);
module.exports = TO_STRING_TAG_SUPPORT ? {}.toString : function toString() {
  return "[object " + classof(this) + "]";
};


/***/ }),

/***/ 2667:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(5408);
var getOwnPropertyNamesModule = __webpack_require__(8265);
var getOwnPropertySymbolsModule = __webpack_require__(258);
var anObject = __webpack_require__(5675);
module.exports = getBuiltIn("Reflect", "ownKeys") || function ownKeys(it) {
  var keys = getOwnPropertyNamesModule.f(anObject(it));
  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
};


/***/ }),

/***/ 7698:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
module.exports = global;


/***/ }),

/***/ 4787:
/***/ ((module) => {

module.exports = function(exec) {
  try {
    return {error: false, value: exec()};
  } catch (error) {
    return {error: true, value: error};
  }
};


/***/ }),

/***/ 3736:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var isObject = __webpack_require__(4963);
var newPromiseCapability = __webpack_require__(6335);
module.exports = function(C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C)
    return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),

/***/ 1557:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var redefine = __webpack_require__(2573);
module.exports = function(target, src, options) {
  for (var key in src)
    redefine(target, key, src[key], options);
  return target;
};


/***/ }),

/***/ 2573:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var createNonEnumerableProperty = __webpack_require__(9465);
var has = __webpack_require__(2450);
var setGlobal = __webpack_require__(8140);
var inspectSource = __webpack_require__(2549);
var InternalStateModule = __webpack_require__(7125);
var getInternalState = InternalStateModule.get;
var enforceInternalState = InternalStateModule.enforce;
var TEMPLATE = String(String).split("String");
(module.exports = function(O, key, value, options) {
  var unsafe = options ? !!options.unsafe : false;
  var simple = options ? !!options.enumerable : false;
  var noTargetGet = options ? !!options.noTargetGet : false;
  var state;
  if (typeof value == "function") {
    if (typeof key == "string" && !has(value, "name")) {
      createNonEnumerableProperty(value, "name", key);
    }
    state = enforceInternalState(value);
    if (!state.source) {
      state.source = TEMPLATE.join(typeof key == "string" ? key : "");
    }
  }
  if (O === global) {
    if (simple)
      O[key] = value;
    else
      setGlobal(key, value);
    return;
  } else if (!unsafe) {
    delete O[key];
  } else if (!noTargetGet && O[key]) {
    simple = true;
  }
  if (simple)
    O[key] = value;
  else
    createNonEnumerableProperty(O, key, value);
})(Function.prototype, "toString", function toString() {
  return typeof this == "function" && getInternalState(this).source || inspectSource(this);
});


/***/ }),

/***/ 9191:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(1409);
var regexpExec = __webpack_require__(9403);
module.exports = function(R, S) {
  var exec = R.exec;
  if (typeof exec === "function") {
    var result = exec.call(R, S);
    if (typeof result !== "object") {
      throw TypeError("RegExp exec method returned something other than an Object or null");
    }
    return result;
  }
  if (classof(R) !== "RegExp") {
    throw TypeError("RegExp#exec called on incompatible receiver");
  }
  return regexpExec.call(R, S);
};


/***/ }),

/***/ 9403:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var regexpFlags = __webpack_require__(565);
var stickyHelpers = __webpack_require__(1986);
var shared = __webpack_require__(6895);
var nativeExec = RegExp.prototype.exec;
var nativeReplace = shared("native-string-replace", String.prototype.replace);
var patchedExec = nativeExec;
var UPDATES_LAST_INDEX_WRONG = function() {
  var re1 = /a/;
  var re2 = /b*/g;
  nativeExec.call(re1, "a");
  nativeExec.call(re2, "a");
  return re1.lastIndex !== 0 || re2.lastIndex !== 0;
}();
var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y || stickyHelpers.BROKEN_CARET;
var NPCG_INCLUDED = /()??/.exec("")[1] !== void 0;
var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y;
if (PATCH) {
  patchedExec = function exec(str) {
    var re = this;
    var lastIndex, reCopy, match, i;
    var sticky = UNSUPPORTED_Y && re.sticky;
    var flags = regexpFlags.call(re);
    var source = re.source;
    var charsAdded = 0;
    var strCopy = str;
    if (sticky) {
      flags = flags.replace("y", "");
      if (flags.indexOf("g") === -1) {
        flags += "g";
      }
      strCopy = String(str).slice(re.lastIndex);
      if (re.lastIndex > 0 && (!re.multiline || re.multiline && str[re.lastIndex - 1] !== "\n")) {
        source = "(?: " + source + ")";
        strCopy = " " + strCopy;
        charsAdded++;
      }
      reCopy = new RegExp("^(?:" + source + ")", flags);
    }
    if (NPCG_INCLUDED) {
      reCopy = new RegExp("^" + source + "$(?!\\s)", flags);
    }
    if (UPDATES_LAST_INDEX_WRONG)
      lastIndex = re.lastIndex;
    match = nativeExec.call(sticky ? reCopy : re, strCopy);
    if (sticky) {
      if (match) {
        match.input = match.input.slice(charsAdded);
        match[0] = match[0].slice(charsAdded);
        match.index = re.lastIndex;
        re.lastIndex += match[0].length;
      } else
        re.lastIndex = 0;
    } else if (UPDATES_LAST_INDEX_WRONG && match) {
      re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
    }
    if (NPCG_INCLUDED && match && match.length > 1) {
      nativeReplace.call(match[0], reCopy, function() {
        for (i = 1; i < arguments.length - 2; i++) {
          if (arguments[i] === void 0)
            match[i] = void 0;
        }
      });
    }
    return match;
  };
}
module.exports = patchedExec;


/***/ }),

/***/ 565:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var anObject = __webpack_require__(5675);
module.exports = function() {
  var that = anObject(this);
  var result = "";
  if (that.global)
    result += "g";
  if (that.ignoreCase)
    result += "i";
  if (that.multiline)
    result += "m";
  if (that.dotAll)
    result += "s";
  if (that.unicode)
    result += "u";
  if (that.sticky)
    result += "y";
  return result;
};


/***/ }),

/***/ 1986:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

var fails = __webpack_require__(3665);
function RE(s, f) {
  return RegExp(s, f);
}
exports.UNSUPPORTED_Y = fails(function() {
  var re = RE("a", "y");
  re.lastIndex = 2;
  return re.exec("abcd") != null;
});
exports.BROKEN_CARET = fails(function() {
  var re = RE("^r", "gy");
  re.lastIndex = 2;
  return re.exec("str") != null;
});


/***/ }),

/***/ 6213:
/***/ ((module) => {

module.exports = function(it) {
  if (it == void 0)
    throw TypeError("Can't call method on " + it);
  return it;
};


/***/ }),

/***/ 8140:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var createNonEnumerableProperty = __webpack_require__(9465);
module.exports = function(key, value) {
  try {
    createNonEnumerableProperty(global, key, value);
  } catch (error) {
    global[key] = value;
  }
  return value;
};


/***/ }),

/***/ 68:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var getBuiltIn = __webpack_require__(5408);
var definePropertyModule = __webpack_require__(2826);
var wellKnownSymbol = __webpack_require__(4354);
var DESCRIPTORS = __webpack_require__(582);
var SPECIES = wellKnownSymbol("species");
module.exports = function(CONSTRUCTOR_NAME) {
  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
  var defineProperty = definePropertyModule.f;
  if (DESCRIPTORS && Constructor && !Constructor[SPECIES]) {
    defineProperty(Constructor, SPECIES, {
      configurable: true,
      get: function() {
        return this;
      }
    });
  }
};


/***/ }),

/***/ 8907:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var defineProperty = __webpack_require__(2826).f;
var has = __webpack_require__(2450);
var wellKnownSymbol = __webpack_require__(4354);
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
module.exports = function(it, TAG, STATIC) {
  if (it && !has(it = STATIC ? it : it.prototype, TO_STRING_TAG)) {
    defineProperty(it, TO_STRING_TAG, {configurable: true, value: TAG});
  }
};


/***/ }),

/***/ 7429:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var shared = __webpack_require__(6895);
var uid = __webpack_require__(657);
var keys = shared("keys");
module.exports = function(key) {
  return keys[key] || (keys[key] = uid(key));
};


/***/ }),

/***/ 5204:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var setGlobal = __webpack_require__(8140);
var SHARED = "__core-js_shared__";
var store = global[SHARED] || setGlobal(SHARED, {});
module.exports = store;


/***/ }),

/***/ 6895:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var IS_PURE = __webpack_require__(726);
var store = __webpack_require__(5204);
(module.exports = function(key, value) {
  return store[key] || (store[key] = value !== void 0 ? value : {});
})("versions", []).push({
  version: "3.10.0",
  mode: IS_PURE ? "pure" : "global",
  copyright: "\xA9 2021 Denis Pushkarev (zloirock.ru)"
});


/***/ }),

/***/ 5523:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(5675);
var aFunction = __webpack_require__(1758);
var wellKnownSymbol = __webpack_require__(4354);
var SPECIES = wellKnownSymbol("species");
module.exports = function(O, defaultConstructor) {
  var C = anObject(O).constructor;
  var S;
  return C === void 0 || (S = anObject(C)[SPECIES]) == void 0 ? defaultConstructor : aFunction(S);
};


/***/ }),

/***/ 9239:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
module.exports = function(METHOD_NAME) {
  return fails(function() {
    var test = ""[METHOD_NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  });
};


/***/ }),

/***/ 9209:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toInteger = __webpack_require__(2983);
var requireObjectCoercible = __webpack_require__(6213);
var createMethod = function(CONVERT_TO_STRING) {
  return function($this, pos) {
    var S = String(requireObjectCoercible($this));
    var position = toInteger(pos);
    var size = S.length;
    var first, second;
    if (position < 0 || position >= size)
      return CONVERT_TO_STRING ? "" : void 0;
    first = S.charCodeAt(position);
    return first < 55296 || first > 56319 || position + 1 === size || (second = S.charCodeAt(position + 1)) < 56320 || second > 57343 ? CONVERT_TO_STRING ? S.charAt(position) : first : CONVERT_TO_STRING ? S.slice(position, position + 2) : (first - 55296 << 10) + (second - 56320) + 65536;
  };
};
module.exports = {
  codeAt: createMethod(false),
  charAt: createMethod(true)
};


/***/ }),

/***/ 7329:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(3665);
var whitespaces = __webpack_require__(2867);
var non = "\u200B\x85\u180E";
module.exports = function(METHOD_NAME) {
  return fails(function() {
    return !!whitespaces[METHOD_NAME]() || non[METHOD_NAME]() != non || whitespaces[METHOD_NAME].name !== METHOD_NAME;
  });
};


/***/ }),

/***/ 2188:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var requireObjectCoercible = __webpack_require__(6213);
var whitespaces = __webpack_require__(2867);
var whitespace = "[" + whitespaces + "]";
var ltrim = RegExp("^" + whitespace + whitespace + "*");
var rtrim = RegExp(whitespace + whitespace + "*$");
var createMethod = function(TYPE) {
  return function($this) {
    var string = String(requireObjectCoercible($this));
    if (TYPE & 1)
      string = string.replace(ltrim, "");
    if (TYPE & 2)
      string = string.replace(rtrim, "");
    return string;
  };
};
module.exports = {
  start: createMethod(1),
  end: createMethod(2),
  trim: createMethod(3)
};


/***/ }),

/***/ 6195:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var fails = __webpack_require__(3665);
var bind = __webpack_require__(3754);
var html = __webpack_require__(5881);
var createElement = __webpack_require__(7249);
var IS_IOS = __webpack_require__(241);
var IS_NODE = __webpack_require__(779);
var location = global.location;
var set = global.setImmediate;
var clear = global.clearImmediate;
var process = global.process;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = "onreadystatechange";
var defer, channel, port;
var run = function(id) {
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var runner = function(id) {
  return function() {
    run(id);
  };
};
var listener = function(event) {
  run(event.data);
};
var post = function(id) {
  global.postMessage(id + "", location.protocol + "//" + location.host);
};
if (!set || !clear) {
  set = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i)
      args.push(arguments[i++]);
    queue[++counter] = function() {
      (typeof fn == "function" ? fn : Function(fn)).apply(void 0, args);
    };
    defer(counter);
    return counter;
  };
  clear = function clearImmediate(id) {
    delete queue[id];
  };
  if (IS_NODE) {
    defer = function(id) {
      process.nextTick(runner(id));
    };
  } else if (Dispatch && Dispatch.now) {
    defer = function(id) {
      Dispatch.now(runner(id));
    };
  } else if (MessageChannel && !IS_IOS) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = bind(port.postMessage, port, 1);
  } else if (global.addEventListener && typeof postMessage == "function" && !global.importScripts && location && location.protocol !== "file:" && !fails(post)) {
    defer = post;
    global.addEventListener("message", listener, false);
  } else if (ONREADYSTATECHANGE in createElement("script")) {
    defer = function(id) {
      html.appendChild(createElement("script"))[ONREADYSTATECHANGE] = function() {
        html.removeChild(this);
        run(id);
      };
    };
  } else {
    defer = function(id) {
      setTimeout(runner(id), 0);
    };
  }
}
module.exports = {
  set,
  clear
};


/***/ }),

/***/ 4052:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toInteger = __webpack_require__(2983);
var max = Math.max;
var min = Math.min;
module.exports = function(index, length) {
  var integer = toInteger(index);
  return integer < 0 ? max(integer + length, 0) : min(integer, length);
};


/***/ }),

/***/ 4362:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var IndexedObject = __webpack_require__(5940);
var requireObjectCoercible = __webpack_require__(6213);
module.exports = function(it) {
  return IndexedObject(requireObjectCoercible(it));
};


/***/ }),

/***/ 2983:
/***/ ((module) => {

var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function(argument) {
  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor : ceil)(argument);
};


/***/ }),

/***/ 9944:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toInteger = __webpack_require__(2983);
var min = Math.min;
module.exports = function(argument) {
  return argument > 0 ? min(toInteger(argument), 9007199254740991) : 0;
};


/***/ }),

/***/ 1734:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var requireObjectCoercible = __webpack_require__(6213);
module.exports = function(argument) {
  return Object(requireObjectCoercible(argument));
};


/***/ }),

/***/ 7197:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(4963);
module.exports = function(input, PREFERRED_STRING) {
  if (!isObject(input))
    return input;
  var fn, val;
  if (PREFERRED_STRING && typeof (fn = input.toString) == "function" && !isObject(val = fn.call(input)))
    return val;
  if (typeof (fn = input.valueOf) == "function" && !isObject(val = fn.call(input)))
    return val;
  if (!PREFERRED_STRING && typeof (fn = input.toString) == "function" && !isObject(val = fn.call(input)))
    return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),

/***/ 8779:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(4354);
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var test = {};
test[TO_STRING_TAG] = "z";
module.exports = String(test) === "[object z]";


/***/ }),

/***/ 657:
/***/ ((module) => {

var id = 0;
var postfix = Math.random();
module.exports = function(key) {
  return "Symbol(" + String(key === void 0 ? "" : key) + ")_" + (++id + postfix).toString(36);
};


/***/ }),

/***/ 1057:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_SYMBOL = __webpack_require__(2726);
module.exports = NATIVE_SYMBOL && !Symbol.sham && typeof Symbol.iterator == "symbol";


/***/ }),

/***/ 4354:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var shared = __webpack_require__(6895);
var has = __webpack_require__(2450);
var uid = __webpack_require__(657);
var NATIVE_SYMBOL = __webpack_require__(2726);
var USE_SYMBOL_AS_UID = __webpack_require__(1057);
var WellKnownSymbolsStore = shared("wks");
var Symbol = global.Symbol;
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol : Symbol && Symbol.withoutSetter || uid;
module.exports = function(name) {
  if (!has(WellKnownSymbolsStore, name) || !(NATIVE_SYMBOL || typeof WellKnownSymbolsStore[name] == "string")) {
    if (NATIVE_SYMBOL && has(Symbol, name)) {
      WellKnownSymbolsStore[name] = Symbol[name];
    } else {
      WellKnownSymbolsStore[name] = createWellKnownSymbol("Symbol." + name);
    }
  }
  return WellKnownSymbolsStore[name];
};


/***/ }),

/***/ 2867:
/***/ ((module) => {

module.exports = "	\n\v\f\r \xA0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF";


/***/ }),

/***/ 6091:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var fails = __webpack_require__(3665);
var isArray = __webpack_require__(4548);
var isObject = __webpack_require__(4963);
var toObject = __webpack_require__(1734);
var toLength = __webpack_require__(9944);
var createProperty = __webpack_require__(9246);
var arraySpeciesCreate = __webpack_require__(6523);
var arrayMethodHasSpeciesSupport = __webpack_require__(2014);
var wellKnownSymbol = __webpack_require__(4354);
var V8_VERSION = __webpack_require__(9470);
var IS_CONCAT_SPREADABLE = wellKnownSymbol("isConcatSpreadable");
var MAX_SAFE_INTEGER = 9007199254740991;
var MAXIMUM_ALLOWED_INDEX_EXCEEDED = "Maximum allowed index exceeded";
var IS_CONCAT_SPREADABLE_SUPPORT = V8_VERSION >= 51 || !fails(function() {
  var array = [];
  array[IS_CONCAT_SPREADABLE] = false;
  return array.concat()[0] !== array;
});
var SPECIES_SUPPORT = arrayMethodHasSpeciesSupport("concat");
var isConcatSpreadable = function(O) {
  if (!isObject(O))
    return false;
  var spreadable = O[IS_CONCAT_SPREADABLE];
  return spreadable !== void 0 ? !!spreadable : isArray(O);
};
var FORCED = !IS_CONCAT_SPREADABLE_SUPPORT || !SPECIES_SUPPORT;
$({target: "Array", proto: true, forced: FORCED}, {
  concat: function concat(arg) {
    var O = toObject(this);
    var A = arraySpeciesCreate(O, 0);
    var n = 0;
    var i, k, length, len, E;
    for (i = -1, length = arguments.length; i < length; i++) {
      E = i === -1 ? O : arguments[i];
      if (isConcatSpreadable(E)) {
        len = toLength(E.length);
        if (n + len > MAX_SAFE_INTEGER)
          throw TypeError(MAXIMUM_ALLOWED_INDEX_EXCEEDED);
        for (k = 0; k < len; k++, n++)
          if (k in E)
            createProperty(A, n, E[k]);
      } else {
        if (n >= MAX_SAFE_INTEGER)
          throw TypeError(MAXIMUM_ALLOWED_INDEX_EXCEEDED);
        createProperty(A, n++, E);
      }
    }
    A.length = n;
    return A;
  }
});


/***/ }),

/***/ 520:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $filter = __webpack_require__(8184).filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(2014);
var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport("filter");
$({target: "Array", proto: true, forced: !HAS_SPECIES_SUPPORT}, {
  filter: function filter(callbackfn) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : void 0);
  }
});


/***/ }),

/***/ 6849:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $findIndex = __webpack_require__(8184).findIndex;
var addToUnscopables = __webpack_require__(4164);
var FIND_INDEX = "findIndex";
var SKIPS_HOLES = true;
if (FIND_INDEX in [])
  Array(1)[FIND_INDEX](function() {
    SKIPS_HOLES = false;
  });
$({target: "Array", proto: true, forced: SKIPS_HOLES}, {
  findIndex: function findIndex(callbackfn) {
    return $findIndex(this, callbackfn, arguments.length > 1 ? arguments[1] : void 0);
  }
});
addToUnscopables(FIND_INDEX);


/***/ }),

/***/ 1362:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $find = __webpack_require__(8184).find;
var addToUnscopables = __webpack_require__(4164);
var FIND = "find";
var SKIPS_HOLES = true;
if (FIND in [])
  Array(1)[FIND](function() {
    SKIPS_HOLES = false;
  });
$({target: "Array", proto: true, forced: SKIPS_HOLES}, {
  find: function find(callbackfn) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : void 0);
  }
});
addToUnscopables(FIND);


/***/ }),

/***/ 2945:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(3298);
var from = __webpack_require__(992);
var checkCorrectnessOfIteration = __webpack_require__(8158);
var INCORRECT_ITERATION = !checkCorrectnessOfIteration(function(iterable) {
  Array.from(iterable);
});
$({target: "Array", stat: true, forced: INCORRECT_ITERATION}, {
  from
});


/***/ }),

/***/ 6654:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $includes = __webpack_require__(8170).includes;
var addToUnscopables = __webpack_require__(4164);
$({target: "Array", proto: true}, {
  includes: function includes(el) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : void 0);
  }
});
addToUnscopables("includes");


/***/ }),

/***/ 5860:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $indexOf = __webpack_require__(8170).indexOf;
var arrayMethodIsStrict = __webpack_require__(2759);
var nativeIndexOf = [].indexOf;
var NEGATIVE_ZERO = !!nativeIndexOf && 1 / [1].indexOf(1, -0) < 0;
var STRICT_METHOD = arrayMethodIsStrict("indexOf");
$({target: "Array", proto: true, forced: NEGATIVE_ZERO || !STRICT_METHOD}, {
  indexOf: function indexOf(searchElement) {
    return NEGATIVE_ZERO ? nativeIndexOf.apply(this, arguments) || 0 : $indexOf(this, searchElement, arguments.length > 1 ? arguments[1] : void 0);
  }
});


/***/ }),

/***/ 4185:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var toIndexedObject = __webpack_require__(4362);
var addToUnscopables = __webpack_require__(4164);
var Iterators = __webpack_require__(2341);
var InternalStateModule = __webpack_require__(7125);
var defineIterator = __webpack_require__(7499);
var ARRAY_ITERATOR = "Array Iterator";
var setInternalState = InternalStateModule.set;
var getInternalState = InternalStateModule.getterFor(ARRAY_ITERATOR);
module.exports = defineIterator(Array, "Array", function(iterated, kind) {
  setInternalState(this, {
    type: ARRAY_ITERATOR,
    target: toIndexedObject(iterated),
    index: 0,
    kind
  });
}, function() {
  var state = getInternalState(this);
  var target = state.target;
  var kind = state.kind;
  var index = state.index++;
  if (!target || index >= target.length) {
    state.target = void 0;
    return {value: void 0, done: true};
  }
  if (kind == "keys")
    return {value: index, done: false};
  if (kind == "values")
    return {value: target[index], done: false};
  return {value: [index, target[index]], done: false};
}, "values");
Iterators.Arguments = Iterators.Array;
addToUnscopables("keys");
addToUnscopables("values");
addToUnscopables("entries");


/***/ }),

/***/ 3070:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var IndexedObject = __webpack_require__(5940);
var toIndexedObject = __webpack_require__(4362);
var arrayMethodIsStrict = __webpack_require__(2759);
var nativeJoin = [].join;
var ES3_STRINGS = IndexedObject != Object;
var STRICT_METHOD = arrayMethodIsStrict("join", ",");
$({target: "Array", proto: true, forced: ES3_STRINGS || !STRICT_METHOD}, {
  join: function join(separator) {
    return nativeJoin.call(toIndexedObject(this), separator === void 0 ? "," : separator);
  }
});


/***/ }),

/***/ 8381:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $map = __webpack_require__(8184).map;
var arrayMethodHasSpeciesSupport = __webpack_require__(2014);
var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport("map");
$({target: "Array", proto: true, forced: !HAS_SPECIES_SUPPORT}, {
  map: function map(callbackfn) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : void 0);
  }
});


/***/ }),

/***/ 6306:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $reduce = __webpack_require__(8575).left;
var arrayMethodIsStrict = __webpack_require__(2759);
var CHROME_VERSION = __webpack_require__(9470);
var IS_NODE = __webpack_require__(779);
var STRICT_METHOD = arrayMethodIsStrict("reduce");
var CHROME_BUG = !IS_NODE && CHROME_VERSION > 79 && CHROME_VERSION < 83;
$({target: "Array", proto: true, forced: !STRICT_METHOD || CHROME_BUG}, {
  reduce: function reduce(callbackfn) {
    return $reduce(this, callbackfn, arguments.length, arguments.length > 1 ? arguments[1] : void 0);
  }
});


/***/ }),

/***/ 8731:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var isArray = __webpack_require__(4548);
var nativeReverse = [].reverse;
var test = [1, 2];
$({target: "Array", proto: true, forced: String(test) === String(test.reverse())}, {
  reverse: function reverse() {
    if (isArray(this))
      this.length = this.length;
    return nativeReverse.call(this);
  }
});


/***/ }),

/***/ 9043:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var isObject = __webpack_require__(4963);
var isArray = __webpack_require__(4548);
var toAbsoluteIndex = __webpack_require__(4052);
var toLength = __webpack_require__(9944);
var toIndexedObject = __webpack_require__(4362);
var createProperty = __webpack_require__(9246);
var wellKnownSymbol = __webpack_require__(4354);
var arrayMethodHasSpeciesSupport = __webpack_require__(2014);
var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport("slice");
var SPECIES = wellKnownSymbol("species");
var nativeSlice = [].slice;
var max = Math.max;
$({target: "Array", proto: true, forced: !HAS_SPECIES_SUPPORT}, {
  slice: function slice(start, end) {
    var O = toIndexedObject(this);
    var length = toLength(O.length);
    var k = toAbsoluteIndex(start, length);
    var fin = toAbsoluteIndex(end === void 0 ? length : end, length);
    var Constructor, result, n;
    if (isArray(O)) {
      Constructor = O.constructor;
      if (typeof Constructor == "function" && (Constructor === Array || isArray(Constructor.prototype))) {
        Constructor = void 0;
      } else if (isObject(Constructor)) {
        Constructor = Constructor[SPECIES];
        if (Constructor === null)
          Constructor = void 0;
      }
      if (Constructor === Array || Constructor === void 0) {
        return nativeSlice.call(O, k, fin);
      }
    }
    result = new (Constructor === void 0 ? Array : Constructor)(max(fin - k, 0));
    for (n = 0; k < fin; k++, n++)
      if (k in O)
        createProperty(result, n, O[k]);
    result.length = n;
    return result;
  }
});


/***/ }),

/***/ 5042:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var aFunction = __webpack_require__(1758);
var toObject = __webpack_require__(1734);
var fails = __webpack_require__(3665);
var arrayMethodIsStrict = __webpack_require__(2759);
var test = [];
var nativeSort = test.sort;
var FAILS_ON_UNDEFINED = fails(function() {
  test.sort(void 0);
});
var FAILS_ON_NULL = fails(function() {
  test.sort(null);
});
var STRICT_METHOD = arrayMethodIsStrict("sort");
var FORCED = FAILS_ON_UNDEFINED || !FAILS_ON_NULL || !STRICT_METHOD;
$({target: "Array", proto: true, forced: FORCED}, {
  sort: function sort(comparefn) {
    return comparefn === void 0 ? nativeSort.call(toObject(this)) : nativeSort.call(toObject(this), aFunction(comparefn));
  }
});


/***/ }),

/***/ 4348:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var toAbsoluteIndex = __webpack_require__(4052);
var toInteger = __webpack_require__(2983);
var toLength = __webpack_require__(9944);
var toObject = __webpack_require__(1734);
var arraySpeciesCreate = __webpack_require__(6523);
var createProperty = __webpack_require__(9246);
var arrayMethodHasSpeciesSupport = __webpack_require__(2014);
var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport("splice");
var max = Math.max;
var min = Math.min;
var MAX_SAFE_INTEGER = 9007199254740991;
var MAXIMUM_ALLOWED_LENGTH_EXCEEDED = "Maximum allowed length exceeded";
$({target: "Array", proto: true, forced: !HAS_SPECIES_SUPPORT}, {
  splice: function splice(start, deleteCount) {
    var O = toObject(this);
    var len = toLength(O.length);
    var actualStart = toAbsoluteIndex(start, len);
    var argumentsLength = arguments.length;
    var insertCount, actualDeleteCount, A, k, from, to;
    if (argumentsLength === 0) {
      insertCount = actualDeleteCount = 0;
    } else if (argumentsLength === 1) {
      insertCount = 0;
      actualDeleteCount = len - actualStart;
    } else {
      insertCount = argumentsLength - 2;
      actualDeleteCount = min(max(toInteger(deleteCount), 0), len - actualStart);
    }
    if (len + insertCount - actualDeleteCount > MAX_SAFE_INTEGER) {
      throw TypeError(MAXIMUM_ALLOWED_LENGTH_EXCEEDED);
    }
    A = arraySpeciesCreate(O, actualDeleteCount);
    for (k = 0; k < actualDeleteCount; k++) {
      from = actualStart + k;
      if (from in O)
        createProperty(A, k, O[from]);
    }
    A.length = actualDeleteCount;
    if (insertCount < actualDeleteCount) {
      for (k = actualStart; k < len - actualDeleteCount; k++) {
        from = k + actualDeleteCount;
        to = k + insertCount;
        if (from in O)
          O[to] = O[from];
        else
          delete O[to];
      }
      for (k = len; k > len - actualDeleteCount + insertCount; k--)
        delete O[k - 1];
    } else if (insertCount > actualDeleteCount) {
      for (k = len - actualDeleteCount; k > actualStart; k--) {
        from = k + actualDeleteCount - 1;
        to = k + insertCount - 1;
        if (from in O)
          O[to] = O[from];
        else
          delete O[to];
      }
    }
    for (k = 0; k < insertCount; k++) {
      O[k + actualStart] = arguments[k + 2];
    }
    O.length = len - actualDeleteCount + insertCount;
    return A;
  }
});


/***/ }),

/***/ 225:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var defineProperty = __webpack_require__(2826).f;
var FunctionPrototype = Function.prototype;
var FunctionPrototypeToString = FunctionPrototype.toString;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = "name";
if (DESCRIPTORS && !(NAME in FunctionPrototype)) {
  defineProperty(FunctionPrototype, NAME, {
    configurable: true,
    get: function() {
      try {
        return FunctionPrototypeToString.call(this).match(nameRE)[1];
      } catch (error) {
        return "";
      }
    }
  });
}


/***/ }),

/***/ 47:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var collection = __webpack_require__(468);
var collectionStrong = __webpack_require__(6787);
module.exports = collection("Map", function(init) {
  return function Map() {
    return init(this, arguments.length ? arguments[0] : void 0);
  };
}, collectionStrong);


/***/ }),

/***/ 5812:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var DESCRIPTORS = __webpack_require__(582);
var global = __webpack_require__(5215);
var isForced = __webpack_require__(7315);
var redefine = __webpack_require__(2573);
var has = __webpack_require__(2450);
var classof = __webpack_require__(1409);
var inheritIfRequired = __webpack_require__(9427);
var toPrimitive = __webpack_require__(7197);
var fails = __webpack_require__(3665);
var create = __webpack_require__(6474);
var getOwnPropertyNames = __webpack_require__(8265).f;
var getOwnPropertyDescriptor = __webpack_require__(7599).f;
var defineProperty = __webpack_require__(2826).f;
var trim = __webpack_require__(2188).trim;
var NUMBER = "Number";
var NativeNumber = global[NUMBER];
var NumberPrototype = NativeNumber.prototype;
var BROKEN_CLASSOF = classof(create(NumberPrototype)) == NUMBER;
var toNumber = function(argument) {
  var it = toPrimitive(argument, false);
  var first, third, radix, maxCode, digits, length, index, code;
  if (typeof it == "string" && it.length > 2) {
    it = trim(it);
    first = it.charCodeAt(0);
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120)
        return NaN;
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66:
        case 98:
          radix = 2;
          maxCode = 49;
          break;
        case 79:
        case 111:
          radix = 8;
          maxCode = 55;
          break;
        default:
          return +it;
      }
      digits = it.slice(2);
      length = digits.length;
      for (index = 0; index < length; index++) {
        code = digits.charCodeAt(index);
        if (code < 48 || code > maxCode)
          return NaN;
      }
      return parseInt(digits, radix);
    }
  }
  return +it;
};
if (isForced(NUMBER, !NativeNumber(" 0o1") || !NativeNumber("0b1") || NativeNumber("+0x1"))) {
  var NumberWrapper = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var dummy = this;
    return dummy instanceof NumberWrapper && (BROKEN_CLASSOF ? fails(function() {
      NumberPrototype.valueOf.call(dummy);
    }) : classof(dummy) != NUMBER) ? inheritIfRequired(new NativeNumber(toNumber(it)), dummy, NumberWrapper) : toNumber(it);
  };
  for (var keys = DESCRIPTORS ? getOwnPropertyNames(NativeNumber) : "MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger,fromString,range".split(","), j = 0, key; keys.length > j; j++) {
    if (has(NativeNumber, key = keys[j]) && !has(NumberWrapper, key)) {
      defineProperty(NumberWrapper, key, getOwnPropertyDescriptor(NativeNumber, key));
    }
  }
  NumberWrapper.prototype = NumberPrototype;
  NumberPrototype.constructor = NumberWrapper;
  redefine(global, NUMBER, NumberWrapper);
}


/***/ }),

/***/ 5982:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(3298);
var $entries = __webpack_require__(3004).entries;
$({target: "Object", stat: true}, {
  entries: function entries(O) {
    return $entries(O);
  }
});


/***/ }),

/***/ 5496:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(3298);
var fails = __webpack_require__(3665);
var isObject = __webpack_require__(4963);
var $isFrozen = Object.isFrozen;
var FAILS_ON_PRIMITIVES = fails(function() {
  $isFrozen(1);
});
$({target: "Object", stat: true, forced: FAILS_ON_PRIMITIVES}, {
  isFrozen: function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  }
});


/***/ }),

/***/ 2478:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(3298);
var toObject = __webpack_require__(1734);
var nativeKeys = __webpack_require__(4944);
var fails = __webpack_require__(3665);
var FAILS_ON_PRIMITIVES = fails(function() {
  nativeKeys(1);
});
$({target: "Object", stat: true, forced: FAILS_ON_PRIMITIVES}, {
  keys: function keys(it) {
    return nativeKeys(toObject(it));
  }
});


/***/ }),

/***/ 4565:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var TO_STRING_TAG_SUPPORT = __webpack_require__(8779);
var redefine = __webpack_require__(2573);
var toString = __webpack_require__(9766);
if (!TO_STRING_TAG_SUPPORT) {
  redefine(Object.prototype, "toString", toString, {unsafe: true});
}


/***/ }),

/***/ 8599:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var IS_PURE = __webpack_require__(726);
var global = __webpack_require__(5215);
var getBuiltIn = __webpack_require__(5408);
var NativePromise = __webpack_require__(9846);
var redefine = __webpack_require__(2573);
var redefineAll = __webpack_require__(1557);
var setToStringTag = __webpack_require__(8907);
var setSpecies = __webpack_require__(68);
var isObject = __webpack_require__(4963);
var aFunction = __webpack_require__(1758);
var anInstance = __webpack_require__(7089);
var inspectSource = __webpack_require__(2549);
var iterate = __webpack_require__(9682);
var checkCorrectnessOfIteration = __webpack_require__(8158);
var speciesConstructor = __webpack_require__(5523);
var task = __webpack_require__(6195).set;
var microtask = __webpack_require__(5650);
var promiseResolve = __webpack_require__(3736);
var hostReportErrors = __webpack_require__(9506);
var newPromiseCapabilityModule = __webpack_require__(6335);
var perform = __webpack_require__(4787);
var InternalStateModule = __webpack_require__(7125);
var isForced = __webpack_require__(7315);
var wellKnownSymbol = __webpack_require__(4354);
var IS_NODE = __webpack_require__(779);
var V8_VERSION = __webpack_require__(9470);
var SPECIES = wellKnownSymbol("species");
var PROMISE = "Promise";
var getInternalState = InternalStateModule.get;
var setInternalState = InternalStateModule.set;
var getInternalPromiseState = InternalStateModule.getterFor(PROMISE);
var PromiseConstructor = NativePromise;
var TypeError = global.TypeError;
var document = global.document;
var process = global.process;
var $fetch = getBuiltIn("fetch");
var newPromiseCapability = newPromiseCapabilityModule.f;
var newGenericPromiseCapability = newPromiseCapability;
var DISPATCH_EVENT = !!(document && document.createEvent && global.dispatchEvent);
var NATIVE_REJECTION_EVENT = typeof PromiseRejectionEvent == "function";
var UNHANDLED_REJECTION = "unhandledrejection";
var REJECTION_HANDLED = "rejectionhandled";
var PENDING = 0;
var FULFILLED = 1;
var REJECTED = 2;
var HANDLED = 1;
var UNHANDLED = 2;
var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;
var FORCED = isForced(PROMISE, function() {
  var GLOBAL_CORE_JS_PROMISE = inspectSource(PromiseConstructor) !== String(PromiseConstructor);
  if (!GLOBAL_CORE_JS_PROMISE) {
    if (V8_VERSION === 66)
      return true;
    if (!IS_NODE && !NATIVE_REJECTION_EVENT)
      return true;
  }
  if (IS_PURE && !PromiseConstructor.prototype["finally"])
    return true;
  if (V8_VERSION >= 51 && /native code/.test(PromiseConstructor))
    return false;
  var promise = PromiseConstructor.resolve(1);
  var FakePromise = function(exec) {
    exec(function() {
    }, function() {
    });
  };
  var constructor = promise.constructor = {};
  constructor[SPECIES] = FakePromise;
  return !(promise.then(function() {
  }) instanceof FakePromise);
});
var INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function(iterable) {
  PromiseConstructor.all(iterable)["catch"](function() {
  });
});
var isThenable = function(it) {
  var then;
  return isObject(it) && typeof (then = it.then) == "function" ? then : false;
};
var notify = function(state, isReject) {
  if (state.notified)
    return;
  state.notified = true;
  var chain = state.reactions;
  microtask(function() {
    var value = state.value;
    var ok = state.state == FULFILLED;
    var index = 0;
    while (chain.length > index) {
      var reaction = chain[index++];
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve2 = reaction.resolve;
      var reject2 = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (state.rejection === UNHANDLED)
              onHandleUnhandled(state);
            state.rejection = HANDLED;
          }
          if (handler === true)
            result = value;
          else {
            if (domain)
              domain.enter();
            result = handler(value);
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject2(TypeError("Promise-chain cycle"));
          } else if (then = isThenable(result)) {
            then.call(result, resolve2, reject2);
          } else
            resolve2(result);
        } else
          reject2(value);
      } catch (error) {
        if (domain && !exited)
          domain.exit();
        reject2(error);
      }
    }
    state.reactions = [];
    state.notified = false;
    if (isReject && !state.rejection)
      onUnhandled(state);
  });
};
var dispatchEvent = function(name, promise, reason) {
  var event, handler;
  if (DISPATCH_EVENT) {
    event = document.createEvent("Event");
    event.promise = promise;
    event.reason = reason;
    event.initEvent(name, false, true);
    global.dispatchEvent(event);
  } else
    event = {promise, reason};
  if (!NATIVE_REJECTION_EVENT && (handler = global["on" + name]))
    handler(event);
  else if (name === UNHANDLED_REJECTION)
    hostReportErrors("Unhandled promise rejection", reason);
};
var onUnhandled = function(state) {
  task.call(global, function() {
    var promise = state.facade;
    var value = state.value;
    var IS_UNHANDLED = isUnhandled(state);
    var result;
    if (IS_UNHANDLED) {
      result = perform(function() {
        if (IS_NODE) {
          process.emit("unhandledRejection", value, promise);
        } else
          dispatchEvent(UNHANDLED_REJECTION, promise, value);
      });
      state.rejection = IS_NODE || isUnhandled(state) ? UNHANDLED : HANDLED;
      if (result.error)
        throw result.value;
    }
  });
};
var isUnhandled = function(state) {
  return state.rejection !== HANDLED && !state.parent;
};
var onHandleUnhandled = function(state) {
  task.call(global, function() {
    var promise = state.facade;
    if (IS_NODE) {
      process.emit("rejectionHandled", promise);
    } else
      dispatchEvent(REJECTION_HANDLED, promise, state.value);
  });
};
var bind = function(fn, state, unwrap) {
  return function(value) {
    fn(state, value, unwrap);
  };
};
var internalReject = function(state, value, unwrap) {
  if (state.done)
    return;
  state.done = true;
  if (unwrap)
    state = unwrap;
  state.value = value;
  state.state = REJECTED;
  notify(state, true);
};
var internalResolve = function(state, value, unwrap) {
  if (state.done)
    return;
  state.done = true;
  if (unwrap)
    state = unwrap;
  try {
    if (state.facade === value)
      throw TypeError("Promise can't be resolved itself");
    var then = isThenable(value);
    if (then) {
      microtask(function() {
        var wrapper = {done: false};
        try {
          then.call(value, bind(internalResolve, wrapper, state), bind(internalReject, wrapper, state));
        } catch (error) {
          internalReject(wrapper, error, state);
        }
      });
    } else {
      state.value = value;
      state.state = FULFILLED;
      notify(state, false);
    }
  } catch (error) {
    internalReject({done: false}, error, state);
  }
};
if (FORCED) {
  PromiseConstructor = function Promise(executor) {
    anInstance(this, PromiseConstructor, PROMISE);
    aFunction(executor);
    Internal.call(this);
    var state = getInternalState(this);
    try {
      executor(bind(internalResolve, state), bind(internalReject, state));
    } catch (error) {
      internalReject(state, error);
    }
  };
  Internal = function Promise(executor) {
    setInternalState(this, {
      type: PROMISE,
      done: false,
      notified: false,
      parent: false,
      reactions: [],
      rejection: false,
      state: PENDING,
      value: void 0
    });
  };
  Internal.prototype = redefineAll(PromiseConstructor.prototype, {
    then: function then(onFulfilled, onRejected) {
      var state = getInternalPromiseState(this);
      var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
      reaction.ok = typeof onFulfilled == "function" ? onFulfilled : true;
      reaction.fail = typeof onRejected == "function" && onRejected;
      reaction.domain = IS_NODE ? process.domain : void 0;
      state.parent = true;
      state.reactions.push(reaction);
      if (state.state != PENDING)
        notify(state, false);
      return reaction.promise;
    },
    catch: function(onRejected) {
      return this.then(void 0, onRejected);
    }
  });
  OwnPromiseCapability = function() {
    var promise = new Internal();
    var state = getInternalState(promise);
    this.promise = promise;
    this.resolve = bind(internalResolve, state);
    this.reject = bind(internalReject, state);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function(C) {
    return C === PromiseConstructor || C === PromiseWrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C);
  };
  if (!IS_PURE && typeof NativePromise == "function") {
    nativeThen = NativePromise.prototype.then;
    redefine(NativePromise.prototype, "then", function then(onFulfilled, onRejected) {
      var that = this;
      return new PromiseConstructor(function(resolve2, reject2) {
        nativeThen.call(that, resolve2, reject2);
      }).then(onFulfilled, onRejected);
    }, {unsafe: true});
    if (typeof $fetch == "function")
      $({global: true, enumerable: true, forced: true}, {
        fetch: function fetch(input) {
          return promiseResolve(PromiseConstructor, $fetch.apply(global, arguments));
        }
      });
  }
}
$({global: true, wrap: true, forced: FORCED}, {
  Promise: PromiseConstructor
});
setToStringTag(PromiseConstructor, PROMISE, false, true);
setSpecies(PROMISE);
PromiseWrapper = getBuiltIn(PROMISE);
$({target: PROMISE, stat: true, forced: FORCED}, {
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    capability.reject.call(void 0, r);
    return capability.promise;
  }
});
$({target: PROMISE, stat: true, forced: IS_PURE || FORCED}, {
  resolve: function resolve(x) {
    return promiseResolve(IS_PURE && this === PromiseWrapper ? PromiseConstructor : this, x);
  }
});
$({target: PROMISE, stat: true, forced: INCORRECT_ITERATION}, {
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve2 = capability.resolve;
    var reject2 = capability.reject;
    var result = perform(function() {
      var $promiseResolve = aFunction(C.resolve);
      var values = [];
      var counter = 0;
      var remaining = 1;
      iterate(iterable, function(promise) {
        var index = counter++;
        var alreadyCalled = false;
        values.push(void 0);
        remaining++;
        $promiseResolve.call(C, promise).then(function(value) {
          if (alreadyCalled)
            return;
          alreadyCalled = true;
          values[index] = value;
          --remaining || resolve2(values);
        }, reject2);
      });
      --remaining || resolve2(values);
    });
    if (result.error)
      reject2(result.value);
    return capability.promise;
  },
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject2 = capability.reject;
    var result = perform(function() {
      var $promiseResolve = aFunction(C.resolve);
      iterate(iterable, function(promise) {
        $promiseResolve.call(C, promise).then(capability.resolve, reject2);
      });
    });
    if (result.error)
      reject2(result.value);
    return capability.promise;
  }
});


/***/ }),

/***/ 6346:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(3298);
var getBuiltIn = __webpack_require__(5408);
var aFunction = __webpack_require__(1758);
var anObject = __webpack_require__(5675);
var isObject = __webpack_require__(4963);
var create = __webpack_require__(6474);
var bind = __webpack_require__(3143);
var fails = __webpack_require__(3665);
var nativeConstruct = getBuiltIn("Reflect", "construct");
var NEW_TARGET_BUG = fails(function() {
  function F() {
  }
  return !(nativeConstruct(function() {
  }, [], F) instanceof F);
});
var ARGS_BUG = !fails(function() {
  nativeConstruct(function() {
  });
});
var FORCED = NEW_TARGET_BUG || ARGS_BUG;
$({target: "Reflect", stat: true, forced: FORCED, sham: FORCED}, {
  construct: function construct(Target, args) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG)
      return nativeConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      switch (args.length) {
        case 0:
          return new Target();
        case 1:
          return new Target(args[0]);
        case 2:
          return new Target(args[0], args[1]);
        case 3:
          return new Target(args[0], args[1], args[2]);
        case 4:
          return new Target(args[0], args[1], args[2], args[3]);
      }
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});


/***/ }),

/***/ 6944:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(582);
var global = __webpack_require__(5215);
var isForced = __webpack_require__(7315);
var inheritIfRequired = __webpack_require__(9427);
var defineProperty = __webpack_require__(2826).f;
var getOwnPropertyNames = __webpack_require__(8265).f;
var isRegExp = __webpack_require__(8844);
var getFlags = __webpack_require__(565);
var stickyHelpers = __webpack_require__(1986);
var redefine = __webpack_require__(2573);
var fails = __webpack_require__(3665);
var setInternalState = __webpack_require__(7125).set;
var setSpecies = __webpack_require__(68);
var wellKnownSymbol = __webpack_require__(4354);
var MATCH = wellKnownSymbol("match");
var NativeRegExp = global.RegExp;
var RegExpPrototype = NativeRegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
var CORRECT_NEW = new NativeRegExp(re1) !== re1;
var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;
var FORCED = DESCRIPTORS && isForced("RegExp", !CORRECT_NEW || UNSUPPORTED_Y || fails(function() {
  re2[MATCH] = false;
  return NativeRegExp(re1) != re1 || NativeRegExp(re2) == re2 || NativeRegExp(re1, "i") != "/a/i";
}));
if (FORCED) {
  var RegExpWrapper = function RegExp(pattern, flags) {
    var thisIsRegExp = this instanceof RegExpWrapper;
    var patternIsRegExp = isRegExp(pattern);
    var flagsAreUndefined = flags === void 0;
    var sticky;
    if (!thisIsRegExp && patternIsRegExp && pattern.constructor === RegExpWrapper && flagsAreUndefined) {
      return pattern;
    }
    if (CORRECT_NEW) {
      if (patternIsRegExp && !flagsAreUndefined)
        pattern = pattern.source;
    } else if (pattern instanceof RegExpWrapper) {
      if (flagsAreUndefined)
        flags = getFlags.call(pattern);
      pattern = pattern.source;
    }
    if (UNSUPPORTED_Y) {
      sticky = !!flags && flags.indexOf("y") > -1;
      if (sticky)
        flags = flags.replace(/y/g, "");
    }
    var result = inheritIfRequired(CORRECT_NEW ? new NativeRegExp(pattern, flags) : NativeRegExp(pattern, flags), thisIsRegExp ? this : RegExpPrototype, RegExpWrapper);
    if (UNSUPPORTED_Y && sticky)
      setInternalState(result, {sticky});
    return result;
  };
  var proxy = function(key) {
    key in RegExpWrapper || defineProperty(RegExpWrapper, key, {
      configurable: true,
      get: function() {
        return NativeRegExp[key];
      },
      set: function(it) {
        NativeRegExp[key] = it;
      }
    });
  };
  var keys = getOwnPropertyNames(NativeRegExp);
  var index = 0;
  while (keys.length > index)
    proxy(keys[index++]);
  RegExpPrototype.constructor = RegExpWrapper;
  RegExpWrapper.prototype = RegExpPrototype;
  redefine(global, "RegExp", RegExpWrapper);
}
setSpecies("RegExp");


/***/ }),

/***/ 7298:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var exec = __webpack_require__(9403);
$({target: "RegExp", proto: true, forced: /./.exec !== exec}, {
  exec
});


/***/ }),

/***/ 2325:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var redefine = __webpack_require__(2573);
var anObject = __webpack_require__(5675);
var fails = __webpack_require__(3665);
var flags = __webpack_require__(565);
var TO_STRING = "toString";
var RegExpPrototype = RegExp.prototype;
var nativeToString = RegExpPrototype[TO_STRING];
var NOT_GENERIC = fails(function() {
  return nativeToString.call({source: "a", flags: "b"}) != "/a/b";
});
var INCORRECT_NAME = nativeToString.name != TO_STRING;
if (NOT_GENERIC || INCORRECT_NAME) {
  redefine(RegExp.prototype, TO_STRING, function toString() {
    var R = anObject(this);
    var p = String(R.source);
    var rf = R.flags;
    var f = String(rf === void 0 && R instanceof RegExp && !("flags" in RegExpPrototype) ? flags.call(R) : rf);
    return "/" + p + "/" + f;
  }, {unsafe: true});
}


/***/ }),

/***/ 2736:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var createHTML = __webpack_require__(802);
var forcedStringHTMLMethod = __webpack_require__(9239);
$({target: "String", proto: true, forced: forcedStringHTMLMethod("bold")}, {
  bold: function bold() {
    return createHTML(this, "b", "", "");
  }
});


/***/ }),

/***/ 9332:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var notARegExp = __webpack_require__(4755);
var requireObjectCoercible = __webpack_require__(6213);
var correctIsRegExpLogic = __webpack_require__(6174);
$({target: "String", proto: true, forced: !correctIsRegExpLogic("includes")}, {
  includes: function includes(searchString) {
    return !!~String(requireObjectCoercible(this)).indexOf(notARegExp(searchString), arguments.length > 1 ? arguments[1] : void 0);
  }
});


/***/ }),

/***/ 5781:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var charAt = __webpack_require__(9209).charAt;
var InternalStateModule = __webpack_require__(7125);
var defineIterator = __webpack_require__(7499);
var STRING_ITERATOR = "String Iterator";
var setInternalState = InternalStateModule.set;
var getInternalState = InternalStateModule.getterFor(STRING_ITERATOR);
defineIterator(String, "String", function(iterated) {
  setInternalState(this, {
    type: STRING_ITERATOR,
    string: String(iterated),
    index: 0
  });
}, function next() {
  var state = getInternalState(this);
  var string = state.string;
  var index = state.index;
  var point;
  if (index >= string.length)
    return {value: void 0, done: true};
  point = charAt(string, index);
  state.index += point.length;
  return {value: point, done: false};
});


/***/ }),

/***/ 6679:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(1052);
var anObject = __webpack_require__(5675);
var toLength = __webpack_require__(9944);
var requireObjectCoercible = __webpack_require__(6213);
var advanceStringIndex = __webpack_require__(9679);
var regExpExec = __webpack_require__(9191);
fixRegExpWellKnownSymbolLogic("match", 1, function(MATCH, nativeMatch, maybeCallNative) {
  return [
    function match(regexp) {
      var O = requireObjectCoercible(this);
      var matcher = regexp == void 0 ? void 0 : regexp[MATCH];
      return matcher !== void 0 ? matcher.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
    },
    function(regexp) {
      var res = maybeCallNative(nativeMatch, regexp, this);
      if (res.done)
        return res.value;
      var rx = anObject(regexp);
      var S = String(this);
      if (!rx.global)
        return regExpExec(rx, S);
      var fullUnicode = rx.unicode;
      rx.lastIndex = 0;
      var A = [];
      var n = 0;
      var result;
      while ((result = regExpExec(rx, S)) !== null) {
        var matchStr = String(result[0]);
        A[n] = matchStr;
        if (matchStr === "")
          rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
        n++;
      }
      return n === 0 ? null : A;
    }
  ];
});


/***/ }),

/***/ 6915:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(1052);
var anObject = __webpack_require__(5675);
var toLength = __webpack_require__(9944);
var toInteger = __webpack_require__(2983);
var requireObjectCoercible = __webpack_require__(6213);
var advanceStringIndex = __webpack_require__(9679);
var getSubstitution = __webpack_require__(2992);
var regExpExec = __webpack_require__(9191);
var max = Math.max;
var min = Math.min;
var maybeToString = function(it) {
  return it === void 0 ? it : String(it);
};
fixRegExpWellKnownSymbolLogic("replace", 2, function(REPLACE, nativeReplace, maybeCallNative, reason) {
  var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = reason.REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE;
  var REPLACE_KEEPS_$0 = reason.REPLACE_KEEPS_$0;
  var UNSAFE_SUBSTITUTE = REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE ? "$" : "$0";
  return [
    function replace(searchValue, replaceValue) {
      var O = requireObjectCoercible(this);
      var replacer = searchValue == void 0 ? void 0 : searchValue[REPLACE];
      return replacer !== void 0 ? replacer.call(searchValue, O, replaceValue) : nativeReplace.call(String(O), searchValue, replaceValue);
    },
    function(regexp, replaceValue) {
      if (!REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE && REPLACE_KEEPS_$0 || typeof replaceValue === "string" && replaceValue.indexOf(UNSAFE_SUBSTITUTE) === -1) {
        var res = maybeCallNative(nativeReplace, regexp, this, replaceValue);
        if (res.done)
          return res.value;
      }
      var rx = anObject(regexp);
      var S = String(this);
      var functionalReplace = typeof replaceValue === "function";
      if (!functionalReplace)
        replaceValue = String(replaceValue);
      var global = rx.global;
      if (global) {
        var fullUnicode = rx.unicode;
        rx.lastIndex = 0;
      }
      var results = [];
      while (true) {
        var result = regExpExec(rx, S);
        if (result === null)
          break;
        results.push(result);
        if (!global)
          break;
        var matchStr = String(result[0]);
        if (matchStr === "")
          rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
      }
      var accumulatedResult = "";
      var nextSourcePosition = 0;
      for (var i = 0; i < results.length; i++) {
        result = results[i];
        var matched = String(result[0]);
        var position = max(min(toInteger(result.index), S.length), 0);
        var captures = [];
        for (var j = 1; j < result.length; j++)
          captures.push(maybeToString(result[j]));
        var namedCaptures = result.groups;
        if (functionalReplace) {
          var replacerArgs = [matched].concat(captures, position, S);
          if (namedCaptures !== void 0)
            replacerArgs.push(namedCaptures);
          var replacement = String(replaceValue.apply(void 0, replacerArgs));
        } else {
          replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
        }
        if (position >= nextSourcePosition) {
          accumulatedResult += S.slice(nextSourcePosition, position) + replacement;
          nextSourcePosition = position + matched.length;
        }
      }
      return accumulatedResult + S.slice(nextSourcePosition);
    }
  ];
});


/***/ }),

/***/ 2409:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var createHTML = __webpack_require__(802);
var forcedStringHTMLMethod = __webpack_require__(9239);
$({target: "String", proto: true, forced: forcedStringHTMLMethod("small")}, {
  small: function small() {
    return createHTML(this, "small", "", "");
  }
});


/***/ }),

/***/ 1733:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(1052);
var isRegExp = __webpack_require__(8844);
var anObject = __webpack_require__(5675);
var requireObjectCoercible = __webpack_require__(6213);
var speciesConstructor = __webpack_require__(5523);
var advanceStringIndex = __webpack_require__(9679);
var toLength = __webpack_require__(9944);
var callRegExpExec = __webpack_require__(9191);
var regexpExec = __webpack_require__(9403);
var fails = __webpack_require__(3665);
var arrayPush = [].push;
var min = Math.min;
var MAX_UINT32 = 4294967295;
var SUPPORTS_Y = !fails(function() {
  return !RegExp(MAX_UINT32, "y");
});
fixRegExpWellKnownSymbolLogic("split", 2, function(SPLIT, nativeSplit, maybeCallNative) {
  var internalSplit;
  if ("abbc".split(/(b)*/)[1] == "c" || "test".split(/(?:)/, -1).length != 4 || "ab".split(/(?:ab)*/).length != 2 || ".".split(/(.?)(.?)/).length != 4 || ".".split(/()()/).length > 1 || "".split(/.?/).length) {
    internalSplit = function(separator, limit) {
      var string = String(requireObjectCoercible(this));
      var lim = limit === void 0 ? MAX_UINT32 : limit >>> 0;
      if (lim === 0)
        return [];
      if (separator === void 0)
        return [string];
      if (!isRegExp(separator)) {
        return nativeSplit.call(string, separator, lim);
      }
      var output = [];
      var flags = (separator.ignoreCase ? "i" : "") + (separator.multiline ? "m" : "") + (separator.unicode ? "u" : "") + (separator.sticky ? "y" : "");
      var lastLastIndex = 0;
      var separatorCopy = new RegExp(separator.source, flags + "g");
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy.lastIndex;
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match.length > 1 && match.index < string.length)
            arrayPush.apply(output, match.slice(1));
          lastLength = match[0].length;
          lastLastIndex = lastIndex;
          if (output.length >= lim)
            break;
        }
        if (separatorCopy.lastIndex === match.index)
          separatorCopy.lastIndex++;
      }
      if (lastLastIndex === string.length) {
        if (lastLength || !separatorCopy.test(""))
          output.push("");
      } else
        output.push(string.slice(lastLastIndex));
      return output.length > lim ? output.slice(0, lim) : output;
    };
  } else if ("0".split(void 0, 0).length) {
    internalSplit = function(separator, limit) {
      return separator === void 0 && limit === 0 ? [] : nativeSplit.call(this, separator, limit);
    };
  } else
    internalSplit = nativeSplit;
  return [
    function split(separator, limit) {
      var O = requireObjectCoercible(this);
      var splitter = separator == void 0 ? void 0 : separator[SPLIT];
      return splitter !== void 0 ? splitter.call(separator, O, limit) : internalSplit.call(String(O), separator, limit);
    },
    function(regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== nativeSplit);
      if (res.done)
        return res.value;
      var rx = anObject(regexp);
      var S = String(this);
      var C = speciesConstructor(rx, RegExp);
      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? "i" : "") + (rx.multiline ? "m" : "") + (rx.unicode ? "u" : "") + (SUPPORTS_Y ? "y" : "g");
      var splitter = new C(SUPPORTS_Y ? rx : "^(?:" + rx.source + ")", flags);
      var lim = limit === void 0 ? MAX_UINT32 : limit >>> 0;
      if (lim === 0)
        return [];
      if (S.length === 0)
        return callRegExpExec(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = SUPPORTS_Y ? q : 0;
        var z = callRegExpExec(splitter, SUPPORTS_Y ? S : S.slice(q));
        var e;
        if (z === null || (e = min(toLength(splitter.lastIndex + (SUPPORTS_Y ? 0 : q)), S.length)) === p) {
          q = advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim)
            return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim)
              return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
}, !SUPPORTS_Y);


/***/ }),

/***/ 7110:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var $ = __webpack_require__(3298);
var $trim = __webpack_require__(2188).trim;
var forcedStringTrimMethod = __webpack_require__(7329);
$({target: "String", proto: true, forced: forcedStringTrimMethod("trim")}, {
  trim: function trim() {
    return $trim(this);
  }
});


/***/ }),

/***/ 1698:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var DOMIterables = __webpack_require__(8839);
var forEach = __webpack_require__(4947);
var createNonEnumerableProperty = __webpack_require__(9465);
for (var COLLECTION_NAME in DOMIterables) {
  var Collection = global[COLLECTION_NAME];
  var CollectionPrototype = Collection && Collection.prototype;
  if (CollectionPrototype && CollectionPrototype.forEach !== forEach)
    try {
      createNonEnumerableProperty(CollectionPrototype, "forEach", forEach);
    } catch (error) {
      CollectionPrototype.forEach = forEach;
    }
}


/***/ }),

/***/ 395:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(5215);
var DOMIterables = __webpack_require__(8839);
var ArrayIteratorMethods = __webpack_require__(4185);
var createNonEnumerableProperty = __webpack_require__(9465);
var wellKnownSymbol = __webpack_require__(4354);
var ITERATOR = wellKnownSymbol("iterator");
var TO_STRING_TAG = wellKnownSymbol("toStringTag");
var ArrayValues = ArrayIteratorMethods.values;
for (var COLLECTION_NAME in DOMIterables) {
  var Collection = global[COLLECTION_NAME];
  var CollectionPrototype = Collection && Collection.prototype;
  if (CollectionPrototype) {
    if (CollectionPrototype[ITERATOR] !== ArrayValues)
      try {
        createNonEnumerableProperty(CollectionPrototype, ITERATOR, ArrayValues);
      } catch (error) {
        CollectionPrototype[ITERATOR] = ArrayValues;
      }
    if (!CollectionPrototype[TO_STRING_TAG]) {
      createNonEnumerableProperty(CollectionPrototype, TO_STRING_TAG, COLLECTION_NAME);
    }
    if (DOMIterables[COLLECTION_NAME])
      for (var METHOD_NAME in ArrayIteratorMethods) {
        if (CollectionPrototype[METHOD_NAME] !== ArrayIteratorMethods[METHOD_NAME])
          try {
            createNonEnumerableProperty(CollectionPrototype, METHOD_NAME, ArrayIteratorMethods[METHOD_NAME]);
          } catch (error) {
            CollectionPrototype[METHOD_NAME] = ArrayIteratorMethods[METHOD_NAME];
          }
      }
  }
}


/***/ }),

/***/ 1984:
/***/ ((module, exports) => {

function keyCode(searchInput) {
  if (searchInput && typeof searchInput === "object") {
    var hasKeyCode = searchInput.which || searchInput.keyCode || searchInput.charCode;
    if (hasKeyCode)
      searchInput = hasKeyCode;
  }
  if (typeof searchInput === "number")
    return names[searchInput];
  var search = String(searchInput);
  var foundNamedKey = codes[search.toLowerCase()];
  if (foundNamedKey)
    return foundNamedKey;
  var foundNamedKey = aliases[search.toLowerCase()];
  if (foundNamedKey)
    return foundNamedKey;
  if (search.length === 1)
    return search.charCodeAt(0);
  return void 0;
}
keyCode.isEventKey = function isEventKey(event, nameOrCode) {
  if (event && typeof event === "object") {
    var keyCode2 = event.which || event.keyCode || event.charCode;
    if (keyCode2 === null || keyCode2 === void 0) {
      return false;
    }
    if (typeof nameOrCode === "string") {
      var foundNamedKey = codes[nameOrCode.toLowerCase()];
      if (foundNamedKey) {
        return foundNamedKey === keyCode2;
      }
      var foundNamedKey = aliases[nameOrCode.toLowerCase()];
      if (foundNamedKey) {
        return foundNamedKey === keyCode2;
      }
    } else if (typeof nameOrCode === "number") {
      return nameOrCode === keyCode2;
    }
    return false;
  }
};
exports = module.exports = keyCode;
var codes = exports.code = exports.codes = {
  backspace: 8,
  tab: 9,
  enter: 13,
  shift: 16,
  ctrl: 17,
  alt: 18,
  "pause/break": 19,
  "caps lock": 20,
  esc: 27,
  space: 32,
  "page up": 33,
  "page down": 34,
  end: 35,
  home: 36,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  insert: 45,
  delete: 46,
  command: 91,
  "left command": 91,
  "right command": 93,
  "numpad *": 106,
  "numpad +": 107,
  "numpad -": 109,
  "numpad .": 110,
  "numpad /": 111,
  "num lock": 144,
  "scroll lock": 145,
  "my computer": 182,
  "my calculator": 183,
  ";": 186,
  "=": 187,
  ",": 188,
  "-": 189,
  ".": 190,
  "/": 191,
  "`": 192,
  "[": 219,
  "\\": 220,
  "]": 221,
  "'": 222
};
var aliases = exports.aliases = {
  windows: 91,
  "\u21E7": 16,
  "\u2325": 18,
  "\u2303": 17,
  "\u2318": 91,
  ctl: 17,
  control: 17,
  option: 18,
  pause: 19,
  break: 19,
  caps: 20,
  return: 13,
  escape: 27,
  spc: 32,
  spacebar: 32,
  pgup: 33,
  pgdn: 34,
  ins: 45,
  del: 46,
  cmd: 91
};
/*!
 * Programatically add the following
 */
for (i = 97; i < 123; i++)
  codes[String.fromCharCode(i)] = i - 32;
for (var i = 48; i < 58; i++)
  codes[i - 48] = i;
for (i = 1; i < 13; i++)
  codes["f" + i] = i + 111;
for (i = 0; i < 10; i++)
  codes["numpad " + i] = i + 96;
var names = exports.names = exports.title = {};
for (i in codes)
  names[codes[i]] = i;
for (var alias in aliases) {
  codes[alias] = aliases[alias];
}


/***/ }),

/***/ 6674:
/***/ ((module) => {

"use strict";

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;
function toObject(val) {
  if (val === null || val === void 0) {
    throw new TypeError("Object.assign cannot be called with null or undefined");
  }
  return Object(val);
}
function shouldUseNative() {
  try {
    if (!Object.assign) {
      return false;
    }
    var test1 = new String("abc");
    test1[5] = "de";
    if (Object.getOwnPropertyNames(test1)[0] === "5") {
      return false;
    }
    var test2 = {};
    for (var i = 0; i < 10; i++) {
      test2["_" + String.fromCharCode(i)] = i;
    }
    var order2 = Object.getOwnPropertyNames(test2).map(function(n) {
      return test2[n];
    });
    if (order2.join("") !== "0123456789") {
      return false;
    }
    var test3 = {};
    "abcdefghijklmnopqrst".split("").forEach(function(letter) {
      test3[letter] = letter;
    });
    if (Object.keys(Object.assign({}, test3)).join("") !== "abcdefghijklmnopqrst") {
      return false;
    }
    return true;
  } catch (err) {
    return false;
  }
}
module.exports = shouldUseNative() ? Object.assign : function(target, source) {
  var from;
  var to = toObject(target);
  var symbols;
  for (var s = 1; s < arguments.length; s++) {
    from = Object(arguments[s]);
    for (var key in from) {
      if (hasOwnProperty.call(from, key)) {
        to[key] = from[key];
      }
    }
    if (getOwnPropertySymbols) {
      symbols = getOwnPropertySymbols(from);
      for (var i = 0; i < symbols.length; i++) {
        if (propIsEnumerable.call(from, symbols[i])) {
          to[symbols[i]] = from[symbols[i]];
        }
      }
    }
  }
  return to;
};


/***/ }),

/***/ 2376:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

var ReactPropTypesSecret = __webpack_require__(9904);
function emptyFunction() {
}
function emptyFunctionWithReset() {
}
emptyFunctionWithReset.resetWarningCache = emptyFunction;
module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      return;
    }
    var err = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
    err.name = "Invariant Violation";
    throw err;
  }
  ;
  shim.isRequired = shim;
  function getShim() {
    return shim;
  }
  ;
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,
    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,
    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };
  ReactPropTypes.PropTypes = ReactPropTypes;
  return ReactPropTypes;
};


/***/ }),

/***/ 6050:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

if (false) { var throwOnDirectAccess, ReactIs; } else {
  module.exports = __webpack_require__(2376)();
}


/***/ }),

/***/ 9904:
/***/ ((module) => {

"use strict";

var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
module.exports = ReactPropTypesSecret;


/***/ }),

/***/ 5786:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

/** @license React v17.0.2
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var aa = __webpack_require__(4339), m = __webpack_require__(6674), r = __webpack_require__(6762);
function y(a) {
  for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++)
    b += "&args[]=" + encodeURIComponent(arguments[c]);
  return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
if (!aa)
  throw Error(y(227));
var ba = new Set(), ca = {};
function da(a, b) {
  ea(a, b);
  ea(a + "Capture", b);
}
function ea(a, b) {
  ca[a] = b;
  for (a = 0; a < b.length; a++)
    ba.add(b[a]);
}
var fa = !(typeof window === "undefined" || typeof window.document === "undefined" || typeof window.document.createElement === "undefined"), ha = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, ia = Object.prototype.hasOwnProperty, ja = {}, ka = {};
function la(a) {
  if (ia.call(ka, a))
    return true;
  if (ia.call(ja, a))
    return false;
  if (ha.test(a))
    return ka[a] = true;
  ja[a] = true;
  return false;
}
function ma(a, b, c, d) {
  if (c !== null && c.type === 0)
    return false;
  switch (typeof b) {
    case "function":
    case "symbol":
      return true;
    case "boolean":
      if (d)
        return false;
      if (c !== null)
        return !c.acceptsBooleans;
      a = a.toLowerCase().slice(0, 5);
      return a !== "data-" && a !== "aria-";
    default:
      return false;
  }
}
function na(a, b, c, d) {
  if (b === null || typeof b === "undefined" || ma(a, b, c, d))
    return true;
  if (d)
    return false;
  if (c !== null)
    switch (c.type) {
      case 3:
        return !b;
      case 4:
        return b === false;
      case 5:
        return isNaN(b);
      case 6:
        return isNaN(b) || 1 > b;
    }
  return false;
}
function B(a, b, c, d, e, f, g) {
  this.acceptsBooleans = b === 2 || b === 3 || b === 4;
  this.attributeName = d;
  this.attributeNamespace = e;
  this.mustUseProperty = c;
  this.propertyName = a;
  this.type = b;
  this.sanitizeURL = f;
  this.removeEmptyString = g;
}
var D = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
  D[a] = new B(a, 0, false, a, null, false, false);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
  var b = a[0];
  D[b] = new B(b, 1, false, a[1], null, false, false);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
  D[a] = new B(a, 2, false, a.toLowerCase(), null, false, false);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
  D[a] = new B(a, 2, false, a, null, false, false);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
  D[a] = new B(a, 3, false, a.toLowerCase(), null, false, false);
});
["checked", "multiple", "muted", "selected"].forEach(function(a) {
  D[a] = new B(a, 3, true, a, null, false, false);
});
["capture", "download"].forEach(function(a) {
  D[a] = new B(a, 4, false, a, null, false, false);
});
["cols", "rows", "size", "span"].forEach(function(a) {
  D[a] = new B(a, 6, false, a, null, false, false);
});
["rowSpan", "start"].forEach(function(a) {
  D[a] = new B(a, 5, false, a.toLowerCase(), null, false, false);
});
var oa = /[\-:]([a-z])/g;
function pa(a) {
  return a[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
  var b = a.replace(oa, pa);
  D[b] = new B(b, 1, false, a, null, false, false);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
  var b = a.replace(oa, pa);
  D[b] = new B(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
  var b = a.replace(oa, pa);
  D[b] = new B(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
});
["tabIndex", "crossOrigin"].forEach(function(a) {
  D[a] = new B(a, 1, false, a.toLowerCase(), null, false, false);
});
D.xlinkHref = new B("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
["src", "href", "action", "formAction"].forEach(function(a) {
  D[a] = new B(a, 1, false, a.toLowerCase(), null, true, true);
});
function qa(a, b, c, d) {
  var e = D.hasOwnProperty(b) ? D[b] : null;
  var f = e !== null ? e.type === 0 : d ? false : !(2 < b.length) || b[0] !== "o" && b[0] !== "O" || b[1] !== "n" && b[1] !== "N" ? false : true;
  f || (na(b, c, e, d) && (c = null), d || e === null ? la(b) && (c === null ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = c === null ? e.type === 3 ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, c === null ? a.removeAttribute(b) : (e = e.type, c = e === 3 || e === 4 && c === true ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c))));
}
var ra = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, sa = 60103, ta = 60106, ua = 60107, wa = 60108, xa = 60114, ya = 60109, za = 60110, Aa = 60112, Ba = 60113, Ca = 60120, Da = 60115, Ea = 60116, Fa = 60121, Ga = 60128, Ha = 60129, Ia = 60130, Ja = 60131;
if (typeof Symbol === "function" && Symbol.for) {
  var E = Symbol.for;
  sa = E("react.element");
  ta = E("react.portal");
  ua = E("react.fragment");
  wa = E("react.strict_mode");
  xa = E("react.profiler");
  ya = E("react.provider");
  za = E("react.context");
  Aa = E("react.forward_ref");
  Ba = E("react.suspense");
  Ca = E("react.suspense_list");
  Da = E("react.memo");
  Ea = E("react.lazy");
  Fa = E("react.block");
  E("react.scope");
  Ga = E("react.opaque.id");
  Ha = E("react.debug_trace_mode");
  Ia = E("react.offscreen");
  Ja = E("react.legacy_hidden");
}
var Ka = typeof Symbol === "function" && Symbol.iterator;
function La(a) {
  if (a === null || typeof a !== "object")
    return null;
  a = Ka && a[Ka] || a["@@iterator"];
  return typeof a === "function" ? a : null;
}
var Ma;
function Na(a) {
  if (Ma === void 0)
    try {
      throw Error();
    } catch (c) {
      var b = c.stack.trim().match(/\n( *(at )?)/);
      Ma = b && b[1] || "";
    }
  return "\n" + Ma + a;
}
var Oa = false;
function Pa(a, b) {
  if (!a || Oa)
    return "";
  Oa = true;
  var c = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (b)
      if (b = function() {
        throw Error();
      }, Object.defineProperty(b.prototype, "props", {set: function() {
        throw Error();
      }}), typeof Reflect === "object" && Reflect.construct) {
        try {
          Reflect.construct(b, []);
        } catch (k) {
          var d = k;
        }
        Reflect.construct(a, [], b);
      } else {
        try {
          b.call();
        } catch (k) {
          d = k;
        }
        a.call(b.prototype);
      }
    else {
      try {
        throw Error();
      } catch (k) {
        d = k;
      }
      a();
    }
  } catch (k) {
    if (k && d && typeof k.stack === "string") {
      for (var e = k.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h]; )
        h--;
      for (; 1 <= g && 0 <= h; g--, h--)
        if (e[g] !== f[h]) {
          if (g !== 1 || h !== 1) {
            do
              if (g--, h--, 0 > h || e[g] !== f[h])
                return "\n" + e[g].replace(" at new ", " at ");
            while (1 <= g && 0 <= h);
          }
          break;
        }
    }
  } finally {
    Oa = false, Error.prepareStackTrace = c;
  }
  return (a = a ? a.displayName || a.name : "") ? Na(a) : "";
}
function Qa(a) {
  switch (a.tag) {
    case 5:
      return Na(a.type);
    case 16:
      return Na("Lazy");
    case 13:
      return Na("Suspense");
    case 19:
      return Na("SuspenseList");
    case 0:
    case 2:
    case 15:
      return a = Pa(a.type, false), a;
    case 11:
      return a = Pa(a.type.render, false), a;
    case 22:
      return a = Pa(a.type._render, false), a;
    case 1:
      return a = Pa(a.type, true), a;
    default:
      return "";
  }
}
function Ra(a) {
  if (a == null)
    return null;
  if (typeof a === "function")
    return a.displayName || a.name || null;
  if (typeof a === "string")
    return a;
  switch (a) {
    case ua:
      return "Fragment";
    case ta:
      return "Portal";
    case xa:
      return "Profiler";
    case wa:
      return "StrictMode";
    case Ba:
      return "Suspense";
    case Ca:
      return "SuspenseList";
  }
  if (typeof a === "object")
    switch (a.$$typeof) {
      case za:
        return (a.displayName || "Context") + ".Consumer";
      case ya:
        return (a._context.displayName || "Context") + ".Provider";
      case Aa:
        var b = a.render;
        b = b.displayName || b.name || "";
        return a.displayName || (b !== "" ? "ForwardRef(" + b + ")" : "ForwardRef");
      case Da:
        return Ra(a.type);
      case Fa:
        return Ra(a._render);
      case Ea:
        b = a._payload;
        a = a._init;
        try {
          return Ra(a(b));
        } catch (c) {
        }
    }
  return null;
}
function Sa(a) {
  switch (typeof a) {
    case "boolean":
    case "number":
    case "object":
    case "string":
    case "undefined":
      return a;
    default:
      return "";
  }
}
function Ta(a) {
  var b = a.type;
  return (a = a.nodeName) && a.toLowerCase() === "input" && (b === "checkbox" || b === "radio");
}
function Ua(a) {
  var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
  if (!a.hasOwnProperty(b) && typeof c !== "undefined" && typeof c.get === "function" && typeof c.set === "function") {
    var e = c.get, f = c.set;
    Object.defineProperty(a, b, {configurable: true, get: function() {
      return e.call(this);
    }, set: function(a2) {
      d = "" + a2;
      f.call(this, a2);
    }});
    Object.defineProperty(a, b, {enumerable: c.enumerable});
    return {getValue: function() {
      return d;
    }, setValue: function(a2) {
      d = "" + a2;
    }, stopTracking: function() {
      a._valueTracker = null;
      delete a[b];
    }};
  }
}
function Va(a) {
  a._valueTracker || (a._valueTracker = Ua(a));
}
function Wa(a) {
  if (!a)
    return false;
  var b = a._valueTracker;
  if (!b)
    return true;
  var c = b.getValue();
  var d = "";
  a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
  a = d;
  return a !== c ? (b.setValue(a), true) : false;
}
function Xa(a) {
  a = a || (typeof document !== "undefined" ? document : void 0);
  if (typeof a === "undefined")
    return null;
  try {
    return a.activeElement || a.body;
  } catch (b) {
    return a.body;
  }
}
function Ya(a, b) {
  var c = b.checked;
  return m({}, b, {defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: c != null ? c : a._wrapperState.initialChecked});
}
function Za(a, b) {
  var c = b.defaultValue == null ? "" : b.defaultValue, d = b.checked != null ? b.checked : b.defaultChecked;
  c = Sa(b.value != null ? b.value : c);
  a._wrapperState = {initialChecked: d, initialValue: c, controlled: b.type === "checkbox" || b.type === "radio" ? b.checked != null : b.value != null};
}
function $a(a, b) {
  b = b.checked;
  b != null && qa(a, "checked", b, false);
}
function ab(a, b) {
  $a(a, b);
  var c = Sa(b.value), d = b.type;
  if (c != null)
    if (d === "number") {
      if (c === 0 && a.value === "" || a.value != c)
        a.value = "" + c;
    } else
      a.value !== "" + c && (a.value = "" + c);
  else if (d === "submit" || d === "reset") {
    a.removeAttribute("value");
    return;
  }
  b.hasOwnProperty("value") ? bb(a, b.type, c) : b.hasOwnProperty("defaultValue") && bb(a, b.type, Sa(b.defaultValue));
  b.checked == null && b.defaultChecked != null && (a.defaultChecked = !!b.defaultChecked);
}
function cb(a, b, c) {
  if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
    var d = b.type;
    if (!(d !== "submit" && d !== "reset" || b.value !== void 0 && b.value !== null))
      return;
    b = "" + a._wrapperState.initialValue;
    c || b === a.value || (a.value = b);
    a.defaultValue = b;
  }
  c = a.name;
  c !== "" && (a.name = "");
  a.defaultChecked = !!a._wrapperState.initialChecked;
  c !== "" && (a.name = c);
}
function bb(a, b, c) {
  if (b !== "number" || Xa(a.ownerDocument) !== a)
    c == null ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
}
function db(a) {
  var b = "";
  aa.Children.forEach(a, function(a2) {
    a2 != null && (b += a2);
  });
  return b;
}
function eb(a, b) {
  a = m({children: void 0}, b);
  if (b = db(b.children))
    a.children = b;
  return a;
}
function fb(a, b, c, d) {
  a = a.options;
  if (b) {
    b = {};
    for (var e = 0; e < c.length; e++)
      b["$" + c[e]] = true;
    for (c = 0; c < a.length; c++)
      e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
  } else {
    c = "" + Sa(c);
    b = null;
    for (e = 0; e < a.length; e++) {
      if (a[e].value === c) {
        a[e].selected = true;
        d && (a[e].defaultSelected = true);
        return;
      }
      b !== null || a[e].disabled || (b = a[e]);
    }
    b !== null && (b.selected = true);
  }
}
function gb(a, b) {
  if (b.dangerouslySetInnerHTML != null)
    throw Error(y(91));
  return m({}, b, {value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue});
}
function hb(a, b) {
  var c = b.value;
  if (c == null) {
    c = b.children;
    b = b.defaultValue;
    if (c != null) {
      if (b != null)
        throw Error(y(92));
      if (Array.isArray(c)) {
        if (!(1 >= c.length))
          throw Error(y(93));
        c = c[0];
      }
      b = c;
    }
    b == null && (b = "");
    c = b;
  }
  a._wrapperState = {initialValue: Sa(c)};
}
function ib(a, b) {
  var c = Sa(b.value), d = Sa(b.defaultValue);
  c != null && (c = "" + c, c !== a.value && (a.value = c), b.defaultValue == null && a.defaultValue !== c && (a.defaultValue = c));
  d != null && (a.defaultValue = "" + d);
}
function jb(a) {
  var b = a.textContent;
  b === a._wrapperState.initialValue && b !== "" && b !== null && (a.value = b);
}
var kb = {html: "http://www.w3.org/1999/xhtml", mathml: "http://www.w3.org/1998/Math/MathML", svg: "http://www.w3.org/2000/svg"};
function lb(a) {
  switch (a) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function mb(a, b) {
  return a == null || a === "http://www.w3.org/1999/xhtml" ? lb(b) : a === "http://www.w3.org/2000/svg" && b === "foreignObject" ? "http://www.w3.org/1999/xhtml" : a;
}
var nb, ob = function(a) {
  return typeof MSApp !== "undefined" && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
    MSApp.execUnsafeLocalFunction(function() {
      return a(b, c, d, e);
    });
  } : a;
}(function(a, b) {
  if (a.namespaceURI !== kb.svg || "innerHTML" in a)
    a.innerHTML = b;
  else {
    nb = nb || document.createElement("div");
    nb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
    for (b = nb.firstChild; a.firstChild; )
      a.removeChild(a.firstChild);
    for (; b.firstChild; )
      a.appendChild(b.firstChild);
  }
});
function pb(a, b) {
  if (b) {
    var c = a.firstChild;
    if (c && c === a.lastChild && c.nodeType === 3) {
      c.nodeValue = b;
      return;
    }
  }
  a.textContent = b;
}
var qb = {
  animationIterationCount: true,
  borderImageOutset: true,
  borderImageSlice: true,
  borderImageWidth: true,
  boxFlex: true,
  boxFlexGroup: true,
  boxOrdinalGroup: true,
  columnCount: true,
  columns: true,
  flex: true,
  flexGrow: true,
  flexPositive: true,
  flexShrink: true,
  flexNegative: true,
  flexOrder: true,
  gridArea: true,
  gridRow: true,
  gridRowEnd: true,
  gridRowSpan: true,
  gridRowStart: true,
  gridColumn: true,
  gridColumnEnd: true,
  gridColumnSpan: true,
  gridColumnStart: true,
  fontWeight: true,
  lineClamp: true,
  lineHeight: true,
  opacity: true,
  order: true,
  orphans: true,
  tabSize: true,
  widows: true,
  zIndex: true,
  zoom: true,
  fillOpacity: true,
  floodOpacity: true,
  stopOpacity: true,
  strokeDasharray: true,
  strokeDashoffset: true,
  strokeMiterlimit: true,
  strokeOpacity: true,
  strokeWidth: true
}, rb = ["Webkit", "ms", "Moz", "O"];
Object.keys(qb).forEach(function(a) {
  rb.forEach(function(b) {
    b = b + a.charAt(0).toUpperCase() + a.substring(1);
    qb[b] = qb[a];
  });
});
function sb(a, b, c) {
  return b == null || typeof b === "boolean" || b === "" ? "" : c || typeof b !== "number" || b === 0 || qb.hasOwnProperty(a) && qb[a] ? ("" + b).trim() : b + "px";
}
function tb(a, b) {
  a = a.style;
  for (var c in b)
    if (b.hasOwnProperty(c)) {
      var d = c.indexOf("--") === 0, e = sb(c, b[c], d);
      c === "float" && (c = "cssFloat");
      d ? a.setProperty(c, e) : a[c] = e;
    }
}
var ub = m({menuitem: true}, {area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true});
function vb(a, b) {
  if (b) {
    if (ub[a] && (b.children != null || b.dangerouslySetInnerHTML != null))
      throw Error(y(137, a));
    if (b.dangerouslySetInnerHTML != null) {
      if (b.children != null)
        throw Error(y(60));
      if (!(typeof b.dangerouslySetInnerHTML === "object" && "__html" in b.dangerouslySetInnerHTML))
        throw Error(y(61));
    }
    if (b.style != null && typeof b.style !== "object")
      throw Error(y(62));
  }
}
function wb(a, b) {
  if (a.indexOf("-") === -1)
    return typeof b.is === "string";
  switch (a) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return false;
    default:
      return true;
  }
}
function xb(a) {
  a = a.target || a.srcElement || window;
  a.correspondingUseElement && (a = a.correspondingUseElement);
  return a.nodeType === 3 ? a.parentNode : a;
}
var yb = null, zb = null, Ab = null;
function Bb(a) {
  if (a = Cb(a)) {
    if (typeof yb !== "function")
      throw Error(y(280));
    var b = a.stateNode;
    b && (b = Db(b), yb(a.stateNode, a.type, b));
  }
}
function Eb(a) {
  zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
}
function Fb() {
  if (zb) {
    var a = zb, b = Ab;
    Ab = zb = null;
    Bb(a);
    if (b)
      for (a = 0; a < b.length; a++)
        Bb(b[a]);
  }
}
function Gb(a, b) {
  return a(b);
}
function Hb(a, b, c, d, e) {
  return a(b, c, d, e);
}
function Ib() {
}
var Jb = Gb, Kb = false, Lb = false;
function Mb() {
  if (zb !== null || Ab !== null)
    Ib(), Fb();
}
function Nb(a, b, c) {
  if (Lb)
    return a(b, c);
  Lb = true;
  try {
    return Jb(a, b, c);
  } finally {
    Lb = false, Mb();
  }
}
function Ob(a, b) {
  var c = a.stateNode;
  if (c === null)
    return null;
  var d = Db(c);
  if (d === null)
    return null;
  c = d[b];
  a:
    switch (b) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (d = !d.disabled) || (a = a.type, d = !(a === "button" || a === "input" || a === "select" || a === "textarea"));
        a = !d;
        break a;
      default:
        a = false;
    }
  if (a)
    return null;
  if (c && typeof c !== "function")
    throw Error(y(231, b, typeof c));
  return c;
}
var Pb = false;
if (fa)
  try {
    var Qb = {};
    Object.defineProperty(Qb, "passive", {get: function() {
      Pb = true;
    }});
    window.addEventListener("test", Qb, Qb);
    window.removeEventListener("test", Qb, Qb);
  } catch (a) {
    Pb = false;
  }
function Rb(a, b, c, d, e, f, g, h, k) {
  var l = Array.prototype.slice.call(arguments, 3);
  try {
    b.apply(c, l);
  } catch (n) {
    this.onError(n);
  }
}
var Sb = false, Tb = null, Ub = false, Vb = null, Wb = {onError: function(a) {
  Sb = true;
  Tb = a;
}};
function Xb(a, b, c, d, e, f, g, h, k) {
  Sb = false;
  Tb = null;
  Rb.apply(Wb, arguments);
}
function Yb(a, b, c, d, e, f, g, h, k) {
  Xb.apply(this, arguments);
  if (Sb) {
    if (Sb) {
      var l = Tb;
      Sb = false;
      Tb = null;
    } else
      throw Error(y(198));
    Ub || (Ub = true, Vb = l);
  }
}
function Zb(a) {
  var b = a, c = a;
  if (a.alternate)
    for (; b.return; )
      b = b.return;
  else {
    a = b;
    do
      b = a, (b.flags & 1026) !== 0 && (c = b.return), a = b.return;
    while (a);
  }
  return b.tag === 3 ? c : null;
}
function $b(a) {
  if (a.tag === 13) {
    var b = a.memoizedState;
    b === null && (a = a.alternate, a !== null && (b = a.memoizedState));
    if (b !== null)
      return b.dehydrated;
  }
  return null;
}
function ac(a) {
  if (Zb(a) !== a)
    throw Error(y(188));
}
function bc(a) {
  var b = a.alternate;
  if (!b) {
    b = Zb(a);
    if (b === null)
      throw Error(y(188));
    return b !== a ? null : a;
  }
  for (var c = a, d = b; ; ) {
    var e = c.return;
    if (e === null)
      break;
    var f = e.alternate;
    if (f === null) {
      d = e.return;
      if (d !== null) {
        c = d;
        continue;
      }
      break;
    }
    if (e.child === f.child) {
      for (f = e.child; f; ) {
        if (f === c)
          return ac(e), a;
        if (f === d)
          return ac(e), b;
        f = f.sibling;
      }
      throw Error(y(188));
    }
    if (c.return !== d.return)
      c = e, d = f;
    else {
      for (var g = false, h = e.child; h; ) {
        if (h === c) {
          g = true;
          c = e;
          d = f;
          break;
        }
        if (h === d) {
          g = true;
          d = e;
          c = f;
          break;
        }
        h = h.sibling;
      }
      if (!g) {
        for (h = f.child; h; ) {
          if (h === c) {
            g = true;
            c = f;
            d = e;
            break;
          }
          if (h === d) {
            g = true;
            d = f;
            c = e;
            break;
          }
          h = h.sibling;
        }
        if (!g)
          throw Error(y(189));
      }
    }
    if (c.alternate !== d)
      throw Error(y(190));
  }
  if (c.tag !== 3)
    throw Error(y(188));
  return c.stateNode.current === c ? a : b;
}
function cc(a) {
  a = bc(a);
  if (!a)
    return null;
  for (var b = a; ; ) {
    if (b.tag === 5 || b.tag === 6)
      return b;
    if (b.child)
      b.child.return = b, b = b.child;
    else {
      if (b === a)
        break;
      for (; !b.sibling; ) {
        if (!b.return || b.return === a)
          return null;
        b = b.return;
      }
      b.sibling.return = b.return;
      b = b.sibling;
    }
  }
  return null;
}
function dc(a, b) {
  for (var c = a.alternate; b !== null; ) {
    if (b === a || b === c)
      return true;
    b = b.return;
  }
  return false;
}
var ec, fc, gc, hc, ic = false, jc = [], kc = null, lc = null, mc = null, nc = new Map(), oc = new Map(), pc = [], qc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function rc(a, b, c, d, e) {
  return {blockedOn: a, domEventName: b, eventSystemFlags: c | 16, nativeEvent: e, targetContainers: [d]};
}
function sc(a, b) {
  switch (a) {
    case "focusin":
    case "focusout":
      kc = null;
      break;
    case "dragenter":
    case "dragleave":
      lc = null;
      break;
    case "mouseover":
    case "mouseout":
      mc = null;
      break;
    case "pointerover":
    case "pointerout":
      nc.delete(b.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      oc.delete(b.pointerId);
  }
}
function tc(a, b, c, d, e, f) {
  if (a === null || a.nativeEvent !== f)
    return a = rc(b, c, d, e, f), b !== null && (b = Cb(b), b !== null && fc(b)), a;
  a.eventSystemFlags |= d;
  b = a.targetContainers;
  e !== null && b.indexOf(e) === -1 && b.push(e);
  return a;
}
function uc(a, b, c, d, e) {
  switch (b) {
    case "focusin":
      return kc = tc(kc, a, b, c, d, e), true;
    case "dragenter":
      return lc = tc(lc, a, b, c, d, e), true;
    case "mouseover":
      return mc = tc(mc, a, b, c, d, e), true;
    case "pointerover":
      var f = e.pointerId;
      nc.set(f, tc(nc.get(f) || null, a, b, c, d, e));
      return true;
    case "gotpointercapture":
      return f = e.pointerId, oc.set(f, tc(oc.get(f) || null, a, b, c, d, e)), true;
  }
  return false;
}
function vc(a) {
  var b = wc(a.target);
  if (b !== null) {
    var c = Zb(b);
    if (c !== null) {
      if (b = c.tag, b === 13) {
        if (b = $b(c), b !== null) {
          a.blockedOn = b;
          hc(a.lanePriority, function() {
            r.unstable_runWithPriority(a.priority, function() {
              gc(c);
            });
          });
          return;
        }
      } else if (b === 3 && c.stateNode.hydrate) {
        a.blockedOn = c.tag === 3 ? c.stateNode.containerInfo : null;
        return;
      }
    }
  }
  a.blockedOn = null;
}
function xc(a) {
  if (a.blockedOn !== null)
    return false;
  for (var b = a.targetContainers; 0 < b.length; ) {
    var c = yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
    if (c !== null)
      return b = Cb(c), b !== null && fc(b), a.blockedOn = c, false;
    b.shift();
  }
  return true;
}
function zc(a, b, c) {
  xc(a) && c.delete(b);
}
function Ac() {
  for (ic = false; 0 < jc.length; ) {
    var a = jc[0];
    if (a.blockedOn !== null) {
      a = Cb(a.blockedOn);
      a !== null && ec(a);
      break;
    }
    for (var b = a.targetContainers; 0 < b.length; ) {
      var c = yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
      if (c !== null) {
        a.blockedOn = c;
        break;
      }
      b.shift();
    }
    a.blockedOn === null && jc.shift();
  }
  kc !== null && xc(kc) && (kc = null);
  lc !== null && xc(lc) && (lc = null);
  mc !== null && xc(mc) && (mc = null);
  nc.forEach(zc);
  oc.forEach(zc);
}
function Bc(a, b) {
  a.blockedOn === b && (a.blockedOn = null, ic || (ic = true, r.unstable_scheduleCallback(r.unstable_NormalPriority, Ac)));
}
function Cc(a) {
  function b(b2) {
    return Bc(b2, a);
  }
  if (0 < jc.length) {
    Bc(jc[0], a);
    for (var c = 1; c < jc.length; c++) {
      var d = jc[c];
      d.blockedOn === a && (d.blockedOn = null);
    }
  }
  kc !== null && Bc(kc, a);
  lc !== null && Bc(lc, a);
  mc !== null && Bc(mc, a);
  nc.forEach(b);
  oc.forEach(b);
  for (c = 0; c < pc.length; c++)
    d = pc[c], d.blockedOn === a && (d.blockedOn = null);
  for (; 0 < pc.length && (c = pc[0], c.blockedOn === null); )
    vc(c), c.blockedOn === null && pc.shift();
}
function Dc(a, b) {
  var c = {};
  c[a.toLowerCase()] = b.toLowerCase();
  c["Webkit" + a] = "webkit" + b;
  c["Moz" + a] = "moz" + b;
  return c;
}
var Ec = {animationend: Dc("Animation", "AnimationEnd"), animationiteration: Dc("Animation", "AnimationIteration"), animationstart: Dc("Animation", "AnimationStart"), transitionend: Dc("Transition", "TransitionEnd")}, Fc = {}, Gc = {};
fa && (Gc = document.createElement("div").style, "AnimationEvent" in window || (delete Ec.animationend.animation, delete Ec.animationiteration.animation, delete Ec.animationstart.animation), "TransitionEvent" in window || delete Ec.transitionend.transition);
function Hc(a) {
  if (Fc[a])
    return Fc[a];
  if (!Ec[a])
    return a;
  var b = Ec[a], c;
  for (c in b)
    if (b.hasOwnProperty(c) && c in Gc)
      return Fc[a] = b[c];
  return a;
}
var Ic = Hc("animationend"), Jc = Hc("animationiteration"), Kc = Hc("animationstart"), Lc = Hc("transitionend"), Mc = new Map(), Nc = new Map(), Oc = [
  "abort",
  "abort",
  Ic,
  "animationEnd",
  Jc,
  "animationIteration",
  Kc,
  "animationStart",
  "canplay",
  "canPlay",
  "canplaythrough",
  "canPlayThrough",
  "durationchange",
  "durationChange",
  "emptied",
  "emptied",
  "encrypted",
  "encrypted",
  "ended",
  "ended",
  "error",
  "error",
  "gotpointercapture",
  "gotPointerCapture",
  "load",
  "load",
  "loadeddata",
  "loadedData",
  "loadedmetadata",
  "loadedMetadata",
  "loadstart",
  "loadStart",
  "lostpointercapture",
  "lostPointerCapture",
  "playing",
  "playing",
  "progress",
  "progress",
  "seeking",
  "seeking",
  "stalled",
  "stalled",
  "suspend",
  "suspend",
  "timeupdate",
  "timeUpdate",
  Lc,
  "transitionEnd",
  "waiting",
  "waiting"
];
function Pc(a, b) {
  for (var c = 0; c < a.length; c += 2) {
    var d = a[c], e = a[c + 1];
    e = "on" + (e[0].toUpperCase() + e.slice(1));
    Nc.set(d, b);
    Mc.set(d, e);
    da(e, [d]);
  }
}
var Qc = r.unstable_now;
Qc();
var F = 8;
function Rc(a) {
  if ((1 & a) !== 0)
    return F = 15, 1;
  if ((2 & a) !== 0)
    return F = 14, 2;
  if ((4 & a) !== 0)
    return F = 13, 4;
  var b = 24 & a;
  if (b !== 0)
    return F = 12, b;
  if ((a & 32) !== 0)
    return F = 11, 32;
  b = 192 & a;
  if (b !== 0)
    return F = 10, b;
  if ((a & 256) !== 0)
    return F = 9, 256;
  b = 3584 & a;
  if (b !== 0)
    return F = 8, b;
  if ((a & 4096) !== 0)
    return F = 7, 4096;
  b = 4186112 & a;
  if (b !== 0)
    return F = 6, b;
  b = 62914560 & a;
  if (b !== 0)
    return F = 5, b;
  if (a & 67108864)
    return F = 4, 67108864;
  if ((a & 134217728) !== 0)
    return F = 3, 134217728;
  b = 805306368 & a;
  if (b !== 0)
    return F = 2, b;
  if ((1073741824 & a) !== 0)
    return F = 1, 1073741824;
  F = 8;
  return a;
}
function Sc(a) {
  switch (a) {
    case 99:
      return 15;
    case 98:
      return 10;
    case 97:
    case 96:
      return 8;
    case 95:
      return 2;
    default:
      return 0;
  }
}
function Tc(a) {
  switch (a) {
    case 15:
    case 14:
      return 99;
    case 13:
    case 12:
    case 11:
    case 10:
      return 98;
    case 9:
    case 8:
    case 7:
    case 6:
    case 4:
    case 5:
      return 97;
    case 3:
    case 2:
    case 1:
      return 95;
    case 0:
      return 90;
    default:
      throw Error(y(358, a));
  }
}
function Uc(a, b) {
  var c = a.pendingLanes;
  if (c === 0)
    return F = 0;
  var d = 0, e = 0, f = a.expiredLanes, g = a.suspendedLanes, h = a.pingedLanes;
  if (f !== 0)
    d = f, e = F = 15;
  else if (f = c & 134217727, f !== 0) {
    var k = f & ~g;
    k !== 0 ? (d = Rc(k), e = F) : (h &= f, h !== 0 && (d = Rc(h), e = F));
  } else
    f = c & ~g, f !== 0 ? (d = Rc(f), e = F) : h !== 0 && (d = Rc(h), e = F);
  if (d === 0)
    return 0;
  d = 31 - Vc(d);
  d = c & ((0 > d ? 0 : 1 << d) << 1) - 1;
  if (b !== 0 && b !== d && (b & g) === 0) {
    Rc(b);
    if (e <= F)
      return b;
    F = e;
  }
  b = a.entangledLanes;
  if (b !== 0)
    for (a = a.entanglements, b &= d; 0 < b; )
      c = 31 - Vc(b), e = 1 << c, d |= a[c], b &= ~e;
  return d;
}
function Wc(a) {
  a = a.pendingLanes & -1073741825;
  return a !== 0 ? a : a & 1073741824 ? 1073741824 : 0;
}
function Xc(a, b) {
  switch (a) {
    case 15:
      return 1;
    case 14:
      return 2;
    case 12:
      return a = Yc(24 & ~b), a === 0 ? Xc(10, b) : a;
    case 10:
      return a = Yc(192 & ~b), a === 0 ? Xc(8, b) : a;
    case 8:
      return a = Yc(3584 & ~b), a === 0 && (a = Yc(4186112 & ~b), a === 0 && (a = 512)), a;
    case 2:
      return b = Yc(805306368 & ~b), b === 0 && (b = 268435456), b;
  }
  throw Error(y(358, a));
}
function Yc(a) {
  return a & -a;
}
function Zc(a) {
  for (var b = [], c = 0; 31 > c; c++)
    b.push(a);
  return b;
}
function $c(a, b, c) {
  a.pendingLanes |= b;
  var d = b - 1;
  a.suspendedLanes &= d;
  a.pingedLanes &= d;
  a = a.eventTimes;
  b = 31 - Vc(b);
  a[b] = c;
}
var Vc = Math.clz32 ? Math.clz32 : ad, bd = Math.log, cd = Math.LN2;
function ad(a) {
  return a === 0 ? 32 : 31 - (bd(a) / cd | 0) | 0;
}
var dd = r.unstable_UserBlockingPriority, ed = r.unstable_runWithPriority, fd = true;
function gd(a, b, c, d) {
  Kb || Ib();
  var e = hd, f = Kb;
  Kb = true;
  try {
    Hb(e, a, b, c, d);
  } finally {
    (Kb = f) || Mb();
  }
}
function id(a, b, c, d) {
  ed(dd, hd.bind(null, a, b, c, d));
}
function hd(a, b, c, d) {
  if (fd) {
    var e;
    if ((e = (b & 4) === 0) && 0 < jc.length && -1 < qc.indexOf(a))
      a = rc(null, a, b, c, d), jc.push(a);
    else {
      var f = yc(a, b, c, d);
      if (f === null)
        e && sc(a, d);
      else {
        if (e) {
          if (-1 < qc.indexOf(a)) {
            a = rc(f, a, b, c, d);
            jc.push(a);
            return;
          }
          if (uc(f, a, b, c, d))
            return;
          sc(a, d);
        }
        jd(a, b, d, null, c);
      }
    }
  }
}
function yc(a, b, c, d) {
  var e = xb(d);
  e = wc(e);
  if (e !== null) {
    var f = Zb(e);
    if (f === null)
      e = null;
    else {
      var g = f.tag;
      if (g === 13) {
        e = $b(f);
        if (e !== null)
          return e;
        e = null;
      } else if (g === 3) {
        if (f.stateNode.hydrate)
          return f.tag === 3 ? f.stateNode.containerInfo : null;
        e = null;
      } else
        f !== e && (e = null);
    }
  }
  jd(a, b, d, e, c);
  return null;
}
var kd = null, ld = null, md = null;
function nd() {
  if (md)
    return md;
  var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
  for (a = 0; a < c && b[a] === e[a]; a++)
    ;
  var g = c - a;
  for (d = 1; d <= g && b[c - d] === e[f - d]; d++)
    ;
  return md = e.slice(a, 1 < d ? 1 - d : void 0);
}
function od(a) {
  var b = a.keyCode;
  "charCode" in a ? (a = a.charCode, a === 0 && b === 13 && (a = 13)) : a = b;
  a === 10 && (a = 13);
  return 32 <= a || a === 13 ? a : 0;
}
function pd() {
  return true;
}
function qd() {
  return false;
}
function rd(a) {
  function b(b2, d, e, f, g) {
    this._reactName = b2;
    this._targetInst = e;
    this.type = d;
    this.nativeEvent = f;
    this.target = g;
    this.currentTarget = null;
    for (var c in a)
      a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
    this.isDefaultPrevented = (f.defaultPrevented != null ? f.defaultPrevented : f.returnValue === false) ? pd : qd;
    this.isPropagationStopped = qd;
    return this;
  }
  m(b.prototype, {preventDefault: function() {
    this.defaultPrevented = true;
    var a2 = this.nativeEvent;
    a2 && (a2.preventDefault ? a2.preventDefault() : typeof a2.returnValue !== "unknown" && (a2.returnValue = false), this.isDefaultPrevented = pd);
  }, stopPropagation: function() {
    var a2 = this.nativeEvent;
    a2 && (a2.stopPropagation ? a2.stopPropagation() : typeof a2.cancelBubble !== "unknown" && (a2.cancelBubble = true), this.isPropagationStopped = pd);
  }, persist: function() {
  }, isPersistent: pd});
  return b;
}
var sd = {eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
  return a.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0}, td = rd(sd), ud = m({}, sd, {view: 0, detail: 0}), vd = rd(ud), wd, xd, yd, Ad = m({}, ud, {screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
  return a.relatedTarget === void 0 ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
}, movementX: function(a) {
  if ("movementX" in a)
    return a.movementX;
  a !== yd && (yd && a.type === "mousemove" ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
  return wd;
}, movementY: function(a) {
  return "movementY" in a ? a.movementY : xd;
}}), Bd = rd(Ad), Cd = m({}, Ad, {dataTransfer: 0}), Dd = rd(Cd), Ed = m({}, ud, {relatedTarget: 0}), Fd = rd(Ed), Gd = m({}, sd, {animationName: 0, elapsedTime: 0, pseudoElement: 0}), Hd = rd(Gd), Id = m({}, sd, {clipboardData: function(a) {
  return "clipboardData" in a ? a.clipboardData : window.clipboardData;
}}), Jd = rd(Id), Kd = m({}, sd, {data: 0}), Ld = rd(Kd), Md = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, Nd = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, Od = {Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey"};
function Pd(a) {
  var b = this.nativeEvent;
  return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
}
function zd() {
  return Pd;
}
var Qd = m({}, ud, {key: function(a) {
  if (a.key) {
    var b = Md[a.key] || a.key;
    if (b !== "Unidentified")
      return b;
  }
  return a.type === "keypress" ? (a = od(a), a === 13 ? "Enter" : String.fromCharCode(a)) : a.type === "keydown" || a.type === "keyup" ? Nd[a.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
  return a.type === "keypress" ? od(a) : 0;
}, keyCode: function(a) {
  return a.type === "keydown" || a.type === "keyup" ? a.keyCode : 0;
}, which: function(a) {
  return a.type === "keypress" ? od(a) : a.type === "keydown" || a.type === "keyup" ? a.keyCode : 0;
}}), Rd = rd(Qd), Sd = m({}, Ad, {pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0}), Td = rd(Sd), Ud = m({}, ud, {touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd}), Vd = rd(Ud), Wd = m({}, sd, {propertyName: 0, elapsedTime: 0, pseudoElement: 0}), Xd = rd(Wd), Yd = m({}, Ad, {
  deltaX: function(a) {
    return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
  },
  deltaY: function(a) {
    return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), Zd = rd(Yd), $d = [9, 13, 27, 32], ae = fa && "CompositionEvent" in window, be = null;
fa && "documentMode" in document && (be = document.documentMode);
var ce = fa && "TextEvent" in window && !be, de = fa && (!ae || be && 8 < be && 11 >= be), ee = String.fromCharCode(32), fe = false;
function ge(a, b) {
  switch (a) {
    case "keyup":
      return $d.indexOf(b.keyCode) !== -1;
    case "keydown":
      return b.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return true;
    default:
      return false;
  }
}
function he(a) {
  a = a.detail;
  return typeof a === "object" && "data" in a ? a.data : null;
}
var ie = false;
function je(a, b) {
  switch (a) {
    case "compositionend":
      return he(b);
    case "keypress":
      if (b.which !== 32)
        return null;
      fe = true;
      return ee;
    case "textInput":
      return a = b.data, a === ee && fe ? null : a;
    default:
      return null;
  }
}
function ke(a, b) {
  if (ie)
    return a === "compositionend" || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
  switch (a) {
    case "paste":
      return null;
    case "keypress":
      if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
        if (b.char && 1 < b.char.length)
          return b.char;
        if (b.which)
          return String.fromCharCode(b.which);
      }
      return null;
    case "compositionend":
      return de && b.locale !== "ko" ? null : b.data;
    default:
      return null;
  }
}
var le = {color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true};
function me(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return b === "input" ? !!le[a.type] : b === "textarea" ? true : false;
}
function ne(a, b, c, d) {
  Eb(d);
  b = oe(b, "onChange");
  0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({event: c, listeners: b}));
}
var pe = null, qe = null;
function re(a) {
  se(a, 0);
}
function te(a) {
  var b = ue(a);
  if (Wa(b))
    return a;
}
function ve(a, b) {
  if (a === "change")
    return b;
}
var we = false;
if (fa) {
  var xe;
  if (fa) {
    var ye = "oninput" in document;
    if (!ye) {
      var ze = document.createElement("div");
      ze.setAttribute("oninput", "return;");
      ye = typeof ze.oninput === "function";
    }
    xe = ye;
  } else
    xe = false;
  we = xe && (!document.documentMode || 9 < document.documentMode);
}
function Ae() {
  pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
}
function Be(a) {
  if (a.propertyName === "value" && te(qe)) {
    var b = [];
    ne(b, qe, a, xb(a));
    a = re;
    if (Kb)
      a(b);
    else {
      Kb = true;
      try {
        Gb(a, b);
      } finally {
        Kb = false, Mb();
      }
    }
  }
}
function Ce(a, b, c) {
  a === "focusin" ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : a === "focusout" && Ae();
}
function De(a) {
  if (a === "selectionchange" || a === "keyup" || a === "keydown")
    return te(qe);
}
function Ee(a, b) {
  if (a === "click")
    return te(b);
}
function Fe(a, b) {
  if (a === "input" || a === "change")
    return te(b);
}
function Ge(a, b) {
  return a === b && (a !== 0 || 1 / a === 1 / b) || a !== a && b !== b;
}
var He = typeof Object.is === "function" ? Object.is : Ge, Ie = Object.prototype.hasOwnProperty;
function Je(a, b) {
  if (He(a, b))
    return true;
  if (typeof a !== "object" || a === null || typeof b !== "object" || b === null)
    return false;
  var c = Object.keys(a), d = Object.keys(b);
  if (c.length !== d.length)
    return false;
  for (d = 0; d < c.length; d++)
    if (!Ie.call(b, c[d]) || !He(a[c[d]], b[c[d]]))
      return false;
  return true;
}
function Ke(a) {
  for (; a && a.firstChild; )
    a = a.firstChild;
  return a;
}
function Le(a, b) {
  var c = Ke(a);
  a = 0;
  for (var d; c; ) {
    if (c.nodeType === 3) {
      d = a + c.textContent.length;
      if (a <= b && d >= b)
        return {node: c, offset: b - a};
      a = d;
    }
    a: {
      for (; c; ) {
        if (c.nextSibling) {
          c = c.nextSibling;
          break a;
        }
        c = c.parentNode;
      }
      c = void 0;
    }
    c = Ke(c);
  }
}
function Me(a, b) {
  return a && b ? a === b ? true : a && a.nodeType === 3 ? false : b && b.nodeType === 3 ? Me(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
}
function Ne() {
  for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
    try {
      var c = typeof b.contentWindow.location.href === "string";
    } catch (d) {
      c = false;
    }
    if (c)
      a = b.contentWindow;
    else
      break;
    b = Xa(a.document);
  }
  return b;
}
function Oe(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return b && (b === "input" && (a.type === "text" || a.type === "search" || a.type === "tel" || a.type === "url" || a.type === "password") || b === "textarea" || a.contentEditable === "true");
}
var Pe = fa && "documentMode" in document && 11 >= document.documentMode, Qe = null, Re = null, Se = null, Te = false;
function Ue(a, b, c) {
  var d = c.window === c ? c.document : c.nodeType === 9 ? c : c.ownerDocument;
  Te || Qe == null || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Oe(d) ? d = {start: d.selectionStart, end: d.selectionEnd} : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = {anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset}), Se && Je(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({event: b, listeners: d}), b.target = Qe)));
}
Pc("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "), 0);
Pc("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "), 1);
Pc(Oc, 2);
for (var Ve = "change selectionchange textInput compositionstart compositionend compositionupdate".split(" "), We = 0; We < Ve.length; We++)
  Nc.set(Ve[We], 0);
ea("onMouseEnter", ["mouseout", "mouseover"]);
ea("onMouseLeave", ["mouseout", "mouseover"]);
ea("onPointerEnter", ["pointerout", "pointerover"]);
ea("onPointerLeave", ["pointerout", "pointerover"]);
da("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
da("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
da("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
da("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
da("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Xe = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), Ye = new Set("cancel close invalid load scroll toggle".split(" ").concat(Xe));
function Ze(a, b, c) {
  var d = a.type || "unknown-event";
  a.currentTarget = c;
  Yb(d, b, void 0, a);
  a.currentTarget = null;
}
function se(a, b) {
  b = (b & 4) !== 0;
  for (var c = 0; c < a.length; c++) {
    var d = a[c], e = d.event;
    d = d.listeners;
    a: {
      var f = void 0;
      if (b)
        for (var g = d.length - 1; 0 <= g; g--) {
          var h = d[g], k = h.instance, l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped())
            break a;
          Ze(e, h, l);
          f = k;
        }
      else
        for (g = 0; g < d.length; g++) {
          h = d[g];
          k = h.instance;
          l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped())
            break a;
          Ze(e, h, l);
          f = k;
        }
    }
  }
  if (Ub)
    throw a = Vb, Ub = false, Vb = null, a;
}
function G(a, b) {
  var c = $e(b), d = a + "__bubble";
  c.has(d) || (af(b, a, 2, false), c.add(d));
}
var bf = "_reactListening" + Math.random().toString(36).slice(2);
function cf(a) {
  a[bf] || (a[bf] = true, ba.forEach(function(b) {
    Ye.has(b) || df(b, false, a, null);
    df(b, true, a, null);
  }));
}
function df(a, b, c, d) {
  var e = 4 < arguments.length && arguments[4] !== void 0 ? arguments[4] : 0, f = c;
  a === "selectionchange" && c.nodeType !== 9 && (f = c.ownerDocument);
  if (d !== null && !b && Ye.has(a)) {
    if (a !== "scroll")
      return;
    e |= 2;
    f = d;
  }
  var g = $e(f), h = a + "__" + (b ? "capture" : "bubble");
  g.has(h) || (b && (e |= 4), af(f, a, e, b), g.add(h));
}
function af(a, b, c, d) {
  var e = Nc.get(b);
  switch (e === void 0 ? 2 : e) {
    case 0:
      e = gd;
      break;
    case 1:
      e = id;
      break;
    default:
      e = hd;
  }
  c = e.bind(null, b, c, a);
  e = void 0;
  !Pb || b !== "touchstart" && b !== "touchmove" && b !== "wheel" || (e = true);
  d ? e !== void 0 ? a.addEventListener(b, c, {capture: true, passive: e}) : a.addEventListener(b, c, true) : e !== void 0 ? a.addEventListener(b, c, {passive: e}) : a.addEventListener(b, c, false);
}
function jd(a, b, c, d, e) {
  var f = d;
  if ((b & 1) === 0 && (b & 2) === 0 && d !== null)
    a:
      for (; ; ) {
        if (d === null)
          return;
        var g = d.tag;
        if (g === 3 || g === 4) {
          var h = d.stateNode.containerInfo;
          if (h === e || h.nodeType === 8 && h.parentNode === e)
            break;
          if (g === 4)
            for (g = d.return; g !== null; ) {
              var k = g.tag;
              if (k === 3 || k === 4) {
                if (k = g.stateNode.containerInfo, k === e || k.nodeType === 8 && k.parentNode === e)
                  return;
              }
              g = g.return;
            }
          for (; h !== null; ) {
            g = wc(h);
            if (g === null)
              return;
            k = g.tag;
            if (k === 5 || k === 6) {
              d = f = g;
              continue a;
            }
            h = h.parentNode;
          }
        }
        d = d.return;
      }
  Nb(function() {
    var d2 = f, e2 = xb(c), g2 = [];
    a: {
      var h2 = Mc.get(a);
      if (h2 !== void 0) {
        var k2 = td, x = a;
        switch (a) {
          case "keypress":
            if (od(c) === 0)
              break a;
          case "keydown":
          case "keyup":
            k2 = Rd;
            break;
          case "focusin":
            x = "focus";
            k2 = Fd;
            break;
          case "focusout":
            x = "blur";
            k2 = Fd;
            break;
          case "beforeblur":
          case "afterblur":
            k2 = Fd;
            break;
          case "click":
            if (c.button === 2)
              break a;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            k2 = Bd;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            k2 = Dd;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            k2 = Vd;
            break;
          case Ic:
          case Jc:
          case Kc:
            k2 = Hd;
            break;
          case Lc:
            k2 = Xd;
            break;
          case "scroll":
            k2 = vd;
            break;
          case "wheel":
            k2 = Zd;
            break;
          case "copy":
          case "cut":
          case "paste":
            k2 = Jd;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            k2 = Td;
        }
        var w = (b & 4) !== 0, z = !w && a === "scroll", u = w ? h2 !== null ? h2 + "Capture" : null : h2;
        w = [];
        for (var t = d2, q; t !== null; ) {
          q = t;
          var v = q.stateNode;
          q.tag === 5 && v !== null && (q = v, u !== null && (v = Ob(t, u), v != null && w.push(ef(t, v, q))));
          if (z)
            break;
          t = t.return;
        }
        0 < w.length && (h2 = new k2(h2, x, null, c, e2), g2.push({event: h2, listeners: w}));
      }
    }
    if ((b & 7) === 0) {
      a: {
        h2 = a === "mouseover" || a === "pointerover";
        k2 = a === "mouseout" || a === "pointerout";
        if (h2 && (b & 16) === 0 && (x = c.relatedTarget || c.fromElement) && (wc(x) || x[ff]))
          break a;
        if (k2 || h2) {
          h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
          if (k2) {
            if (x = c.relatedTarget || c.toElement, k2 = d2, x = x ? wc(x) : null, x !== null && (z = Zb(x), x !== z || x.tag !== 5 && x.tag !== 6))
              x = null;
          } else
            k2 = null, x = d2;
          if (k2 !== x) {
            w = Bd;
            v = "onMouseLeave";
            u = "onMouseEnter";
            t = "mouse";
            if (a === "pointerout" || a === "pointerover")
              w = Td, v = "onPointerLeave", u = "onPointerEnter", t = "pointer";
            z = k2 == null ? h2 : ue(k2);
            q = x == null ? h2 : ue(x);
            h2 = new w(v, t + "leave", k2, c, e2);
            h2.target = z;
            h2.relatedTarget = q;
            v = null;
            wc(e2) === d2 && (w = new w(u, t + "enter", x, c, e2), w.target = q, w.relatedTarget = z, v = w);
            z = v;
            if (k2 && x)
              b: {
                w = k2;
                u = x;
                t = 0;
                for (q = w; q; q = gf(q))
                  t++;
                q = 0;
                for (v = u; v; v = gf(v))
                  q++;
                for (; 0 < t - q; )
                  w = gf(w), t--;
                for (; 0 < q - t; )
                  u = gf(u), q--;
                for (; t--; ) {
                  if (w === u || u !== null && w === u.alternate)
                    break b;
                  w = gf(w);
                  u = gf(u);
                }
                w = null;
              }
            else
              w = null;
            k2 !== null && hf(g2, h2, k2, w, false);
            x !== null && z !== null && hf(g2, z, x, w, true);
          }
        }
      }
      a: {
        h2 = d2 ? ue(d2) : window;
        k2 = h2.nodeName && h2.nodeName.toLowerCase();
        if (k2 === "select" || k2 === "input" && h2.type === "file")
          var J = ve;
        else if (me(h2))
          if (we)
            J = Fe;
          else {
            J = De;
            var K = Ce;
          }
        else
          (k2 = h2.nodeName) && k2.toLowerCase() === "input" && (h2.type === "checkbox" || h2.type === "radio") && (J = Ee);
        if (J && (J = J(a, d2))) {
          ne(g2, J, c, e2);
          break a;
        }
        K && K(a, h2, d2);
        a === "focusout" && (K = h2._wrapperState) && K.controlled && h2.type === "number" && bb(h2, "number", h2.value);
      }
      K = d2 ? ue(d2) : window;
      switch (a) {
        case "focusin":
          if (me(K) || K.contentEditable === "true")
            Qe = K, Re = d2, Se = null;
          break;
        case "focusout":
          Se = Re = Qe = null;
          break;
        case "mousedown":
          Te = true;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          Te = false;
          Ue(g2, c, e2);
          break;
        case "selectionchange":
          if (Pe)
            break;
        case "keydown":
        case "keyup":
          Ue(g2, c, e2);
      }
      var Q;
      if (ae)
        b: {
          switch (a) {
            case "compositionstart":
              var L = "onCompositionStart";
              break b;
            case "compositionend":
              L = "onCompositionEnd";
              break b;
            case "compositionupdate":
              L = "onCompositionUpdate";
              break b;
          }
          L = void 0;
        }
      else
        ie ? ge(a, c) && (L = "onCompositionEnd") : a === "keydown" && c.keyCode === 229 && (L = "onCompositionStart");
      L && (de && c.locale !== "ko" && (ie || L !== "onCompositionStart" ? L === "onCompositionEnd" && ie && (Q = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), K = oe(d2, L), 0 < K.length && (L = new Ld(L, a, null, c, e2), g2.push({event: L, listeners: K}), Q ? L.data = Q : (Q = he(c), Q !== null && (L.data = Q))));
      if (Q = ce ? je(a, c) : ke(a, c))
        d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({event: e2, listeners: d2}), e2.data = Q);
    }
    se(g2, b);
  });
}
function ef(a, b, c) {
  return {instance: a, listener: b, currentTarget: c};
}
function oe(a, b) {
  for (var c = b + "Capture", d = []; a !== null; ) {
    var e = a, f = e.stateNode;
    e.tag === 5 && f !== null && (e = f, f = Ob(a, c), f != null && d.unshift(ef(a, f, e)), f = Ob(a, b), f != null && d.push(ef(a, f, e)));
    a = a.return;
  }
  return d;
}
function gf(a) {
  if (a === null)
    return null;
  do
    a = a.return;
  while (a && a.tag !== 5);
  return a ? a : null;
}
function hf(a, b, c, d, e) {
  for (var f = b._reactName, g = []; c !== null && c !== d; ) {
    var h = c, k = h.alternate, l = h.stateNode;
    if (k !== null && k === d)
      break;
    h.tag === 5 && l !== null && (h = l, e ? (k = Ob(c, f), k != null && g.unshift(ef(c, k, h))) : e || (k = Ob(c, f), k != null && g.push(ef(c, k, h))));
    c = c.return;
  }
  g.length !== 0 && a.push({event: b, listeners: g});
}
function jf() {
}
var kf = null, lf = null;
function mf(a, b) {
  switch (a) {
    case "button":
    case "input":
    case "select":
    case "textarea":
      return !!b.autoFocus;
  }
  return false;
}
function nf(a, b) {
  return a === "textarea" || a === "option" || a === "noscript" || typeof b.children === "string" || typeof b.children === "number" || typeof b.dangerouslySetInnerHTML === "object" && b.dangerouslySetInnerHTML !== null && b.dangerouslySetInnerHTML.__html != null;
}
var of = typeof setTimeout === "function" ? setTimeout : void 0, pf = typeof clearTimeout === "function" ? clearTimeout : void 0;
function qf(a) {
  a.nodeType === 1 ? a.textContent = "" : a.nodeType === 9 && (a = a.body, a != null && (a.textContent = ""));
}
function rf(a) {
  for (; a != null; a = a.nextSibling) {
    var b = a.nodeType;
    if (b === 1 || b === 3)
      break;
  }
  return a;
}
function sf(a) {
  a = a.previousSibling;
  for (var b = 0; a; ) {
    if (a.nodeType === 8) {
      var c = a.data;
      if (c === "$" || c === "$!" || c === "$?") {
        if (b === 0)
          return a;
        b--;
      } else
        c === "/$" && b++;
    }
    a = a.previousSibling;
  }
  return null;
}
var tf = 0;
function uf(a) {
  return {$$typeof: Ga, toString: a, valueOf: a};
}
var vf = Math.random().toString(36).slice(2), wf = "__reactFiber$" + vf, xf = "__reactProps$" + vf, ff = "__reactContainer$" + vf, yf = "__reactEvents$" + vf;
function wc(a) {
  var b = a[wf];
  if (b)
    return b;
  for (var c = a.parentNode; c; ) {
    if (b = c[ff] || c[wf]) {
      c = b.alternate;
      if (b.child !== null || c !== null && c.child !== null)
        for (a = sf(a); a !== null; ) {
          if (c = a[wf])
            return c;
          a = sf(a);
        }
      return b;
    }
    a = c;
    c = a.parentNode;
  }
  return null;
}
function Cb(a) {
  a = a[wf] || a[ff];
  return !a || a.tag !== 5 && a.tag !== 6 && a.tag !== 13 && a.tag !== 3 ? null : a;
}
function ue(a) {
  if (a.tag === 5 || a.tag === 6)
    return a.stateNode;
  throw Error(y(33));
}
function Db(a) {
  return a[xf] || null;
}
function $e(a) {
  var b = a[yf];
  b === void 0 && (b = a[yf] = new Set());
  return b;
}
var zf = [], Af = -1;
function Bf(a) {
  return {current: a};
}
function H(a) {
  0 > Af || (a.current = zf[Af], zf[Af] = null, Af--);
}
function I(a, b) {
  Af++;
  zf[Af] = a.current;
  a.current = b;
}
var Cf = {}, M = Bf(Cf), N = Bf(false), Df = Cf;
function Ef(a, b) {
  var c = a.type.contextTypes;
  if (!c)
    return Cf;
  var d = a.stateNode;
  if (d && d.__reactInternalMemoizedUnmaskedChildContext === b)
    return d.__reactInternalMemoizedMaskedChildContext;
  var e = {}, f;
  for (f in c)
    e[f] = b[f];
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
  return e;
}
function Ff(a) {
  a = a.childContextTypes;
  return a !== null && a !== void 0;
}
function Gf() {
  H(N);
  H(M);
}
function Hf(a, b, c) {
  if (M.current !== Cf)
    throw Error(y(168));
  I(M, b);
  I(N, c);
}
function If(a, b, c) {
  var d = a.stateNode;
  a = b.childContextTypes;
  if (typeof d.getChildContext !== "function")
    return c;
  d = d.getChildContext();
  for (var e in d)
    if (!(e in a))
      throw Error(y(108, Ra(b) || "Unknown", e));
  return m({}, c, d);
}
function Jf(a) {
  a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Cf;
  Df = M.current;
  I(M, a);
  I(N, N.current);
  return true;
}
function Kf(a, b, c) {
  var d = a.stateNode;
  if (!d)
    throw Error(y(169));
  c ? (a = If(a, b, Df), d.__reactInternalMemoizedMergedChildContext = a, H(N), H(M), I(M, a)) : H(N);
  I(N, c);
}
var Lf = null, Mf = null, Nf = r.unstable_runWithPriority, Of = r.unstable_scheduleCallback, Pf = r.unstable_cancelCallback, Qf = r.unstable_shouldYield, Rf = r.unstable_requestPaint, Sf = r.unstable_now, Tf = r.unstable_getCurrentPriorityLevel, Uf = r.unstable_ImmediatePriority, Vf = r.unstable_UserBlockingPriority, Wf = r.unstable_NormalPriority, Xf = r.unstable_LowPriority, Yf = r.unstable_IdlePriority, Zf = {}, $f = Rf !== void 0 ? Rf : function() {
}, ag = null, bg = null, cg = false, dg = Sf(), O = 1e4 > dg ? Sf : function() {
  return Sf() - dg;
};
function eg() {
  switch (Tf()) {
    case Uf:
      return 99;
    case Vf:
      return 98;
    case Wf:
      return 97;
    case Xf:
      return 96;
    case Yf:
      return 95;
    default:
      throw Error(y(332));
  }
}
function fg(a) {
  switch (a) {
    case 99:
      return Uf;
    case 98:
      return Vf;
    case 97:
      return Wf;
    case 96:
      return Xf;
    case 95:
      return Yf;
    default:
      throw Error(y(332));
  }
}
function gg(a, b) {
  a = fg(a);
  return Nf(a, b);
}
function hg(a, b, c) {
  a = fg(a);
  return Of(a, b, c);
}
function ig() {
  if (bg !== null) {
    var a = bg;
    bg = null;
    Pf(a);
  }
  jg();
}
function jg() {
  if (!cg && ag !== null) {
    cg = true;
    var a = 0;
    try {
      var b = ag;
      gg(99, function() {
        for (; a < b.length; a++) {
          var c = b[a];
          do
            c = c(true);
          while (c !== null);
        }
      });
      ag = null;
    } catch (c) {
      throw ag !== null && (ag = ag.slice(a + 1)), Of(Uf, ig), c;
    } finally {
      cg = false;
    }
  }
}
var kg = ra.ReactCurrentBatchConfig;
function lg(a, b) {
  if (a && a.defaultProps) {
    b = m({}, b);
    a = a.defaultProps;
    for (var c in a)
      b[c] === void 0 && (b[c] = a[c]);
    return b;
  }
  return b;
}
var mg = Bf(null), ng = null, og = null, pg = null;
function qg() {
  pg = og = ng = null;
}
function rg(a) {
  var b = mg.current;
  H(mg);
  a.type._context._currentValue = b;
}
function sg(a, b) {
  for (; a !== null; ) {
    var c = a.alternate;
    if ((a.childLanes & b) === b)
      if (c === null || (c.childLanes & b) === b)
        break;
      else
        c.childLanes |= b;
    else
      a.childLanes |= b, c !== null && (c.childLanes |= b);
    a = a.return;
  }
}
function tg(a, b) {
  ng = a;
  pg = og = null;
  a = a.dependencies;
  a !== null && a.firstContext !== null && ((a.lanes & b) !== 0 && (ug = true), a.firstContext = null);
}
function vg(a, b) {
  if (pg !== a && b !== false && b !== 0) {
    if (typeof b !== "number" || b === 1073741823)
      pg = a, b = 1073741823;
    b = {context: a, observedBits: b, next: null};
    if (og === null) {
      if (ng === null)
        throw Error(y(308));
      og = b;
      ng.dependencies = {lanes: 0, firstContext: b, responders: null};
    } else
      og = og.next = b;
  }
  return a._currentValue;
}
var wg = false;
function xg(a) {
  a.updateQueue = {baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: {pending: null}, effects: null};
}
function yg(a, b) {
  a = a.updateQueue;
  b.updateQueue === a && (b.updateQueue = {baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects});
}
function zg(a, b) {
  return {eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null};
}
function Ag(a, b) {
  a = a.updateQueue;
  if (a !== null) {
    a = a.shared;
    var c = a.pending;
    c === null ? b.next = b : (b.next = c.next, c.next = b);
    a.pending = b;
  }
}
function Bg(a, b) {
  var c = a.updateQueue, d = a.alternate;
  if (d !== null && (d = d.updateQueue, c === d)) {
    var e = null, f = null;
    c = c.firstBaseUpdate;
    if (c !== null) {
      do {
        var g = {eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null};
        f === null ? e = f = g : f = f.next = g;
        c = c.next;
      } while (c !== null);
      f === null ? e = f = b : f = f.next = b;
    } else
      e = f = b;
    c = {baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects};
    a.updateQueue = c;
    return;
  }
  a = c.lastBaseUpdate;
  a === null ? c.firstBaseUpdate = b : a.next = b;
  c.lastBaseUpdate = b;
}
function Cg(a, b, c, d) {
  var e = a.updateQueue;
  wg = false;
  var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
  if (h !== null) {
    e.shared.pending = null;
    var k = h, l = k.next;
    k.next = null;
    g === null ? f = l : g.next = l;
    g = k;
    var n = a.alternate;
    if (n !== null) {
      n = n.updateQueue;
      var A = n.lastBaseUpdate;
      A !== g && (A === null ? n.firstBaseUpdate = l : A.next = l, n.lastBaseUpdate = k);
    }
  }
  if (f !== null) {
    A = e.baseState;
    g = 0;
    n = l = k = null;
    do {
      h = f.lane;
      var p = f.eventTime;
      if ((d & h) === h) {
        n !== null && (n = n.next = {
          eventTime: p,
          lane: 0,
          tag: f.tag,
          payload: f.payload,
          callback: f.callback,
          next: null
        });
        a: {
          var C = a, x = f;
          h = b;
          p = c;
          switch (x.tag) {
            case 1:
              C = x.payload;
              if (typeof C === "function") {
                A = C.call(p, A, h);
                break a;
              }
              A = C;
              break a;
            case 3:
              C.flags = C.flags & -4097 | 64;
            case 0:
              C = x.payload;
              h = typeof C === "function" ? C.call(p, A, h) : C;
              if (h === null || h === void 0)
                break a;
              A = m({}, A, h);
              break a;
            case 2:
              wg = true;
          }
        }
        f.callback !== null && (a.flags |= 32, h = e.effects, h === null ? e.effects = [f] : h.push(f));
      } else
        p = {eventTime: p, lane: h, tag: f.tag, payload: f.payload, callback: f.callback, next: null}, n === null ? (l = n = p, k = A) : n = n.next = p, g |= h;
      f = f.next;
      if (f === null)
        if (h = e.shared.pending, h === null)
          break;
        else
          f = h.next, h.next = null, e.lastBaseUpdate = h, e.shared.pending = null;
    } while (1);
    n === null && (k = A);
    e.baseState = k;
    e.firstBaseUpdate = l;
    e.lastBaseUpdate = n;
    Dg |= g;
    a.lanes = g;
    a.memoizedState = A;
  }
}
function Eg(a, b, c) {
  a = b.effects;
  b.effects = null;
  if (a !== null)
    for (b = 0; b < a.length; b++) {
      var d = a[b], e = d.callback;
      if (e !== null) {
        d.callback = null;
        d = c;
        if (typeof e !== "function")
          throw Error(y(191, e));
        e.call(d);
      }
    }
}
var Fg = new aa.Component().refs;
function Gg(a, b, c, d) {
  b = a.memoizedState;
  c = c(d, b);
  c = c === null || c === void 0 ? b : m({}, b, c);
  a.memoizedState = c;
  a.lanes === 0 && (a.updateQueue.baseState = c);
}
var Kg = {isMounted: function(a) {
  return (a = a._reactInternals) ? Zb(a) === a : false;
}, enqueueSetState: function(a, b, c) {
  a = a._reactInternals;
  var d = Hg(), e = Ig(a), f = zg(d, e);
  f.payload = b;
  c !== void 0 && c !== null && (f.callback = c);
  Ag(a, f);
  Jg(a, e, d);
}, enqueueReplaceState: function(a, b, c) {
  a = a._reactInternals;
  var d = Hg(), e = Ig(a), f = zg(d, e);
  f.tag = 1;
  f.payload = b;
  c !== void 0 && c !== null && (f.callback = c);
  Ag(a, f);
  Jg(a, e, d);
}, enqueueForceUpdate: function(a, b) {
  a = a._reactInternals;
  var c = Hg(), d = Ig(a), e = zg(c, d);
  e.tag = 2;
  b !== void 0 && b !== null && (e.callback = b);
  Ag(a, e);
  Jg(a, d, c);
}};
function Lg(a, b, c, d, e, f, g) {
  a = a.stateNode;
  return typeof a.shouldComponentUpdate === "function" ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Je(c, d) || !Je(e, f) : true;
}
function Mg(a, b, c) {
  var d = false, e = Cf;
  var f = b.contextType;
  typeof f === "object" && f !== null ? f = vg(f) : (e = Ff(b) ? Df : M.current, d = b.contextTypes, f = (d = d !== null && d !== void 0) ? Ef(a, e) : Cf);
  b = new b(c, f);
  a.memoizedState = b.state !== null && b.state !== void 0 ? b.state : null;
  b.updater = Kg;
  a.stateNode = b;
  b._reactInternals = a;
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
  return b;
}
function Ng(a, b, c, d) {
  a = b.state;
  typeof b.componentWillReceiveProps === "function" && b.componentWillReceiveProps(c, d);
  typeof b.UNSAFE_componentWillReceiveProps === "function" && b.UNSAFE_componentWillReceiveProps(c, d);
  b.state !== a && Kg.enqueueReplaceState(b, b.state, null);
}
function Og(a, b, c, d) {
  var e = a.stateNode;
  e.props = c;
  e.state = a.memoizedState;
  e.refs = Fg;
  xg(a);
  var f = b.contextType;
  typeof f === "object" && f !== null ? e.context = vg(f) : (f = Ff(b) ? Df : M.current, e.context = Ef(a, f));
  Cg(a, c, e, d);
  e.state = a.memoizedState;
  f = b.getDerivedStateFromProps;
  typeof f === "function" && (Gg(a, b, f, c), e.state = a.memoizedState);
  typeof b.getDerivedStateFromProps === "function" || typeof e.getSnapshotBeforeUpdate === "function" || typeof e.UNSAFE_componentWillMount !== "function" && typeof e.componentWillMount !== "function" || (b = e.state, typeof e.componentWillMount === "function" && e.componentWillMount(), typeof e.UNSAFE_componentWillMount === "function" && e.UNSAFE_componentWillMount(), b !== e.state && Kg.enqueueReplaceState(e, e.state, null), Cg(a, c, e, d), e.state = a.memoizedState);
  typeof e.componentDidMount === "function" && (a.flags |= 4);
}
var Pg = Array.isArray;
function Qg(a, b, c) {
  a = c.ref;
  if (a !== null && typeof a !== "function" && typeof a !== "object") {
    if (c._owner) {
      c = c._owner;
      if (c) {
        if (c.tag !== 1)
          throw Error(y(309));
        var d = c.stateNode;
      }
      if (!d)
        throw Error(y(147, a));
      var e = "" + a;
      if (b !== null && b.ref !== null && typeof b.ref === "function" && b.ref._stringRef === e)
        return b.ref;
      b = function(a2) {
        var b2 = d.refs;
        b2 === Fg && (b2 = d.refs = {});
        a2 === null ? delete b2[e] : b2[e] = a2;
      };
      b._stringRef = e;
      return b;
    }
    if (typeof a !== "string")
      throw Error(y(284));
    if (!c._owner)
      throw Error(y(290, a));
  }
  return a;
}
function Rg(a, b) {
  if (a.type !== "textarea")
    throw Error(y(31, Object.prototype.toString.call(b) === "[object Object]" ? "object with keys {" + Object.keys(b).join(", ") + "}" : b));
}
function Sg(a) {
  function b(b2, c2) {
    if (a) {
      var d2 = b2.lastEffect;
      d2 !== null ? (d2.nextEffect = c2, b2.lastEffect = c2) : b2.firstEffect = b2.lastEffect = c2;
      c2.nextEffect = null;
      c2.flags = 8;
    }
  }
  function c(c2, d2) {
    if (!a)
      return null;
    for (; d2 !== null; )
      b(c2, d2), d2 = d2.sibling;
    return null;
  }
  function d(a2, b2) {
    for (a2 = new Map(); b2 !== null; )
      b2.key !== null ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
    return a2;
  }
  function e(a2, b2) {
    a2 = Tg(a2, b2);
    a2.index = 0;
    a2.sibling = null;
    return a2;
  }
  function f(b2, c2, d2) {
    b2.index = d2;
    if (!a)
      return c2;
    d2 = b2.alternate;
    if (d2 !== null)
      return d2 = d2.index, d2 < c2 ? (b2.flags = 2, c2) : d2;
    b2.flags = 2;
    return c2;
  }
  function g(b2) {
    a && b2.alternate === null && (b2.flags = 2);
    return b2;
  }
  function h(a2, b2, c2, d2) {
    if (b2 === null || b2.tag !== 6)
      return b2 = Ug(c2, a2.mode, d2), b2.return = a2, b2;
    b2 = e(b2, c2);
    b2.return = a2;
    return b2;
  }
  function k(a2, b2, c2, d2) {
    if (b2 !== null && b2.elementType === c2.type)
      return d2 = e(b2, c2.props), d2.ref = Qg(a2, b2, c2), d2.return = a2, d2;
    d2 = Vg(c2.type, c2.key, c2.props, null, a2.mode, d2);
    d2.ref = Qg(a2, b2, c2);
    d2.return = a2;
    return d2;
  }
  function l(a2, b2, c2, d2) {
    if (b2 === null || b2.tag !== 4 || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation)
      return b2 = Wg(c2, a2.mode, d2), b2.return = a2, b2;
    b2 = e(b2, c2.children || []);
    b2.return = a2;
    return b2;
  }
  function n(a2, b2, c2, d2, f2) {
    if (b2 === null || b2.tag !== 7)
      return b2 = Xg(c2, a2.mode, d2, f2), b2.return = a2, b2;
    b2 = e(b2, c2);
    b2.return = a2;
    return b2;
  }
  function A(a2, b2, c2) {
    if (typeof b2 === "string" || typeof b2 === "number")
      return b2 = Ug("" + b2, a2.mode, c2), b2.return = a2, b2;
    if (typeof b2 === "object" && b2 !== null) {
      switch (b2.$$typeof) {
        case sa:
          return c2 = Vg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Qg(a2, null, b2), c2.return = a2, c2;
        case ta:
          return b2 = Wg(b2, a2.mode, c2), b2.return = a2, b2;
      }
      if (Pg(b2) || La(b2))
        return b2 = Xg(b2, a2.mode, c2, null), b2.return = a2, b2;
      Rg(a2, b2);
    }
    return null;
  }
  function p(a2, b2, c2, d2) {
    var e2 = b2 !== null ? b2.key : null;
    if (typeof c2 === "string" || typeof c2 === "number")
      return e2 !== null ? null : h(a2, b2, "" + c2, d2);
    if (typeof c2 === "object" && c2 !== null) {
      switch (c2.$$typeof) {
        case sa:
          return c2.key === e2 ? c2.type === ua ? n(a2, b2, c2.props.children, d2, e2) : k(a2, b2, c2, d2) : null;
        case ta:
          return c2.key === e2 ? l(a2, b2, c2, d2) : null;
      }
      if (Pg(c2) || La(c2))
        return e2 !== null ? null : n(a2, b2, c2, d2, null);
      Rg(a2, c2);
    }
    return null;
  }
  function C(a2, b2, c2, d2, e2) {
    if (typeof d2 === "string" || typeof d2 === "number")
      return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
    if (typeof d2 === "object" && d2 !== null) {
      switch (d2.$$typeof) {
        case sa:
          return a2 = a2.get(d2.key === null ? c2 : d2.key) || null, d2.type === ua ? n(b2, a2, d2.props.children, e2, d2.key) : k(b2, a2, d2, e2);
        case ta:
          return a2 = a2.get(d2.key === null ? c2 : d2.key) || null, l(b2, a2, d2, e2);
      }
      if (Pg(d2) || La(d2))
        return a2 = a2.get(c2) || null, n(b2, a2, d2, e2, null);
      Rg(b2, d2);
    }
    return null;
  }
  function x(e2, g2, h2, k2) {
    for (var l2 = null, t = null, u = g2, z = g2 = 0, q = null; u !== null && z < h2.length; z++) {
      u.index > z ? (q = u, u = null) : q = u.sibling;
      var n2 = p(e2, u, h2[z], k2);
      if (n2 === null) {
        u === null && (u = q);
        break;
      }
      a && u && n2.alternate === null && b(e2, u);
      g2 = f(n2, g2, z);
      t === null ? l2 = n2 : t.sibling = n2;
      t = n2;
      u = q;
    }
    if (z === h2.length)
      return c(e2, u), l2;
    if (u === null) {
      for (; z < h2.length; z++)
        u = A(e2, h2[z], k2), u !== null && (g2 = f(u, g2, z), t === null ? l2 = u : t.sibling = u, t = u);
      return l2;
    }
    for (u = d(e2, u); z < h2.length; z++)
      q = C(u, e2, z, h2[z], k2), q !== null && (a && q.alternate !== null && u.delete(q.key === null ? z : q.key), g2 = f(q, g2, z), t === null ? l2 = q : t.sibling = q, t = q);
    a && u.forEach(function(a2) {
      return b(e2, a2);
    });
    return l2;
  }
  function w(e2, g2, h2, k2) {
    var l2 = La(h2);
    if (typeof l2 !== "function")
      throw Error(y(150));
    h2 = l2.call(h2);
    if (h2 == null)
      throw Error(y(151));
    for (var t = l2 = null, u = g2, z = g2 = 0, q = null, n2 = h2.next(); u !== null && !n2.done; z++, n2 = h2.next()) {
      u.index > z ? (q = u, u = null) : q = u.sibling;
      var w2 = p(e2, u, n2.value, k2);
      if (w2 === null) {
        u === null && (u = q);
        break;
      }
      a && u && w2.alternate === null && b(e2, u);
      g2 = f(w2, g2, z);
      t === null ? l2 = w2 : t.sibling = w2;
      t = w2;
      u = q;
    }
    if (n2.done)
      return c(e2, u), l2;
    if (u === null) {
      for (; !n2.done; z++, n2 = h2.next())
        n2 = A(e2, n2.value, k2), n2 !== null && (g2 = f(n2, g2, z), t === null ? l2 = n2 : t.sibling = n2, t = n2);
      return l2;
    }
    for (u = d(e2, u); !n2.done; z++, n2 = h2.next())
      n2 = C(u, e2, z, n2.value, k2), n2 !== null && (a && n2.alternate !== null && u.delete(n2.key === null ? z : n2.key), g2 = f(n2, g2, z), t === null ? l2 = n2 : t.sibling = n2, t = n2);
    a && u.forEach(function(a2) {
      return b(e2, a2);
    });
    return l2;
  }
  return function(a2, d2, f2, h2) {
    var k2 = typeof f2 === "object" && f2 !== null && f2.type === ua && f2.key === null;
    k2 && (f2 = f2.props.children);
    var l2 = typeof f2 === "object" && f2 !== null;
    if (l2)
      switch (f2.$$typeof) {
        case sa:
          a: {
            l2 = f2.key;
            for (k2 = d2; k2 !== null; ) {
              if (k2.key === l2) {
                switch (k2.tag) {
                  case 7:
                    if (f2.type === ua) {
                      c(a2, k2.sibling);
                      d2 = e(k2, f2.props.children);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                    break;
                  default:
                    if (k2.elementType === f2.type) {
                      c(a2, k2.sibling);
                      d2 = e(k2, f2.props);
                      d2.ref = Qg(a2, k2, f2);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                }
                c(a2, k2);
                break;
              } else
                b(a2, k2);
              k2 = k2.sibling;
            }
            f2.type === ua ? (d2 = Xg(f2.props.children, a2.mode, h2, f2.key), d2.return = a2, a2 = d2) : (h2 = Vg(f2.type, f2.key, f2.props, null, a2.mode, h2), h2.ref = Qg(a2, d2, f2), h2.return = a2, a2 = h2);
          }
          return g(a2);
        case ta:
          a: {
            for (k2 = f2.key; d2 !== null; ) {
              if (d2.key === k2)
                if (d2.tag === 4 && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                  c(a2, d2.sibling);
                  d2 = e(d2, f2.children || []);
                  d2.return = a2;
                  a2 = d2;
                  break a;
                } else {
                  c(a2, d2);
                  break;
                }
              else
                b(a2, d2);
              d2 = d2.sibling;
            }
            d2 = Wg(f2, a2.mode, h2);
            d2.return = a2;
            a2 = d2;
          }
          return g(a2);
      }
    if (typeof f2 === "string" || typeof f2 === "number")
      return f2 = "" + f2, d2 !== null && d2.tag === 6 ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Ug(f2, a2.mode, h2), d2.return = a2, a2 = d2), g(a2);
    if (Pg(f2))
      return x(a2, d2, f2, h2);
    if (La(f2))
      return w(a2, d2, f2, h2);
    l2 && Rg(a2, f2);
    if (typeof f2 === "undefined" && !k2)
      switch (a2.tag) {
        case 1:
        case 22:
        case 0:
        case 11:
        case 15:
          throw Error(y(152, Ra(a2.type) || "Component"));
      }
    return c(a2, d2);
  };
}
var Yg = Sg(true), Zg = Sg(false), $g = {}, ah = Bf($g), bh = Bf($g), ch = Bf($g);
function dh(a) {
  if (a === $g)
    throw Error(y(174));
  return a;
}
function eh(a, b) {
  I(ch, b);
  I(bh, a);
  I(ah, $g);
  a = b.nodeType;
  switch (a) {
    case 9:
    case 11:
      b = (b = b.documentElement) ? b.namespaceURI : mb(null, "");
      break;
    default:
      a = a === 8 ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = mb(b, a);
  }
  H(ah);
  I(ah, b);
}
function fh() {
  H(ah);
  H(bh);
  H(ch);
}
function gh(a) {
  dh(ch.current);
  var b = dh(ah.current);
  var c = mb(b, a.type);
  b !== c && (I(bh, a), I(ah, c));
}
function hh(a) {
  bh.current === a && (H(ah), H(bh));
}
var P = Bf(0);
function ih(a) {
  for (var b = a; b !== null; ) {
    if (b.tag === 13) {
      var c = b.memoizedState;
      if (c !== null && (c = c.dehydrated, c === null || c.data === "$?" || c.data === "$!"))
        return b;
    } else if (b.tag === 19 && b.memoizedProps.revealOrder !== void 0) {
      if ((b.flags & 64) !== 0)
        return b;
    } else if (b.child !== null) {
      b.child.return = b;
      b = b.child;
      continue;
    }
    if (b === a)
      break;
    for (; b.sibling === null; ) {
      if (b.return === null || b.return === a)
        return null;
      b = b.return;
    }
    b.sibling.return = b.return;
    b = b.sibling;
  }
  return null;
}
var jh = null, kh = null, lh = false;
function mh(a, b) {
  var c = nh(5, null, null, 0);
  c.elementType = "DELETED";
  c.type = "DELETED";
  c.stateNode = b;
  c.return = a;
  c.flags = 8;
  a.lastEffect !== null ? (a.lastEffect.nextEffect = c, a.lastEffect = c) : a.firstEffect = a.lastEffect = c;
}
function oh(a, b) {
  switch (a.tag) {
    case 5:
      var c = a.type;
      b = b.nodeType !== 1 || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
      return b !== null ? (a.stateNode = b, true) : false;
    case 6:
      return b = a.pendingProps === "" || b.nodeType !== 3 ? null : b, b !== null ? (a.stateNode = b, true) : false;
    case 13:
      return false;
    default:
      return false;
  }
}
function ph(a) {
  if (lh) {
    var b = kh;
    if (b) {
      var c = b;
      if (!oh(a, b)) {
        b = rf(c.nextSibling);
        if (!b || !oh(a, b)) {
          a.flags = a.flags & -1025 | 2;
          lh = false;
          jh = a;
          return;
        }
        mh(jh, c);
      }
      jh = a;
      kh = rf(b.firstChild);
    } else
      a.flags = a.flags & -1025 | 2, lh = false, jh = a;
  }
}
function qh(a) {
  for (a = a.return; a !== null && a.tag !== 5 && a.tag !== 3 && a.tag !== 13; )
    a = a.return;
  jh = a;
}
function rh(a) {
  if (a !== jh)
    return false;
  if (!lh)
    return qh(a), lh = true, false;
  var b = a.type;
  if (a.tag !== 5 || b !== "head" && b !== "body" && !nf(b, a.memoizedProps))
    for (b = kh; b; )
      mh(a, b), b = rf(b.nextSibling);
  qh(a);
  if (a.tag === 13) {
    a = a.memoizedState;
    a = a !== null ? a.dehydrated : null;
    if (!a)
      throw Error(y(317));
    a: {
      a = a.nextSibling;
      for (b = 0; a; ) {
        if (a.nodeType === 8) {
          var c = a.data;
          if (c === "/$") {
            if (b === 0) {
              kh = rf(a.nextSibling);
              break a;
            }
            b--;
          } else
            c !== "$" && c !== "$!" && c !== "$?" || b++;
        }
        a = a.nextSibling;
      }
      kh = null;
    }
  } else
    kh = jh ? rf(a.stateNode.nextSibling) : null;
  return true;
}
function sh() {
  kh = jh = null;
  lh = false;
}
var th = [];
function uh() {
  for (var a = 0; a < th.length; a++)
    th[a]._workInProgressVersionPrimary = null;
  th.length = 0;
}
var vh = ra.ReactCurrentDispatcher, wh = ra.ReactCurrentBatchConfig, xh = 0, R = null, S = null, T = null, yh = false, zh = false;
function Ah() {
  throw Error(y(321));
}
function Bh(a, b) {
  if (b === null)
    return false;
  for (var c = 0; c < b.length && c < a.length; c++)
    if (!He(a[c], b[c]))
      return false;
  return true;
}
function Ch(a, b, c, d, e, f) {
  xh = f;
  R = b;
  b.memoizedState = null;
  b.updateQueue = null;
  b.lanes = 0;
  vh.current = a === null || a.memoizedState === null ? Dh : Eh;
  a = c(d, e);
  if (zh) {
    f = 0;
    do {
      zh = false;
      if (!(25 > f))
        throw Error(y(301));
      f += 1;
      T = S = null;
      b.updateQueue = null;
      vh.current = Fh;
      a = c(d, e);
    } while (zh);
  }
  vh.current = Gh;
  b = S !== null && S.next !== null;
  xh = 0;
  T = S = R = null;
  yh = false;
  if (b)
    throw Error(y(300));
  return a;
}
function Hh() {
  var a = {memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null};
  T === null ? R.memoizedState = T = a : T = T.next = a;
  return T;
}
function Ih() {
  if (S === null) {
    var a = R.alternate;
    a = a !== null ? a.memoizedState : null;
  } else
    a = S.next;
  var b = T === null ? R.memoizedState : T.next;
  if (b !== null)
    T = b, S = a;
  else {
    if (a === null)
      throw Error(y(310));
    S = a;
    a = {memoizedState: S.memoizedState, baseState: S.baseState, baseQueue: S.baseQueue, queue: S.queue, next: null};
    T === null ? R.memoizedState = T = a : T = T.next = a;
  }
  return T;
}
function Jh(a, b) {
  return typeof b === "function" ? b(a) : b;
}
function Kh(a) {
  var b = Ih(), c = b.queue;
  if (c === null)
    throw Error(y(311));
  c.lastRenderedReducer = a;
  var d = S, e = d.baseQueue, f = c.pending;
  if (f !== null) {
    if (e !== null) {
      var g = e.next;
      e.next = f.next;
      f.next = g;
    }
    d.baseQueue = e = f;
    c.pending = null;
  }
  if (e !== null) {
    e = e.next;
    d = d.baseState;
    var h = g = f = null, k = e;
    do {
      var l = k.lane;
      if ((xh & l) === l)
        h !== null && (h = h.next = {lane: 0, action: k.action, eagerReducer: k.eagerReducer, eagerState: k.eagerState, next: null}), d = k.eagerReducer === a ? k.eagerState : a(d, k.action);
      else {
        var n = {
          lane: l,
          action: k.action,
          eagerReducer: k.eagerReducer,
          eagerState: k.eagerState,
          next: null
        };
        h === null ? (g = h = n, f = d) : h = h.next = n;
        R.lanes |= l;
        Dg |= l;
      }
      k = k.next;
    } while (k !== null && k !== e);
    h === null ? f = d : h.next = g;
    He(d, b.memoizedState) || (ug = true);
    b.memoizedState = d;
    b.baseState = f;
    b.baseQueue = h;
    c.lastRenderedState = d;
  }
  return [b.memoizedState, c.dispatch];
}
function Lh(a) {
  var b = Ih(), c = b.queue;
  if (c === null)
    throw Error(y(311));
  c.lastRenderedReducer = a;
  var d = c.dispatch, e = c.pending, f = b.memoizedState;
  if (e !== null) {
    c.pending = null;
    var g = e = e.next;
    do
      f = a(f, g.action), g = g.next;
    while (g !== e);
    He(f, b.memoizedState) || (ug = true);
    b.memoizedState = f;
    b.baseQueue === null && (b.baseState = f);
    c.lastRenderedState = f;
  }
  return [f, d];
}
function Mh(a, b, c) {
  var d = b._getVersion;
  d = d(b._source);
  var e = b._workInProgressVersionPrimary;
  if (e !== null)
    a = e === d;
  else if (a = a.mutableReadLanes, a = (xh & a) === a)
    b._workInProgressVersionPrimary = d, th.push(b);
  if (a)
    return c(b._source);
  th.push(b);
  throw Error(y(350));
}
function Nh(a, b, c, d) {
  var e = U;
  if (e === null)
    throw Error(y(349));
  var f = b._getVersion, g = f(b._source), h = vh.current, k = h.useState(function() {
    return Mh(e, b, c);
  }), l = k[1], n = k[0];
  k = T;
  var A = a.memoizedState, p = A.refs, C = p.getSnapshot, x = A.source;
  A = A.subscribe;
  var w = R;
  a.memoizedState = {refs: p, source: b, subscribe: d};
  h.useEffect(function() {
    p.getSnapshot = c;
    p.setSnapshot = l;
    var a2 = f(b._source);
    if (!He(g, a2)) {
      a2 = c(b._source);
      He(n, a2) || (l(a2), a2 = Ig(w), e.mutableReadLanes |= a2 & e.pendingLanes);
      a2 = e.mutableReadLanes;
      e.entangledLanes |= a2;
      for (var d2 = e.entanglements, h2 = a2; 0 < h2; ) {
        var k2 = 31 - Vc(h2), v = 1 << k2;
        d2[k2] |= a2;
        h2 &= ~v;
      }
    }
  }, [c, b, d]);
  h.useEffect(function() {
    return d(b._source, function() {
      var a2 = p.getSnapshot, c2 = p.setSnapshot;
      try {
        c2(a2(b._source));
        var d2 = Ig(w);
        e.mutableReadLanes |= d2 & e.pendingLanes;
      } catch (q) {
        c2(function() {
          throw q;
        });
      }
    });
  }, [b, d]);
  He(C, c) && He(x, b) && He(A, d) || (a = {pending: null, dispatch: null, lastRenderedReducer: Jh, lastRenderedState: n}, a.dispatch = l = Oh.bind(null, R, a), k.queue = a, k.baseQueue = null, n = Mh(e, b, c), k.memoizedState = k.baseState = n);
  return n;
}
function Ph(a, b, c) {
  var d = Ih();
  return Nh(d, a, b, c);
}
function Qh(a) {
  var b = Hh();
  typeof a === "function" && (a = a());
  b.memoizedState = b.baseState = a;
  a = b.queue = {pending: null, dispatch: null, lastRenderedReducer: Jh, lastRenderedState: a};
  a = a.dispatch = Oh.bind(null, R, a);
  return [b.memoizedState, a];
}
function Rh(a, b, c, d) {
  a = {tag: a, create: b, destroy: c, deps: d, next: null};
  b = R.updateQueue;
  b === null ? (b = {lastEffect: null}, R.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, c === null ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
  return a;
}
function Sh(a) {
  var b = Hh();
  a = {current: a};
  return b.memoizedState = a;
}
function Th() {
  return Ih().memoizedState;
}
function Uh(a, b, c, d) {
  var e = Hh();
  R.flags |= a;
  e.memoizedState = Rh(1 | b, c, void 0, d === void 0 ? null : d);
}
function Vh(a, b, c, d) {
  var e = Ih();
  d = d === void 0 ? null : d;
  var f = void 0;
  if (S !== null) {
    var g = S.memoizedState;
    f = g.destroy;
    if (d !== null && Bh(d, g.deps)) {
      Rh(b, c, f, d);
      return;
    }
  }
  R.flags |= a;
  e.memoizedState = Rh(1 | b, c, f, d);
}
function Wh(a, b) {
  return Uh(516, 4, a, b);
}
function Xh(a, b) {
  return Vh(516, 4, a, b);
}
function Yh(a, b) {
  return Vh(4, 2, a, b);
}
function Zh(a, b) {
  if (typeof b === "function")
    return a = a(), b(a), function() {
      b(null);
    };
  if (b !== null && b !== void 0)
    return a = a(), b.current = a, function() {
      b.current = null;
    };
}
function $h(a, b, c) {
  c = c !== null && c !== void 0 ? c.concat([a]) : null;
  return Vh(4, 2, Zh.bind(null, b, a), c);
}
function ai() {
}
function bi(a, b) {
  var c = Ih();
  b = b === void 0 ? null : b;
  var d = c.memoizedState;
  if (d !== null && b !== null && Bh(b, d[1]))
    return d[0];
  c.memoizedState = [a, b];
  return a;
}
function ci(a, b) {
  var c = Ih();
  b = b === void 0 ? null : b;
  var d = c.memoizedState;
  if (d !== null && b !== null && Bh(b, d[1]))
    return d[0];
  a = a();
  c.memoizedState = [a, b];
  return a;
}
function di(a, b) {
  var c = eg();
  gg(98 > c ? 98 : c, function() {
    a(true);
  });
  gg(97 < c ? 97 : c, function() {
    var c2 = wh.transition;
    wh.transition = 1;
    try {
      a(false), b();
    } finally {
      wh.transition = c2;
    }
  });
}
function Oh(a, b, c) {
  var d = Hg(), e = Ig(a), f = {lane: e, action: c, eagerReducer: null, eagerState: null, next: null}, g = b.pending;
  g === null ? f.next = f : (f.next = g.next, g.next = f);
  b.pending = f;
  g = a.alternate;
  if (a === R || g !== null && g === R)
    zh = yh = true;
  else {
    if (a.lanes === 0 && (g === null || g.lanes === 0) && (g = b.lastRenderedReducer, g !== null))
      try {
        var h = b.lastRenderedState, k = g(h, c);
        f.eagerReducer = g;
        f.eagerState = k;
        if (He(k, h))
          return;
      } catch (l) {
      } finally {
      }
    Jg(a, e, d);
  }
}
var Gh = {readContext: vg, useCallback: Ah, useContext: Ah, useEffect: Ah, useImperativeHandle: Ah, useLayoutEffect: Ah, useMemo: Ah, useReducer: Ah, useRef: Ah, useState: Ah, useDebugValue: Ah, useDeferredValue: Ah, useTransition: Ah, useMutableSource: Ah, useOpaqueIdentifier: Ah, unstable_isNewReconciler: false}, Dh = {readContext: vg, useCallback: function(a, b) {
  Hh().memoizedState = [a, b === void 0 ? null : b];
  return a;
}, useContext: vg, useEffect: Wh, useImperativeHandle: function(a, b, c) {
  c = c !== null && c !== void 0 ? c.concat([a]) : null;
  return Uh(4, 2, Zh.bind(null, b, a), c);
}, useLayoutEffect: function(a, b) {
  return Uh(4, 2, a, b);
}, useMemo: function(a, b) {
  var c = Hh();
  b = b === void 0 ? null : b;
  a = a();
  c.memoizedState = [a, b];
  return a;
}, useReducer: function(a, b, c) {
  var d = Hh();
  b = c !== void 0 ? c(b) : b;
  d.memoizedState = d.baseState = b;
  a = d.queue = {pending: null, dispatch: null, lastRenderedReducer: a, lastRenderedState: b};
  a = a.dispatch = Oh.bind(null, R, a);
  return [d.memoizedState, a];
}, useRef: Sh, useState: Qh, useDebugValue: ai, useDeferredValue: function(a) {
  var b = Qh(a), c = b[0], d = b[1];
  Wh(function() {
    var b2 = wh.transition;
    wh.transition = 1;
    try {
      d(a);
    } finally {
      wh.transition = b2;
    }
  }, [a]);
  return c;
}, useTransition: function() {
  var a = Qh(false), b = a[0];
  a = di.bind(null, a[1]);
  Sh(a);
  return [a, b];
}, useMutableSource: function(a, b, c) {
  var d = Hh();
  d.memoizedState = {refs: {getSnapshot: b, setSnapshot: null}, source: a, subscribe: c};
  return Nh(d, a, b, c);
}, useOpaqueIdentifier: function() {
  if (lh) {
    var a = false, b = uf(function() {
      a || (a = true, c("r:" + (tf++).toString(36)));
      throw Error(y(355));
    }), c = Qh(b)[1];
    (R.mode & 2) === 0 && (R.flags |= 516, Rh(5, function() {
      c("r:" + (tf++).toString(36));
    }, void 0, null));
    return b;
  }
  b = "r:" + (tf++).toString(36);
  Qh(b);
  return b;
}, unstable_isNewReconciler: false}, Eh = {readContext: vg, useCallback: bi, useContext: vg, useEffect: Xh, useImperativeHandle: $h, useLayoutEffect: Yh, useMemo: ci, useReducer: Kh, useRef: Th, useState: function() {
  return Kh(Jh);
}, useDebugValue: ai, useDeferredValue: function(a) {
  var b = Kh(Jh), c = b[0], d = b[1];
  Xh(function() {
    var b2 = wh.transition;
    wh.transition = 1;
    try {
      d(a);
    } finally {
      wh.transition = b2;
    }
  }, [a]);
  return c;
}, useTransition: function() {
  var a = Kh(Jh)[0];
  return [
    Th().current,
    a
  ];
}, useMutableSource: Ph, useOpaqueIdentifier: function() {
  return Kh(Jh)[0];
}, unstable_isNewReconciler: false}, Fh = {readContext: vg, useCallback: bi, useContext: vg, useEffect: Xh, useImperativeHandle: $h, useLayoutEffect: Yh, useMemo: ci, useReducer: Lh, useRef: Th, useState: function() {
  return Lh(Jh);
}, useDebugValue: ai, useDeferredValue: function(a) {
  var b = Lh(Jh), c = b[0], d = b[1];
  Xh(function() {
    var b2 = wh.transition;
    wh.transition = 1;
    try {
      d(a);
    } finally {
      wh.transition = b2;
    }
  }, [a]);
  return c;
}, useTransition: function() {
  var a = Lh(Jh)[0];
  return [
    Th().current,
    a
  ];
}, useMutableSource: Ph, useOpaqueIdentifier: function() {
  return Lh(Jh)[0];
}, unstable_isNewReconciler: false}, ei = ra.ReactCurrentOwner, ug = false;
function fi(a, b, c, d) {
  b.child = a === null ? Zg(b, null, c, d) : Yg(b, a.child, c, d);
}
function gi(a, b, c, d, e) {
  c = c.render;
  var f = b.ref;
  tg(b, e);
  d = Ch(a, b, c, d, f, e);
  if (a !== null && !ug)
    return b.updateQueue = a.updateQueue, b.flags &= -517, a.lanes &= ~e, hi(a, b, e);
  b.flags |= 1;
  fi(a, b, d, e);
  return b.child;
}
function ii(a, b, c, d, e, f) {
  if (a === null) {
    var g = c.type;
    if (typeof g === "function" && !ji(g) && g.defaultProps === void 0 && c.compare === null && c.defaultProps === void 0)
      return b.tag = 15, b.type = g, ki(a, b, g, d, e, f);
    a = Vg(c.type, null, d, b, b.mode, f);
    a.ref = b.ref;
    a.return = b;
    return b.child = a;
  }
  g = a.child;
  if ((e & f) === 0 && (e = g.memoizedProps, c = c.compare, c = c !== null ? c : Je, c(e, d) && a.ref === b.ref))
    return hi(a, b, f);
  b.flags |= 1;
  a = Tg(g, d);
  a.ref = b.ref;
  a.return = b;
  return b.child = a;
}
function ki(a, b, c, d, e, f) {
  if (a !== null && Je(a.memoizedProps, d) && a.ref === b.ref)
    if (ug = false, (f & e) !== 0)
      (a.flags & 16384) !== 0 && (ug = true);
    else
      return b.lanes = a.lanes, hi(a, b, f);
  return li(a, b, c, d, f);
}
function mi(a, b, c) {
  var d = b.pendingProps, e = d.children, f = a !== null ? a.memoizedState : null;
  if (d.mode === "hidden" || d.mode === "unstable-defer-without-hiding")
    if ((b.mode & 4) === 0)
      b.memoizedState = {baseLanes: 0}, ni(b, c);
    else if ((c & 1073741824) !== 0)
      b.memoizedState = {baseLanes: 0}, ni(b, f !== null ? f.baseLanes : c);
    else
      return a = f !== null ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = {baseLanes: a}, ni(b, a), null;
  else
    f !== null ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, ni(b, d);
  fi(a, b, e, c);
  return b.child;
}
function oi(a, b) {
  var c = b.ref;
  if (a === null && c !== null || a !== null && a.ref !== c)
    b.flags |= 128;
}
function li(a, b, c, d, e) {
  var f = Ff(c) ? Df : M.current;
  f = Ef(b, f);
  tg(b, e);
  c = Ch(a, b, c, d, f, e);
  if (a !== null && !ug)
    return b.updateQueue = a.updateQueue, b.flags &= -517, a.lanes &= ~e, hi(a, b, e);
  b.flags |= 1;
  fi(a, b, c, e);
  return b.child;
}
function pi(a, b, c, d, e) {
  if (Ff(c)) {
    var f = true;
    Jf(b);
  } else
    f = false;
  tg(b, e);
  if (b.stateNode === null)
    a !== null && (a.alternate = null, b.alternate = null, b.flags |= 2), Mg(b, c, d), Og(b, c, d, e), d = true;
  else if (a === null) {
    var g = b.stateNode, h = b.memoizedProps;
    g.props = h;
    var k = g.context, l = c.contextType;
    typeof l === "object" && l !== null ? l = vg(l) : (l = Ff(c) ? Df : M.current, l = Ef(b, l));
    var n = c.getDerivedStateFromProps, A = typeof n === "function" || typeof g.getSnapshotBeforeUpdate === "function";
    A || typeof g.UNSAFE_componentWillReceiveProps !== "function" && typeof g.componentWillReceiveProps !== "function" || (h !== d || k !== l) && Ng(b, g, d, l);
    wg = false;
    var p = b.memoizedState;
    g.state = p;
    Cg(b, d, g, e);
    k = b.memoizedState;
    h !== d || p !== k || N.current || wg ? (typeof n === "function" && (Gg(b, c, n, d), k = b.memoizedState), (h = wg || Lg(b, c, h, d, p, k, l)) ? (A || typeof g.UNSAFE_componentWillMount !== "function" && typeof g.componentWillMount !== "function" || (typeof g.componentWillMount === "function" && g.componentWillMount(), typeof g.UNSAFE_componentWillMount === "function" && g.UNSAFE_componentWillMount()), typeof g.componentDidMount === "function" && (b.flags |= 4)) : (typeof g.componentDidMount === "function" && (b.flags |= 4), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : (typeof g.componentDidMount === "function" && (b.flags |= 4), d = false);
  } else {
    g = b.stateNode;
    yg(a, b);
    h = b.memoizedProps;
    l = b.type === b.elementType ? h : lg(b.type, h);
    g.props = l;
    A = b.pendingProps;
    p = g.context;
    k = c.contextType;
    typeof k === "object" && k !== null ? k = vg(k) : (k = Ff(c) ? Df : M.current, k = Ef(b, k));
    var C = c.getDerivedStateFromProps;
    (n = typeof C === "function" || typeof g.getSnapshotBeforeUpdate === "function") || typeof g.UNSAFE_componentWillReceiveProps !== "function" && typeof g.componentWillReceiveProps !== "function" || (h !== A || p !== k) && Ng(b, g, d, k);
    wg = false;
    p = b.memoizedState;
    g.state = p;
    Cg(b, d, g, e);
    var x = b.memoizedState;
    h !== A || p !== x || N.current || wg ? (typeof C === "function" && (Gg(b, c, C, d), x = b.memoizedState), (l = wg || Lg(b, c, l, d, p, x, k)) ? (n || typeof g.UNSAFE_componentWillUpdate !== "function" && typeof g.componentWillUpdate !== "function" || (typeof g.componentWillUpdate === "function" && g.componentWillUpdate(d, x, k), typeof g.UNSAFE_componentWillUpdate === "function" && g.UNSAFE_componentWillUpdate(d, x, k)), typeof g.componentDidUpdate === "function" && (b.flags |= 4), typeof g.getSnapshotBeforeUpdate === "function" && (b.flags |= 256)) : (typeof g.componentDidUpdate !== "function" || h === a.memoizedProps && p === a.memoizedState || (b.flags |= 4), typeof g.getSnapshotBeforeUpdate !== "function" || h === a.memoizedProps && p === a.memoizedState || (b.flags |= 256), b.memoizedProps = d, b.memoizedState = x), g.props = d, g.state = x, g.context = k, d = l) : (typeof g.componentDidUpdate !== "function" || h === a.memoizedProps && p === a.memoizedState || (b.flags |= 4), typeof g.getSnapshotBeforeUpdate !== "function" || h === a.memoizedProps && p === a.memoizedState || (b.flags |= 256), d = false);
  }
  return qi(a, b, c, d, f, e);
}
function qi(a, b, c, d, e, f) {
  oi(a, b);
  var g = (b.flags & 64) !== 0;
  if (!d && !g)
    return e && Kf(b, c, false), hi(a, b, f);
  d = b.stateNode;
  ei.current = b;
  var h = g && typeof c.getDerivedStateFromError !== "function" ? null : d.render();
  b.flags |= 1;
  a !== null && g ? (b.child = Yg(b, a.child, null, f), b.child = Yg(b, null, h, f)) : fi(a, b, h, f);
  b.memoizedState = d.state;
  e && Kf(b, c, true);
  return b.child;
}
function ri(a) {
  var b = a.stateNode;
  b.pendingContext ? Hf(a, b.pendingContext, b.pendingContext !== b.context) : b.context && Hf(a, b.context, false);
  eh(a, b.containerInfo);
}
var si = {dehydrated: null, retryLane: 0};
function ti(a, b, c) {
  var d = b.pendingProps, e = P.current, f = false, g;
  (g = (b.flags & 64) !== 0) || (g = a !== null && a.memoizedState === null ? false : (e & 2) !== 0);
  g ? (f = true, b.flags &= -65) : a !== null && a.memoizedState === null || d.fallback === void 0 || d.unstable_avoidThisFallback === true || (e |= 1);
  I(P, e & 1);
  if (a === null) {
    d.fallback !== void 0 && ph(b);
    a = d.children;
    e = d.fallback;
    if (f)
      return a = ui(b, a, e, c), b.child.memoizedState = {baseLanes: c}, b.memoizedState = si, a;
    if (typeof d.unstable_expectedLoadTime === "number")
      return a = ui(b, a, e, c), b.child.memoizedState = {baseLanes: c}, b.memoizedState = si, b.lanes = 33554432, a;
    c = vi({mode: "visible", children: a}, b.mode, c, null);
    c.return = b;
    return b.child = c;
  }
  if (a.memoizedState !== null) {
    if (f)
      return d = wi(a, b, d.children, d.fallback, c), f = b.child, e = a.child.memoizedState, f.memoizedState = e === null ? {baseLanes: c} : {baseLanes: e.baseLanes | c}, f.childLanes = a.childLanes & ~c, b.memoizedState = si, d;
    c = xi(a, b, d.children, c);
    b.memoizedState = null;
    return c;
  }
  if (f)
    return d = wi(a, b, d.children, d.fallback, c), f = b.child, e = a.child.memoizedState, f.memoizedState = e === null ? {baseLanes: c} : {baseLanes: e.baseLanes | c}, f.childLanes = a.childLanes & ~c, b.memoizedState = si, d;
  c = xi(a, b, d.children, c);
  b.memoizedState = null;
  return c;
}
function ui(a, b, c, d) {
  var e = a.mode, f = a.child;
  b = {mode: "hidden", children: b};
  (e & 2) === 0 && f !== null ? (f.childLanes = 0, f.pendingProps = b) : f = vi(b, e, 0, null);
  c = Xg(c, e, d, null);
  f.return = a;
  c.return = a;
  f.sibling = c;
  a.child = f;
  return c;
}
function xi(a, b, c, d) {
  var e = a.child;
  a = e.sibling;
  c = Tg(e, {mode: "visible", children: c});
  (b.mode & 2) === 0 && (c.lanes = d);
  c.return = b;
  c.sibling = null;
  a !== null && (a.nextEffect = null, a.flags = 8, b.firstEffect = b.lastEffect = a);
  return b.child = c;
}
function wi(a, b, c, d, e) {
  var f = b.mode, g = a.child;
  a = g.sibling;
  var h = {mode: "hidden", children: c};
  (f & 2) === 0 && b.child !== g ? (c = b.child, c.childLanes = 0, c.pendingProps = h, g = c.lastEffect, g !== null ? (b.firstEffect = c.firstEffect, b.lastEffect = g, g.nextEffect = null) : b.firstEffect = b.lastEffect = null) : c = Tg(g, h);
  a !== null ? d = Tg(a, d) : (d = Xg(d, f, e, null), d.flags |= 2);
  d.return = b;
  c.return = b;
  c.sibling = d;
  b.child = c;
  return d;
}
function yi(a, b) {
  a.lanes |= b;
  var c = a.alternate;
  c !== null && (c.lanes |= b);
  sg(a.return, b);
}
function zi(a, b, c, d, e, f) {
  var g = a.memoizedState;
  g === null ? a.memoizedState = {isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e, lastEffect: f} : (g.isBackwards = b, g.rendering = null, g.renderingStartTime = 0, g.last = d, g.tail = c, g.tailMode = e, g.lastEffect = f);
}
function Ai(a, b, c) {
  var d = b.pendingProps, e = d.revealOrder, f = d.tail;
  fi(a, b, d.children, c);
  d = P.current;
  if ((d & 2) !== 0)
    d = d & 1 | 2, b.flags |= 64;
  else {
    if (a !== null && (a.flags & 64) !== 0)
      a:
        for (a = b.child; a !== null; ) {
          if (a.tag === 13)
            a.memoizedState !== null && yi(a, c);
          else if (a.tag === 19)
            yi(a, c);
          else if (a.child !== null) {
            a.child.return = a;
            a = a.child;
            continue;
          }
          if (a === b)
            break a;
          for (; a.sibling === null; ) {
            if (a.return === null || a.return === b)
              break a;
            a = a.return;
          }
          a.sibling.return = a.return;
          a = a.sibling;
        }
    d &= 1;
  }
  I(P, d);
  if ((b.mode & 2) === 0)
    b.memoizedState = null;
  else
    switch (e) {
      case "forwards":
        c = b.child;
        for (e = null; c !== null; )
          a = c.alternate, a !== null && ih(a) === null && (e = c), c = c.sibling;
        c = e;
        c === null ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
        zi(b, false, e, c, f, b.lastEffect);
        break;
      case "backwards":
        c = null;
        e = b.child;
        for (b.child = null; e !== null; ) {
          a = e.alternate;
          if (a !== null && ih(a) === null) {
            b.child = e;
            break;
          }
          a = e.sibling;
          e.sibling = c;
          c = e;
          e = a;
        }
        zi(b, true, c, null, f, b.lastEffect);
        break;
      case "together":
        zi(b, false, null, null, void 0, b.lastEffect);
        break;
      default:
        b.memoizedState = null;
    }
  return b.child;
}
function hi(a, b, c) {
  a !== null && (b.dependencies = a.dependencies);
  Dg |= b.lanes;
  if ((c & b.childLanes) !== 0) {
    if (a !== null && b.child !== a.child)
      throw Error(y(153));
    if (b.child !== null) {
      a = b.child;
      c = Tg(a, a.pendingProps);
      b.child = c;
      for (c.return = b; a.sibling !== null; )
        a = a.sibling, c = c.sibling = Tg(a, a.pendingProps), c.return = b;
      c.sibling = null;
    }
    return b.child;
  }
  return null;
}
var Bi, Ci, Di, Ei;
Bi = function(a, b) {
  for (var c = b.child; c !== null; ) {
    if (c.tag === 5 || c.tag === 6)
      a.appendChild(c.stateNode);
    else if (c.tag !== 4 && c.child !== null) {
      c.child.return = c;
      c = c.child;
      continue;
    }
    if (c === b)
      break;
    for (; c.sibling === null; ) {
      if (c.return === null || c.return === b)
        return;
      c = c.return;
    }
    c.sibling.return = c.return;
    c = c.sibling;
  }
};
Ci = function() {
};
Di = function(a, b, c, d) {
  var e = a.memoizedProps;
  if (e !== d) {
    a = b.stateNode;
    dh(ah.current);
    var f = null;
    switch (c) {
      case "input":
        e = Ya(a, e);
        d = Ya(a, d);
        f = [];
        break;
      case "option":
        e = eb(a, e);
        d = eb(a, d);
        f = [];
        break;
      case "select":
        e = m({}, e, {value: void 0});
        d = m({}, d, {value: void 0});
        f = [];
        break;
      case "textarea":
        e = gb(a, e);
        d = gb(a, d);
        f = [];
        break;
      default:
        typeof e.onClick !== "function" && typeof d.onClick === "function" && (a.onclick = jf);
    }
    vb(c, d);
    var g;
    c = null;
    for (l in e)
      if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && e[l] != null)
        if (l === "style") {
          var h = e[l];
          for (g in h)
            h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
        } else
          l !== "dangerouslySetInnerHTML" && l !== "children" && l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && l !== "autoFocus" && (ca.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
    for (l in d) {
      var k = d[l];
      h = e != null ? e[l] : void 0;
      if (d.hasOwnProperty(l) && k !== h && (k != null || h != null))
        if (l === "style")
          if (h) {
            for (g in h)
              !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
            for (g in k)
              k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
          } else
            c || (f || (f = []), f.push(l, c)), c = k;
        else
          l === "dangerouslySetInnerHTML" ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, k != null && h !== k && (f = f || []).push(l, k)) : l === "children" ? typeof k !== "string" && typeof k !== "number" || (f = f || []).push(l, "" + k) : l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && (ca.hasOwnProperty(l) ? (k != null && l === "onScroll" && G("scroll", a), f || h === k || (f = [])) : typeof k === "object" && k !== null && k.$$typeof === Ga ? k.toString() : (f = f || []).push(l, k));
    }
    c && (f = f || []).push("style", c);
    var l = f;
    if (b.updateQueue = l)
      b.flags |= 4;
  }
};
Ei = function(a, b, c, d) {
  c !== d && (b.flags |= 4);
};
function Fi(a, b) {
  if (!lh)
    switch (a.tailMode) {
      case "hidden":
        b = a.tail;
        for (var c = null; b !== null; )
          b.alternate !== null && (c = b), b = b.sibling;
        c === null ? a.tail = null : c.sibling = null;
        break;
      case "collapsed":
        c = a.tail;
        for (var d = null; c !== null; )
          c.alternate !== null && (d = c), c = c.sibling;
        d === null ? b || a.tail === null ? a.tail = null : a.tail.sibling = null : d.sibling = null;
    }
}
function Gi(a, b, c) {
  var d = b.pendingProps;
  switch (b.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return null;
    case 1:
      return Ff(b.type) && Gf(), null;
    case 3:
      fh();
      H(N);
      H(M);
      uh();
      d = b.stateNode;
      d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
      if (a === null || a.child === null)
        rh(b) ? b.flags |= 4 : d.hydrate || (b.flags |= 256);
      Ci(b);
      return null;
    case 5:
      hh(b);
      var e = dh(ch.current);
      c = b.type;
      if (a !== null && b.stateNode != null)
        Di(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 128);
      else {
        if (!d) {
          if (b.stateNode === null)
            throw Error(y(166));
          return null;
        }
        a = dh(ah.current);
        if (rh(b)) {
          d = b.stateNode;
          c = b.type;
          var f = b.memoizedProps;
          d[wf] = b;
          d[xf] = f;
          switch (c) {
            case "dialog":
              G("cancel", d);
              G("close", d);
              break;
            case "iframe":
            case "object":
            case "embed":
              G("load", d);
              break;
            case "video":
            case "audio":
              for (a = 0; a < Xe.length; a++)
                G(Xe[a], d);
              break;
            case "source":
              G("error", d);
              break;
            case "img":
            case "image":
            case "link":
              G("error", d);
              G("load", d);
              break;
            case "details":
              G("toggle", d);
              break;
            case "input":
              Za(d, f);
              G("invalid", d);
              break;
            case "select":
              d._wrapperState = {wasMultiple: !!f.multiple};
              G("invalid", d);
              break;
            case "textarea":
              hb(d, f), G("invalid", d);
          }
          vb(c, f);
          a = null;
          for (var g in f)
            f.hasOwnProperty(g) && (e = f[g], g === "children" ? typeof e === "string" ? d.textContent !== e && (a = ["children", e]) : typeof e === "number" && d.textContent !== "" + e && (a = ["children", "" + e]) : ca.hasOwnProperty(g) && e != null && g === "onScroll" && G("scroll", d));
          switch (c) {
            case "input":
              Va(d);
              cb(d, f, true);
              break;
            case "textarea":
              Va(d);
              jb(d);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof f.onClick === "function" && (d.onclick = jf);
          }
          d = a;
          b.updateQueue = d;
          d !== null && (b.flags |= 4);
        } else {
          g = e.nodeType === 9 ? e : e.ownerDocument;
          a === kb.html && (a = lb(c));
          a === kb.html ? c === "script" ? (a = g.createElement("div"), a.innerHTML = "<script></script>", a = a.removeChild(a.firstChild)) : typeof d.is === "string" ? a = g.createElement(c, {is: d.is}) : (a = g.createElement(c), c === "select" && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
          a[wf] = b;
          a[xf] = d;
          Bi(a, b, false, false);
          b.stateNode = a;
          g = wb(c, d);
          switch (c) {
            case "dialog":
              G("cancel", a);
              G("close", a);
              e = d;
              break;
            case "iframe":
            case "object":
            case "embed":
              G("load", a);
              e = d;
              break;
            case "video":
            case "audio":
              for (e = 0; e < Xe.length; e++)
                G(Xe[e], a);
              e = d;
              break;
            case "source":
              G("error", a);
              e = d;
              break;
            case "img":
            case "image":
            case "link":
              G("error", a);
              G("load", a);
              e = d;
              break;
            case "details":
              G("toggle", a);
              e = d;
              break;
            case "input":
              Za(a, d);
              e = Ya(a, d);
              G("invalid", a);
              break;
            case "option":
              e = eb(a, d);
              break;
            case "select":
              a._wrapperState = {wasMultiple: !!d.multiple};
              e = m({}, d, {value: void 0});
              G("invalid", a);
              break;
            case "textarea":
              hb(a, d);
              e = gb(a, d);
              G("invalid", a);
              break;
            default:
              e = d;
          }
          vb(c, e);
          var h = e;
          for (f in h)
            if (h.hasOwnProperty(f)) {
              var k = h[f];
              f === "style" ? tb(a, k) : f === "dangerouslySetInnerHTML" ? (k = k ? k.__html : void 0, k != null && ob(a, k)) : f === "children" ? typeof k === "string" ? (c !== "textarea" || k !== "") && pb(a, k) : typeof k === "number" && pb(a, "" + k) : f !== "suppressContentEditableWarning" && f !== "suppressHydrationWarning" && f !== "autoFocus" && (ca.hasOwnProperty(f) ? k != null && f === "onScroll" && G("scroll", a) : k != null && qa(a, f, k, g));
            }
          switch (c) {
            case "input":
              Va(a);
              cb(a, d, false);
              break;
            case "textarea":
              Va(a);
              jb(a);
              break;
            case "option":
              d.value != null && a.setAttribute("value", "" + Sa(d.value));
              break;
            case "select":
              a.multiple = !!d.multiple;
              f = d.value;
              f != null ? fb(a, !!d.multiple, f, false) : d.defaultValue != null && fb(a, !!d.multiple, d.defaultValue, true);
              break;
            default:
              typeof e.onClick === "function" && (a.onclick = jf);
          }
          mf(c, d) && (b.flags |= 4);
        }
        b.ref !== null && (b.flags |= 128);
      }
      return null;
    case 6:
      if (a && b.stateNode != null)
        Ei(a, b, a.memoizedProps, d);
      else {
        if (typeof d !== "string" && b.stateNode === null)
          throw Error(y(166));
        c = dh(ch.current);
        dh(ah.current);
        rh(b) ? (d = b.stateNode, c = b.memoizedProps, d[wf] = b, d.nodeValue !== c && (b.flags |= 4)) : (d = (c.nodeType === 9 ? c : c.ownerDocument).createTextNode(d), d[wf] = b, b.stateNode = d);
      }
      return null;
    case 13:
      H(P);
      d = b.memoizedState;
      if ((b.flags & 64) !== 0)
        return b.lanes = c, b;
      d = d !== null;
      c = false;
      a === null ? b.memoizedProps.fallback !== void 0 && rh(b) : c = a.memoizedState !== null;
      if (d && !c && (b.mode & 2) !== 0)
        if (a === null && b.memoizedProps.unstable_avoidThisFallback !== true || (P.current & 1) !== 0)
          V === 0 && (V = 3);
        else {
          if (V === 0 || V === 3)
            V = 4;
          U === null || (Dg & 134217727) === 0 && (Hi & 134217727) === 0 || Ii(U, W);
        }
      if (d || c)
        b.flags |= 4;
      return null;
    case 4:
      return fh(), Ci(b), a === null && cf(b.stateNode.containerInfo), null;
    case 10:
      return rg(b), null;
    case 17:
      return Ff(b.type) && Gf(), null;
    case 19:
      H(P);
      d = b.memoizedState;
      if (d === null)
        return null;
      f = (b.flags & 64) !== 0;
      g = d.rendering;
      if (g === null)
        if (f)
          Fi(d, false);
        else {
          if (V !== 0 || a !== null && (a.flags & 64) !== 0)
            for (a = b.child; a !== null; ) {
              g = ih(a);
              if (g !== null) {
                b.flags |= 64;
                Fi(d, false);
                f = g.updateQueue;
                f !== null && (b.updateQueue = f, b.flags |= 4);
                d.lastEffect === null && (b.firstEffect = null);
                b.lastEffect = d.lastEffect;
                d = c;
                for (c = b.child; c !== null; )
                  f = c, a = d, f.flags &= 2, f.nextEffect = null, f.firstEffect = null, f.lastEffect = null, g = f.alternate, g === null ? (f.childLanes = 0, f.lanes = a, f.child = null, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = a === null ? null : {lanes: a.lanes, firstContext: a.firstContext}), c = c.sibling;
                I(P, P.current & 1 | 2);
                return b.child;
              }
              a = a.sibling;
            }
          d.tail !== null && O() > Ji && (b.flags |= 64, f = true, Fi(d, false), b.lanes = 33554432);
        }
      else {
        if (!f)
          if (a = ih(g), a !== null) {
            if (b.flags |= 64, f = true, c = a.updateQueue, c !== null && (b.updateQueue = c, b.flags |= 4), Fi(d, true), d.tail === null && d.tailMode === "hidden" && !g.alternate && !lh)
              return b = b.lastEffect = d.lastEffect, b !== null && (b.nextEffect = null), null;
          } else
            2 * O() - d.renderingStartTime > Ji && c !== 1073741824 && (b.flags |= 64, f = true, Fi(d, false), b.lanes = 33554432);
        d.isBackwards ? (g.sibling = b.child, b.child = g) : (c = d.last, c !== null ? c.sibling = g : b.child = g, d.last = g);
      }
      return d.tail !== null ? (c = d.tail, d.rendering = c, d.tail = c.sibling, d.lastEffect = b.lastEffect, d.renderingStartTime = O(), c.sibling = null, b = P.current, I(P, f ? b & 1 | 2 : b & 1), c) : null;
    case 23:
    case 24:
      return Ki(), a !== null && a.memoizedState !== null !== (b.memoizedState !== null) && d.mode !== "unstable-defer-without-hiding" && (b.flags |= 4), null;
  }
  throw Error(y(156, b.tag));
}
function Li(a) {
  switch (a.tag) {
    case 1:
      Ff(a.type) && Gf();
      var b = a.flags;
      return b & 4096 ? (a.flags = b & -4097 | 64, a) : null;
    case 3:
      fh();
      H(N);
      H(M);
      uh();
      b = a.flags;
      if ((b & 64) !== 0)
        throw Error(y(285));
      a.flags = b & -4097 | 64;
      return a;
    case 5:
      return hh(a), null;
    case 13:
      return H(P), b = a.flags, b & 4096 ? (a.flags = b & -4097 | 64, a) : null;
    case 19:
      return H(P), null;
    case 4:
      return fh(), null;
    case 10:
      return rg(a), null;
    case 23:
    case 24:
      return Ki(), null;
    default:
      return null;
  }
}
function Mi(a, b) {
  try {
    var c = "", d = b;
    do
      c += Qa(d), d = d.return;
    while (d);
    var e = c;
  } catch (f) {
    e = "\nError generating stack: " + f.message + "\n" + f.stack;
  }
  return {value: a, source: b, stack: e};
}
function Ni(a, b) {
  try {
    console.error(b.value);
  } catch (c) {
    setTimeout(function() {
      throw c;
    });
  }
}
var Oi = typeof WeakMap === "function" ? WeakMap : Map;
function Pi(a, b, c) {
  c = zg(-1, c);
  c.tag = 3;
  c.payload = {element: null};
  var d = b.value;
  c.callback = function() {
    Qi || (Qi = true, Ri = d);
    Ni(a, b);
  };
  return c;
}
function Si(a, b, c) {
  c = zg(-1, c);
  c.tag = 3;
  var d = a.type.getDerivedStateFromError;
  if (typeof d === "function") {
    var e = b.value;
    c.payload = function() {
      Ni(a, b);
      return d(e);
    };
  }
  var f = a.stateNode;
  f !== null && typeof f.componentDidCatch === "function" && (c.callback = function() {
    typeof d !== "function" && (Ti === null ? Ti = new Set([this]) : Ti.add(this), Ni(a, b));
    var c2 = b.stack;
    this.componentDidCatch(b.value, {componentStack: c2 !== null ? c2 : ""});
  });
  return c;
}
var Ui = typeof WeakSet === "function" ? WeakSet : Set;
function Vi(a) {
  var b = a.ref;
  if (b !== null)
    if (typeof b === "function")
      try {
        b(null);
      } catch (c) {
        Wi(a, c);
      }
    else
      b.current = null;
}
function Xi(a, b) {
  switch (b.tag) {
    case 0:
    case 11:
    case 15:
    case 22:
      return;
    case 1:
      if (b.flags & 256 && a !== null) {
        var c = a.memoizedProps, d = a.memoizedState;
        a = b.stateNode;
        b = a.getSnapshotBeforeUpdate(b.elementType === b.type ? c : lg(b.type, c), d);
        a.__reactInternalSnapshotBeforeUpdate = b;
      }
      return;
    case 3:
      b.flags & 256 && qf(b.stateNode.containerInfo);
      return;
    case 5:
    case 6:
    case 4:
    case 17:
      return;
  }
  throw Error(y(163));
}
function Yi(a, b, c) {
  switch (c.tag) {
    case 0:
    case 11:
    case 15:
    case 22:
      b = c.updateQueue;
      b = b !== null ? b.lastEffect : null;
      if (b !== null) {
        a = b = b.next;
        do {
          if ((a.tag & 3) === 3) {
            var d = a.create;
            a.destroy = d();
          }
          a = a.next;
        } while (a !== b);
      }
      b = c.updateQueue;
      b = b !== null ? b.lastEffect : null;
      if (b !== null) {
        a = b = b.next;
        do {
          var e = a;
          d = e.next;
          e = e.tag;
          (e & 4) !== 0 && (e & 1) !== 0 && (Zi(c, a), $i(c, a));
          a = d;
        } while (a !== b);
      }
      return;
    case 1:
      a = c.stateNode;
      c.flags & 4 && (b === null ? a.componentDidMount() : (d = c.elementType === c.type ? b.memoizedProps : lg(c.type, b.memoizedProps), a.componentDidUpdate(d, b.memoizedState, a.__reactInternalSnapshotBeforeUpdate)));
      b = c.updateQueue;
      b !== null && Eg(c, b, a);
      return;
    case 3:
      b = c.updateQueue;
      if (b !== null) {
        a = null;
        if (c.child !== null)
          switch (c.child.tag) {
            case 5:
              a = c.child.stateNode;
              break;
            case 1:
              a = c.child.stateNode;
          }
        Eg(c, b, a);
      }
      return;
    case 5:
      a = c.stateNode;
      b === null && c.flags & 4 && mf(c.type, c.memoizedProps) && a.focus();
      return;
    case 6:
      return;
    case 4:
      return;
    case 12:
      return;
    case 13:
      c.memoizedState === null && (c = c.alternate, c !== null && (c = c.memoizedState, c !== null && (c = c.dehydrated, c !== null && Cc(c))));
      return;
    case 19:
    case 17:
    case 20:
    case 21:
    case 23:
    case 24:
      return;
  }
  throw Error(y(163));
}
function aj(a, b) {
  for (var c = a; ; ) {
    if (c.tag === 5) {
      var d = c.stateNode;
      if (b)
        d = d.style, typeof d.setProperty === "function" ? d.setProperty("display", "none", "important") : d.display = "none";
      else {
        d = c.stateNode;
        var e = c.memoizedProps.style;
        e = e !== void 0 && e !== null && e.hasOwnProperty("display") ? e.display : null;
        d.style.display = sb("display", e);
      }
    } else if (c.tag === 6)
      c.stateNode.nodeValue = b ? "" : c.memoizedProps;
    else if ((c.tag !== 23 && c.tag !== 24 || c.memoizedState === null || c === a) && c.child !== null) {
      c.child.return = c;
      c = c.child;
      continue;
    }
    if (c === a)
      break;
    for (; c.sibling === null; ) {
      if (c.return === null || c.return === a)
        return;
      c = c.return;
    }
    c.sibling.return = c.return;
    c = c.sibling;
  }
}
function bj(a, b) {
  if (Mf && typeof Mf.onCommitFiberUnmount === "function")
    try {
      Mf.onCommitFiberUnmount(Lf, b);
    } catch (f) {
    }
  switch (b.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
    case 22:
      a = b.updateQueue;
      if (a !== null && (a = a.lastEffect, a !== null)) {
        var c = a = a.next;
        do {
          var d = c, e = d.destroy;
          d = d.tag;
          if (e !== void 0)
            if ((d & 4) !== 0)
              Zi(b, c);
            else {
              d = b;
              try {
                e();
              } catch (f) {
                Wi(d, f);
              }
            }
          c = c.next;
        } while (c !== a);
      }
      break;
    case 1:
      Vi(b);
      a = b.stateNode;
      if (typeof a.componentWillUnmount === "function")
        try {
          a.props = b.memoizedProps, a.state = b.memoizedState, a.componentWillUnmount();
        } catch (f) {
          Wi(b, f);
        }
      break;
    case 5:
      Vi(b);
      break;
    case 4:
      cj(a, b);
  }
}
function dj(a) {
  a.alternate = null;
  a.child = null;
  a.dependencies = null;
  a.firstEffect = null;
  a.lastEffect = null;
  a.memoizedProps = null;
  a.memoizedState = null;
  a.pendingProps = null;
  a.return = null;
  a.updateQueue = null;
}
function ej(a) {
  return a.tag === 5 || a.tag === 3 || a.tag === 4;
}
function fj(a) {
  a: {
    for (var b = a.return; b !== null; ) {
      if (ej(b))
        break a;
      b = b.return;
    }
    throw Error(y(160));
  }
  var c = b;
  b = c.stateNode;
  switch (c.tag) {
    case 5:
      var d = false;
      break;
    case 3:
      b = b.containerInfo;
      d = true;
      break;
    case 4:
      b = b.containerInfo;
      d = true;
      break;
    default:
      throw Error(y(161));
  }
  c.flags & 16 && (pb(b, ""), c.flags &= -17);
  a:
    b:
      for (c = a; ; ) {
        for (; c.sibling === null; ) {
          if (c.return === null || ej(c.return)) {
            c = null;
            break a;
          }
          c = c.return;
        }
        c.sibling.return = c.return;
        for (c = c.sibling; c.tag !== 5 && c.tag !== 6 && c.tag !== 18; ) {
          if (c.flags & 2)
            continue b;
          if (c.child === null || c.tag === 4)
            continue b;
          else
            c.child.return = c, c = c.child;
        }
        if (!(c.flags & 2)) {
          c = c.stateNode;
          break a;
        }
      }
  d ? gj(a, c, b) : hj(a, c, b);
}
function gj(a, b, c) {
  var d = a.tag, e = d === 5 || d === 6;
  if (e)
    a = e ? a.stateNode : a.stateNode.instance, b ? c.nodeType === 8 ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (c.nodeType === 8 ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, c !== null && c !== void 0 || b.onclick !== null || (b.onclick = jf));
  else if (d !== 4 && (a = a.child, a !== null))
    for (gj(a, b, c), a = a.sibling; a !== null; )
      gj(a, b, c), a = a.sibling;
}
function hj(a, b, c) {
  var d = a.tag, e = d === 5 || d === 6;
  if (e)
    a = e ? a.stateNode : a.stateNode.instance, b ? c.insertBefore(a, b) : c.appendChild(a);
  else if (d !== 4 && (a = a.child, a !== null))
    for (hj(a, b, c), a = a.sibling; a !== null; )
      hj(a, b, c), a = a.sibling;
}
function cj(a, b) {
  for (var c = b, d = false, e, f; ; ) {
    if (!d) {
      d = c.return;
      a:
        for (; ; ) {
          if (d === null)
            throw Error(y(160));
          e = d.stateNode;
          switch (d.tag) {
            case 5:
              f = false;
              break a;
            case 3:
              e = e.containerInfo;
              f = true;
              break a;
            case 4:
              e = e.containerInfo;
              f = true;
              break a;
          }
          d = d.return;
        }
      d = true;
    }
    if (c.tag === 5 || c.tag === 6) {
      a:
        for (var g = a, h = c, k = h; ; )
          if (bj(g, k), k.child !== null && k.tag !== 4)
            k.child.return = k, k = k.child;
          else {
            if (k === h)
              break a;
            for (; k.sibling === null; ) {
              if (k.return === null || k.return === h)
                break a;
              k = k.return;
            }
            k.sibling.return = k.return;
            k = k.sibling;
          }
      f ? (g = e, h = c.stateNode, g.nodeType === 8 ? g.parentNode.removeChild(h) : g.removeChild(h)) : e.removeChild(c.stateNode);
    } else if (c.tag === 4) {
      if (c.child !== null) {
        e = c.stateNode.containerInfo;
        f = true;
        c.child.return = c;
        c = c.child;
        continue;
      }
    } else if (bj(a, c), c.child !== null) {
      c.child.return = c;
      c = c.child;
      continue;
    }
    if (c === b)
      break;
    for (; c.sibling === null; ) {
      if (c.return === null || c.return === b)
        return;
      c = c.return;
      c.tag === 4 && (d = false);
    }
    c.sibling.return = c.return;
    c = c.sibling;
  }
}
function ij(a, b) {
  switch (b.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
    case 22:
      var c = b.updateQueue;
      c = c !== null ? c.lastEffect : null;
      if (c !== null) {
        var d = c = c.next;
        do
          (d.tag & 3) === 3 && (a = d.destroy, d.destroy = void 0, a !== void 0 && a()), d = d.next;
        while (d !== c);
      }
      return;
    case 1:
      return;
    case 5:
      c = b.stateNode;
      if (c != null) {
        d = b.memoizedProps;
        var e = a !== null ? a.memoizedProps : d;
        a = b.type;
        var f = b.updateQueue;
        b.updateQueue = null;
        if (f !== null) {
          c[xf] = d;
          a === "input" && d.type === "radio" && d.name != null && $a(c, d);
          wb(a, e);
          b = wb(a, d);
          for (e = 0; e < f.length; e += 2) {
            var g = f[e], h = f[e + 1];
            g === "style" ? tb(c, h) : g === "dangerouslySetInnerHTML" ? ob(c, h) : g === "children" ? pb(c, h) : qa(c, g, h, b);
          }
          switch (a) {
            case "input":
              ab(c, d);
              break;
            case "textarea":
              ib(c, d);
              break;
            case "select":
              a = c._wrapperState.wasMultiple, c._wrapperState.wasMultiple = !!d.multiple, f = d.value, f != null ? fb(c, !!d.multiple, f, false) : a !== !!d.multiple && (d.defaultValue != null ? fb(c, !!d.multiple, d.defaultValue, true) : fb(c, !!d.multiple, d.multiple ? [] : "", false));
          }
        }
      }
      return;
    case 6:
      if (b.stateNode === null)
        throw Error(y(162));
      b.stateNode.nodeValue = b.memoizedProps;
      return;
    case 3:
      c = b.stateNode;
      c.hydrate && (c.hydrate = false, Cc(c.containerInfo));
      return;
    case 12:
      return;
    case 13:
      b.memoizedState !== null && (jj = O(), aj(b.child, true));
      kj(b);
      return;
    case 19:
      kj(b);
      return;
    case 17:
      return;
    case 23:
    case 24:
      aj(b, b.memoizedState !== null);
      return;
  }
  throw Error(y(163));
}
function kj(a) {
  var b = a.updateQueue;
  if (b !== null) {
    a.updateQueue = null;
    var c = a.stateNode;
    c === null && (c = a.stateNode = new Ui());
    b.forEach(function(b2) {
      var d = lj.bind(null, a, b2);
      c.has(b2) || (c.add(b2), b2.then(d, d));
    });
  }
}
function mj(a, b) {
  return a !== null && (a = a.memoizedState, a === null || a.dehydrated !== null) ? (b = b.memoizedState, b !== null && b.dehydrated === null) : false;
}
var nj = Math.ceil, oj = ra.ReactCurrentDispatcher, pj = ra.ReactCurrentOwner, X = 0, U = null, Y = null, W = 0, qj = 0, rj = Bf(0), V = 0, sj = null, tj = 0, Dg = 0, Hi = 0, uj = 0, vj = null, jj = 0, Ji = Infinity;
function wj() {
  Ji = O() + 500;
}
var Z = null, Qi = false, Ri = null, Ti = null, xj = false, yj = null, zj = 90, Aj = [], Bj = [], Cj = null, Dj = 0, Ej = null, Fj = -1, Gj = 0, Hj = 0, Ij = null, Jj = false;
function Hg() {
  return (X & 48) !== 0 ? O() : Fj !== -1 ? Fj : Fj = O();
}
function Ig(a) {
  a = a.mode;
  if ((a & 2) === 0)
    return 1;
  if ((a & 4) === 0)
    return eg() === 99 ? 1 : 2;
  Gj === 0 && (Gj = tj);
  if (kg.transition !== 0) {
    Hj !== 0 && (Hj = vj !== null ? vj.pendingLanes : 0);
    a = Gj;
    var b = 4186112 & ~Hj;
    b &= -b;
    b === 0 && (a = 4186112 & ~a, b = a & -a, b === 0 && (b = 8192));
    return b;
  }
  a = eg();
  (X & 4) !== 0 && a === 98 ? a = Xc(12, Gj) : (a = Sc(a), a = Xc(a, Gj));
  return a;
}
function Jg(a, b, c) {
  if (50 < Dj)
    throw Dj = 0, Ej = null, Error(y(185));
  a = Kj(a, b);
  if (a === null)
    return null;
  $c(a, b, c);
  a === U && (Hi |= b, V === 4 && Ii(a, W));
  var d = eg();
  b === 1 ? (X & 8) !== 0 && (X & 48) === 0 ? Lj(a) : (Mj(a, c), X === 0 && (wj(), ig())) : ((X & 4) === 0 || d !== 98 && d !== 99 || (Cj === null ? Cj = new Set([a]) : Cj.add(a)), Mj(a, c));
  vj = a;
}
function Kj(a, b) {
  a.lanes |= b;
  var c = a.alternate;
  c !== null && (c.lanes |= b);
  c = a;
  for (a = a.return; a !== null; )
    a.childLanes |= b, c = a.alternate, c !== null && (c.childLanes |= b), c = a, a = a.return;
  return c.tag === 3 ? c.stateNode : null;
}
function Mj(a, b) {
  for (var c = a.callbackNode, d = a.suspendedLanes, e = a.pingedLanes, f = a.expirationTimes, g = a.pendingLanes; 0 < g; ) {
    var h = 31 - Vc(g), k = 1 << h, l = f[h];
    if (l === -1) {
      if ((k & d) === 0 || (k & e) !== 0) {
        l = b;
        Rc(k);
        var n = F;
        f[h] = 10 <= n ? l + 250 : 6 <= n ? l + 5e3 : -1;
      }
    } else
      l <= b && (a.expiredLanes |= k);
    g &= ~k;
  }
  d = Uc(a, a === U ? W : 0);
  b = F;
  if (d === 0)
    c !== null && (c !== Zf && Pf(c), a.callbackNode = null, a.callbackPriority = 0);
  else {
    if (c !== null) {
      if (a.callbackPriority === b)
        return;
      c !== Zf && Pf(c);
    }
    b === 15 ? (c = Lj.bind(null, a), ag === null ? (ag = [c], bg = Of(Uf, jg)) : ag.push(c), c = Zf) : b === 14 ? c = hg(99, Lj.bind(null, a)) : (c = Tc(b), c = hg(c, Nj.bind(null, a)));
    a.callbackPriority = b;
    a.callbackNode = c;
  }
}
function Nj(a) {
  Fj = -1;
  Hj = Gj = 0;
  if ((X & 48) !== 0)
    throw Error(y(327));
  var b = a.callbackNode;
  if (Oj() && a.callbackNode !== b)
    return null;
  var c = Uc(a, a === U ? W : 0);
  if (c === 0)
    return null;
  var d = c;
  var e = X;
  X |= 16;
  var f = Pj();
  if (U !== a || W !== d)
    wj(), Qj(a, d);
  do
    try {
      Rj();
      break;
    } catch (h) {
      Sj(a, h);
    }
  while (1);
  qg();
  oj.current = f;
  X = e;
  Y !== null ? d = 0 : (U = null, W = 0, d = V);
  if ((tj & Hi) !== 0)
    Qj(a, 0);
  else if (d !== 0) {
    d === 2 && (X |= 64, a.hydrate && (a.hydrate = false, qf(a.containerInfo)), c = Wc(a), c !== 0 && (d = Tj(a, c)));
    if (d === 1)
      throw b = sj, Qj(a, 0), Ii(a, c), Mj(a, O()), b;
    a.finishedWork = a.current.alternate;
    a.finishedLanes = c;
    switch (d) {
      case 0:
      case 1:
        throw Error(y(345));
      case 2:
        Uj(a);
        break;
      case 3:
        Ii(a, c);
        if ((c & 62914560) === c && (d = jj + 500 - O(), 10 < d)) {
          if (Uc(a, 0) !== 0)
            break;
          e = a.suspendedLanes;
          if ((e & c) !== c) {
            Hg();
            a.pingedLanes |= a.suspendedLanes & e;
            break;
          }
          a.timeoutHandle = of(Uj.bind(null, a), d);
          break;
        }
        Uj(a);
        break;
      case 4:
        Ii(a, c);
        if ((c & 4186112) === c)
          break;
        d = a.eventTimes;
        for (e = -1; 0 < c; ) {
          var g = 31 - Vc(c);
          f = 1 << g;
          g = d[g];
          g > e && (e = g);
          c &= ~f;
        }
        c = e;
        c = O() - c;
        c = (120 > c ? 120 : 480 > c ? 480 : 1080 > c ? 1080 : 1920 > c ? 1920 : 3e3 > c ? 3e3 : 4320 > c ? 4320 : 1960 * nj(c / 1960)) - c;
        if (10 < c) {
          a.timeoutHandle = of(Uj.bind(null, a), c);
          break;
        }
        Uj(a);
        break;
      case 5:
        Uj(a);
        break;
      default:
        throw Error(y(329));
    }
  }
  Mj(a, O());
  return a.callbackNode === b ? Nj.bind(null, a) : null;
}
function Ii(a, b) {
  b &= ~uj;
  b &= ~Hi;
  a.suspendedLanes |= b;
  a.pingedLanes &= ~b;
  for (a = a.expirationTimes; 0 < b; ) {
    var c = 31 - Vc(b), d = 1 << c;
    a[c] = -1;
    b &= ~d;
  }
}
function Lj(a) {
  if ((X & 48) !== 0)
    throw Error(y(327));
  Oj();
  if (a === U && (a.expiredLanes & W) !== 0) {
    var b = W;
    var c = Tj(a, b);
    (tj & Hi) !== 0 && (b = Uc(a, b), c = Tj(a, b));
  } else
    b = Uc(a, 0), c = Tj(a, b);
  a.tag !== 0 && c === 2 && (X |= 64, a.hydrate && (a.hydrate = false, qf(a.containerInfo)), b = Wc(a), b !== 0 && (c = Tj(a, b)));
  if (c === 1)
    throw c = sj, Qj(a, 0), Ii(a, b), Mj(a, O()), c;
  a.finishedWork = a.current.alternate;
  a.finishedLanes = b;
  Uj(a);
  Mj(a, O());
  return null;
}
function Vj() {
  if (Cj !== null) {
    var a = Cj;
    Cj = null;
    a.forEach(function(a2) {
      a2.expiredLanes |= 24 & a2.pendingLanes;
      Mj(a2, O());
    });
  }
  ig();
}
function Wj(a, b) {
  var c = X;
  X |= 1;
  try {
    return a(b);
  } finally {
    X = c, X === 0 && (wj(), ig());
  }
}
function Xj(a, b) {
  var c = X;
  X &= -2;
  X |= 8;
  try {
    return a(b);
  } finally {
    X = c, X === 0 && (wj(), ig());
  }
}
function ni(a, b) {
  I(rj, qj);
  qj |= b;
  tj |= b;
}
function Ki() {
  qj = rj.current;
  H(rj);
}
function Qj(a, b) {
  a.finishedWork = null;
  a.finishedLanes = 0;
  var c = a.timeoutHandle;
  c !== -1 && (a.timeoutHandle = -1, pf(c));
  if (Y !== null)
    for (c = Y.return; c !== null; ) {
      var d = c;
      switch (d.tag) {
        case 1:
          d = d.type.childContextTypes;
          d !== null && d !== void 0 && Gf();
          break;
        case 3:
          fh();
          H(N);
          H(M);
          uh();
          break;
        case 5:
          hh(d);
          break;
        case 4:
          fh();
          break;
        case 13:
          H(P);
          break;
        case 19:
          H(P);
          break;
        case 10:
          rg(d);
          break;
        case 23:
        case 24:
          Ki();
      }
      c = c.return;
    }
  U = a;
  Y = Tg(a.current, null);
  W = qj = tj = b;
  V = 0;
  sj = null;
  uj = Hi = Dg = 0;
}
function Sj(a, b) {
  do {
    var c = Y;
    try {
      qg();
      vh.current = Gh;
      if (yh) {
        for (var d = R.memoizedState; d !== null; ) {
          var e = d.queue;
          e !== null && (e.pending = null);
          d = d.next;
        }
        yh = false;
      }
      xh = 0;
      T = S = R = null;
      zh = false;
      pj.current = null;
      if (c === null || c.return === null) {
        V = 1;
        sj = b;
        Y = null;
        break;
      }
      a: {
        var f = a, g = c.return, h = c, k = b;
        b = W;
        h.flags |= 2048;
        h.firstEffect = h.lastEffect = null;
        if (k !== null && typeof k === "object" && typeof k.then === "function") {
          var l = k;
          if ((h.mode & 2) === 0) {
            var n = h.alternate;
            n ? (h.updateQueue = n.updateQueue, h.memoizedState = n.memoizedState, h.lanes = n.lanes) : (h.updateQueue = null, h.memoizedState = null);
          }
          var A = (P.current & 1) !== 0, p = g;
          do {
            var C;
            if (C = p.tag === 13) {
              var x = p.memoizedState;
              if (x !== null)
                C = x.dehydrated !== null ? true : false;
              else {
                var w = p.memoizedProps;
                C = w.fallback === void 0 ? false : w.unstable_avoidThisFallback !== true ? true : A ? false : true;
              }
            }
            if (C) {
              var z = p.updateQueue;
              if (z === null) {
                var u = new Set();
                u.add(l);
                p.updateQueue = u;
              } else
                z.add(l);
              if ((p.mode & 2) === 0) {
                p.flags |= 64;
                h.flags |= 16384;
                h.flags &= -2981;
                if (h.tag === 1)
                  if (h.alternate === null)
                    h.tag = 17;
                  else {
                    var t = zg(-1, 1);
                    t.tag = 2;
                    Ag(h, t);
                  }
                h.lanes |= 1;
                break a;
              }
              k = void 0;
              h = b;
              var q = f.pingCache;
              q === null ? (q = f.pingCache = new Oi(), k = new Set(), q.set(l, k)) : (k = q.get(l), k === void 0 && (k = new Set(), q.set(l, k)));
              if (!k.has(h)) {
                k.add(h);
                var v = Yj.bind(null, f, l, h);
                l.then(v, v);
              }
              p.flags |= 4096;
              p.lanes = b;
              break a;
            }
            p = p.return;
          } while (p !== null);
          k = Error((Ra(h.type) || "A React component") + " suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.");
        }
        V !== 5 && (V = 2);
        k = Mi(k, h);
        p = g;
        do {
          switch (p.tag) {
            case 3:
              f = k;
              p.flags |= 4096;
              b &= -b;
              p.lanes |= b;
              var J = Pi(p, f, b);
              Bg(p, J);
              break a;
            case 1:
              f = k;
              var K = p.type, Q = p.stateNode;
              if ((p.flags & 64) === 0 && (typeof K.getDerivedStateFromError === "function" || Q !== null && typeof Q.componentDidCatch === "function" && (Ti === null || !Ti.has(Q)))) {
                p.flags |= 4096;
                b &= -b;
                p.lanes |= b;
                var L = Si(p, f, b);
                Bg(p, L);
                break a;
              }
          }
          p = p.return;
        } while (p !== null);
      }
      Zj(c);
    } catch (va) {
      b = va;
      Y === c && c !== null && (Y = c = c.return);
      continue;
    }
    break;
  } while (1);
}
function Pj() {
  var a = oj.current;
  oj.current = Gh;
  return a === null ? Gh : a;
}
function Tj(a, b) {
  var c = X;
  X |= 16;
  var d = Pj();
  U === a && W === b || Qj(a, b);
  do
    try {
      ak();
      break;
    } catch (e) {
      Sj(a, e);
    }
  while (1);
  qg();
  X = c;
  oj.current = d;
  if (Y !== null)
    throw Error(y(261));
  U = null;
  W = 0;
  return V;
}
function ak() {
  for (; Y !== null; )
    bk(Y);
}
function Rj() {
  for (; Y !== null && !Qf(); )
    bk(Y);
}
function bk(a) {
  var b = ck(a.alternate, a, qj);
  a.memoizedProps = a.pendingProps;
  b === null ? Zj(a) : Y = b;
  pj.current = null;
}
function Zj(a) {
  var b = a;
  do {
    var c = b.alternate;
    a = b.return;
    if ((b.flags & 2048) === 0) {
      c = Gi(c, b, qj);
      if (c !== null) {
        Y = c;
        return;
      }
      c = b;
      if (c.tag !== 24 && c.tag !== 23 || c.memoizedState === null || (qj & 1073741824) !== 0 || (c.mode & 4) === 0) {
        for (var d = 0, e = c.child; e !== null; )
          d |= e.lanes | e.childLanes, e = e.sibling;
        c.childLanes = d;
      }
      a !== null && (a.flags & 2048) === 0 && (a.firstEffect === null && (a.firstEffect = b.firstEffect), b.lastEffect !== null && (a.lastEffect !== null && (a.lastEffect.nextEffect = b.firstEffect), a.lastEffect = b.lastEffect), 1 < b.flags && (a.lastEffect !== null ? a.lastEffect.nextEffect = b : a.firstEffect = b, a.lastEffect = b));
    } else {
      c = Li(b);
      if (c !== null) {
        c.flags &= 2047;
        Y = c;
        return;
      }
      a !== null && (a.firstEffect = a.lastEffect = null, a.flags |= 2048);
    }
    b = b.sibling;
    if (b !== null) {
      Y = b;
      return;
    }
    Y = b = a;
  } while (b !== null);
  V === 0 && (V = 5);
}
function Uj(a) {
  var b = eg();
  gg(99, dk.bind(null, a, b));
  return null;
}
function dk(a, b) {
  do
    Oj();
  while (yj !== null);
  if ((X & 48) !== 0)
    throw Error(y(327));
  var c = a.finishedWork;
  if (c === null)
    return null;
  a.finishedWork = null;
  a.finishedLanes = 0;
  if (c === a.current)
    throw Error(y(177));
  a.callbackNode = null;
  var d = c.lanes | c.childLanes, e = d, f = a.pendingLanes & ~e;
  a.pendingLanes = e;
  a.suspendedLanes = 0;
  a.pingedLanes = 0;
  a.expiredLanes &= e;
  a.mutableReadLanes &= e;
  a.entangledLanes &= e;
  e = a.entanglements;
  for (var g = a.eventTimes, h = a.expirationTimes; 0 < f; ) {
    var k = 31 - Vc(f), l = 1 << k;
    e[k] = 0;
    g[k] = -1;
    h[k] = -1;
    f &= ~l;
  }
  Cj !== null && (d & 24) === 0 && Cj.has(a) && Cj.delete(a);
  a === U && (Y = U = null, W = 0);
  1 < c.flags ? c.lastEffect !== null ? (c.lastEffect.nextEffect = c, d = c.firstEffect) : d = c : d = c.firstEffect;
  if (d !== null) {
    e = X;
    X |= 32;
    pj.current = null;
    kf = fd;
    g = Ne();
    if (Oe(g)) {
      if ("selectionStart" in g)
        h = {start: g.selectionStart, end: g.selectionEnd};
      else
        a:
          if (h = (h = g.ownerDocument) && h.defaultView || window, (l = h.getSelection && h.getSelection()) && l.rangeCount !== 0) {
            h = l.anchorNode;
            f = l.anchorOffset;
            k = l.focusNode;
            l = l.focusOffset;
            try {
              h.nodeType, k.nodeType;
            } catch (va) {
              h = null;
              break a;
            }
            var n = 0, A = -1, p = -1, C = 0, x = 0, w = g, z = null;
            b:
              for (; ; ) {
                for (var u; ; ) {
                  w !== h || f !== 0 && w.nodeType !== 3 || (A = n + f);
                  w !== k || l !== 0 && w.nodeType !== 3 || (p = n + l);
                  w.nodeType === 3 && (n += w.nodeValue.length);
                  if ((u = w.firstChild) === null)
                    break;
                  z = w;
                  w = u;
                }
                for (; ; ) {
                  if (w === g)
                    break b;
                  z === h && ++C === f && (A = n);
                  z === k && ++x === l && (p = n);
                  if ((u = w.nextSibling) !== null)
                    break;
                  w = z;
                  z = w.parentNode;
                }
                w = u;
              }
            h = A === -1 || p === -1 ? null : {start: A, end: p};
          } else
            h = null;
      h = h || {start: 0, end: 0};
    } else
      h = null;
    lf = {focusedElem: g, selectionRange: h};
    fd = false;
    Ij = null;
    Jj = false;
    Z = d;
    do
      try {
        ek();
      } catch (va) {
        if (Z === null)
          throw Error(y(330));
        Wi(Z, va);
        Z = Z.nextEffect;
      }
    while (Z !== null);
    Ij = null;
    Z = d;
    do
      try {
        for (g = a; Z !== null; ) {
          var t = Z.flags;
          t & 16 && pb(Z.stateNode, "");
          if (t & 128) {
            var q = Z.alternate;
            if (q !== null) {
              var v = q.ref;
              v !== null && (typeof v === "function" ? v(null) : v.current = null);
            }
          }
          switch (t & 1038) {
            case 2:
              fj(Z);
              Z.flags &= -3;
              break;
            case 6:
              fj(Z);
              Z.flags &= -3;
              ij(Z.alternate, Z);
              break;
            case 1024:
              Z.flags &= -1025;
              break;
            case 1028:
              Z.flags &= -1025;
              ij(Z.alternate, Z);
              break;
            case 4:
              ij(Z.alternate, Z);
              break;
            case 8:
              h = Z;
              cj(g, h);
              var J = h.alternate;
              dj(h);
              J !== null && dj(J);
          }
          Z = Z.nextEffect;
        }
      } catch (va) {
        if (Z === null)
          throw Error(y(330));
        Wi(Z, va);
        Z = Z.nextEffect;
      }
    while (Z !== null);
    v = lf;
    q = Ne();
    t = v.focusedElem;
    g = v.selectionRange;
    if (q !== t && t && t.ownerDocument && Me(t.ownerDocument.documentElement, t)) {
      g !== null && Oe(t) && (q = g.start, v = g.end, v === void 0 && (v = q), "selectionStart" in t ? (t.selectionStart = q, t.selectionEnd = Math.min(v, t.value.length)) : (v = (q = t.ownerDocument || document) && q.defaultView || window, v.getSelection && (v = v.getSelection(), h = t.textContent.length, J = Math.min(g.start, h), g = g.end === void 0 ? J : Math.min(g.end, h), !v.extend && J > g && (h = g, g = J, J = h), h = Le(t, J), f = Le(t, g), h && f && (v.rangeCount !== 1 || v.anchorNode !== h.node || v.anchorOffset !== h.offset || v.focusNode !== f.node || v.focusOffset !== f.offset) && (q = q.createRange(), q.setStart(h.node, h.offset), v.removeAllRanges(), J > g ? (v.addRange(q), v.extend(f.node, f.offset)) : (q.setEnd(f.node, f.offset), v.addRange(q))))));
      q = [];
      for (v = t; v = v.parentNode; )
        v.nodeType === 1 && q.push({element: v, left: v.scrollLeft, top: v.scrollTop});
      typeof t.focus === "function" && t.focus();
      for (t = 0; t < q.length; t++)
        v = q[t], v.element.scrollLeft = v.left, v.element.scrollTop = v.top;
    }
    fd = !!kf;
    lf = kf = null;
    a.current = c;
    Z = d;
    do
      try {
        for (t = a; Z !== null; ) {
          var K = Z.flags;
          K & 36 && Yi(t, Z.alternate, Z);
          if (K & 128) {
            q = void 0;
            var Q = Z.ref;
            if (Q !== null) {
              var L = Z.stateNode;
              switch (Z.tag) {
                case 5:
                  q = L;
                  break;
                default:
                  q = L;
              }
              typeof Q === "function" ? Q(q) : Q.current = q;
            }
          }
          Z = Z.nextEffect;
        }
      } catch (va) {
        if (Z === null)
          throw Error(y(330));
        Wi(Z, va);
        Z = Z.nextEffect;
      }
    while (Z !== null);
    Z = null;
    $f();
    X = e;
  } else
    a.current = c;
  if (xj)
    xj = false, yj = a, zj = b;
  else
    for (Z = d; Z !== null; )
      b = Z.nextEffect, Z.nextEffect = null, Z.flags & 8 && (K = Z, K.sibling = null, K.stateNode = null), Z = b;
  d = a.pendingLanes;
  d === 0 && (Ti = null);
  d === 1 ? a === Ej ? Dj++ : (Dj = 0, Ej = a) : Dj = 0;
  c = c.stateNode;
  if (Mf && typeof Mf.onCommitFiberRoot === "function")
    try {
      Mf.onCommitFiberRoot(Lf, c, void 0, (c.current.flags & 64) === 64);
    } catch (va) {
    }
  Mj(a, O());
  if (Qi)
    throw Qi = false, a = Ri, Ri = null, a;
  if ((X & 8) !== 0)
    return null;
  ig();
  return null;
}
function ek() {
  for (; Z !== null; ) {
    var a = Z.alternate;
    Jj || Ij === null || ((Z.flags & 8) !== 0 ? dc(Z, Ij) && (Jj = true) : Z.tag === 13 && mj(a, Z) && dc(Z, Ij) && (Jj = true));
    var b = Z.flags;
    (b & 256) !== 0 && Xi(a, Z);
    (b & 512) === 0 || xj || (xj = true, hg(97, function() {
      Oj();
      return null;
    }));
    Z = Z.nextEffect;
  }
}
function Oj() {
  if (zj !== 90) {
    var a = 97 < zj ? 97 : zj;
    zj = 90;
    return gg(a, fk);
  }
  return false;
}
function $i(a, b) {
  Aj.push(b, a);
  xj || (xj = true, hg(97, function() {
    Oj();
    return null;
  }));
}
function Zi(a, b) {
  Bj.push(b, a);
  xj || (xj = true, hg(97, function() {
    Oj();
    return null;
  }));
}
function fk() {
  if (yj === null)
    return false;
  var a = yj;
  yj = null;
  if ((X & 48) !== 0)
    throw Error(y(331));
  var b = X;
  X |= 32;
  var c = Bj;
  Bj = [];
  for (var d = 0; d < c.length; d += 2) {
    var e = c[d], f = c[d + 1], g = e.destroy;
    e.destroy = void 0;
    if (typeof g === "function")
      try {
        g();
      } catch (k) {
        if (f === null)
          throw Error(y(330));
        Wi(f, k);
      }
  }
  c = Aj;
  Aj = [];
  for (d = 0; d < c.length; d += 2) {
    e = c[d];
    f = c[d + 1];
    try {
      var h = e.create;
      e.destroy = h();
    } catch (k) {
      if (f === null)
        throw Error(y(330));
      Wi(f, k);
    }
  }
  for (h = a.current.firstEffect; h !== null; )
    a = h.nextEffect, h.nextEffect = null, h.flags & 8 && (h.sibling = null, h.stateNode = null), h = a;
  X = b;
  ig();
  return true;
}
function gk(a, b, c) {
  b = Mi(c, b);
  b = Pi(a, b, 1);
  Ag(a, b);
  b = Hg();
  a = Kj(a, 1);
  a !== null && ($c(a, 1, b), Mj(a, b));
}
function Wi(a, b) {
  if (a.tag === 3)
    gk(a, a, b);
  else
    for (var c = a.return; c !== null; ) {
      if (c.tag === 3) {
        gk(c, a, b);
        break;
      } else if (c.tag === 1) {
        var d = c.stateNode;
        if (typeof c.type.getDerivedStateFromError === "function" || typeof d.componentDidCatch === "function" && (Ti === null || !Ti.has(d))) {
          a = Mi(b, a);
          var e = Si(c, a, 1);
          Ag(c, e);
          e = Hg();
          c = Kj(c, 1);
          if (c !== null)
            $c(c, 1, e), Mj(c, e);
          else if (typeof d.componentDidCatch === "function" && (Ti === null || !Ti.has(d)))
            try {
              d.componentDidCatch(b, a);
            } catch (f) {
            }
          break;
        }
      }
      c = c.return;
    }
}
function Yj(a, b, c) {
  var d = a.pingCache;
  d !== null && d.delete(b);
  b = Hg();
  a.pingedLanes |= a.suspendedLanes & c;
  U === a && (W & c) === c && (V === 4 || V === 3 && (W & 62914560) === W && 500 > O() - jj ? Qj(a, 0) : uj |= c);
  Mj(a, b);
}
function lj(a, b) {
  var c = a.stateNode;
  c !== null && c.delete(b);
  b = 0;
  b === 0 && (b = a.mode, (b & 2) === 0 ? b = 1 : (b & 4) === 0 ? b = eg() === 99 ? 1 : 2 : (Gj === 0 && (Gj = tj), b = Yc(62914560 & ~Gj), b === 0 && (b = 4194304)));
  c = Hg();
  a = Kj(a, b);
  a !== null && ($c(a, b, c), Mj(a, c));
}
var ck;
ck = function(a, b, c) {
  var d = b.lanes;
  if (a !== null)
    if (a.memoizedProps !== b.pendingProps || N.current)
      ug = true;
    else if ((c & d) !== 0)
      ug = (a.flags & 16384) !== 0 ? true : false;
    else {
      ug = false;
      switch (b.tag) {
        case 3:
          ri(b);
          sh();
          break;
        case 5:
          gh(b);
          break;
        case 1:
          Ff(b.type) && Jf(b);
          break;
        case 4:
          eh(b, b.stateNode.containerInfo);
          break;
        case 10:
          d = b.memoizedProps.value;
          var e = b.type._context;
          I(mg, e._currentValue);
          e._currentValue = d;
          break;
        case 13:
          if (b.memoizedState !== null) {
            if ((c & b.child.childLanes) !== 0)
              return ti(a, b, c);
            I(P, P.current & 1);
            b = hi(a, b, c);
            return b !== null ? b.sibling : null;
          }
          I(P, P.current & 1);
          break;
        case 19:
          d = (c & b.childLanes) !== 0;
          if ((a.flags & 64) !== 0) {
            if (d)
              return Ai(a, b, c);
            b.flags |= 64;
          }
          e = b.memoizedState;
          e !== null && (e.rendering = null, e.tail = null, e.lastEffect = null);
          I(P, P.current);
          if (d)
            break;
          else
            return null;
        case 23:
        case 24:
          return b.lanes = 0, mi(a, b, c);
      }
      return hi(a, b, c);
    }
  else
    ug = false;
  b.lanes = 0;
  switch (b.tag) {
    case 2:
      d = b.type;
      a !== null && (a.alternate = null, b.alternate = null, b.flags |= 2);
      a = b.pendingProps;
      e = Ef(b, M.current);
      tg(b, c);
      e = Ch(null, b, d, a, e, c);
      b.flags |= 1;
      if (typeof e === "object" && e !== null && typeof e.render === "function" && e.$$typeof === void 0) {
        b.tag = 1;
        b.memoizedState = null;
        b.updateQueue = null;
        if (Ff(d)) {
          var f = true;
          Jf(b);
        } else
          f = false;
        b.memoizedState = e.state !== null && e.state !== void 0 ? e.state : null;
        xg(b);
        var g = d.getDerivedStateFromProps;
        typeof g === "function" && Gg(b, d, g, a);
        e.updater = Kg;
        b.stateNode = e;
        e._reactInternals = b;
        Og(b, d, a, c);
        b = qi(null, b, d, true, f, c);
      } else
        b.tag = 0, fi(null, b, e, c), b = b.child;
      return b;
    case 16:
      e = b.elementType;
      a: {
        a !== null && (a.alternate = null, b.alternate = null, b.flags |= 2);
        a = b.pendingProps;
        f = e._init;
        e = f(e._payload);
        b.type = e;
        f = b.tag = hk(e);
        a = lg(e, a);
        switch (f) {
          case 0:
            b = li(null, b, e, a, c);
            break a;
          case 1:
            b = pi(null, b, e, a, c);
            break a;
          case 11:
            b = gi(null, b, e, a, c);
            break a;
          case 14:
            b = ii(null, b, e, lg(e.type, a), d, c);
            break a;
        }
        throw Error(y(306, e, ""));
      }
      return b;
    case 0:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : lg(d, e), li(a, b, d, e, c);
    case 1:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : lg(d, e), pi(a, b, d, e, c);
    case 3:
      ri(b);
      d = b.updateQueue;
      if (a === null || d === null)
        throw Error(y(282));
      d = b.pendingProps;
      e = b.memoizedState;
      e = e !== null ? e.element : null;
      yg(a, b);
      Cg(b, d, null, c);
      d = b.memoizedState.element;
      if (d === e)
        sh(), b = hi(a, b, c);
      else {
        e = b.stateNode;
        if (f = e.hydrate)
          kh = rf(b.stateNode.containerInfo.firstChild), jh = b, f = lh = true;
        if (f) {
          a = e.mutableSourceEagerHydrationData;
          if (a != null)
            for (e = 0; e < a.length; e += 2)
              f = a[e], f._workInProgressVersionPrimary = a[e + 1], th.push(f);
          c = Zg(b, null, d, c);
          for (b.child = c; c; )
            c.flags = c.flags & -3 | 1024, c = c.sibling;
        } else
          fi(a, b, d, c), sh();
        b = b.child;
      }
      return b;
    case 5:
      return gh(b), a === null && ph(b), d = b.type, e = b.pendingProps, f = a !== null ? a.memoizedProps : null, g = e.children, nf(d, e) ? g = null : f !== null && nf(d, f) && (b.flags |= 16), oi(a, b), fi(a, b, g, c), b.child;
    case 6:
      return a === null && ph(b), null;
    case 13:
      return ti(a, b, c);
    case 4:
      return eh(b, b.stateNode.containerInfo), d = b.pendingProps, a === null ? b.child = Yg(b, null, d, c) : fi(a, b, d, c), b.child;
    case 11:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : lg(d, e), gi(a, b, d, e, c);
    case 7:
      return fi(a, b, b.pendingProps, c), b.child;
    case 8:
      return fi(a, b, b.pendingProps.children, c), b.child;
    case 12:
      return fi(a, b, b.pendingProps.children, c), b.child;
    case 10:
      a: {
        d = b.type._context;
        e = b.pendingProps;
        g = b.memoizedProps;
        f = e.value;
        var h = b.type._context;
        I(mg, h._currentValue);
        h._currentValue = f;
        if (g !== null)
          if (h = g.value, f = He(h, f) ? 0 : (typeof d._calculateChangedBits === "function" ? d._calculateChangedBits(h, f) : 1073741823) | 0, f === 0) {
            if (g.children === e.children && !N.current) {
              b = hi(a, b, c);
              break a;
            }
          } else
            for (h = b.child, h !== null && (h.return = b); h !== null; ) {
              var k = h.dependencies;
              if (k !== null) {
                g = h.child;
                for (var l = k.firstContext; l !== null; ) {
                  if (l.context === d && (l.observedBits & f) !== 0) {
                    h.tag === 1 && (l = zg(-1, c & -c), l.tag = 2, Ag(h, l));
                    h.lanes |= c;
                    l = h.alternate;
                    l !== null && (l.lanes |= c);
                    sg(h.return, c);
                    k.lanes |= c;
                    break;
                  }
                  l = l.next;
                }
              } else
                g = h.tag === 10 ? h.type === b.type ? null : h.child : h.child;
              if (g !== null)
                g.return = h;
              else
                for (g = h; g !== null; ) {
                  if (g === b) {
                    g = null;
                    break;
                  }
                  h = g.sibling;
                  if (h !== null) {
                    h.return = g.return;
                    g = h;
                    break;
                  }
                  g = g.return;
                }
              h = g;
            }
        fi(a, b, e.children, c);
        b = b.child;
      }
      return b;
    case 9:
      return e = b.type, f = b.pendingProps, d = f.children, tg(b, c), e = vg(e, f.unstable_observedBits), d = d(e), b.flags |= 1, fi(a, b, d, c), b.child;
    case 14:
      return e = b.type, f = lg(e, b.pendingProps), f = lg(e.type, f), ii(a, b, e, f, d, c);
    case 15:
      return ki(a, b, b.type, b.pendingProps, d, c);
    case 17:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : lg(d, e), a !== null && (a.alternate = null, b.alternate = null, b.flags |= 2), b.tag = 1, Ff(d) ? (a = true, Jf(b)) : a = false, tg(b, c), Mg(b, d, e), Og(b, d, e, c), qi(null, b, d, true, a, c);
    case 19:
      return Ai(a, b, c);
    case 23:
      return mi(a, b, c);
    case 24:
      return mi(a, b, c);
  }
  throw Error(y(156, b.tag));
};
function ik(a, b, c, d) {
  this.tag = a;
  this.key = c;
  this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
  this.index = 0;
  this.ref = null;
  this.pendingProps = b;
  this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
  this.mode = d;
  this.flags = 0;
  this.lastEffect = this.firstEffect = this.nextEffect = null;
  this.childLanes = this.lanes = 0;
  this.alternate = null;
}
function nh(a, b, c, d) {
  return new ik(a, b, c, d);
}
function ji(a) {
  a = a.prototype;
  return !(!a || !a.isReactComponent);
}
function hk(a) {
  if (typeof a === "function")
    return ji(a) ? 1 : 0;
  if (a !== void 0 && a !== null) {
    a = a.$$typeof;
    if (a === Aa)
      return 11;
    if (a === Da)
      return 14;
  }
  return 2;
}
function Tg(a, b) {
  var c = a.alternate;
  c === null ? (c = nh(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.nextEffect = null, c.firstEffect = null, c.lastEffect = null);
  c.childLanes = a.childLanes;
  c.lanes = a.lanes;
  c.child = a.child;
  c.memoizedProps = a.memoizedProps;
  c.memoizedState = a.memoizedState;
  c.updateQueue = a.updateQueue;
  b = a.dependencies;
  c.dependencies = b === null ? null : {lanes: b.lanes, firstContext: b.firstContext};
  c.sibling = a.sibling;
  c.index = a.index;
  c.ref = a.ref;
  return c;
}
function Vg(a, b, c, d, e, f) {
  var g = 2;
  d = a;
  if (typeof a === "function")
    ji(a) && (g = 1);
  else if (typeof a === "string")
    g = 5;
  else
    a:
      switch (a) {
        case ua:
          return Xg(c.children, e, f, b);
        case Ha:
          g = 8;
          e |= 16;
          break;
        case wa:
          g = 8;
          e |= 1;
          break;
        case xa:
          return a = nh(12, c, b, e | 8), a.elementType = xa, a.type = xa, a.lanes = f, a;
        case Ba:
          return a = nh(13, c, b, e), a.type = Ba, a.elementType = Ba, a.lanes = f, a;
        case Ca:
          return a = nh(19, c, b, e), a.elementType = Ca, a.lanes = f, a;
        case Ia:
          return vi(c, e, f, b);
        case Ja:
          return a = nh(24, c, b, e), a.elementType = Ja, a.lanes = f, a;
        default:
          if (typeof a === "object" && a !== null)
            switch (a.$$typeof) {
              case ya:
                g = 10;
                break a;
              case za:
                g = 9;
                break a;
              case Aa:
                g = 11;
                break a;
              case Da:
                g = 14;
                break a;
              case Ea:
                g = 16;
                d = null;
                break a;
              case Fa:
                g = 22;
                break a;
            }
          throw Error(y(130, a == null ? a : typeof a, ""));
      }
  b = nh(g, c, b, e);
  b.elementType = a;
  b.type = d;
  b.lanes = f;
  return b;
}
function Xg(a, b, c, d) {
  a = nh(7, a, d, b);
  a.lanes = c;
  return a;
}
function vi(a, b, c, d) {
  a = nh(23, a, d, b);
  a.elementType = Ia;
  a.lanes = c;
  return a;
}
function Ug(a, b, c) {
  a = nh(6, a, null, b);
  a.lanes = c;
  return a;
}
function Wg(a, b, c) {
  b = nh(4, a.children !== null ? a.children : [], a.key, b);
  b.lanes = c;
  b.stateNode = {containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation};
  return b;
}
function jk(a, b, c) {
  this.tag = b;
  this.containerInfo = a;
  this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
  this.timeoutHandle = -1;
  this.pendingContext = this.context = null;
  this.hydrate = c;
  this.callbackNode = null;
  this.callbackPriority = 0;
  this.eventTimes = Zc(0);
  this.expirationTimes = Zc(-1);
  this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
  this.entanglements = Zc(0);
  this.mutableSourceEagerHydrationData = null;
}
function kk(a, b, c) {
  var d = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return {$$typeof: ta, key: d == null ? null : "" + d, children: a, containerInfo: b, implementation: c};
}
function lk(a, b, c, d) {
  var e = b.current, f = Hg(), g = Ig(e);
  a:
    if (c) {
      c = c._reactInternals;
      b: {
        if (Zb(c) !== c || c.tag !== 1)
          throw Error(y(170));
        var h = c;
        do {
          switch (h.tag) {
            case 3:
              h = h.stateNode.context;
              break b;
            case 1:
              if (Ff(h.type)) {
                h = h.stateNode.__reactInternalMemoizedMergedChildContext;
                break b;
              }
          }
          h = h.return;
        } while (h !== null);
        throw Error(y(171));
      }
      if (c.tag === 1) {
        var k = c.type;
        if (Ff(k)) {
          c = If(c, k, h);
          break a;
        }
      }
      c = h;
    } else
      c = Cf;
  b.context === null ? b.context = c : b.pendingContext = c;
  b = zg(f, g);
  b.payload = {element: a};
  d = d === void 0 ? null : d;
  d !== null && (b.callback = d);
  Ag(e, b);
  Jg(e, g, f);
  return g;
}
function mk(a) {
  a = a.current;
  if (!a.child)
    return null;
  switch (a.child.tag) {
    case 5:
      return a.child.stateNode;
    default:
      return a.child.stateNode;
  }
}
function nk(a, b) {
  a = a.memoizedState;
  if (a !== null && a.dehydrated !== null) {
    var c = a.retryLane;
    a.retryLane = c !== 0 && c < b ? c : b;
  }
}
function ok(a, b) {
  nk(a, b);
  (a = a.alternate) && nk(a, b);
}
function pk() {
  return null;
}
function qk(a, b, c) {
  var d = c != null && c.hydrationOptions != null && c.hydrationOptions.mutableSources || null;
  c = new jk(a, b, c != null && c.hydrate === true);
  b = nh(3, null, null, b === 2 ? 7 : b === 1 ? 3 : 0);
  c.current = b;
  b.stateNode = c;
  xg(b);
  a[ff] = c.current;
  cf(a.nodeType === 8 ? a.parentNode : a);
  if (d)
    for (a = 0; a < d.length; a++) {
      b = d[a];
      var e = b._getVersion;
      e = e(b._source);
      c.mutableSourceEagerHydrationData == null ? c.mutableSourceEagerHydrationData = [b, e] : c.mutableSourceEagerHydrationData.push(b, e);
    }
  this._internalRoot = c;
}
qk.prototype.render = function(a) {
  lk(a, this._internalRoot, null, null);
};
qk.prototype.unmount = function() {
  var a = this._internalRoot, b = a.containerInfo;
  lk(null, a, null, function() {
    b[ff] = null;
  });
};
function rk(a) {
  return !(!a || a.nodeType !== 1 && a.nodeType !== 9 && a.nodeType !== 11 && (a.nodeType !== 8 || a.nodeValue !== " react-mount-point-unstable "));
}
function sk(a, b) {
  b || (b = a ? a.nodeType === 9 ? a.documentElement : a.firstChild : null, b = !(!b || b.nodeType !== 1 || !b.hasAttribute("data-reactroot")));
  if (!b)
    for (var c; c = a.lastChild; )
      a.removeChild(c);
  return new qk(a, 0, b ? {hydrate: true} : void 0);
}
function tk(a, b, c, d, e) {
  var f = c._reactRootContainer;
  if (f) {
    var g = f._internalRoot;
    if (typeof e === "function") {
      var h = e;
      e = function() {
        var a2 = mk(g);
        h.call(a2);
      };
    }
    lk(b, g, a, e);
  } else {
    f = c._reactRootContainer = sk(c, d);
    g = f._internalRoot;
    if (typeof e === "function") {
      var k = e;
      e = function() {
        var a2 = mk(g);
        k.call(a2);
      };
    }
    Xj(function() {
      lk(b, g, a, e);
    });
  }
  return mk(g);
}
ec = function(a) {
  if (a.tag === 13) {
    var b = Hg();
    Jg(a, 4, b);
    ok(a, 4);
  }
};
fc = function(a) {
  if (a.tag === 13) {
    var b = Hg();
    Jg(a, 67108864, b);
    ok(a, 67108864);
  }
};
gc = function(a) {
  if (a.tag === 13) {
    var b = Hg(), c = Ig(a);
    Jg(a, c, b);
    ok(a, c);
  }
};
hc = function(a, b) {
  return b();
};
yb = function(a, b, c) {
  switch (b) {
    case "input":
      ab(a, c);
      b = c.name;
      if (c.type === "radio" && b != null) {
        for (c = a; c.parentNode; )
          c = c.parentNode;
        c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
        for (b = 0; b < c.length; b++) {
          var d = c[b];
          if (d !== a && d.form === a.form) {
            var e = Db(d);
            if (!e)
              throw Error(y(90));
            Wa(d);
            ab(d, e);
          }
        }
      }
      break;
    case "textarea":
      ib(a, c);
      break;
    case "select":
      b = c.value, b != null && fb(a, !!c.multiple, b, false);
  }
};
Gb = Wj;
Hb = function(a, b, c, d, e) {
  var f = X;
  X |= 4;
  try {
    return gg(98, a.bind(null, b, c, d, e));
  } finally {
    X = f, X === 0 && (wj(), ig());
  }
};
Ib = function() {
  (X & 49) === 0 && (Vj(), Oj());
};
Jb = function(a, b) {
  var c = X;
  X |= 2;
  try {
    return a(b);
  } finally {
    X = c, X === 0 && (wj(), ig());
  }
};
function uk(a, b) {
  var c = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!rk(b))
    throw Error(y(200));
  return kk(a, b, null, c);
}
var vk = {Events: [Cb, ue, Db, Eb, Fb, Oj, {current: false}]}, wk = {findFiberByHostInstance: wc, bundleType: 0, version: "17.0.2", rendererPackageName: "react-dom"};
var xk = {bundleType: wk.bundleType, version: wk.version, rendererPackageName: wk.rendererPackageName, rendererConfig: wk.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ra.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
  a = cc(a);
  return a === null ? null : a.stateNode;
}, findFiberByHostInstance: wk.findFiberByHostInstance || pk, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null};
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined") {
  var yk = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!yk.isDisabled && yk.supportsFiber)
    try {
      Lf = yk.inject(xk), Mf = yk;
    } catch (a) {
    }
}
exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = vk;
exports.createPortal = uk;
exports.findDOMNode = function(a) {
  if (a == null)
    return null;
  if (a.nodeType === 1)
    return a;
  var b = a._reactInternals;
  if (b === void 0) {
    if (typeof a.render === "function")
      throw Error(y(188));
    throw Error(y(268, Object.keys(a)));
  }
  a = cc(b);
  a = a === null ? null : a.stateNode;
  return a;
};
exports.flushSync = function(a, b) {
  var c = X;
  if ((c & 48) !== 0)
    return a(b);
  X |= 1;
  try {
    if (a)
      return gg(99, a.bind(null, b));
  } finally {
    X = c, ig();
  }
};
exports.hydrate = function(a, b, c) {
  if (!rk(b))
    throw Error(y(200));
  return tk(null, a, b, true, c);
};
exports.render = function(a, b, c) {
  if (!rk(b))
    throw Error(y(200));
  return tk(null, a, b, false, c);
};
exports.unmountComponentAtNode = function(a) {
  if (!rk(a))
    throw Error(y(40));
  return a._reactRootContainer ? (Xj(function() {
    tk(null, null, a, false, function() {
      a._reactRootContainer = null;
      a[ff] = null;
    });
  }), true) : false;
};
exports.unstable_batchedUpdates = Wj;
exports.unstable_createPortal = function(a, b) {
  return uk(a, b, 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null);
};
exports.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
  if (!rk(c))
    throw Error(y(200));
  if (a == null || a._reactInternals === void 0)
    throw Error(y(38));
  return tk(a, b, c, false, d);
};
exports.version = "17.0.2";


/***/ }),

/***/ 7888:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

function checkDCE() {
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
    return;
  }
  if (false) {}
  try {
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    console.error(err);
  }
}
if (true) {
  checkDCE();
  module.exports = __webpack_require__(5786);
} else {}


/***/ }),

/***/ 2367:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l = __webpack_require__(6674), n = 60103, p = 60106;
exports.Fragment = 60107;
exports.StrictMode = 60108;
exports.Profiler = 60114;
var q = 60109, r = 60110, t = 60112;
exports.Suspense = 60113;
var u = 60115, v = 60116;
if (typeof Symbol === "function" && Symbol.for) {
  var w = Symbol.for;
  n = w("react.element");
  p = w("react.portal");
  exports.Fragment = w("react.fragment");
  exports.StrictMode = w("react.strict_mode");
  exports.Profiler = w("react.profiler");
  q = w("react.provider");
  r = w("react.context");
  t = w("react.forward_ref");
  exports.Suspense = w("react.suspense");
  u = w("react.memo");
  v = w("react.lazy");
}
var x = typeof Symbol === "function" && Symbol.iterator;
function y(a) {
  if (a === null || typeof a !== "object")
    return null;
  a = x && a[x] || a["@@iterator"];
  return typeof a === "function" ? a : null;
}
function z(a) {
  for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++)
    b += "&args[]=" + encodeURIComponent(arguments[c]);
  return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var A = {isMounted: function() {
  return false;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
}}, B = {};
function C(a, b, c) {
  this.props = a;
  this.context = b;
  this.refs = B;
  this.updater = c || A;
}
C.prototype.isReactComponent = {};
C.prototype.setState = function(a, b) {
  if (typeof a !== "object" && typeof a !== "function" && a != null)
    throw Error(z(85));
  this.updater.enqueueSetState(this, a, b, "setState");
};
C.prototype.forceUpdate = function(a) {
  this.updater.enqueueForceUpdate(this, a, "forceUpdate");
};
function D() {
}
D.prototype = C.prototype;
function E(a, b, c) {
  this.props = a;
  this.context = b;
  this.refs = B;
  this.updater = c || A;
}
var F = E.prototype = new D();
F.constructor = E;
l(F, C.prototype);
F.isPureReactComponent = true;
var G = {current: null}, H = Object.prototype.hasOwnProperty, I = {key: true, ref: true, __self: true, __source: true};
function J(a, b, c) {
  var e, d = {}, k = null, h = null;
  if (b != null)
    for (e in b.ref !== void 0 && (h = b.ref), b.key !== void 0 && (k = "" + b.key), b)
      H.call(b, e) && !I.hasOwnProperty(e) && (d[e] = b[e]);
  var g = arguments.length - 2;
  if (g === 1)
    d.children = c;
  else if (1 < g) {
    for (var f = Array(g), m = 0; m < g; m++)
      f[m] = arguments[m + 2];
    d.children = f;
  }
  if (a && a.defaultProps)
    for (e in g = a.defaultProps, g)
      d[e] === void 0 && (d[e] = g[e]);
  return {$$typeof: n, type: a, key: k, ref: h, props: d, _owner: G.current};
}
function K(a, b) {
  return {$$typeof: n, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner};
}
function L(a) {
  return typeof a === "object" && a !== null && a.$$typeof === n;
}
function escape(a) {
  var b = {"=": "=0", ":": "=2"};
  return "$" + a.replace(/[=:]/g, function(a2) {
    return b[a2];
  });
}
var M = /\/+/g;
function N(a, b) {
  return typeof a === "object" && a !== null && a.key != null ? escape("" + a.key) : b.toString(36);
}
function O(a, b, c, e, d) {
  var k = typeof a;
  if (k === "undefined" || k === "boolean")
    a = null;
  var h = false;
  if (a === null)
    h = true;
  else
    switch (k) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case n:
          case p:
            h = true;
        }
    }
  if (h)
    return h = a, d = d(h), a = e === "" ? "." + N(h, 0) : e, Array.isArray(d) ? (c = "", a != null && (c = a.replace(M, "$&/") + "/"), O(d, b, c, "", function(a2) {
      return a2;
    })) : d != null && (L(d) && (d = K(d, c + (!d.key || h && h.key === d.key ? "" : ("" + d.key).replace(M, "$&/") + "/") + a)), b.push(d)), 1;
  h = 0;
  e = e === "" ? "." : e + ":";
  if (Array.isArray(a))
    for (var g = 0; g < a.length; g++) {
      k = a[g];
      var f = e + N(k, g);
      h += O(k, b, c, f, d);
    }
  else if (f = y(a), typeof f === "function")
    for (a = f.call(a), g = 0; !(k = a.next()).done; )
      k = k.value, f = e + N(k, g++), h += O(k, b, c, f, d);
  else if (k === "object")
    throw b = "" + a, Error(z(31, b === "[object Object]" ? "object with keys {" + Object.keys(a).join(", ") + "}" : b));
  return h;
}
function P(a, b, c) {
  if (a == null)
    return a;
  var e = [], d = 0;
  O(a, e, "", "", function(a2) {
    return b.call(c, a2, d++);
  });
  return e;
}
function Q(a) {
  if (a._status === -1) {
    var b = a._result;
    b = b();
    a._status = 0;
    a._result = b;
    b.then(function(b2) {
      a._status === 0 && (b2 = b2.default, a._status = 1, a._result = b2);
    }, function(b2) {
      a._status === 0 && (a._status = 2, a._result = b2);
    });
  }
  if (a._status === 1)
    return a._result;
  throw a._result;
}
var R = {current: null};
function S() {
  var a = R.current;
  if (a === null)
    throw Error(z(321));
  return a;
}
var T = {ReactCurrentDispatcher: R, ReactCurrentBatchConfig: {transition: 0}, ReactCurrentOwner: G, IsSomeRendererActing: {current: false}, assign: l};
exports.Children = {map: P, forEach: function(a, b, c) {
  P(a, function() {
    b.apply(this, arguments);
  }, c);
}, count: function(a) {
  var b = 0;
  P(a, function() {
    b++;
  });
  return b;
}, toArray: function(a) {
  return P(a, function(a2) {
    return a2;
  }) || [];
}, only: function(a) {
  if (!L(a))
    throw Error(z(143));
  return a;
}};
exports.Component = C;
exports.PureComponent = E;
exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = T;
exports.cloneElement = function(a, b, c) {
  if (a === null || a === void 0)
    throw Error(z(267, a));
  var e = l({}, a.props), d = a.key, k = a.ref, h = a._owner;
  if (b != null) {
    b.ref !== void 0 && (k = b.ref, h = G.current);
    b.key !== void 0 && (d = "" + b.key);
    if (a.type && a.type.defaultProps)
      var g = a.type.defaultProps;
    for (f in b)
      H.call(b, f) && !I.hasOwnProperty(f) && (e[f] = b[f] === void 0 && g !== void 0 ? g[f] : b[f]);
  }
  var f = arguments.length - 2;
  if (f === 1)
    e.children = c;
  else if (1 < f) {
    g = Array(f);
    for (var m = 0; m < f; m++)
      g[m] = arguments[m + 2];
    e.children = g;
  }
  return {
    $$typeof: n,
    type: a.type,
    key: d,
    ref: k,
    props: e,
    _owner: h
  };
};
exports.createContext = function(a, b) {
  b === void 0 && (b = null);
  a = {$$typeof: r, _calculateChangedBits: b, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null};
  a.Provider = {$$typeof: q, _context: a};
  return a.Consumer = a;
};
exports.createElement = J;
exports.createFactory = function(a) {
  var b = J.bind(null, a);
  b.type = a;
  return b;
};
exports.createRef = function() {
  return {current: null};
};
exports.forwardRef = function(a) {
  return {$$typeof: t, render: a};
};
exports.isValidElement = L;
exports.lazy = function(a) {
  return {$$typeof: v, _payload: {_status: -1, _result: a}, _init: Q};
};
exports.memo = function(a, b) {
  return {$$typeof: u, type: a, compare: b === void 0 ? null : b};
};
exports.useCallback = function(a, b) {
  return S().useCallback(a, b);
};
exports.useContext = function(a, b) {
  return S().useContext(a, b);
};
exports.useDebugValue = function() {
};
exports.useEffect = function(a, b) {
  return S().useEffect(a, b);
};
exports.useImperativeHandle = function(a, b, c) {
  return S().useImperativeHandle(a, b, c);
};
exports.useLayoutEffect = function(a, b) {
  return S().useLayoutEffect(a, b);
};
exports.useMemo = function(a, b) {
  return S().useMemo(a, b);
};
exports.useReducer = function(a, b, c) {
  return S().useReducer(a, b, c);
};
exports.useRef = function(a) {
  return S().useRef(a);
};
exports.useState = function(a) {
  return S().useState(a);
};
exports.version = "17.0.2";


/***/ }),

/***/ 4339:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (true) {
  module.exports = __webpack_require__(2367);
} else {}


/***/ }),

/***/ 7684:
/***/ ((module) => {

var runtime = function(exports) {
  "use strict";
  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined;
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }
  function wrap(innerFn, outerFn, self, tryLocsList) {
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);
    generator._invoke = makeInvokeMethod(innerFn, self, context);
    return generator;
  }
  exports.wrap = wrap;
  function tryCatch(fn, obj, arg) {
    try {
      return {type: "normal", arg: fn.call(obj, arg)};
    } catch (err) {
      return {type: "throw", arg: err};
    }
  }
  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";
  var ContinueSentinel = {};
  function Generator() {
  }
  function GeneratorFunction() {
  }
  function GeneratorFunctionPrototype() {
  }
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function() {
    return this;
  };
  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    IteratorPrototype = NativeIteratorPrototype;
  }
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction");
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }
  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor ? ctor === GeneratorFunction || (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
  };
  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };
  exports.awrap = function(arg) {
    return {__await: arg};
  };
  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value2) {
            invoke("next", value2, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }
        return PromiseImpl.resolve(value).then(function(unwrapped) {
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          return invoke("throw", error, resolve, reject);
        });
      }
    }
    var previousPromise;
    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }
      return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    }
    this._invoke = enqueue;
  }
  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function() {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0)
      PromiseImpl = Promise;
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
      return result.done ? result.value : iter.next();
    });
  };
  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;
    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }
      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }
        return doneResult();
      }
      context.method = method;
      context.arg = arg;
      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel)
              continue;
            return delegateResult;
          }
        }
        if (context.method === "next") {
          context.sent = context._sent = context.arg;
        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }
          context.dispatchException(context.arg);
        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }
        state = GenStateExecuting;
        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          state = context.done ? GenStateCompleted : GenStateSuspendedYield;
          if (record.arg === ContinueSentinel) {
            continue;
          }
          return {
            value: record.arg,
            done: context.done
          };
        } else if (record.type === "throw") {
          state = GenStateCompleted;
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      context.delegate = null;
      if (context.method === "throw") {
        if (delegate.iterator["return"]) {
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);
          if (context.method === "throw") {
            return ContinueSentinel;
          }
        }
        context.method = "throw";
        context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }
      return ContinueSentinel;
    }
    var record = tryCatch(method, delegate.iterator, context.arg);
    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }
    var info = record.arg;
    if (!info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }
    if (info.done) {
      context[delegate.resultName] = info.value;
      context.next = delegate.nextLoc;
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }
    } else {
      return info;
    }
    context.delegate = null;
    return ContinueSentinel;
  }
  defineIteratorMethods(Gp);
  define(Gp, toStringTagSymbol, "Generator");
  Gp[iteratorSymbol] = function() {
    return this;
  };
  Gp.toString = function() {
    return "[object Generator]";
  };
  function pushTryEntry(locs) {
    var entry = {tryLoc: locs[0]};
    if (1 in locs) {
      entry.catchLoc = locs[1];
    }
    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }
    this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }
  function Context(tryLocsList) {
    this.tryEntries = [{tryLoc: "root"}];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }
  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();
    return function next() {
      while (keys.length) {
        var key2 = keys.pop();
        if (key2 in object) {
          next.value = key2;
          next.done = false;
          return next;
        }
      }
      next.done = true;
      return next;
    };
  };
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }
      if (typeof iterable.next === "function") {
        return iterable;
      }
      if (!isNaN(iterable.length)) {
        var i = -1, next = function next2() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next2.value = iterable[i];
              next2.done = false;
              return next2;
            }
          }
          next2.value = undefined;
          next2.done = true;
          return next2;
        };
        return next.next = next;
      }
    }
    return {next: doneResult};
  }
  exports.values = values;
  function doneResult() {
    return {value: undefined, done: true};
  }
  Context.prototype = {
    constructor: Context,
    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;
      this.method = "next";
      this.arg = undefined;
      this.tryEntries.forEach(resetTryEntry);
      if (!skipTempReset) {
        for (var name in this) {
          if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },
    stop: function() {
      this.done = true;
      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }
      return this.rval;
    },
    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }
      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        if (caught) {
          context.method = "next";
          context.arg = undefined;
        }
        return !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;
        if (entry.tryLoc === "root") {
          return handle("end");
        }
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }
          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },
    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
        finallyEntry = null;
      }
      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;
      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }
      return this.complete(record);
    },
    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }
      if (record.type === "break" || record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
      return ContinueSentinel;
    },
    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },
    catch: function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }
      throw new Error("illegal catch attempt");
    },
    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName,
        nextLoc
      };
      if (this.method === "next") {
        this.arg = undefined;
      }
      return ContinueSentinel;
    }
  };
  return exports;
}( true ? module.exports : 0);
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  Function("r", "regeneratorRuntime = r")(runtime);
}


/***/ }),

/***/ 2947:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

/** @license React v0.20.2
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f, g, h, k;
if (typeof performance === "object" && typeof performance.now === "function") {
  var l = performance;
  exports.unstable_now = function() {
    return l.now();
  };
} else {
  var p = Date, q = p.now();
  exports.unstable_now = function() {
    return p.now() - q;
  };
}
if (typeof window === "undefined" || typeof MessageChannel !== "function") {
  var t = null, u = null, w = function() {
    if (t !== null)
      try {
        var a = exports.unstable_now();
        t(true, a);
        t = null;
      } catch (b) {
        throw setTimeout(w, 0), b;
      }
  };
  f = function(a) {
    t !== null ? setTimeout(f, 0, a) : (t = a, setTimeout(w, 0));
  };
  g = function(a, b) {
    u = setTimeout(a, b);
  };
  h = function() {
    clearTimeout(u);
  };
  exports.unstable_shouldYield = function() {
    return false;
  };
  k = exports.unstable_forceFrameRate = function() {
  };
} else {
  var x = window.setTimeout, y = window.clearTimeout;
  if (typeof console !== "undefined") {
    var z = window.cancelAnimationFrame;
    typeof window.requestAnimationFrame !== "function" && console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");
    typeof z !== "function" && console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");
  }
  var A = false, B = null, C = -1, D = 5, E = 0;
  exports.unstable_shouldYield = function() {
    return exports.unstable_now() >= E;
  };
  k = function() {
  };
  exports.unstable_forceFrameRate = function(a) {
    0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : D = 0 < a ? Math.floor(1e3 / a) : 5;
  };
  var F = new MessageChannel(), G = F.port2;
  F.port1.onmessage = function() {
    if (B !== null) {
      var a = exports.unstable_now();
      E = a + D;
      try {
        B(true, a) ? G.postMessage(null) : (A = false, B = null);
      } catch (b) {
        throw G.postMessage(null), b;
      }
    } else
      A = false;
  };
  f = function(a) {
    B = a;
    A || (A = true, G.postMessage(null));
  };
  g = function(a, b) {
    C = x(function() {
      a(exports.unstable_now());
    }, b);
  };
  h = function() {
    y(C);
    C = -1;
  };
}
function H(a, b) {
  var c = a.length;
  a.push(b);
  a:
    for (; ; ) {
      var d = c - 1 >>> 1, e = a[d];
      if (e !== void 0 && 0 < I(e, b))
        a[d] = b, a[c] = e, c = d;
      else
        break a;
    }
}
function J(a) {
  a = a[0];
  return a === void 0 ? null : a;
}
function K(a) {
  var b = a[0];
  if (b !== void 0) {
    var c = a.pop();
    if (c !== b) {
      a[0] = c;
      a:
        for (var d = 0, e = a.length; d < e; ) {
          var m = 2 * (d + 1) - 1, n = a[m], v = m + 1, r = a[v];
          if (n !== void 0 && 0 > I(n, c))
            r !== void 0 && 0 > I(r, n) ? (a[d] = r, a[v] = c, d = v) : (a[d] = n, a[m] = c, d = m);
          else if (r !== void 0 && 0 > I(r, c))
            a[d] = r, a[v] = c, d = v;
          else
            break a;
        }
    }
    return b;
  }
  return null;
}
function I(a, b) {
  var c = a.sortIndex - b.sortIndex;
  return c !== 0 ? c : a.id - b.id;
}
var L = [], M = [], N = 1, O = null, P = 3, Q = false, R = false, S = false;
function T(a) {
  for (var b = J(M); b !== null; ) {
    if (b.callback === null)
      K(M);
    else if (b.startTime <= a)
      K(M), b.sortIndex = b.expirationTime, H(L, b);
    else
      break;
    b = J(M);
  }
}
function U(a) {
  S = false;
  T(a);
  if (!R)
    if (J(L) !== null)
      R = true, f(V);
    else {
      var b = J(M);
      b !== null && g(U, b.startTime - a);
    }
}
function V(a, b) {
  R = false;
  S && (S = false, h());
  Q = true;
  var c = P;
  try {
    T(b);
    for (O = J(L); O !== null && (!(O.expirationTime > b) || a && !exports.unstable_shouldYield()); ) {
      var d = O.callback;
      if (typeof d === "function") {
        O.callback = null;
        P = O.priorityLevel;
        var e = d(O.expirationTime <= b);
        b = exports.unstable_now();
        typeof e === "function" ? O.callback = e : O === J(L) && K(L);
        T(b);
      } else
        K(L);
      O = J(L);
    }
    if (O !== null)
      var m = true;
    else {
      var n = J(M);
      n !== null && g(U, n.startTime - b);
      m = false;
    }
    return m;
  } finally {
    O = null, P = c, Q = false;
  }
}
var W = k;
exports.unstable_IdlePriority = 5;
exports.unstable_ImmediatePriority = 1;
exports.unstable_LowPriority = 4;
exports.unstable_NormalPriority = 3;
exports.unstable_Profiling = null;
exports.unstable_UserBlockingPriority = 2;
exports.unstable_cancelCallback = function(a) {
  a.callback = null;
};
exports.unstable_continueExecution = function() {
  R || Q || (R = true, f(V));
};
exports.unstable_getCurrentPriorityLevel = function() {
  return P;
};
exports.unstable_getFirstCallbackNode = function() {
  return J(L);
};
exports.unstable_next = function(a) {
  switch (P) {
    case 1:
    case 2:
    case 3:
      var b = 3;
      break;
    default:
      b = P;
  }
  var c = P;
  P = b;
  try {
    return a();
  } finally {
    P = c;
  }
};
exports.unstable_pauseExecution = function() {
};
exports.unstable_requestPaint = W;
exports.unstable_runWithPriority = function(a, b) {
  switch (a) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
      break;
    default:
      a = 3;
  }
  var c = P;
  P = a;
  try {
    return b();
  } finally {
    P = c;
  }
};
exports.unstable_scheduleCallback = function(a, b, c) {
  var d = exports.unstable_now();
  typeof c === "object" && c !== null ? (c = c.delay, c = typeof c === "number" && 0 < c ? d + c : d) : c = d;
  switch (a) {
    case 1:
      var e = -1;
      break;
    case 2:
      e = 250;
      break;
    case 5:
      e = 1073741823;
      break;
    case 4:
      e = 1e4;
      break;
    default:
      e = 5e3;
  }
  e = c + e;
  a = {id: N++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1};
  c > d ? (a.sortIndex = c, H(M, a), J(L) === null && a === J(M) && (S ? h() : S = true, g(U, c - d))) : (a.sortIndex = e, H(L, a), R || Q || (R = true, f(V)));
  return a;
};
exports.unstable_wrapCallback = function(a) {
  var b = P;
  return function() {
    var c = P;
    P = b;
    try {
      return a.apply(this, arguments);
    } finally {
      P = c;
    }
  };
};


/***/ }),

/***/ 6762:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (true) {
  module.exports = __webpack_require__(2947);
} else {}


/***/ }),

/***/ 9930:
/***/ (function(module) {

/**
 * what-input - A global utility for tracking the current input method (mouse, keyboard or touch).
 * @version v5.2.10
 * @link https://github.com/ten1seven/what-input
 * @license MIT
 */
(function webpackUniversalModuleDefinition(root, factory) {
  if (true)
    module.exports = factory();
  else {}
})(this, function() {
  return function(modules) {
    var installedModules = {};
    function __nested_webpack_require_648__(moduleId) {
      if (installedModules[moduleId])
        return installedModules[moduleId].exports;
      var module2 = installedModules[moduleId] = {
        exports: {},
        id: moduleId,
        loaded: false
      };
      modules[moduleId].call(module2.exports, module2, module2.exports, __nested_webpack_require_648__);
      module2.loaded = true;
      return module2.exports;
    }
    __nested_webpack_require_648__.m = modules;
    __nested_webpack_require_648__.c = installedModules;
    __nested_webpack_require_648__.p = "";
    return __nested_webpack_require_648__(0);
  }([
    function(module2, exports2) {
      "use strict";
      module2.exports = function() {
        if (typeof document === "undefined" || typeof window === "undefined") {
          return {
            ask: function ask() {
              return "initial";
            },
            element: function element() {
              return null;
            },
            ignoreKeys: function ignoreKeys() {
            },
            specificKeys: function specificKeys() {
            },
            registerOnChange: function registerOnChange() {
            },
            unRegisterOnChange: function unRegisterOnChange() {
            }
          };
        }
        var docElem = document.documentElement;
        var currentElement = null;
        var currentInput = "initial";
        var currentIntent = currentInput;
        var currentTimestamp = Date.now();
        var shouldPersist = "false";
        var formInputs = ["button", "input", "select", "textarea"];
        var functionList = [];
        var ignoreMap = [
          16,
          17,
          18,
          91,
          93
        ];
        var specificMap = [];
        var inputMap = {
          keydown: "keyboard",
          keyup: "keyboard",
          mousedown: "mouse",
          mousemove: "mouse",
          MSPointerDown: "pointer",
          MSPointerMove: "pointer",
          pointerdown: "pointer",
          pointermove: "pointer",
          touchstart: "touch",
          touchend: "touch"
        };
        var isScrolling = false;
        var mousePos = {
          x: null,
          y: null
        };
        var pointerMap = {
          2: "touch",
          3: "touch",
          4: "mouse"
        };
        var supportsPassive = false;
        try {
          var opts = Object.defineProperty({}, "passive", {
            get: function get() {
              supportsPassive = true;
            }
          });
          window.addEventListener("test", null, opts);
        } catch (e) {
        }
        var setUp = function setUp2() {
          inputMap[detectWheel()] = "mouse";
          addListeners();
        };
        var addListeners = function addListeners2() {
          var options = supportsPassive ? {passive: true} : false;
          document.addEventListener("DOMContentLoaded", setPersist);
          if (window.PointerEvent) {
            window.addEventListener("pointerdown", setInput);
            window.addEventListener("pointermove", setIntent);
          } else if (window.MSPointerEvent) {
            window.addEventListener("MSPointerDown", setInput);
            window.addEventListener("MSPointerMove", setIntent);
          } else {
            window.addEventListener("mousedown", setInput);
            window.addEventListener("mousemove", setIntent);
            if ("ontouchstart" in window) {
              window.addEventListener("touchstart", setInput, options);
              window.addEventListener("touchend", setInput);
            }
          }
          window.addEventListener(detectWheel(), setIntent, options);
          window.addEventListener("keydown", setInput);
          window.addEventListener("keyup", setInput);
          window.addEventListener("focusin", setElement);
          window.addEventListener("focusout", clearElement);
        };
        var setPersist = function setPersist2() {
          shouldPersist = !(docElem.getAttribute("data-whatpersist") || document.body.getAttribute("data-whatpersist") === "false");
          if (shouldPersist) {
            try {
              if (window.sessionStorage.getItem("what-input")) {
                currentInput = window.sessionStorage.getItem("what-input");
              }
              if (window.sessionStorage.getItem("what-intent")) {
                currentIntent = window.sessionStorage.getItem("what-intent");
              }
            } catch (e) {
            }
          }
          doUpdate("input");
          doUpdate("intent");
        };
        var setInput = function setInput2(event) {
          var eventKey = event.which;
          var value = inputMap[event.type];
          if (value === "pointer") {
            value = pointerType(event);
          }
          var ignoreMatch = !specificMap.length && ignoreMap.indexOf(eventKey) === -1;
          var specificMatch = specificMap.length && specificMap.indexOf(eventKey) !== -1;
          var shouldUpdate = value === "keyboard" && eventKey && (ignoreMatch || specificMatch) || value === "mouse" || value === "touch";
          if (validateTouch(value)) {
            shouldUpdate = false;
          }
          if (shouldUpdate && currentInput !== value) {
            currentInput = value;
            persistInput("input", currentInput);
            doUpdate("input");
          }
          if (shouldUpdate && currentIntent !== value) {
            var activeElem = document.activeElement;
            var notFormInput = activeElem && activeElem.nodeName && (formInputs.indexOf(activeElem.nodeName.toLowerCase()) === -1 || activeElem.nodeName.toLowerCase() === "button" && !checkClosest(activeElem, "form"));
            if (notFormInput) {
              currentIntent = value;
              persistInput("intent", currentIntent);
              doUpdate("intent");
            }
          }
        };
        var doUpdate = function doUpdate2(which) {
          docElem.setAttribute("data-what" + which, which === "input" ? currentInput : currentIntent);
          fireFunctions(which);
        };
        var setIntent = function setIntent2(event) {
          var value = inputMap[event.type];
          if (value === "pointer") {
            value = pointerType(event);
          }
          detectScrolling(event);
          if ((!isScrolling && !validateTouch(value) || isScrolling && event.type === "wheel" || event.type === "mousewheel" || event.type === "DOMMouseScroll") && currentIntent !== value) {
            currentIntent = value;
            persistInput("intent", currentIntent);
            doUpdate("intent");
          }
        };
        var setElement = function setElement2(event) {
          if (!event.target.nodeName) {
            clearElement();
            return;
          }
          currentElement = event.target.nodeName.toLowerCase();
          docElem.setAttribute("data-whatelement", currentElement);
          if (event.target.classList && event.target.classList.length) {
            docElem.setAttribute("data-whatclasses", event.target.classList.toString().replace(" ", ","));
          }
        };
        var clearElement = function clearElement2() {
          currentElement = null;
          docElem.removeAttribute("data-whatelement");
          docElem.removeAttribute("data-whatclasses");
        };
        var persistInput = function persistInput2(which, value) {
          if (shouldPersist) {
            try {
              window.sessionStorage.setItem("what-" + which, value);
            } catch (e) {
            }
          }
        };
        var pointerType = function pointerType2(event) {
          if (typeof event.pointerType === "number") {
            return pointerMap[event.pointerType];
          } else {
            return event.pointerType === "pen" ? "touch" : event.pointerType;
          }
        };
        var validateTouch = function validateTouch2(value) {
          var timestamp = Date.now();
          var touchIsValid = value === "mouse" && currentInput === "touch" && timestamp - currentTimestamp < 200;
          currentTimestamp = timestamp;
          return touchIsValid;
        };
        var detectWheel = function detectWheel2() {
          var wheelType = null;
          if ("onwheel" in document.createElement("div")) {
            wheelType = "wheel";
          } else {
            wheelType = document.onmousewheel !== void 0 ? "mousewheel" : "DOMMouseScroll";
          }
          return wheelType;
        };
        var fireFunctions = function fireFunctions2(type) {
          for (var i = 0, len = functionList.length; i < len; i++) {
            if (functionList[i].type === type) {
              functionList[i].fn.call(void 0, type === "input" ? currentInput : currentIntent);
            }
          }
        };
        var objPos = function objPos2(match) {
          for (var i = 0, len = functionList.length; i < len; i++) {
            if (functionList[i].fn === match) {
              return i;
            }
          }
        };
        var detectScrolling = function detectScrolling2(event) {
          if (mousePos.x !== event.screenX || mousePos.y !== event.screenY) {
            isScrolling = false;
            mousePos.x = event.screenX;
            mousePos.y = event.screenY;
          } else {
            isScrolling = true;
          }
        };
        var checkClosest = function checkClosest2(elem, tag) {
          var ElementPrototype = window.Element.prototype;
          if (!ElementPrototype.matches) {
            ElementPrototype.matches = ElementPrototype.msMatchesSelector || ElementPrototype.webkitMatchesSelector;
          }
          if (!ElementPrototype.closest) {
            do {
              if (elem.matches(tag)) {
                return elem;
              }
              elem = elem.parentElement || elem.parentNode;
            } while (elem !== null && elem.nodeType === 1);
            return null;
          } else {
            return elem.closest(tag);
          }
        };
        if ("addEventListener" in window && Array.prototype.indexOf) {
          setUp();
        }
        return {
          ask: function ask(opt) {
            return opt === "intent" ? currentIntent : currentInput;
          },
          element: function element() {
            return currentElement;
          },
          ignoreKeys: function ignoreKeys(arr) {
            ignoreMap = arr;
          },
          specificKeys: function specificKeys(arr) {
            specificMap = arr;
          },
          registerOnChange: function registerOnChange(fn, eventType) {
            functionList.push({
              fn,
              type: eventType || "input"
            });
          },
          unRegisterOnChange: function unRegisterOnChange(fn) {
            var position = objPos(fn);
            if (position || position === 0) {
              functionList.splice(position, 1);
            }
          },
          clearStorage: function clearStorage() {
            window.sessionStorage.clear();
          }
        };
      }();
    }
  ]);
});
;


/***/ }),

/***/ 2742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);

function create$1(createState) {
  let state;
  const listeners = new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (nextState !== state) {
      const previousState = state;
      state = replace ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const subscribeWithSelector = (listener, selector = getState, equalityFn = Object.is) => {
    let currentSlice = selector(state);
    function listenerToAdd() {
      const nextSlice = selector(state);
      if (!equalityFn(currentSlice, nextSlice)) {
        const previousSlice = currentSlice;
        listener(currentSlice = nextSlice, previousSlice);
      }
    }
    listeners.add(listenerToAdd);
    return () => listeners.delete(listenerToAdd);
  };
  const subscribe = (listener, selector, equalityFn) => {
    if (selector || equalityFn) {
      return subscribeWithSelector(listener, selector, equalityFn);
    }
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const destroy = () => listeners.clear();
  const api = {
    setState,
    getState,
    subscribe,
    destroy
  };
  state = createState(setState, getState, api);
  return api;
}
const useIsoLayoutEffect = typeof window === "undefined" ? react__WEBPACK_IMPORTED_MODULE_0__.useEffect : react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect;
function create(createState) {
  const api = typeof createState === "function" ? create$1(createState) : createState;
  const useStore = (selector = api.getState, equalityFn = Object.is) => {
    const [, forceUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useReducer)((c) => c + 1, 0);
    const state = api.getState();
    const stateRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(state);
    const selectorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(selector);
    const equalityFnRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(equalityFn);
    const erroredRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    const currentSliceRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    if (currentSliceRef.current === void 0) {
      currentSliceRef.current = selector(state);
    }
    let newStateSlice;
    let hasNewStateSlice = false;
    if (stateRef.current !== state || selectorRef.current !== selector || equalityFnRef.current !== equalityFn || erroredRef.current) {
      newStateSlice = selector(state);
      hasNewStateSlice = !equalityFn(currentSliceRef.current, newStateSlice);
    }
    useIsoLayoutEffect(() => {
      if (hasNewStateSlice) {
        currentSliceRef.current = newStateSlice;
      }
      stateRef.current = state;
      selectorRef.current = selector;
      equalityFnRef.current = equalityFn;
      erroredRef.current = false;
    });
    const stateBeforeSubscriptionRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(state);
    useIsoLayoutEffect(() => {
      const listener = () => {
        try {
          const nextState = api.getState();
          const nextStateSlice = selectorRef.current(nextState);
          if (!equalityFnRef.current(currentSliceRef.current, nextStateSlice)) {
            stateRef.current = nextState;
            currentSliceRef.current = nextStateSlice;
            forceUpdate();
          }
        } catch (error) {
          erroredRef.current = true;
          forceUpdate();
        }
      };
      const unsubscribe = api.subscribe(listener);
      if (api.getState() !== stateBeforeSubscriptionRef.current) {
        listener();
      }
      return unsubscribe;
    }, []);
    return hasNewStateSlice ? newStateSlice : currentSliceRef.current;
  };
  Object.assign(useStore, api);
  useStore[Symbol.iterator] = function* () {
    console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
    yield useStore;
    yield api;
  };
  return useStore;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (create);


/***/ }),

/***/ 1818:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;

__webpack_unused_export__ = ({value: true});
var _asyncToGenerator = __webpack_require__(1327);
var _extends = __webpack_require__(2186);
var _regeneratorRuntime = __webpack_require__(9096);
function _interopDefaultLegacy(e) {
  return e && typeof e === "object" && "default" in e ? e : {default: e};
}
var _asyncToGenerator__default = /* @__PURE__ */ _interopDefaultLegacy(_asyncToGenerator);
var _extends__default = /* @__PURE__ */ _interopDefaultLegacy(_extends);
var _regeneratorRuntime__default = /* @__PURE__ */ _interopDefaultLegacy(_regeneratorRuntime);
var redux = function redux2(reducer, initial) {
  return function(set, get, api) {
    api.dispatch = function(action) {
      set(function(state) {
        return reducer(state, action);
      });
      if (api.devtools) {
        api.devtools.send(api.devtools.prefix + action.type, get());
      }
      return action;
    };
    return _extends__default["default"]({
      dispatch: api.dispatch
    }, initial);
  };
};
var devtools = function devtools2(fn, prefix) {
  return function(set, get, api) {
    var extension;
    try {
      extension = window.__REDUX_DEVTOOLS_EXTENSION__ || window.top.__REDUX_DEVTOOLS_EXTENSION__;
    } catch (_unused) {
    }
    if (!extension) {
      if (false) {}
      api.devtools = null;
      return fn(set, get, api);
    }
    var namedSet = function namedSet2(state, replace, name) {
      set(state, replace);
      if (!api.dispatch) {
        api.devtools.send(api.devtools.prefix + (name || "action"), get());
      }
    };
    var initialState = fn(namedSet, get, api);
    if (!api.devtools) {
      var savedSetState = api.setState;
      api.setState = function(state, replace) {
        savedSetState(state, replace);
        api.devtools.send(api.devtools.prefix + "setState", api.getState());
      };
      api.devtools = extension.connect({
        name: prefix
      });
      api.devtools.prefix = prefix ? prefix + " > " : "";
      api.devtools.subscribe(function(message) {
        var _message$payload;
        if (message.type === "DISPATCH" && message.state) {
          var ignoreState = message.payload.type === "JUMP_TO_ACTION" || message.payload.type === "JUMP_TO_STATE";
          if (!api.dispatch && !ignoreState) {
            api.setState(JSON.parse(message.state));
          } else {
            savedSetState(JSON.parse(message.state));
          }
        } else if (message.type === "DISPATCH" && ((_message$payload = message.payload) == null ? void 0 : _message$payload.type) === "COMMIT") {
          api.devtools.init(api.getState());
        }
      });
      api.devtools.init(initialState);
    }
    return initialState;
  };
};
var combine = function combine2(initialState, create) {
  return function(set, get, api) {
    return Object.assign({}, initialState, create(set, get, api));
  };
};
var persist = function persist2(config, options) {
  return function(set, get, api) {
    var _ref = options || {}, name = _ref.name, _ref$getStorage = _ref.getStorage, getStorage = _ref$getStorage === void 0 ? function() {
      return localStorage;
    } : _ref$getStorage, _ref$serialize = _ref.serialize, serialize = _ref$serialize === void 0 ? JSON.stringify : _ref$serialize, _ref$deserialize = _ref.deserialize, deserialize = _ref$deserialize === void 0 ? JSON.parse : _ref$deserialize, blacklist = _ref.blacklist, whitelist = _ref.whitelist, onRehydrateStorage = _ref.onRehydrateStorage, _ref$version = _ref.version, version = _ref$version === void 0 ? 0 : _ref$version, migrate = _ref.migrate;
    var storage;
    try {
      storage = getStorage();
    } catch (e) {
    }
    if (!storage) {
      return config(function() {
        console.warn("Persist middleware: unable to update " + name + ", the given storage is currently unavailable.");
        set.apply(void 0, arguments);
      }, get, api);
    }
    var setItem = /* @__PURE__ */ function() {
      var _ref2 = _asyncToGenerator__default["default"](/* @__PURE__ */ _regeneratorRuntime__default["default"].mark(function _callee() {
        var _storage;
        var state;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                state = _extends__default["default"]({}, get());
                if (whitelist) {
                  Object.keys(state).forEach(function(key) {
                    !whitelist.includes(key) && delete state[key];
                  });
                }
                if (blacklist) {
                  blacklist.forEach(function(key) {
                    return delete state[key];
                  });
                }
                if (!((_storage = storage) == null)) {
                  _context.next = 7;
                  break;
                }
                _context.t0 = void 0;
                _context.next = 13;
                break;
              case 7:
                _context.t1 = _storage;
                _context.t2 = name;
                _context.next = 11;
                return serialize({
                  state,
                  version
                });
              case 11:
                _context.t3 = _context.sent;
                _context.t0 = _context.t1.setItem.call(_context.t1, _context.t2, _context.t3);
              case 13:
                return _context.abrupt("return", _context.t0);
              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
      return function setItem2() {
        return _ref2.apply(this, arguments);
      };
    }();
    var savedSetState = api.setState;
    api.setState = function(state, replace) {
      savedSetState(state, replace);
      setItem();
    };
    _asyncToGenerator__default["default"](/* @__PURE__ */ _regeneratorRuntime__default["default"].mark(function _callee2() {
      var postRehydrationCallback, storageValue, deserializedStorageValue, migratedState;
      return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              postRehydrationCallback = (onRehydrateStorage == null ? void 0 : onRehydrateStorage(get())) || void 0;
              _context2.prev = 1;
              _context2.next = 4;
              return storage.getItem(name);
            case 4:
              storageValue = _context2.sent;
              if (!storageValue) {
                _context2.next = 20;
                break;
              }
              _context2.next = 8;
              return deserialize(storageValue);
            case 8:
              deserializedStorageValue = _context2.sent;
              if (!(deserializedStorageValue.version !== version)) {
                _context2.next = 19;
                break;
              }
              _context2.next = 12;
              return migrate == null ? void 0 : migrate(deserializedStorageValue.state, deserializedStorageValue.version);
            case 12:
              migratedState = _context2.sent;
              if (!migratedState) {
                _context2.next = 17;
                break;
              }
              set(migratedState);
              _context2.next = 17;
              return setItem();
            case 17:
              _context2.next = 20;
              break;
            case 19:
              set(deserializedStorageValue.state);
            case 20:
              _context2.next = 26;
              break;
            case 22:
              _context2.prev = 22;
              _context2.t0 = _context2["catch"](1);
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, _context2.t0);
              return _context2.abrupt("return");
            case 26:
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(get(), void 0);
            case 27:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 22]]);
    }))();
    return config(function() {
      set.apply(void 0, arguments);
      setItem();
    }, get, api);
  };
};
__webpack_unused_export__ = combine;
__webpack_unused_export__ = devtools;
exports.tJ = persist;
__webpack_unused_export__ = redux;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ./src/shared/Browser.js
var Browser = __webpack_require__(5101);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(7888);
// EXTERNAL MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js + 2 modules
var emotion_styled_browser_esm = __webpack_require__(5462);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(691);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__(8802);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/toConsumableArray.js + 3 modules
var toConsumableArray = __webpack_require__(2707);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__(6934);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(225);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(4565);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(4185);
// EXTERNAL MODULE: ../node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(395);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(6654);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(9332);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(6091);
// EXTERNAL MODULE: ../node_modules/prop-types/index.js
var prop_types = __webpack_require__(6050);
// EXTERNAL MODULE: ../node_modules/classnames/index.js
var classnames = __webpack_require__(855);
// EXTERNAL MODULE: ../node_modules/keycode/index.js
var keycode = __webpack_require__(1984);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/custom-element.js + 3 modules
var custom_element = __webpack_require__(6357);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/AlignmentHelper.js
var AlignmentHelper = __webpack_require__(2294);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/SpacingHelper.js
var SpacingHelper = __webpack_require__(3039);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/skeleton/SkeletonHelper.js
var SkeletonHelper = __webpack_require__(5818);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-label/FormLabel.js
var FormLabel = __webpack_require__(6799);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-status/FormStatus.js
var FormStatus = __webpack_require__(3427);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-row/FormRow.js
var FormRow = __webpack_require__(1530);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Context.js + 3 modules
var Context = __webpack_require__(3898);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/helpers/Suffix.js
var Suffix = __webpack_require__(8231);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/RadioGroupContext.js

var RadioGroupContext = react.createContext({});
/* harmony default export */ const radio_RadioGroupContext = (RadioGroupContext);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/RadioGroup.js









var _AlignmentHelper;

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}











var RadioGroup = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(RadioGroup2, _React$PureComponent);
  var _super = _createSuper(RadioGroup2);
  function RadioGroup2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, RadioGroup2);
    _this = _super.call(this, props);
    _this.onChangeHandler = function(_ref) {
      var value = _ref.value, event = _ref.event;
      _this.setState({
        value,
        _listenForPropChanges: false
      });
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        value,
        event
      });
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._name = props.name || _this._id;
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(RadioGroup2, [{
    key: "render",
    value: function render() {
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, RadioGroup2.defaultProps, this.context.FormRow, this.context.RadioGroup);
      var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, label_position = props.label_position, vertical = props.vertical, layout_direction = props.layout_direction, no_fieldset = props.no_fieldset, size = props.size, disabled = props.disabled, skeleton = props.skeleton, className = props.className, _className = props.class, _id = props.id, _name = props.name, _value = props.value, attributes = props.attributes, children = props.children, on_change = props.on_change, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "label_position", "vertical", "layout_direction", "no_fieldset", "size", "disabled", "skeleton", "className", "class", "id", "name", "value", "attributes", "children", "on_change", "custom_method", "custom_element"]);
      var value = this.state.value;
      var id = this._id;
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var classes = classnames("dnb-radio-group dnb-radio-group--".concat(layout_direction, " dnb-form-component"), (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-radio-group__status--".concat(status_state));
      var params = (0,esm_extends/* default */.Z)({}, rest);
      if (showStatus || suffix) {
        params["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(params, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (label) {
        params["aria-labelledby"] = id + "-label";
      }
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, params);
      var context = {
        name: this._name,
        value,
        size,
        disabled,
        label_position,
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id,
        label,
        label_id: id + "-label",
        label_direction,
        label_sr_only,
        direction: label_direction,
        vertical,
        disabled,
        skeleton,
        no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(radio_RadioGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, _AlignmentHelper || (_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(FormRow/* default */.ZP, formRowParams, react.createElement("span", (0,esm_extends/* default */.Z)({
        id,
        className: "dnb-radio-group__shell",
        role: "radiogroup"
      }, params), children, suffix && react.createElement(Suffix/* default */.Z, {
        className: "dnb-radio-group__suffix",
        id: id + "-suffix",
        context: props
      }, suffix), showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text: status,
        status: status_state,
        text_id: id + "-status",
        width_selector: id + ", " + id + "-label",
        animation: status_animation,
        skeleton
      })))));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(RadioGroup2.tagName, RadioGroup2, RadioGroup2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.value !== state._value) {
          state.value = props.value;
        }
        if (typeof props.value !== "undefined") {
          state._value = props.value;
        }
      }
      state._listenForPropChanges = true;
      return state;
    }
  }]);
  return RadioGroup2;
}(react.PureComponent);
RadioGroup.tagName = "dnb-radio-group";
RadioGroup.contextType = Context/* default */.Z;
RadioGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  label_position: null,
  title: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  size: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: "row",
  value: void 0,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};
RadioGroup.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/Radio.js









var Radio_AlignmentHelper, _span, _span2;

function Radio_createSuper(Derived) {
  var hasNativeReflectConstruct = Radio_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Radio_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}














var Radio = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Radio2, _React$PureComponent);
  var _super = Radio_createSuper(Radio2);
  function Radio2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, Radio2);
    _this = _super.call(this, props);
    _this.onKeyDownHandler = function(event) {
      var key = keycode(event);
      if (_this.isInNoGroup()) {
        switch (key) {
          case "enter":
            _this.onChangeHandler(event);
            break;
        }
      } else if (_this.isContextGroupOrSingle()) {
        switch (key) {
          case "space":
          case "enter": {
            var value = _this.context.value;
            if (value !== null && typeof value !== "undefined") {
              event.preventDefault();
            }
            if (key === "enter") {
              var checked = !_this.state.checked;
              _this.setState({
                checked,
                _listenForPropChanges: false
              });
            }
            break;
          }
        }
      } else {
        switch (key) {
          case "space": {
            event.preventDefault();
            break;
          }
        }
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_key_down", {
        event
      });
    };
    _this.onChangeHandler = function(_event) {
      var event = _event;
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      var value = event.target.value;
      var checked = !_this.state.checked;
      if (_this.isPlainGroup()) {
        setTimeout(function() {
          _this.setState({
            checked,
            _listenForPropChanges: false
          }, function() {
            return _this.callOnChange({
              value,
              checked,
              event
            });
          });
        }, 1);
      } else {
        _this.setState({
          checked,
          _listenForPropChanges: false
        });
        _this.callOnChange({
          value,
          checked,
          event
        });
      }
    };
    _this.isContextGroupOrSingle = function() {
      return typeof _this.context.value !== "undefined" && !_this.props.group;
    };
    _this.isPlainGroup = function() {
      return typeof _this.context.value === "undefined" && _this.props.group;
    };
    _this.isInNoGroup = function() {
      return typeof _this.context.value === "undefined" && !_this.props.group;
    };
    _this.onClickHandler = function(event) {
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      if (!_this.isPlainGroup()) {
        return;
      }
      var value = event.target.value;
      var checked = event.target.checked;
      _this.callOnChange({
        value,
        checked,
        event
      });
    };
    _this.callOnChange = function(_ref) {
      var value = _ref.value, checked = _ref.checked, event = _ref.event;
      var group = _this.props.group;
      if (_this.context.onChange) {
        _this.context.onChange({
          value
        });
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        group,
        checked,
        value,
        event
      });
      if (_this._refInput.current) {
        _this._refInput.current.focus();
      }
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(Radio2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      return react.createElement(Context/* default.Consumer */.Z.Consumer, null, function(context) {
        var props = (0,component_helper/* extendPropsWithContext */.Xw)(_this2.props, Radio2.defaultProps, _this2.context, {
          skeleton: context === null || context === void 0 ? void 0 : context.skeleton
        }, context.FormRow, context.Radio);
        var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_sr_only = props.label_sr_only, label_position = props.label_position, size = props.size, readOnly = props.readOnly, skeleton = props.skeleton, className = props.className, _className = props.class, _id = props.id, _group = props.group, _value = props.value, _checked = props.checked, _disabled = props.disabled, attributes = props.attributes, children = props.children, on_change = props.on_change, on_state_update = props.on_state_update, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_sr_only", "label_position", "size", "readOnly", "skeleton", "className", "class", "id", "group", "value", "checked", "disabled", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);
        var checked = _this2.state.checked;
        var value = props.value, group = props.group, disabled = props.disabled;
        var hasContext = typeof _this2.context.name !== "undefined";
        if (hasContext) {
          if (typeof _this2.context.value !== "undefined") {
            checked = _this2.context.value === value;
          }
          group = _this2.context.name;
          disabled = (0,component_helper/* isTrue */.oA)(_this2.context.disabled);
        } else if (typeof rest.name !== "undefined") {
          group = rest.name;
        }
        var id = _this2._id;
        var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
        var mainParams = {
          className: classnames("dnb-radio", (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-radio__status--".concat(status_state), size && "dnb-radio--".concat(size), label && "dnb-radio--label-position-".concat(label_position || "right"))
        };
        var inputParams = (0,esm_extends/* default */.Z)({
          role: hasContext || group ? "radio" : null,
          type: hasContext || group ? "radio" : "checkbox"
        }, rest);
        if (showStatus || suffix) {
          inputParams["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(inputParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
        }
        if (readOnly) {
          inputParams["aria-readonly"] = inputParams.readOnly = true;
        }
        if (!group) {
          inputParams.type = "checkbox";
          inputParams.role = "radio";
        }
        (0,SkeletonHelper/* skeletonDOMAttributes */.rZ)(inputParams, skeleton, _this2.context);
        (0,component_helper/* validateDOMAttributes */.L_)(_this2.props, inputParams);
        var labelComp = label && react.createElement(FormLabel/* default */.Z, {
          id: id + "-label",
          for_id: id,
          text: label,
          disabled,
          skeleton,
          sr_only: label_sr_only
        });
        return react.createElement("span", mainParams, react.createElement("span", {
          className: "dnb-radio__order"
        }, label_position === "left" && labelComp, react.createElement("span", {
          className: "dnb-radio__inner"
        }, Radio_AlignmentHelper || (Radio_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), showStatus && react.createElement(FormStatus/* default */.ZP, {
          id: id + "-form-status",
          global_status_id,
          label,
          text_id: id + "-status",
          width_selector: id + ", " + id + "-label",
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton
        }), react.createElement("span", {
          className: "dnb-radio__row"
        }, react.createElement("span", {
          className: "dnb-radio__shell"
        }, react.createElement("input", (0,esm_extends/* default */.Z)({
          type: "radio",
          value,
          id,
          name: group,
          className: "dnb-radio__input",
          checked,
          "aria-checked": checked,
          disabled: (0,component_helper/* isTrue */.oA)(disabled),
          ref: _this2._refInput
        }, inputParams, {
          onChange: _this2.onChangeHandler,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler
        })), react.createElement("span", {
          className: classnames("dnb-radio__button", (0,SkeletonHelper/* createSkeletonClass */.BD)("shape", skeleton, _this2.context)),
          "aria-hidden": true
        }), _span || (_span = react.createElement("span", {
          className: "dnb-radio__focus",
          "aria-hidden": true
        })), _span2 || (_span2 = react.createElement("span", {
          className: "dnb-radio__dot",
          "aria-hidden": true
        }))), label_position !== "left" && labelComp, suffix && react.createElement(Suffix/* default */.Z, {
          className: "dnb-radio__suffix",
          id: id + "-suffix",
          context: props
        }, suffix)))));
      });
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(Radio2.tagName, Radio2, Radio2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = Radio2.parseChecked(props.checked);
        }
      }
      state._listenForPropChanges = true;
      if (state.checked !== state.__checked) {
        (0,component_helper/* dispatchCustomElementEvent */.RW)({
          props
        }, "on_state_update", {
          checked: state.checked
        });
      }
      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);
  return Radio2;
}(react.PureComponent);
Radio.tagName = "dnb-radio";
Radio.contextType = radio_RadioGroupContext;
Radio.defaultProps = {
  label: null,
  label_sr_only: null,
  label_position: null,
  checked: null,
  disabled: false,
  id: null,
  size: null,
  group: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: "",
  attributes: null,
  readOnly: false,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
Radio.Group = RadioGroup;
Radio.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/checkbox/Checkbox.js
var Checkbox = __webpack_require__(4742);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/button/Button.js + 7 modules
var Button = __webpack_require__(9826);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__(4348);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.index-of.js
var es_array_index_of = __webpack_require__(5860);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButtonGroupContext.js

var ToggleButtonGroupContext = react.createContext({});
/* harmony default export */ const toggle_button_ToggleButtonGroupContext = (ToggleButtonGroupContext);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButtonGroup.js









var ToggleButtonGroup_AlignmentHelper;








function ToggleButtonGroup_createSuper(Derived) {
  var hasNativeReflectConstruct = ToggleButtonGroup_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function ToggleButtonGroup_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}











var ToggleButtonGroup = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(ToggleButtonGroup2, _React$PureComponent);
  var _super = ToggleButtonGroup_createSuper(ToggleButtonGroup2);
  function ToggleButtonGroup2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, ToggleButtonGroup2);
    _this = _super.call(this, props);
    _this.onChangeHandler = function(_ref) {
      var value = _ref.value, event = _ref.event;
      var multiselect = _this.props.multiselect;
      var values = _this.state.values || [];
      if ((0,component_helper/* isTrue */.oA)(multiselect)) {
        if (!values.includes(value)) {
          values.push(value);
        } else {
          values.splice(values.indexOf(value), 1);
        }
      }
      _this.setState({
        value,
        values,
        _listenForPropChanges: false
      });
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        value,
        values,
        event
      });
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._name = props.name || (0,component_helper/* makeUniqueId */.Xo)();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(ToggleButtonGroup2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, ToggleButtonGroup2.defaultProps, this.context.getTranslation(this.props).ToggleButton, this.context.FormRow, this.context.ToggleButtonGroup);
      var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label_direction = props.label_direction, label_sr_only = props.label_sr_only, vertical = props.vertical, layout_direction = props.layout_direction, label = props.label, variant = props.variant, left_component = props.left_component, no_fieldset = props.no_fieldset, disabled = props.disabled, skeleton = props.skeleton, className = props.className, _className = props.class, multiselect = props.multiselect, _id = props.id, _name = props.name, _value = props.value, _values = props.values, attributes = props.attributes, children = props.children, on_change = props.on_change, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label_direction", "label_sr_only", "vertical", "layout_direction", "label", "variant", "left_component", "no_fieldset", "disabled", "skeleton", "className", "class", "multiselect", "id", "name", "value", "values", "attributes", "children", "on_change", "custom_method", "custom_element"]);
      var _this$state = this.state, value = _this$state.value, values = _this$state.values;
      var id = this._id;
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var classes = classnames("dnb-toggle-button-group dnb-toggle-button-group--".concat(layout_direction, " dnb-form-component"), ((0,component_helper/* isTrue */.oA)(vertical) || label_direction) && "dnb-form-row--".concat((0,component_helper/* isTrue */.oA)(vertical) ? "vertical" : label_direction, "-label"), (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-toggle-button-group__status--".concat(status_state), !label && "dnb-toggle-button-group--no-label");
      var params = (0,esm_extends/* default */.Z)({}, rest);
      if (showStatus || suffix) {
        params["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(params, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (label) {
        params["aria-labelledby"] = id + "-label";
      }
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, params);
      var context = {
        name: this._name,
        value,
        values,
        multiselect: (0,component_helper/* isTrue */.oA)(multiselect),
        variant,
        left_component,
        disabled,
        skeleton,
        setContext: function setContext(context2) {
          if (typeof context2 === "function") {
            context2 = context2(_this2._tmp);
          }
          _this2._tmp = (0,esm_extends/* default */.Z)({}, _this2._tmp, context2);
          _this2.setState((0,esm_extends/* default */.Z)({}, context2, {
            _listenForPropChanges: false
          }));
        },
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id,
        label,
        label_id: id + "-label",
        label_direction,
        label_sr_only,
        direction: label_direction,
        vertical,
        disabled,
        skeleton,
        no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(toggle_button_ToggleButtonGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, ToggleButtonGroup_AlignmentHelper || (ToggleButtonGroup_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(FormRow/* default */.ZP, formRowParams, react.createElement("span", (0,esm_extends/* default */.Z)({
        id,
        className: "dnb-toggle-button-group__shell",
        role: "group"
      }, params), showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text_id: id + "-status",
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton
      }), react.createElement("span", {
        className: "dnb-toggle-button-group__children"
      }, children, suffix && react.createElement(Suffix/* default */.Z, {
        className: "dnb-toggle-button-group__suffix",
        id: id + "-suffix",
        context: props
      }, suffix))))));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(ToggleButtonGroup2.tagName, ToggleButtonGroup2, ToggleButtonGroup2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (typeof props.value !== "undefined" && props.value !== state.value) {
          state.value = props.value;
        }
        if (typeof props.values !== "undefined" && props.values !== state.values) {
          state.values = ToggleButtonGroup2.getValues(props);
        }
      }
      state._listenForPropChanges = true;
      return state;
    }
  }, {
    key: "getValues",
    value: function getValues(props) {
      if (typeof props.values === "string" && props.values[0] === "[") {
        return JSON.parse(props.values);
      }
      return props.values;
    }
  }]);
  return ToggleButtonGroup2;
}(react.PureComponent);
ToggleButtonGroup.tagName = "dnb-toggle-button-group";
ToggleButtonGroup.contextType = Context/* default */.Z;
ToggleButtonGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  multiselect: null,
  variant: null,
  left_component: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: "row",
  value: void 0,
  values: void 0,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButton.js











var ToggleButton_AlignmentHelper;







function ToggleButton_createSuper(Derived) {
  var hasNativeReflectConstruct = ToggleButton_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function ToggleButton_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}
















var ToggleButton = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(ToggleButton2, _React$PureComponent);
  var _super = ToggleButton_createSuper(ToggleButton2);
  function ToggleButton2(props, context) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, ToggleButton2);
    _this = _super.call(this, props);
    _this.onKeyDownHandler = function(event) {
      switch (keycode(event)) {
        case "enter":
          _this.onClickHandler(event);
          break;
      }
    };
    _this.onKeyUpHandler = function(event) {
      switch (keycode(event)) {
        case "enter":
          _this.onClickHandler(event);
          break;
      }
    };
    _this.onClickHandler = function(_ref) {
      var event = _ref.event;
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      event.persist();
      if (!(0,component_helper/* isTrue */.oA)(_this.context.multiselect) && _this.props.value === _this.context.value) {
        return;
      }
      var checked = !_this.state.checked;
      _this.setState({
        checked,
        _listenForPropChanges: false
      });
      _this.callOnChange({
        checked,
        event
      });
      if (_this._refButton.current && checked) {
        try {
          _this._refButton.current._ref.current.focus();
        } catch (e) {
          (0,component_helper/* warn */.ZK)(e);
        }
      }
    };
    _this.callOnChange = function(_ref2) {
      var checked = _ref2.checked, event = _ref2.event;
      var value = _this.props.value;
      if (_this.context.onChange) {
        _this.context.onChange({
          value,
          event
        });
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        checked,
        value,
        event
      });
    };
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._refButton = react.createRef();
    _this.state = {
      _listenForPropChanges: true
    };
    if (context.name && typeof props.value !== "undefined") {
      if (typeof context.value !== "undefined") {
        _this.state.checked = context.value === props.value;
        _this.state._listenForPropChanges = false;
      } else if (context.values && Array.isArray(context.values)) {
        _this.state.checked = context.values.includes(props.value);
        _this.state._listenForPropChanges = false;
      } else if (ToggleButton2.parseChecked(props.checked)) {
        if (context.setContext) {
          if (context.multiselect) {
            context.setContext(function(tmp) {
              return {
                values: tmp && Array.isArray(tmp.values) ? [].concat((0,toConsumableArray/* default */.Z)(tmp.values), [props.value]) : [props.value]
              };
            });
          } else {
            context.setContext({
              value: props.value
            });
          }
        }
      }
    }
    return _this;
  }
  (0,createClass/* default */.Z)(ToggleButton2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      return react.createElement(Context/* default.Consumer */.Z.Consumer, null, function(context) {
        var _componentParams;
        var props = (0,component_helper/* extendPropsWithContext */.Xw)(_this2.props, ToggleButton2.defaultProps, _this2.context, context.translation.ToggleButton, context.FormRow, context.ToggleButton);
        var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, text = props.text, title = props.title, readOnly = props.readOnly, className = props.className, _className = props.class, disabled = props.disabled, skeleton = props.skeleton, variant = props.variant, left_component = props.left_component, icon = props.icon, icon_size = props.icon_size, icon_position = props.icon_position, propValue = props.value, _id = props.id, _checked = props.checked, attributes = props.attributes, children = props.children, on_change = props.on_change, on_state_update = props.on_state_update, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "text", "title", "readOnly", "className", "class", "disabled", "skeleton", "variant", "left_component", "icon", "icon_size", "icon_position", "value", "id", "checked", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);
        var checked = _this2.state.checked;
        if (!(0,component_helper/* isTrue */.oA)(_this2.context.multiselect) && typeof _this2.context.value !== "undefined") {
          var contextValue = _this2.context.value;
          if (typeof propValue === "string" || typeof propValue === "number") {
            checked = propValue === contextValue;
          } else if (typeof JSON !== "undefined") {
            checked = JSON.stringify(propValue) === JSON.stringify(contextValue);
          }
        }
        var id = _this2._id;
        var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
        var mainParams = {
          className: classnames("dnb-toggle-button", (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-toggle-button__status--".concat(status_state), checked && "dnb-toggle-button--checked", label_direction && "dnb-toggle-button--".concat(label_direction))
        };
        (0,component_helper/* validateDOMAttributes */.L_)(_this2.props, rest);
        var buttonParams = (0,esm_extends/* default */.Z)((0,defineProperty/* default */.Z)({
          id,
          disabled,
          skeleton,
          text: text || children,
          title,
          icon,
          icon_size,
          icon_position
        }, "aria-pressed", String(checked)), rest);
        var componentParams = (_componentParams = {
          checked,
          disabled
        }, (0,defineProperty/* default */.Z)(_componentParams, "aria-hidden", true), (0,defineProperty/* default */.Z)(_componentParams, "tabIndex", "-1"), _componentParams);
        if (status) {
          if (status_state === "info") {
            componentParams.status_state = "info";
          } else {
            componentParams.status = "error";
          }
        }
        if (showStatus || suffix) {
          buttonParams["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(buttonParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
        }
        if (readOnly) {
          buttonParams["aria-readonly"] = buttonParams.readOnly = true;
        }
        var leftComponent = null;
        switch (variant) {
          case "radio":
            leftComponent = react.createElement(Radio, (0,esm_extends/* default */.Z)({
              id: "".concat(id, "-radio")
            }, componentParams));
            break;
          case "checkbox":
            leftComponent = react.createElement(Checkbox/* default */.Z, (0,esm_extends/* default */.Z)({
              id: "".concat(id, "-checkbox")
            }, componentParams));
            break;
          case "default":
          default:
            leftComponent = left_component;
            break;
        }
        return react.createElement("span", mainParams, label && react.createElement(FormLabel/* default */.Z, {
          id: id + "-label",
          for_id: id,
          text: label,
          disabled,
          skeleton,
          label_direction,
          sr_only: label_sr_only
        }), react.createElement("span", {
          className: "dnb-toggle-button__inner"
        }, showStatus && react.createElement(FormStatus/* default */.ZP, {
          id: id + "-form-status",
          global_status_id,
          label,
          text_id: id + "-status",
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton
        }), react.createElement("span", {
          className: "dnb-toggle-button__shell"
        }, ToggleButton_AlignmentHelper || (ToggleButton_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(Button/* default */.ZP, (0,esm_extends/* default */.Z)({
          variant: "secondary",
          className: "dnb-toggle-button__button"
        }, buttonParams, {
          ref: _this2._refButton,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler,
          onKeyUp: _this2.onKeyUpHandler
        }), leftComponent && react.createElement("span", {
          className: "dnb-toggle-button__component"
        }, leftComponent)), suffix && react.createElement(Suffix/* default */.Z, {
          className: "dnb-toggle-button__suffix",
          id: id + "-suffix",
          context: props
        }, suffix))));
      });
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(ToggleButton2.tagName, ToggleButton2, ToggleButton2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = ToggleButton2.parseChecked(props.checked);
        }
      }
      state._listenForPropChanges = true;
      if (state.checked !== state.__checked) {
        (0,component_helper/* dispatchCustomElementEvent */.RW)({
          props
        }, "on_state_update", {
          checked: state.checked
        });
      }
      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);
  return ToggleButton2;
}(react.PureComponent);
ToggleButton.Group = ToggleButtonGroup;
ToggleButton.tagName = "dnb-toggle-button";
ToggleButton.contextType = toggle_button_ToggleButtonGroupContext;
ToggleButton.defaultProps = {
  text: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  checked: void 0,
  variant: null,
  left_component: null,
  disabled: null,
  skeleton: null,
  id: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: "",
  icon: null,
  icon_position: "right",
  icon_size: null,
  attributes: null,
  readOnly: false,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
ToggleButton.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/Space.js
var Space = __webpack_require__(7171);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js + 5 modules
var Dropdown = __webpack_require__(8755);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/P.js
var P = __webpack_require__(3731);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Provider.js
var Provider = __webpack_require__(4024);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up.js
var chevron_up = __webpack_require__(1);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down.js
var chevron_down = __webpack_require__(9444);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/add.js
var add = __webpack_require__(43);
// EXTERNAL MODULE: ./src/shared/ColorController.js
var ColorController = __webpack_require__(4513);
// EXTERNAL MODULE: ../node_modules/zustand/index.js
var zustand = __webpack_require__(2742);
// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(1818);
// EXTERNAL MODULE: ./src/shared/Compiler.js
var Compiler = __webpack_require__(9301);
// EXTERNAL MODULE: ./src/shared/DOM.js
var DOM = __webpack_require__(9494);
;// CONCATENATED MODULE: ./src/extension/editor/EditorStore.js




const useEditorStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)((set, get) => ({
  enabled: false,
  themesHash: null,
  modifications: {},
  addModification: ({path, themeId = null}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  setTheme: ({path, themeId}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  removeTheme: ({path}) => {
    const {modifications} = get();
    delete modifications[path];
    set({modifications});
  },
  setEnabled: (enabled) => {
    set({enabled});
  }
}), getPersistConfig()));
function listenForModifications({onModification} = {}) {
  return useEditorStore.subscribe(() => {
    if (typeof onModification === "function") {
      onModification();
    }
  });
}
function getPersistConfig() {
  return {
    name: "eufemia-theme-editor",
    blacklist: ["themesHash"]
  };
}
function applyModifications({themes}) {
  const {modifications} = useEditorStore.getState();
  const {css} = (0,Compiler/* compileModifications */.VV)({
    modifications,
    themes,
    modifyDeclaration: ({key, change}) => {
      return `${key}: ${change};${key.replace("--", `--theme-`)}: ${change};`;
    }
  });
  (0,DOM/* insertCSS */.Q4)(css, {elementId: "eufemia-theme-custom"});
}
function removeCustomModifications() {
  (0,DOM/* insertCSS */.Q4)("", {elementId: "eufemia-theme-custom"});
}
function flushThemesHash() {
  useEditorStore.setState({themesHash: Date.now()});
}

// EXTERNAL MODULE: ./src/shared/Bridge.js
var Bridge = __webpack_require__(8208);
;// CONCATENATED MODULE: ./src/extension/editor/ExtensionEditor.jsx











const Layout = emotion_styled_browser_esm/* default.div */.Z.div`
  position: fixed;
  z-index: 10000;
  top: 1.5rem;
  bottom: 0;
  left: 2px;

  display: flex;
  flex-direction: column;

  width: var(--ete-width);
  height: 100vh;
  padding: 0.5rem;
  padding-top: 1rem;

  background-color: var(--color-black-3);
  border: 1px solid var(--color-black-8);
`;
const EditorButton = (0,emotion_styled_browser_esm/* default */.Z)(ToggleButton)`
  position: fixed;
  z-index: 10001;
  top: 2px;
  left: 2px;

  button {
    border-radius: 0;
    color: var(--color-white);
  }

  button[aria-pressed='false'] {
    padding: 0;
    opacity: 0.5;
    box-shadow: none;
    background-color: var(--color-black-55);
  }
  button[aria-pressed='true'] {
    width: var(--ete-width);
  }
`;
const EteApp = emotion_styled_browser_esm/* default.div */.Z.div`
  --ete-width: 10rem;
  ${(0,ColorController/* generateThemeIgnoreColors */.RZ)()}
`;
const App = () => {
  const {enabled, setEnabled} = useEditorStore();
  const [logPath, setLogPath] = react.useState(null);
  const [toggleEnabled] = react.useState(() => ({checked}) => setEnabled(checked));
  return /* @__PURE__ */ react.createElement(EteApp, null, /* @__PURE__ */ react.createElement(EditorButton, {
    title: "Eufemia Theme Editor",
    id: "ete-toggle-enabled",
    size: "small",
    checked: enabled,
    on_change: toggleEnabled,
    icon: enabled ? chevron_up/* default */.Z : chevron_down/* default */.Z
  }), enabled && /* @__PURE__ */ react.createElement(Layout, {
    id: "ete",
    className: "dnb-core-style"
  }, /* @__PURE__ */ react.createElement(InspectorHandler, {
    onHover: ({path}) => {
      setLogPath(path);
    },
    onCancel: () => {
      setLogPath(null);
    }
  }), logPath ? /* @__PURE__ */ react.createElement(Path, {
    top: "1rem",
    modifier: "x-small"
  }, logPath) : /* @__PURE__ */ react.createElement(ModificationManager, {
    top: "1rem"
  })));
};
function InspectorHandler({onHover, onCancel}) {
  const {addModification} = useEditorStore();
  const [inspect, setInspect] = react.useState(false);
  const [toggleEnabled] = react.useState(() => () => setInspect((s) => {
    if (s && onCancel) {
      onCancel();
    }
    return !s;
  }));
  const [inspector] = react.useState(() => (0,DOM/* createDOMInspector */.yQ)({
    exclude: ["#ete", "#ete-toggle-inspector"],
    onHover: ({element, path}) => {
      if (onHover) {
        onHover({element, path});
      }
    },
    onClick: ({element, path}) => {
      if (onCancel) {
        onCancel({element, path});
      }
      setInspect(false);
      addModification({path});
    }
  }));
  if (inspect) {
    inspector.enable();
  } else {
    inspector.cancel();
  }
  return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(ToggleButton, {
    id: "ete-toggle-inspector",
    icon: add/* default */.Z,
    icon_position: "left",
    checked: inspect,
    on_change: toggleEnabled
  }, inspect ? "Cancel" : "Inspect"));
}
const marker = (0,DOM/* createInspectorMarker */.gD)();
function hideOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.hide();
  });
}
function showOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.show(elem);
  });
}
function useThemes(themesHash) {
  const [listOfThemes, setListOfThemes] = react.useState([]);
  react.useEffect(() => {
    (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
      setListOfThemes(Object.keys(themes).map((key) => key).filter((key) => !["blue-test", "2x-test"].includes(key)));
    }).catch((e) => {
      console.warn(e);
    });
  }, [themesHash]);
  return listOfThemes;
}
function ModificationManager(props) {
  const {modifications, themesHash, setTheme, removeTheme} = useEditorStore();
  const listOfThemes = useThemes(themesHash);
  return /* @__PURE__ */ react.createElement(Space/* default */.Z, {
    ...props
  }, /* @__PURE__ */ react.createElement(List, null, Object.entries(modifications).map(([path, {themeId}]) => {
    const dontExist = !document.querySelectorAll(path);
    return /* @__PURE__ */ react.createElement("li", {
      key: path
    }, /* @__PURE__ */ react.createElement("div", {
      onMouseOver: () => showOutline({path}),
      onMouseOut: () => hideOutline({path})
    }, /* @__PURE__ */ react.createElement(Path, {
      className: dontExist ? "dont-exist" : "",
      modifier: "x-small"
    }, path), /* @__PURE__ */ react.createElement(StyledDropdown, {
      size: "small",
      skip_portal: true,
      data: [
        ...listOfThemes,
        {content: "Inactive", selected_key: "inactive"},
        {content: "Remove", selected_key: "remove"}
      ],
      value: themeId && listOfThemes ? listOfThemes.indexOf(themeId) : "inactive",
      on_change: ({data}) => {
        const themeId2 = typeof data?.selected_key !== "undefined" ? data?.selected_key : data;
        switch (themeId2) {
          case "remove": {
            removeTheme({path});
            break;
          }
          default: {
            setTheme({path, themeId: themeId2});
          }
        }
      }
    })));
  })));
}
const Path = (0,emotion_styled_browser_esm/* default */.Z)(P/* default */.Z)`
  color: var(--color-success-green);
  &.dont-exist {
    color: var(--color-fire-red);
  }
`;
const StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  display: flex;
  --dropdown-width: 8rem;
`;
const List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  list-style: none;
  padding: 0;

  > li {
    margin-top: 0.5rem;
    background-color: var(--color-pistachio);
  }
`;
function createThemeEditor() {
  let root = document.getElementById("eufemia-theme-editor");
  if (!root) {
    root = document.createElement("div");
    root.setAttribute("id", "eufemia-theme-editor");
    document.body.insertBefore(root, document.body.firstChild);
  }
  react_dom.render(/* @__PURE__ */ react.createElement(Provider/* default */.Z, {
    locale: "en-GB"
  }, /* @__PURE__ */ react.createElement(App, null)), root);
}
function removeThemeEditor() {
  const root = document.getElementById("eufemia-theme-editor");
  if (root) {
    root.remove();
  }
}

;// CONCATENATED MODULE: ./src/extension/content.js




if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
  setLocalThemeModifications();
  (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
    (0,Bridge/* setLocalThemeData */.YB)({themes});
    setLocalThemeModifications();
  });
}
(0,Bridge/* listenForExtensionRequests */.Pb)({
  onResponse: (response) => {
    switch (response.type) {
      case "store-themes": {
        const themes = response.themes;
        (0,Bridge/* setLocalThemeData */.YB)({themes});
        setLocalThemeModifications();
        flushThemesHash();
        if (response.themeId === "blue-test" && response.css) {
          removeCustomModifications();
        }
        break;
      }
      default: {
      }
    }
  }
});
Browser/* default.unsub */.Z.unsub;
function setLocalThemeModifications() {
  if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
    (0,Bridge/* setLocalThemeCSS */.eF)();
    const themes = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
    if (themes) {
      applyModifications({themes});
    }
    createThemeEditor();
    if (typeof Browser/* default.unsub */.Z.unsub === "undefined") {
      Browser/* default.unsub */.Z.unsub = listenForModifications({
        onModification: () => {
          const themes2 = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
          applyModifications({themes: themes2});
        }
      });
    }
  } else if (typeof Browser/* default.unsub */.Z.unsub === "function") {
    removeThemeEditor();
    removeCustomModifications();
    Browser/* default.unsub */.Z.unsub();
    Browser/* default.unsub */.Z.unsub = void 0;
  }
}

})();

/******/ })()
;
//# sourceMappingURL=content.js.map