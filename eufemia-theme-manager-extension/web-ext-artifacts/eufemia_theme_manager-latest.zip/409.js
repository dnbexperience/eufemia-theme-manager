(self["webpackChunkeufemia_theme_manager_extension"] = self["webpackChunkeufemia_theme_manager_extension"] || []).push([[409],{

/***/ 29409:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./src/shared/Browser.js
var Browser = __webpack_require__(15101);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(94339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(77888);
// EXTERNAL MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js + 2 modules
var emotion_styled_browser_esm = __webpack_require__(65462);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButton.js + 5 modules
var ToggleButton = __webpack_require__(55028);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/Space.js
var Space = __webpack_require__(7171);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js + 5 modules
var Dropdown = __webpack_require__(38755);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/P.js
var P = __webpack_require__(93731);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Provider.js
var Provider = __webpack_require__(14024);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up.js
var chevron_up = __webpack_require__(1);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down.js
var chevron_down = __webpack_require__(79444);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/add.js
var add = __webpack_require__(43);
// EXTERNAL MODULE: ./src/shared/ColorController.js
var ColorController = __webpack_require__(44513);
// EXTERNAL MODULE: ../node_modules/zustand/index.js
var zustand = __webpack_require__(2742);
// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(71818);
// EXTERNAL MODULE: ./src/shared/Compiler.js
var Compiler = __webpack_require__(19301);
// EXTERNAL MODULE: ./src/shared/DOM.js
var DOM = __webpack_require__(9494);
;// CONCATENATED MODULE: ./src/extension/editor/EditorStore.js




const useEditorStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)((set, get) => ({
  enabled: false,
  themesHash: null,
  modifications: {},
  addModification: ({path, themeId = null}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  setTheme: ({path, themeId}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  removeTheme: ({path}) => {
    const {modifications} = get();
    delete modifications[path];
    set({modifications});
  },
  setEnabled: (enabled) => {
    set({enabled});
  }
}), getPersistConfig()));
function listenForModifications({onModification} = {}) {
  return useEditorStore.subscribe(() => {
    if (typeof onModification === "function") {
      onModification();
    }
  });
}
function getPersistConfig() {
  return {
    name: "eufemia-theme-editor",
    blacklist: ["themesHash"]
  };
}
function applyModifications({themes}) {
  const {modifications} = useEditorStore.getState();
  const {css} = (0,Compiler/* compileModifications */.VV)({
    modifications,
    themes,
    modifyDeclaration: ({key, change}) => {
      return `${key}: ${change};${key.replace("--", `--theme-`)}: ${change};`;
    }
  });
  (0,DOM/* insertCSS */.Q4)(css, {elementId: "eufemia-theme-custom"});
}
function removeCustomModifications() {
  (0,DOM/* insertCSS */.Q4)("", {elementId: "eufemia-theme-custom"});
}
function flushThemesHash() {
  useEditorStore.setState({themesHash: Date.now()});
}

// EXTERNAL MODULE: ./src/shared/Bridge.js
var Bridge = __webpack_require__(68208);
;// CONCATENATED MODULE: ./src/extension/editor/ExtensionEditor.jsx











const Layout = emotion_styled_browser_esm/* default.div */.Z.div`
  position: fixed;
  z-index: 10000;
  top: 1.5rem;
  bottom: 0;
  left: 2px;

  display: flex;
  flex-direction: column;

  width: var(--ete-width);
  height: 100vh;
  padding: 0.5rem;
  padding-top: 1rem;

  background-color: var(--color-black-3);
  border: 1px solid var(--color-black-8);
`;
const EditorButton = (0,emotion_styled_browser_esm/* default */.Z)(ToggleButton/* default */.Z)`
  position: fixed;
  z-index: 10001;
  top: 2px;
  left: 2px;

  button {
    border-radius: 0;
    color: var(--color-white);
  }

  button[aria-pressed='false'] {
    padding: 0;
    opacity: 0.5;
    box-shadow: none;
    background-color: var(--color-black-55);
  }
  button[aria-pressed='true'] {
    width: var(--ete-width);
  }
`;
const EteApp = emotion_styled_browser_esm/* default.div */.Z.div`
  --ete-width: 10rem;
  ${(0,ColorController/* generateThemeIgnoreColors */.RZ)()}
`;
const App = () => {
  const {enabled, setEnabled} = useEditorStore();
  const [logPath, setLogPath] = react.useState(null);
  const [toggleEnabled] = react.useState(() => ({checked}) => setEnabled(checked));
  return /* @__PURE__ */ react.createElement(EteApp, null, /* @__PURE__ */ react.createElement(EditorButton, {
    title: "Eufemia Theme Editor",
    id: "ete-toggle-enabled",
    size: "small",
    checked: enabled,
    on_change: toggleEnabled,
    icon: enabled ? chevron_up/* default */.Z : chevron_down/* default */.Z
  }), enabled && /* @__PURE__ */ react.createElement(Layout, {
    id: "ete",
    className: "dnb-core-style"
  }, /* @__PURE__ */ react.createElement(InspectorHandler, {
    onHover: ({path}) => {
      setLogPath(path);
    },
    onCancel: () => {
      setLogPath(null);
    }
  }), logPath ? /* @__PURE__ */ react.createElement(Path, {
    top: "1rem",
    modifier: "x-small"
  }, logPath) : /* @__PURE__ */ react.createElement(ModificationManager, {
    top: "1rem"
  })));
};
function InspectorHandler({onHover, onCancel}) {
  const {addModification} = useEditorStore();
  const [inspect, setInspect] = react.useState(false);
  const [toggleEnabled] = react.useState(() => () => setInspect((s) => {
    if (s && onCancel) {
      onCancel();
    }
    return !s;
  }));
  const [inspector] = react.useState(() => (0,DOM/* createDOMInspector */.yQ)({
    exclude: ["#ete", "#ete-toggle-inspector"],
    onHover: ({element, path}) => {
      if (onHover) {
        onHover({element, path});
      }
    },
    onClick: ({element, path}) => {
      if (onCancel) {
        onCancel({element, path});
      }
      setInspect(false);
      addModification({path});
    }
  }));
  if (inspect) {
    inspector.enable();
  } else {
    inspector.cancel();
  }
  return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(ToggleButton/* default */.Z, {
    id: "ete-toggle-inspector",
    icon: add/* default */.Z,
    icon_position: "left",
    checked: inspect,
    on_change: toggleEnabled
  }, inspect ? "Cancel" : "Inspect"));
}
const marker = (0,DOM/* createInspectorMarker */.gD)();
function hideOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.hide();
  });
}
function showOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.show(elem);
  });
}
function useThemes(themesHash) {
  const [listOfThemes, setListOfThemes] = react.useState([]);
  react.useEffect(() => {
    (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
      setListOfThemes(Object.keys(themes).map((key) => key).filter((key) => !["blue-test", "2x-test"].includes(key)));
    }).catch((e) => {
      console.warn(e);
    });
  }, [themesHash]);
  return listOfThemes;
}
function ModificationManager(props) {
  const {modifications, themesHash, setTheme, removeTheme} = useEditorStore();
  const listOfThemes = useThemes(themesHash);
  return /* @__PURE__ */ react.createElement(Space/* default */.Z, {
    ...props
  }, /* @__PURE__ */ react.createElement(List, null, Object.entries(modifications).map(([path, {themeId}]) => {
    const dontExist = !document.querySelectorAll(path);
    return /* @__PURE__ */ react.createElement("li", {
      key: path
    }, /* @__PURE__ */ react.createElement("div", {
      onMouseOver: () => showOutline({path}),
      onMouseOut: () => hideOutline({path})
    }, /* @__PURE__ */ react.createElement(Path, {
      className: dontExist ? "dont-exist" : "",
      modifier: "x-small"
    }, path), /* @__PURE__ */ react.createElement(StyledDropdown, {
      size: "small",
      skip_portal: true,
      data: [
        ...listOfThemes,
        {content: "Inactive", selected_key: "inactive"},
        {content: "Remove", selected_key: "remove"}
      ],
      value: themeId && listOfThemes ? listOfThemes.indexOf(themeId) : "inactive",
      on_change: ({data}) => {
        const themeId2 = typeof data?.selected_key !== "undefined" ? data?.selected_key : data;
        switch (themeId2) {
          case "remove": {
            removeTheme({path});
            break;
          }
          default: {
            setTheme({path, themeId: themeId2});
          }
        }
      }
    })));
  })));
}
const Path = (0,emotion_styled_browser_esm/* default */.Z)(P/* default */.Z)`
  color: var(--color-success-green);
  &.dont-exist {
    color: var(--color-fire-red);
  }
`;
const StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  display: flex;
  --dropdown-width: 8rem;
`;
const List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  list-style: none;
  padding: 0;

  > li {
    margin-top: 0.5rem;
    background-color: var(--color-pistachio);
  }
`;
function createThemeEditor() {
  let root = document.getElementById("eufemia-theme-editor");
  if (!root) {
    root = document.createElement("div");
    root.setAttribute("id", "eufemia-theme-editor");
    document.body.insertBefore(root, document.body.firstChild);
  }
  react_dom.render(/* @__PURE__ */ react.createElement(Provider/* default */.Z, {
    locale: "en-GB"
  }, /* @__PURE__ */ react.createElement(App, null)), root);
}
function removeThemeEditor() {
  const root = document.getElementById("eufemia-theme-editor");
  if (root) {
    root.remove();
  }
}

;// CONCATENATED MODULE: ./src/extension/content.js




if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
  setLocalThemeModifications();
  (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
    (0,Bridge/* setLocalThemeData */.YB)({themes});
    setLocalThemeModifications();
  });
}
(0,Bridge/* listenForExtensionRequests */.Pb)({
  onResponse: (response) => {
    switch (response.type) {
      case "store-themes": {
        const themes = response.themes;
        (0,Bridge/* setLocalThemeData */.YB)({themes});
        setLocalThemeModifications();
        flushThemesHash();
        if (response.themeId === "blue-test" && response.css) {
          removeCustomModifications();
        }
        break;
      }
      default: {
      }
    }
  }
});
Browser/* default.unsub */.Z.unsub;
function setLocalThemeModifications() {
  if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
    (0,Bridge/* setLocalThemeCSS */.eF)();
    const themes = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
    if (themes) {
      applyModifications({themes});
    }
    createThemeEditor();
    if (typeof Browser/* default.unsub */.Z.unsub === "undefined") {
      Browser/* default.unsub */.Z.unsub = listenForModifications({
        onModification: () => {
          const themes2 = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
          applyModifications({themes: themes2});
        }
      });
    }
  } else if (typeof Browser/* default.unsub */.Z.unsub === "function") {
    removeThemeEditor();
    removeCustomModifications();
    Browser/* default.unsub */.Z.unsub();
    Browser/* default.unsub */.Z.unsub = void 0;
  }
}


/***/ })

}]);
//# sourceMappingURL=409.js.map