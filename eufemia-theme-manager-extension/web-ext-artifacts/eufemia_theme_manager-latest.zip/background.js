/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 1327:
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function() {
    var self = this, args = arguments;
    return new Promise(function(resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator;
module.exports.default = module.exports, module.exports.__esModule = true;


/***/ }),

/***/ 2186:
/***/ ((module) => {

function _extends() {
  module.exports = _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  module.exports.default = module.exports, module.exports.__esModule = true;
  return _extends.apply(this, arguments);
}
module.exports = _extends;
module.exports.default = module.exports, module.exports.__esModule = true;


/***/ }),

/***/ 9096:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(7684);


/***/ }),

/***/ 6674:
/***/ ((module) => {

"use strict";

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;
function toObject(val) {
  if (val === null || val === void 0) {
    throw new TypeError("Object.assign cannot be called with null or undefined");
  }
  return Object(val);
}
function shouldUseNative() {
  try {
    if (!Object.assign) {
      return false;
    }
    var test1 = new String("abc");
    test1[5] = "de";
    if (Object.getOwnPropertyNames(test1)[0] === "5") {
      return false;
    }
    var test2 = {};
    for (var i = 0; i < 10; i++) {
      test2["_" + String.fromCharCode(i)] = i;
    }
    var order2 = Object.getOwnPropertyNames(test2).map(function(n) {
      return test2[n];
    });
    if (order2.join("") !== "0123456789") {
      return false;
    }
    var test3 = {};
    "abcdefghijklmnopqrst".split("").forEach(function(letter) {
      test3[letter] = letter;
    });
    if (Object.keys(Object.assign({}, test3)).join("") !== "abcdefghijklmnopqrst") {
      return false;
    }
    return true;
  } catch (err) {
    return false;
  }
}
module.exports = shouldUseNative() ? Object.assign : function(target, source) {
  var from;
  var to = toObject(target);
  var symbols;
  for (var s = 1; s < arguments.length; s++) {
    from = Object(arguments[s]);
    for (var key in from) {
      if (hasOwnProperty.call(from, key)) {
        to[key] = from[key];
      }
    }
    if (getOwnPropertySymbols) {
      symbols = getOwnPropertySymbols(from);
      for (var i = 0; i < symbols.length; i++) {
        if (propIsEnumerable.call(from, symbols[i])) {
          to[symbols[i]] = from[symbols[i]];
        }
      }
    }
  }
  return to;
};


/***/ }),

/***/ 2367:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;

/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l = __webpack_require__(6674), n = 60103, p = 60106;
__webpack_unused_export__ = 60107;
__webpack_unused_export__ = 60108;
__webpack_unused_export__ = 60114;
var q = 60109, r = 60110, t = 60112;
__webpack_unused_export__ = 60113;
var u = 60115, v = 60116;
if (typeof Symbol === "function" && Symbol.for) {
  var w = Symbol.for;
  n = w("react.element");
  p = w("react.portal");
  __webpack_unused_export__ = w("react.fragment");
  __webpack_unused_export__ = w("react.strict_mode");
  __webpack_unused_export__ = w("react.profiler");
  q = w("react.provider");
  r = w("react.context");
  t = w("react.forward_ref");
  __webpack_unused_export__ = w("react.suspense");
  u = w("react.memo");
  v = w("react.lazy");
}
var x = typeof Symbol === "function" && Symbol.iterator;
function y(a) {
  if (a === null || typeof a !== "object")
    return null;
  a = x && a[x] || a["@@iterator"];
  return typeof a === "function" ? a : null;
}
function z(a) {
  for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++)
    b += "&args[]=" + encodeURIComponent(arguments[c]);
  return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var A = {isMounted: function() {
  return false;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
}}, B = {};
function C(a, b, c) {
  this.props = a;
  this.context = b;
  this.refs = B;
  this.updater = c || A;
}
C.prototype.isReactComponent = {};
C.prototype.setState = function(a, b) {
  if (typeof a !== "object" && typeof a !== "function" && a != null)
    throw Error(z(85));
  this.updater.enqueueSetState(this, a, b, "setState");
};
C.prototype.forceUpdate = function(a) {
  this.updater.enqueueForceUpdate(this, a, "forceUpdate");
};
function D() {
}
D.prototype = C.prototype;
function E(a, b, c) {
  this.props = a;
  this.context = b;
  this.refs = B;
  this.updater = c || A;
}
var F = E.prototype = new D();
F.constructor = E;
l(F, C.prototype);
F.isPureReactComponent = true;
var G = {current: null}, H = Object.prototype.hasOwnProperty, I = {key: true, ref: true, __self: true, __source: true};
function J(a, b, c) {
  var e, d = {}, k = null, h = null;
  if (b != null)
    for (e in b.ref !== void 0 && (h = b.ref), b.key !== void 0 && (k = "" + b.key), b)
      H.call(b, e) && !I.hasOwnProperty(e) && (d[e] = b[e]);
  var g = arguments.length - 2;
  if (g === 1)
    d.children = c;
  else if (1 < g) {
    for (var f = Array(g), m = 0; m < g; m++)
      f[m] = arguments[m + 2];
    d.children = f;
  }
  if (a && a.defaultProps)
    for (e in g = a.defaultProps, g)
      d[e] === void 0 && (d[e] = g[e]);
  return {$$typeof: n, type: a, key: k, ref: h, props: d, _owner: G.current};
}
function K(a, b) {
  return {$$typeof: n, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner};
}
function L(a) {
  return typeof a === "object" && a !== null && a.$$typeof === n;
}
function escape(a) {
  var b = {"=": "=0", ":": "=2"};
  return "$" + a.replace(/[=:]/g, function(a2) {
    return b[a2];
  });
}
var M = /\/+/g;
function N(a, b) {
  return typeof a === "object" && a !== null && a.key != null ? escape("" + a.key) : b.toString(36);
}
function O(a, b, c, e, d) {
  var k = typeof a;
  if (k === "undefined" || k === "boolean")
    a = null;
  var h = false;
  if (a === null)
    h = true;
  else
    switch (k) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case n:
          case p:
            h = true;
        }
    }
  if (h)
    return h = a, d = d(h), a = e === "" ? "." + N(h, 0) : e, Array.isArray(d) ? (c = "", a != null && (c = a.replace(M, "$&/") + "/"), O(d, b, c, "", function(a2) {
      return a2;
    })) : d != null && (L(d) && (d = K(d, c + (!d.key || h && h.key === d.key ? "" : ("" + d.key).replace(M, "$&/") + "/") + a)), b.push(d)), 1;
  h = 0;
  e = e === "" ? "." : e + ":";
  if (Array.isArray(a))
    for (var g = 0; g < a.length; g++) {
      k = a[g];
      var f = e + N(k, g);
      h += O(k, b, c, f, d);
    }
  else if (f = y(a), typeof f === "function")
    for (a = f.call(a), g = 0; !(k = a.next()).done; )
      k = k.value, f = e + N(k, g++), h += O(k, b, c, f, d);
  else if (k === "object")
    throw b = "" + a, Error(z(31, b === "[object Object]" ? "object with keys {" + Object.keys(a).join(", ") + "}" : b));
  return h;
}
function P(a, b, c) {
  if (a == null)
    return a;
  var e = [], d = 0;
  O(a, e, "", "", function(a2) {
    return b.call(c, a2, d++);
  });
  return e;
}
function Q(a) {
  if (a._status === -1) {
    var b = a._result;
    b = b();
    a._status = 0;
    a._result = b;
    b.then(function(b2) {
      a._status === 0 && (b2 = b2.default, a._status = 1, a._result = b2);
    }, function(b2) {
      a._status === 0 && (a._status = 2, a._result = b2);
    });
  }
  if (a._status === 1)
    return a._result;
  throw a._result;
}
var R = {current: null};
function S() {
  var a = R.current;
  if (a === null)
    throw Error(z(321));
  return a;
}
var T = {ReactCurrentDispatcher: R, ReactCurrentBatchConfig: {transition: 0}, ReactCurrentOwner: G, IsSomeRendererActing: {current: false}, assign: l};
__webpack_unused_export__ = {map: P, forEach: function(a, b, c) {
  P(a, function() {
    b.apply(this, arguments);
  }, c);
}, count: function(a) {
  var b = 0;
  P(a, function() {
    b++;
  });
  return b;
}, toArray: function(a) {
  return P(a, function(a2) {
    return a2;
  }) || [];
}, only: function(a) {
  if (!L(a))
    throw Error(z(143));
  return a;
}};
__webpack_unused_export__ = C;
__webpack_unused_export__ = E;
__webpack_unused_export__ = T;
__webpack_unused_export__ = function(a, b, c) {
  if (a === null || a === void 0)
    throw Error(z(267, a));
  var e = l({}, a.props), d = a.key, k = a.ref, h = a._owner;
  if (b != null) {
    b.ref !== void 0 && (k = b.ref, h = G.current);
    b.key !== void 0 && (d = "" + b.key);
    if (a.type && a.type.defaultProps)
      var g = a.type.defaultProps;
    for (f in b)
      H.call(b, f) && !I.hasOwnProperty(f) && (e[f] = b[f] === void 0 && g !== void 0 ? g[f] : b[f]);
  }
  var f = arguments.length - 2;
  if (f === 1)
    e.children = c;
  else if (1 < f) {
    g = Array(f);
    for (var m = 0; m < f; m++)
      g[m] = arguments[m + 2];
    e.children = g;
  }
  return {
    $$typeof: n,
    type: a.type,
    key: d,
    ref: k,
    props: e,
    _owner: h
  };
};
__webpack_unused_export__ = function(a, b) {
  b === void 0 && (b = null);
  a = {$$typeof: r, _calculateChangedBits: b, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null};
  a.Provider = {$$typeof: q, _context: a};
  return a.Consumer = a;
};
__webpack_unused_export__ = J;
__webpack_unused_export__ = function(a) {
  var b = J.bind(null, a);
  b.type = a;
  return b;
};
__webpack_unused_export__ = function() {
  return {current: null};
};
__webpack_unused_export__ = function(a) {
  return {$$typeof: t, render: a};
};
__webpack_unused_export__ = L;
__webpack_unused_export__ = function(a) {
  return {$$typeof: v, _payload: {_status: -1, _result: a}, _init: Q};
};
__webpack_unused_export__ = function(a, b) {
  return {$$typeof: u, type: a, compare: b === void 0 ? null : b};
};
__webpack_unused_export__ = function(a, b) {
  return S().useCallback(a, b);
};
__webpack_unused_export__ = function(a, b) {
  return S().useContext(a, b);
};
__webpack_unused_export__ = function() {
};
exports.useEffect = function(a, b) {
  return S().useEffect(a, b);
};
__webpack_unused_export__ = function(a, b, c) {
  return S().useImperativeHandle(a, b, c);
};
exports.useLayoutEffect = function(a, b) {
  return S().useLayoutEffect(a, b);
};
__webpack_unused_export__ = function(a, b) {
  return S().useMemo(a, b);
};
exports.useReducer = function(a, b, c) {
  return S().useReducer(a, b, c);
};
exports.useRef = function(a) {
  return S().useRef(a);
};
__webpack_unused_export__ = function(a) {
  return S().useState(a);
};
__webpack_unused_export__ = "17.0.2";


/***/ }),

/***/ 4339:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (true) {
  module.exports = __webpack_require__(2367);
} else {}


/***/ }),

/***/ 7684:
/***/ ((module) => {

var runtime = function(exports) {
  "use strict";
  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined;
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }
  function wrap(innerFn, outerFn, self, tryLocsList) {
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);
    generator._invoke = makeInvokeMethod(innerFn, self, context);
    return generator;
  }
  exports.wrap = wrap;
  function tryCatch(fn, obj, arg) {
    try {
      return {type: "normal", arg: fn.call(obj, arg)};
    } catch (err) {
      return {type: "throw", arg: err};
    }
  }
  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";
  var ContinueSentinel = {};
  function Generator() {
  }
  function GeneratorFunction() {
  }
  function GeneratorFunctionPrototype() {
  }
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function() {
    return this;
  };
  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    IteratorPrototype = NativeIteratorPrototype;
  }
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction");
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }
  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor ? ctor === GeneratorFunction || (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
  };
  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };
  exports.awrap = function(arg) {
    return {__await: arg};
  };
  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value2) {
            invoke("next", value2, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }
        return PromiseImpl.resolve(value).then(function(unwrapped) {
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          return invoke("throw", error, resolve, reject);
        });
      }
    }
    var previousPromise;
    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }
      return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    }
    this._invoke = enqueue;
  }
  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function() {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0)
      PromiseImpl = Promise;
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
      return result.done ? result.value : iter.next();
    });
  };
  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;
    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }
      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }
        return doneResult();
      }
      context.method = method;
      context.arg = arg;
      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel)
              continue;
            return delegateResult;
          }
        }
        if (context.method === "next") {
          context.sent = context._sent = context.arg;
        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }
          context.dispatchException(context.arg);
        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }
        state = GenStateExecuting;
        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          state = context.done ? GenStateCompleted : GenStateSuspendedYield;
          if (record.arg === ContinueSentinel) {
            continue;
          }
          return {
            value: record.arg,
            done: context.done
          };
        } else if (record.type === "throw") {
          state = GenStateCompleted;
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      context.delegate = null;
      if (context.method === "throw") {
        if (delegate.iterator["return"]) {
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);
          if (context.method === "throw") {
            return ContinueSentinel;
          }
        }
        context.method = "throw";
        context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }
      return ContinueSentinel;
    }
    var record = tryCatch(method, delegate.iterator, context.arg);
    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }
    var info = record.arg;
    if (!info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }
    if (info.done) {
      context[delegate.resultName] = info.value;
      context.next = delegate.nextLoc;
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }
    } else {
      return info;
    }
    context.delegate = null;
    return ContinueSentinel;
  }
  defineIteratorMethods(Gp);
  define(Gp, toStringTagSymbol, "Generator");
  Gp[iteratorSymbol] = function() {
    return this;
  };
  Gp.toString = function() {
    return "[object Generator]";
  };
  function pushTryEntry(locs) {
    var entry = {tryLoc: locs[0]};
    if (1 in locs) {
      entry.catchLoc = locs[1];
    }
    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }
    this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }
  function Context(tryLocsList) {
    this.tryEntries = [{tryLoc: "root"}];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }
  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();
    return function next() {
      while (keys.length) {
        var key2 = keys.pop();
        if (key2 in object) {
          next.value = key2;
          next.done = false;
          return next;
        }
      }
      next.done = true;
      return next;
    };
  };
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }
      if (typeof iterable.next === "function") {
        return iterable;
      }
      if (!isNaN(iterable.length)) {
        var i = -1, next = function next2() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next2.value = iterable[i];
              next2.done = false;
              return next2;
            }
          }
          next2.value = undefined;
          next2.done = true;
          return next2;
        };
        return next.next = next;
      }
    }
    return {next: doneResult};
  }
  exports.values = values;
  function doneResult() {
    return {value: undefined, done: true};
  }
  Context.prototype = {
    constructor: Context,
    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;
      this.method = "next";
      this.arg = undefined;
      this.tryEntries.forEach(resetTryEntry);
      if (!skipTempReset) {
        for (var name in this) {
          if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },
    stop: function() {
      this.done = true;
      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }
      return this.rval;
    },
    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }
      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        if (caught) {
          context.method = "next";
          context.arg = undefined;
        }
        return !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;
        if (entry.tryLoc === "root") {
          return handle("end");
        }
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }
          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },
    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
        finallyEntry = null;
      }
      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;
      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }
      return this.complete(record);
    },
    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }
      if (record.type === "break" || record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
      return ContinueSentinel;
    },
    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },
    catch: function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }
      throw new Error("illegal catch attempt");
    },
    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName,
        nextLoc
      };
      if (this.method === "next") {
        this.arg = undefined;
      }
      return ContinueSentinel;
    }
  };
  return exports;
}( true ? module.exports : 0);
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  Function("r", "regeneratorRuntime = r")(runtime);
}


/***/ }),

/***/ 1818:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;

__webpack_unused_export__ = ({value: true});
var _asyncToGenerator = __webpack_require__(1327);
var _extends = __webpack_require__(2186);
var _regeneratorRuntime = __webpack_require__(9096);
function _interopDefaultLegacy(e) {
  return e && typeof e === "object" && "default" in e ? e : {default: e};
}
var _asyncToGenerator__default = /* @__PURE__ */ _interopDefaultLegacy(_asyncToGenerator);
var _extends__default = /* @__PURE__ */ _interopDefaultLegacy(_extends);
var _regeneratorRuntime__default = /* @__PURE__ */ _interopDefaultLegacy(_regeneratorRuntime);
var redux = function redux2(reducer, initial) {
  return function(set, get, api) {
    api.dispatch = function(action) {
      set(function(state) {
        return reducer(state, action);
      });
      if (api.devtools) {
        api.devtools.send(api.devtools.prefix + action.type, get());
      }
      return action;
    };
    return _extends__default["default"]({
      dispatch: api.dispatch
    }, initial);
  };
};
var devtools = function devtools2(fn, prefix) {
  return function(set, get, api) {
    var extension;
    try {
      extension = window.__REDUX_DEVTOOLS_EXTENSION__ || window.top.__REDUX_DEVTOOLS_EXTENSION__;
    } catch (_unused) {
    }
    if (!extension) {
      if (false) {}
      api.devtools = null;
      return fn(set, get, api);
    }
    var namedSet = function namedSet2(state, replace, name) {
      set(state, replace);
      if (!api.dispatch) {
        api.devtools.send(api.devtools.prefix + (name || "action"), get());
      }
    };
    var initialState = fn(namedSet, get, api);
    if (!api.devtools) {
      var savedSetState = api.setState;
      api.setState = function(state, replace) {
        savedSetState(state, replace);
        api.devtools.send(api.devtools.prefix + "setState", api.getState());
      };
      api.devtools = extension.connect({
        name: prefix
      });
      api.devtools.prefix = prefix ? prefix + " > " : "";
      api.devtools.subscribe(function(message) {
        var _message$payload;
        if (message.type === "DISPATCH" && message.state) {
          var ignoreState = message.payload.type === "JUMP_TO_ACTION" || message.payload.type === "JUMP_TO_STATE";
          if (!api.dispatch && !ignoreState) {
            api.setState(JSON.parse(message.state));
          } else {
            savedSetState(JSON.parse(message.state));
          }
        } else if (message.type === "DISPATCH" && ((_message$payload = message.payload) == null ? void 0 : _message$payload.type) === "COMMIT") {
          api.devtools.init(api.getState());
        }
      });
      api.devtools.init(initialState);
    }
    return initialState;
  };
};
var combine = function combine2(initialState, create) {
  return function(set, get, api) {
    return Object.assign({}, initialState, create(set, get, api));
  };
};
var persist = function persist2(config, options) {
  return function(set, get, api) {
    var _ref = options || {}, name = _ref.name, _ref$getStorage = _ref.getStorage, getStorage = _ref$getStorage === void 0 ? function() {
      return localStorage;
    } : _ref$getStorage, _ref$serialize = _ref.serialize, serialize = _ref$serialize === void 0 ? JSON.stringify : _ref$serialize, _ref$deserialize = _ref.deserialize, deserialize = _ref$deserialize === void 0 ? JSON.parse : _ref$deserialize, blacklist = _ref.blacklist, whitelist = _ref.whitelist, onRehydrateStorage = _ref.onRehydrateStorage, _ref$version = _ref.version, version = _ref$version === void 0 ? 0 : _ref$version, migrate = _ref.migrate;
    var storage;
    try {
      storage = getStorage();
    } catch (e) {
    }
    if (!storage) {
      return config(function() {
        console.warn("Persist middleware: unable to update " + name + ", the given storage is currently unavailable.");
        set.apply(void 0, arguments);
      }, get, api);
    }
    var setItem = /* @__PURE__ */ function() {
      var _ref2 = _asyncToGenerator__default["default"](/* @__PURE__ */ _regeneratorRuntime__default["default"].mark(function _callee() {
        var _storage;
        var state;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                state = _extends__default["default"]({}, get());
                if (whitelist) {
                  Object.keys(state).forEach(function(key) {
                    !whitelist.includes(key) && delete state[key];
                  });
                }
                if (blacklist) {
                  blacklist.forEach(function(key) {
                    return delete state[key];
                  });
                }
                if (!((_storage = storage) == null)) {
                  _context.next = 7;
                  break;
                }
                _context.t0 = void 0;
                _context.next = 13;
                break;
              case 7:
                _context.t1 = _storage;
                _context.t2 = name;
                _context.next = 11;
                return serialize({
                  state,
                  version
                });
              case 11:
                _context.t3 = _context.sent;
                _context.t0 = _context.t1.setItem.call(_context.t1, _context.t2, _context.t3);
              case 13:
                return _context.abrupt("return", _context.t0);
              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
      return function setItem2() {
        return _ref2.apply(this, arguments);
      };
    }();
    var savedSetState = api.setState;
    api.setState = function(state, replace) {
      savedSetState(state, replace);
      setItem();
    };
    _asyncToGenerator__default["default"](/* @__PURE__ */ _regeneratorRuntime__default["default"].mark(function _callee2() {
      var postRehydrationCallback, storageValue, deserializedStorageValue, migratedState;
      return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              postRehydrationCallback = (onRehydrateStorage == null ? void 0 : onRehydrateStorage(get())) || void 0;
              _context2.prev = 1;
              _context2.next = 4;
              return storage.getItem(name);
            case 4:
              storageValue = _context2.sent;
              if (!storageValue) {
                _context2.next = 20;
                break;
              }
              _context2.next = 8;
              return deserialize(storageValue);
            case 8:
              deserializedStorageValue = _context2.sent;
              if (!(deserializedStorageValue.version !== version)) {
                _context2.next = 19;
                break;
              }
              _context2.next = 12;
              return migrate == null ? void 0 : migrate(deserializedStorageValue.state, deserializedStorageValue.version);
            case 12:
              migratedState = _context2.sent;
              if (!migratedState) {
                _context2.next = 17;
                break;
              }
              set(migratedState);
              _context2.next = 17;
              return setItem();
            case 17:
              _context2.next = 20;
              break;
            case 19:
              set(deserializedStorageValue.state);
            case 20:
              _context2.next = 26;
              break;
            case 22:
              _context2.prev = 22;
              _context2.t0 = _context2["catch"](1);
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, _context2.t0);
              return _context2.abrupt("return");
            case 26:
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(get(), void 0);
            case 27:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 22]]);
    }))();
    return config(function() {
      set.apply(void 0, arguments);
      setItem();
    }, get, api);
  };
};
__webpack_unused_export__ = combine;
__webpack_unused_export__ = devtools;
exports.tJ = persist;
__webpack_unused_export__ = redux;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ./src/shared/Browser.js
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","RUNTIME_CHROME_EXTENSION_ID":"","RUNTIME_EXTENSION_DEV_LOCALHOST":"false","RUNTIME_EXTENSION_DEV_WATCH":"true","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const Browser = (useBrowser);

// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
;// CONCATENATED MODULE: ../node_modules/zustand/index.js

function create$1(createState) {
  let state;
  const listeners = new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (nextState !== state) {
      const previousState = state;
      state = replace ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const subscribeWithSelector = (listener, selector = getState, equalityFn = Object.is) => {
    let currentSlice = selector(state);
    function listenerToAdd() {
      const nextSlice = selector(state);
      if (!equalityFn(currentSlice, nextSlice)) {
        const previousSlice = currentSlice;
        listener(currentSlice = nextSlice, previousSlice);
      }
    }
    listeners.add(listenerToAdd);
    return () => listeners.delete(listenerToAdd);
  };
  const subscribe = (listener, selector, equalityFn) => {
    if (selector || equalityFn) {
      return subscribeWithSelector(listener, selector, equalityFn);
    }
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const destroy = () => listeners.clear();
  const api = {
    setState,
    getState,
    subscribe,
    destroy
  };
  state = createState(setState, getState, api);
  return api;
}
const useIsoLayoutEffect = typeof window === "undefined" ? react.useEffect : react.useLayoutEffect;
function create(createState) {
  const api = typeof createState === "function" ? create$1(createState) : createState;
  const useStore = (selector = api.getState, equalityFn = Object.is) => {
    const [, forceUpdate] = (0,react.useReducer)((c) => c + 1, 0);
    const state = api.getState();
    const stateRef = (0,react.useRef)(state);
    const selectorRef = (0,react.useRef)(selector);
    const equalityFnRef = (0,react.useRef)(equalityFn);
    const erroredRef = (0,react.useRef)(false);
    const currentSliceRef = (0,react.useRef)();
    if (currentSliceRef.current === void 0) {
      currentSliceRef.current = selector(state);
    }
    let newStateSlice;
    let hasNewStateSlice = false;
    if (stateRef.current !== state || selectorRef.current !== selector || equalityFnRef.current !== equalityFn || erroredRef.current) {
      newStateSlice = selector(state);
      hasNewStateSlice = !equalityFn(currentSliceRef.current, newStateSlice);
    }
    useIsoLayoutEffect(() => {
      if (hasNewStateSlice) {
        currentSliceRef.current = newStateSlice;
      }
      stateRef.current = state;
      selectorRef.current = selector;
      equalityFnRef.current = equalityFn;
      erroredRef.current = false;
    });
    const stateBeforeSubscriptionRef = (0,react.useRef)(state);
    useIsoLayoutEffect(() => {
      const listener = () => {
        try {
          const nextState = api.getState();
          const nextStateSlice = selectorRef.current(nextState);
          if (!equalityFnRef.current(currentSliceRef.current, nextStateSlice)) {
            stateRef.current = nextState;
            currentSliceRef.current = nextStateSlice;
            forceUpdate();
          }
        } catch (error) {
          erroredRef.current = true;
          forceUpdate();
        }
      };
      const unsubscribe = api.subscribe(listener);
      if (api.getState() !== stateBeforeSubscriptionRef.current) {
        listener();
      }
      return unsubscribe;
    }, []);
    return hasNewStateSlice ? newStateSlice : currentSliceRef.current;
  };
  Object.assign(useStore, api);
  useStore[Symbol.iterator] = function* () {
    console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
    yield useStore;
    yield api;
  };
  return useStore;
}
/* harmony default export */ const zustand = (create);

// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(1818);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/style/properties.js
/* harmony default export */ const properties = ({
  "--font-family-default": "'DNB', sans-serif",
  "--font-family-monospace": "'DNBMono', 'Menlo', 'Consolas', 'Roboto Mono',",
  "--font-weight-default": "normal",
  "--font-weight-basis": "normal",
  "--font-weight-regular": "normal",
  "--font-weight-medium": "500",
  "--font-weight-bold": "600",
  "--font-size-x-small": "0.875rem",
  "--font-size-small": "1rem",
  "--font-size-basis": "1.125rem",
  "--font-size-basis--em": "1em",
  "--font-size-medium": "1.25rem",
  "--font-size-large": "1.625rem",
  "--font-size-x-large": "2.125rem",
  "--font-size-xx-large": "3rem",
  "--line-height-xx-small--em": "1em",
  "--line-height-x-small": "1.125rem",
  "--line-height-small": "1.25rem",
  "--line-height-basis": "1.5rem",
  "--line-height-basis--em": "1.333em",
  "--line-height-medium": "2rem",
  "--line-height-large": "2.5rem",
  "--line-height-x-large": "3.5rem",
  "--color-mint-green-50": "#d2f0e9",
  "--color-mint-green-25": "#e9f8f4",
  "--color-mint-green-12": "#f4fbf9",
  "--color-sea-green-30": "#b3dada",
  "--color-accent-yellow-30": "#feebc1",
  "--color-signal-orange": "#ff5400",
  "--color-fire-red": "#dc2a2a",
  "--color-success-green": "#008000",
  "--color-fire-red-8": "#fdeeee",
  "--color-black": "#000",
  "--color-black-80": "#333",
  "--color-black-55": "#737373",
  "--color-black-20": "#ccc",
  "--color-black-8": "#ebebeb",
  "--color-black-3": "#f8f8f8",
  "--color-white": "#fff",
  "--color-black-border": "#cdcdcd",
  "--color-black-background": "#fafafa",
  "--color-sea-green": "#007272",
  "--color-mint-green": "#a5e1d2",
  "--color-summer-green": "#28b482",
  "--color-emerald-green": "#14555a",
  "--color-ocean-green": "#00343e",
  "--color-accent-yellow": "#fdbb31",
  "--color-indigo": "#23195a",
  "--color-violet": "#6e2382",
  "--color-sky-blue": "#4bbed2",
  "--color-lavender": "#f2f2f5",
  "--color-sand-yellow": "#fbf6ec",
  "--color-pistachio": "#f2f4ec",
  "--color-mint-green-alt": "#ebfffa",
  "--color-indigo-medium": "#6e6491",
  "--color-indigo-light": "#b9afc8",
  "--color-violet-medium": "#a06eaf",
  "--color-violet-light": "#cfb9d7",
  "--color-sky-blue-medium": "#87d2e1",
  "--color-sky-blue-light": "#c3ebf0",
  "--spacing-xx-small": "0.25rem",
  "--spacing-x-small": "0.5rem",
  "--spacing-small": "1rem",
  "--spacing-medium": "1.5rem",
  "--spacing-large": "2rem",
  "--spacing-x-large": "3rem",
  "--spacing-xx-large": "3.5rem",
  "--layout-small": "40em",
  "--layout-medium": "50em",
  "--layout-large": "60em",
  "--layout-x-large": "72em",
  "--layout-xx-large": "80em",
  "--layout-xxx-large": "90em"
});

;// CONCATENATED MODULE: ./src/shared/ColorController.js

const originalColorsAsObject = getOriginalColorsAsObject();
const originalColorsAsArray = getOriginalColorsAsArray();
function fillRemaningColors(originalColorsList, customColorsList) {
  const keyRef = originalColorsAsObject;
  const notInList = (customColorsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalColorsList.map((item) => ({
    ...item,
    ...(customColorsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalColorsAsArray() {
  const colors = Object.entries(originalColorsAsObject).map(([key, value]) => {
    const name = key.replace(/--color-/g, " ").replace(/-/g, " ").trim().replace(/(^|\s)([a-z])/g, (s) => s.toUpperCase());
    return {key, name, value};
  });
  return colors;
}
function getOriginalColorsAsObject() {
  const colors = Object.entries(properties).filter(([name]) => name.includes("--color-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("-border"))
      delete acc[key];
    if (key.includes("-background"))
      delete acc[key];
    if (key.includes("-light"))
      delete acc[key];
    if (key.includes("-medium"))
      delete acc[key];
    return acc;
  }, {});
  delete colors["--color-sea-green-alt-30"];
  delete colors["--color-signal-yellow-30"];
  delete colors["--color-black-30"];
  delete colors["--color-sea-green-alt"];
  delete colors["--color-signal-yellow"];
  return colors;
}
const generateThemeIgnoreColors = () => originalColorsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");

;// CONCATENATED MODULE: ./src/app/core/Store.js




const extensionStorePlain = zustand(themesStore);
const useThemeStore = zustand((0,middleware/* persist */.tJ)(themesStore, getPersistConfig("eufemia-theme-data")));
const Store_useAppStore = zustand((0,middleware/* persist */.tJ)(hostStore, getPersistConfig("eufemia-theme-app")));
const useWindowStore = zustand((0,middleware/* persist */.tJ)(hostStore, getPersistConfig("eufemia-theme-window")));
const useErrorStore = zustand(errorStore);
function useTheme(themeId) {
  const {getTheme} = useThemeStore();
  return getTheme(themeId);
}
function themesStore(set, get) {
  return {
    themes: {},
    getThemes: () => {
      const {getThemeConstructs, themes} = get();
      if (!themes["dnb-ui"]) {
        themes["dnb-ui"] = getThemeConstructs();
        themes["demo"] = getThemeConstructs();
      }
      if (!themes["blue-test"]) {
        themes["blue-test"] = getThemeConstructs();
      }
      if (!themes["2x-test"]) {
        themes["2x-test"] = getThemeConstructs();
      }
      return themes;
    },
    importThemes: (themesData, {overwrite} = {}) => {
      try {
        if (themesData) {
          const existingThemes = get().themes;
          const themes = Object.entries(themesData).reduce((acc, [key, theme]) => {
            if (!["dnb-ui", "blue-test", "2x-test"].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }
            return acc;
          }, {...existingThemes});
          set({themes});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: (themeId) => {
      const {themes, getThemeConstructs} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...getThemeConstructs()};
        set({themes});
      }
    },
    copySelectedTheme: (themeId) => {
      const {themes, selectedThemeId} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...themes[selectedThemeId]};
        set({themes});
      }
    },
    removeTheme: (themeId) => {
      const themes = get().themes;
      if (themes[themeId]) {
        delete themes[themeId];
        set({themes});
      }
    },
    getThemeConstructs: () => {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: (themeId = null) => {
      if (!themeId) {
        themeId = get().selectedThemeId;
      }
      const setState = (object) => {
        const themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object);
        const state = {themes};
        state.selectedThemeId = themeId;
        set(state);
      };
      const getState = () => {
        const theme = get().themes[themeId] || null;
        return theme;
      };
      const getThemeChanges = () => {
        switch (themeId) {
          case "dnb-ui": {
            return [
              ...originalColorsAsArray.map(({key, value}) => ({
                key,
                change: value
              }))
            ];
          }
          case "blue-test": {
            return [
              ...originalColorsAsArray.map(({key}) => ({
                key,
                change: "blue"
              }))
            ];
          }
          case "2x-test": {
            return [
              {
                css: "html{font-size: 200%;}"
              }
            ];
          }
          default: {
            const theme = getState();
            return [
              ...theme?.colorsList || [],
              ...theme?.spacingsList || [],
              ...theme?.fontsizesList || []
            ];
          }
        }
      };
      const changeColor = (origKey, object) => {
        const theme = getState();
        let found = false;
        object.key = origKey;
        const colorsList = (theme?.colorsList || []).map((item) => {
          if (item.key === origKey) {
            item = {...item, ...object};
            found = Boolean(item);
          }
          return item;
        });
        if (!found) {
          colorsList.push(object);
        }
        setState({colorsList});
      };
      const setColor = (origKey, change, fallbackParams = {}) => {
        changeColor(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetColor = (rmKey) => {
        changeColor(rmKey, {
          change: null
        });
      };
      const useColorTools = () => {
        return {
          changeColor,
          setColor,
          resetColor
        };
      };
      const changeSpacing = (origKey, object) => {
        const theme = getState();
        let found;
        const spacingsList = (theme?.spacingsList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          spacingsList.push(Object.assign(object));
        }
        setState({spacingsList});
      };
      const setSpacing = (origKey, change, fallbackParams = {}) => {
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetSpacing = (rmKey) => {
        changeSpacing(rmKey, {
          change: null
        });
      };
      const useSpacingTools = () => {
        return {
          changeSpacing,
          setSpacing,
          resetSpacing
        };
      };
      const changeFontsize = (origKey, object) => {
        const theme = getState();
        let found;
        const fontsizesList = (theme?.fontsizesList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          fontsizesList.push(Object.assign(object));
        }
        setState({fontsizesList});
      };
      const setFontsize = (origKey, change, fallbackParams = {}) => {
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetFontsize = (rmKey) => {
        changeFontsize(rmKey, {
          change: null
        });
      };
      const useFontsizeTools = () => {
        return {
          changeFontsize,
          setFontsize,
          resetFontsize
        };
      };
      return {
        themeId,
        ...getState(),
        setState,
        getState,
        getThemeChanges,
        useColorTools,
        useSpacingTools,
        useFontsizeTools
      };
    }
  };
}
const defaultFallback = {
  enabled: false,
  selectedTab: "colors",
  currentThemeId: null,
  selectedThemeId: "demo"
};
function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: (enabled) => {
      get().setByHost({enabled});
    },
    setFilter: (cacheKey, filter) => {
      const filters = get().getHostData()?.filters || {};
      const existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({filters});
    },
    getFilter: (cacheKey) => {
      const data = get().getHostData();
      return data?.filters ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: (currentThemeId) => {
      get().setByHost({currentThemeId});
    },
    setSelectedThemeId: (selectedThemeId) => {
      get().setByHost({selectedThemeId});
    },
    setSelectedTab: (selectedTab) => {
      get().setByHost({selectedTab});
    },
    getHostData: () => {
      const {hosts} = get();
      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: (data) => {
      const {hosts} = get();
      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({hosts});
    },
    importAppData: (hostsData, {overwrite} = {}) => {
      try {
        if (hostsData) {
          const existingData = get().hosts;
          const hosts = Object.entries(hostsData).reduce((acc, [key, data]) => {
            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }
            return acc;
          }, {...existingData});
          set({hosts});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}
function errorStore(set) {
  return {
    error: null,
    setError: (error) => {
      console.warn(error);
      set({error});
    },
    hideError: () => {
      set({error: null});
    }
  };
}
function getPersistConfig(name) {
  let writeTimeoutId;
  const useBrowserStorage = true;
  return {
    name,
    getStorage: () => ({
      getItem: (name2) => {
        return new Promise((resolve, reject) => {
          if (useBrowserStorage && Browser && Browser.storage !== "undefined") {
            try {
              Browser.storage.sync.get([name2], ({[name2]: themeData}) => {
                if (Browser.runtime.lastError) {
                  useErrorStore.getState().setError(Browser.runtime.lastError.message);
                } else {
                  resolve(themeData);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              resolve(window.localStorage?.getItem(name2) || "{}");
            }
          } else {
            resolve(window.localStorage?.getItem(name2) || "{}");
          }
        });
      },
      setItem: (name2, themeData) => {
        if (useBrowserStorage && Browser && Browser.storage !== "undefined") {
          const write = () => {
            try {
              Browser.storage.sync.set({[name2]: themeData}, () => {
                if (Browser.runtime.lastError) {
                  useErrorStore.getState().setError(Browser.runtime.lastError.message);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              window.localStorage?.setItem(name2, themeData);
            }
          };
          if (!writeTimeoutId) {
            writeTimeoutId = 1;
            write();
          } else {
            clearTimeout(writeTimeoutId);
            writeTimeoutId = setTimeout(() => {
              write();
            }, 1e3);
          }
        } else {
          window.localStorage?.setItem(name2, themeData);
        }
      }
    })
  };
}

;// CONCATENATED MODULE: ./src/shared/Bridge.js



const extensionId =  false || void 0;
function getTabId(cbFunc) {
  if (browser) {
    browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
      const tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests({onResponse = null} = {}) {
  if (!browser) {
    return;
  }
  browser?.runtime?.onMessage?.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-extension-url": {
        getTabId((tabId) => {
          browser.browserAction.getPopup({tabId}, (popup) => {
            response(popup);
          });
        });
        break;
      }
      case "insert-css": {
        const {elementId, css} = request;
        if (typeof css !== "undefined") {
          insertCSS(css, {elementId});
        }
        response(request);
        break;
      }
      case "store-css": {
        const {css} = request;
        if (typeof css !== "undefined") {
          setLocalThemeData({css});
        }
        response(request);
        break;
      }
      case "store-themes": {
        const {themes} = request;
        if (typeof themes !== "undefined") {
          setLocalThemeData({themes});
        }
        response(request);
        break;
      }
      case "get-modifications": {
        const modifications = JSON.parse(window.localStorage.getItem("eufemia-theme-editor") || "{}");
        response({modifications});
        break;
      }
      default:
        response(request);
        return false;
    }
    if (typeof onResponse === "function") {
      onResponse(request);
    }
    return true;
  });
}
function getThemesAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToRuntime({
          type: "get-themes"
        }, (response) => {
          resolve(response || {themes: []});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({themes: null});
    }
  });
}
function getModificationsFromContentAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToTab({
          type: "get-modifications"
        }, (response) => {
          resolve(response || {modifications: {}});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({modifications: {}});
    }
  });
}
function getLocalThemeData() {
  return JSON.parse(window.localStorage?.getItem("eufemia-theme-content") || "{}");
}
function setLocalThemeData(data) {
  const localData = getLocalThemeData();
  window.localStorage?.setItem("eufemia-theme-content", JSON.stringify({...localData, ...data}));
}
function setLocalThemeCSS() {
  const localData = getLocalThemeData();
  if (localData && localData.css) {
    insertCSS(localData.css, {elementId: "eufemia-theme"});
  }
}
function hasEnabledLocalThemeData() {
  const localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data, responseFunc = null) {
  sendMessageToTab({type: "insert-css", ...data}, responseFunc);
}
function storeCSSInPage(data, responseFunc = null) {
  sendMessageToTab({type: "store-css", ...data}, responseFunc);
}
async function getHost() {
  return new Promise((resolve) => {
    if (browser) {
      browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
        const url = new URL(tabs[0].url);
        resolve(url.hostname);
      });
    } else {
      resolve("localhost");
    }
  });
}
function storeThemesInPage(themes, responseFunc = null) {
  sendMessageToRuntime({type: "set-themes", themes}, responseFunc);
  sendMessageToTab({type: "store-themes", themes}, responseFunc);
}
function sendMessageToRuntime(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  browser?.runtime?.sendMessage(extensionId, data, responseFunc);
}
function sendMessageToTab(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  if (browser) {
    getTabId((tabId) => {
      const themeId = window.EXTENSION_HOST ? useAppStore.getState().getHostData().currentThemeId : null;
      browser?.tabs.sendMessage(tabId, Object.assign(data, {themeId}), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc("localhost");
  }
}
function listenForBackgroundMessages() {
  Browser.runtime.onMessage.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-themes": {
        const {themes} = useThemeStore.getState();
        response({themes});
        break;
      }
      case "set-themes": {
        const {themes} = request;
        useThemeStore.setState({themes});
        response({themes});
        break;
      }
      default:
        return false;
    }
    return true;
  });
}

;// CONCATENATED MODULE: ./src/extension/background.js

listenForBackgroundMessages();

})();

/******/ })()
;
//# sourceMappingURL=background.js.map