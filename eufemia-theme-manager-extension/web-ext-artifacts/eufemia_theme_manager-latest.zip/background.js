/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 32872:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


;// CONCATENATED MODULE: ./src/shared/Browser.js
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const Browser = (useBrowser);

// EXTERNAL MODULE: ../node_modules/zustand/index.js
var zustand = __webpack_require__(2742);
// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(71818);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/style/properties.js
var properties = __webpack_require__(37034);
;// CONCATENATED MODULE: ./src/shared/ColorController.js

const originalColorsAsObject = getOriginalColorsAsObject();
const originalColorsAsArray = getOriginalColorsAsArray();
function fillRemaningColors(originalColorsList, customColorsList) {
  const keyRef = originalColorsAsObject;
  const notInList = (customColorsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalColorsList.map((item) => ({
    ...item,
    ...(customColorsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalColorsAsArray() {
  const colors = Object.entries(originalColorsAsObject).map(([key, value]) => {
    const name = key.replace(/--color-/g, " ").replace(/-/g, " ").trim().replace(/(^|\s)([a-z])/g, (s) => s.toUpperCase());
    return {key, name, value};
  });
  return colors;
}
function getOriginalColorsAsObject() {
  const colors = Object.entries(properties/* default */.Z).filter(([name]) => name.includes("--color-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("-border"))
      delete acc[key];
    if (key.includes("-background"))
      delete acc[key];
    if (key.includes("-light"))
      delete acc[key];
    if (key.includes("-medium"))
      delete acc[key];
    return acc;
  }, {});
  delete colors["--color-sea-green-alt-30"];
  delete colors["--color-signal-yellow-30"];
  delete colors["--color-black-30"];
  delete colors["--color-sea-green-alt"];
  delete colors["--color-signal-yellow"];
  return colors;
}
const generateThemeIgnoreColors = () => originalColorsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");

;// CONCATENATED MODULE: ./src/app/core/Store.js




const extensionStorePlain = (0,zustand/* default */.Z)(themesStore);
const useThemeStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)(themesStore, getPersistConfig("eufemia-theme-data")));
const Store_useAppStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)(hostStore, getPersistConfig("eufemia-theme-app")));
const useWindowStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)(hostStore, getPersistConfig("eufemia-theme-window")));
const useErrorStore = (0,zustand/* default */.Z)(errorStore);
function useTheme(themeId) {
  const {getTheme} = useThemeStore();
  return getTheme(themeId);
}
function themesStore(set, get) {
  return {
    themes: {},
    getThemes: () => {
      const {getThemeConstructs, themes} = get();
      if (!themes["dnb-ui"]) {
        themes["dnb-ui"] = getThemeConstructs();
        themes["demo"] = getThemeConstructs();
      }
      if (!themes["blue-test"]) {
        themes["blue-test"] = getThemeConstructs();
      }
      if (!themes["2x-test"]) {
        themes["2x-test"] = getThemeConstructs();
      }
      return themes;
    },
    importThemes: (themesData, {overwrite} = {}) => {
      try {
        if (themesData) {
          const existingThemes = get().themes;
          const themes = Object.entries(themesData).reduce((acc, [key, theme]) => {
            if (!["dnb-ui", "blue-test", "2x-test"].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }
            return acc;
          }, {...existingThemes});
          set({themes});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: (themeId) => {
      const {themes, getThemeConstructs} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...getThemeConstructs()};
        set({themes});
      }
    },
    copySelectedTheme: (themeId) => {
      const {themes, selectedThemeId} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...themes[selectedThemeId]};
        set({themes});
      }
    },
    removeTheme: (themeId) => {
      const themes = get().themes;
      if (themes[themeId]) {
        delete themes[themeId];
        set({themes});
      }
    },
    getThemeConstructs: () => {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: (themeId = null) => {
      if (!themeId) {
        themeId = get().selectedThemeId;
      }
      const setState = (object) => {
        const themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object);
        const state = {themes};
        state.selectedThemeId = themeId;
        set(state);
      };
      const getState = () => {
        const theme = get().themes[themeId] || null;
        return theme;
      };
      const getThemeChanges = () => {
        switch (themeId) {
          case "dnb-ui": {
            return [
              ...originalColorsAsArray.map(({key, value}) => ({
                key,
                change: value
              }))
            ];
          }
          case "blue-test": {
            return [
              ...originalColorsAsArray.map(({key}) => ({
                key,
                change: "blue"
              }))
            ];
          }
          case "2x-test": {
            return [
              {
                css: "html{font-size: 200%;}"
              }
            ];
          }
          default: {
            const theme = getState();
            return [
              ...theme?.colorsList || [],
              ...theme?.spacingsList || [],
              ...theme?.fontsizesList || []
            ];
          }
        }
      };
      const changeColor = (origKey, object) => {
        const theme = getState();
        let found = false;
        object.key = origKey;
        const colorsList = (theme?.colorsList || []).map((item) => {
          if (item.key === origKey) {
            item = {...item, ...object};
            found = Boolean(item);
          }
          return item;
        });
        if (!found) {
          colorsList.push(object);
        }
        setState({colorsList});
      };
      const setColor = (origKey, change, fallbackParams = {}) => {
        changeColor(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetColor = (rmKey) => {
        changeColor(rmKey, {
          change: null
        });
      };
      const useColorTools = () => {
        return {
          changeColor,
          setColor,
          resetColor
        };
      };
      const changeSpacing = (origKey, object) => {
        const theme = getState();
        let found;
        const spacingsList = (theme?.spacingsList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          spacingsList.push(Object.assign(object));
        }
        setState({spacingsList});
      };
      const setSpacing = (origKey, change, fallbackParams = {}) => {
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetSpacing = (rmKey) => {
        changeSpacing(rmKey, {
          change: null
        });
      };
      const useSpacingTools = () => {
        return {
          changeSpacing,
          setSpacing,
          resetSpacing
        };
      };
      const changeFontsize = (origKey, object) => {
        const theme = getState();
        let found;
        const fontsizesList = (theme?.fontsizesList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          fontsizesList.push(Object.assign(object));
        }
        setState({fontsizesList});
      };
      const setFontsize = (origKey, change, fallbackParams = {}) => {
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetFontsize = (rmKey) => {
        changeFontsize(rmKey, {
          change: null
        });
      };
      const useFontsizeTools = () => {
        return {
          changeFontsize,
          setFontsize,
          resetFontsize
        };
      };
      return {
        themeId,
        ...getState(),
        setState,
        getState,
        getThemeChanges,
        useColorTools,
        useSpacingTools,
        useFontsizeTools
      };
    }
  };
}
const defaultFallback = {
  enabled: false,
  selectedTab: "colors",
  currentThemeId: null,
  selectedThemeId: "demo"
};
function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: (enabled) => {
      get().setByHost({enabled});
    },
    setFilter: (cacheKey, filter) => {
      const filters = get().getHostData()?.filters || {};
      const existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({filters});
    },
    getFilter: (cacheKey) => {
      const data = get().getHostData();
      return data?.filters ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: (currentThemeId) => {
      get().setByHost({currentThemeId});
    },
    setSelectedThemeId: (selectedThemeId) => {
      get().setByHost({selectedThemeId});
    },
    setSelectedTab: (selectedTab) => {
      get().setByHost({selectedTab});
    },
    getHostData: () => {
      const {hosts} = get();
      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: (data) => {
      const {hosts} = get();
      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({hosts});
    },
    importAppData: (hostsData, {overwrite} = {}) => {
      try {
        if (hostsData) {
          const existingData = get().hosts;
          const hosts = Object.entries(hostsData).reduce((acc, [key, data]) => {
            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }
            return acc;
          }, {...existingData});
          set({hosts});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}
function errorStore(set) {
  return {
    error: null,
    setError: (error) => {
      console.warn(error);
      set({error});
    },
    hideError: () => {
      set({error: null});
    }
  };
}
function getPersistConfig(name) {
  let writeTimeoutId;
  const useBrowserStorage = true;
  return {
    name,
    getStorage: () => ({
      getItem: (name2) => {
        return new Promise((resolve, reject) => {
          if (useBrowserStorage && Browser && Browser.storage !== "undefined") {
            try {
              Browser.storage.sync.get([name2], ({[name2]: themeData}) => {
                if (Browser.runtime.lastError) {
                  useErrorStore.getState().setError(Browser.runtime.lastError.message);
                } else {
                  resolve(themeData);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              resolve(window.localStorage?.getItem(name2) || "{}");
            }
          } else {
            resolve(window.localStorage?.getItem(name2) || "{}");
          }
        });
      },
      setItem: (name2, themeData) => {
        if (useBrowserStorage && Browser && Browser.storage !== "undefined") {
          const write = () => {
            try {
              Browser.storage.sync.set({[name2]: themeData}, () => {
                if (Browser.runtime.lastError) {
                  useErrorStore.getState().setError(Browser.runtime.lastError.message);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              window.localStorage?.setItem(name2, themeData);
            }
          };
          if (!writeTimeoutId) {
            writeTimeoutId = 1;
            write();
          } else {
            clearTimeout(writeTimeoutId);
            writeTimeoutId = setTimeout(() => {
              write();
            }, 1e3);
          }
        } else {
          window.localStorage?.setItem(name2, themeData);
        }
      }
    })
  };
}

;// CONCATENATED MODULE: ./src/shared/Bridge.js



const extensionId =  false || void 0;
function getTabId(cbFunc) {
  if (browser) {
    browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
      const tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests({onResponse = null} = {}) {
  if (!browser) {
    return;
  }
  browser?.runtime?.onMessage?.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-extension-url": {
        getTabId((tabId) => {
          browser.browserAction.getPopup({tabId}, (popup) => {
            response(popup);
          });
        });
        break;
      }
      case "insert-css": {
        const {elementId, css} = request;
        if (typeof css !== "undefined") {
          insertCSS(css, {elementId});
        }
        response(request);
        break;
      }
      case "store-css": {
        const {css} = request;
        if (typeof css !== "undefined") {
          setLocalThemeData({css});
        }
        response(request);
        break;
      }
      case "store-themes": {
        const {themes} = request;
        if (typeof themes !== "undefined") {
          setLocalThemeData({themes});
        }
        response(request);
        break;
      }
      case "get-modifications": {
        const modifications = JSON.parse(window.localStorage.getItem("eufemia-theme-editor") || "{}");
        response({modifications});
        break;
      }
      default:
        response(request);
        return false;
    }
    if (typeof onResponse === "function") {
      onResponse(request);
    }
    return true;
  });
}
function getThemesAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToRuntime({
          type: "get-themes"
        }, (response) => {
          resolve(response || {themes: []});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({themes: null});
    }
  });
}
function getModificationsFromContentAsync() {
  return new Promise((resolve, reject) => {
    if (browser) {
      try {
        sendMessageToTab({
          type: "get-modifications"
        }, (response) => {
          resolve(response || {modifications: {}});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({modifications: {}});
    }
  });
}
function getLocalThemeData() {
  return JSON.parse(window.localStorage?.getItem("eufemia-theme-content") || "{}");
}
function setLocalThemeData(data) {
  const localData = getLocalThemeData();
  window.localStorage?.setItem("eufemia-theme-content", JSON.stringify({...localData, ...data}));
}
function setLocalThemeCSS() {
  const localData = getLocalThemeData();
  if (localData && localData.css) {
    insertCSS(localData.css, {elementId: "eufemia-theme"});
  }
}
function hasEnabledLocalThemeData() {
  const localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data, responseFunc = null) {
  sendMessageToTab({type: "insert-css", ...data}, responseFunc);
}
function storeCSSInPage(data, responseFunc = null) {
  sendMessageToTab({type: "store-css", ...data}, responseFunc);
}
async function getHost() {
  return new Promise((resolve) => {
    if (browser) {
      browser?.tabs?.query({currentWindow: true, active: true}, (tabs) => {
        const url = new URL(tabs[0].url);
        resolve(url.hostname);
      });
    } else {
      resolve("localhost");
    }
  });
}
function storeThemesInPage(themes, responseFunc = null) {
  sendMessageToRuntime({type: "set-themes", themes}, responseFunc);
  sendMessageToTab({type: "store-themes", themes}, responseFunc);
}
function sendMessageToRuntime(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  browser?.runtime?.sendMessage(extensionId, data, responseFunc);
}
function sendMessageToTab(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  if (browser) {
    getTabId((tabId) => {
      const themeId = window.EXTENSION_HOST ? useAppStore.getState().getHostData().currentThemeId : null;
      browser?.tabs.sendMessage(tabId, Object.assign(data, {themeId}), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc("localhost");
  }
}
function listenForBackgroundMessages() {
  Browser.runtime.onMessage.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-themes": {
        const {themes} = useThemeStore.getState();
        response({themes});
        break;
      }
      case "set-themes": {
        const {themes} = request;
        useThemeStore.setState({themes});
        response({themes});
        break;
      }
      default:
        return false;
    }
    return true;
  });
}

;// CONCATENATED MODULE: ./src/extension/background.js

listenForBackgroundMessages();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					result = fn();
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 352;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			352: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			for(moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			__webpack_require__.O();
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkeufemia_theme_manager_extension"] = self["webpackChunkeufemia_theme_manager_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [216], () => (__webpack_require__(32872)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=background.js.map