var global$1 = (typeof global !== "undefined" ? global :
            typeof self !== "undefined" ? self :
            typeof window !== "undefined" ? window : {});

// from https://github.com/kumavis/browser-process-hrtime/blob/master/index.js
var performance = global$1.performance || {};
var performanceNow =
  performance.now        ||
  performance.mozNow     ||
  performance.msNow      ||
  performance.oNow       ||
  performance.webkitNow  ||
  function(){ return (new Date()).getTime() };

function createCommonjsModule(fn) {
  var module = { exports: {} };
	return fn(module, module.exports), module.exports;
}

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime_1 = createCommonjsModule(function (module) {
var runtime = (function (exports) {

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined$1; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined$1) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined$1;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined$1;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined$1;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined$1, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined$1;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined$1;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined$1;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined$1;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined$1;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   module.exports 
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}
});

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

var useBrowser = undefined;
// String(window.location.host).includes('localhost')

{
  {
    useBrowser = window.chrome;
  }
}

var browser = useBrowser;

var regenerator = runtime_1;

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

var objectAssign = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};

/** @license React v17.0.1
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var react_production_min = createCommonjsModule(function (module, exports) {
var n=60103,p=60106;exports.Fragment=60107;exports.StrictMode=60108;exports.Profiler=60114;var q=60109,r=60110,t=60112;exports.Suspense=60113;var u=60115,v=60116;
if("function"===typeof Symbol&&Symbol.for){var w=Symbol.for;n=w("react.element");p=w("react.portal");exports.Fragment=w("react.fragment");exports.StrictMode=w("react.strict_mode");exports.Profiler=w("react.profiler");q=w("react.provider");r=w("react.context");t=w("react.forward_ref");exports.Suspense=w("react.suspense");u=w("react.memo");v=w("react.lazy");}var x="function"===typeof Symbol&&Symbol.iterator;
function y(a){if(null===a||"object"!==typeof a)return null;a=x&&a[x]||a["@@iterator"];return "function"===typeof a?a:null}function z(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return "Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}
var A={isMounted:function(){return !1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},B={};function C(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A;}C.prototype.isReactComponent={};C.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(z(85));this.updater.enqueueSetState(this,a,b,"setState");};C.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate");};
function D(){}D.prototype=C.prototype;function E(a,b,c){this.props=a;this.context=b;this.refs=B;this.updater=c||A;}var F=E.prototype=new D;F.constructor=E;objectAssign(F,C.prototype);F.isPureReactComponent=!0;var G={current:null},H=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};
function J(a,b,c){var e,d={},k=null,h=null;if(null!=b)for(e in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)H.call(b,e)&&!I.hasOwnProperty(e)&&(d[e]=b[e]);var g=arguments.length-2;if(1===g)d.children=c;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];d.children=f;}if(a&&a.defaultProps)for(e in g=a.defaultProps,g)void 0===d[e]&&(d[e]=g[e]);return {$$typeof:n,type:a,key:k,ref:h,props:d,_owner:G.current}}
function K(a,b){return {$$typeof:n,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function L(a){return "object"===typeof a&&null!==a&&a.$$typeof===n}function escape(a){var b={"=":"=0",":":"=2"};return "$"+a.replace(/[=:]/g,function(a){return b[a]})}var M=/\/+/g;function N(a,b){return "object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function O(a,b,c,e,d){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=!1;if(null===a)h=!0;else switch(k){case "string":case "number":h=!0;break;case "object":switch(a.$$typeof){case n:case p:h=!0;}}if(h)return h=a,d=d(h),a=""===e?"."+N(h,0):e,Array.isArray(d)?(c="",null!=a&&(c=a.replace(M,"$&/")+"/"),O(d,b,c,"",function(a){return a})):null!=d&&(L(d)&&(d=K(d,c+(!d.key||h&&h.key===d.key?"":(""+d.key).replace(M,"$&/")+"/")+a)),b.push(d)),1;h=0;e=""===e?".":e+":";if(Array.isArray(a))for(var g=
0;g<a.length;g++){k=a[g];var f=e+N(k,g);h+=O(k,b,c,f,d);}else if(f=y(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=e+N(k,g++),h+=O(k,b,c,f,d);else if("object"===k)throw b=""+a,Error(z(31,"[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b));return h}function P(a,b,c){if(null==a)return a;var e=[],d=0;O(a,e,"","",function(a){return b.call(c,a,d++)});return e}
function Q(a){if(-1===a._status){var b=a._result;b=b();a._status=0;a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b);},function(b){0===a._status&&(a._status=2,a._result=b);});}if(1===a._status)return a._result;throw a._result;}var R={current:null};function S(){var a=R.current;if(null===a)throw Error(z(321));return a}var T={ReactCurrentDispatcher:R,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:G,IsSomeRendererActing:{current:!1},assign:objectAssign};
exports.Children={map:P,forEach:function(a,b,c){P(a,function(){b.apply(this,arguments);},c);},count:function(a){var b=0;P(a,function(){b++;});return b},toArray:function(a){return P(a,function(a){return a})||[]},only:function(a){if(!L(a))throw Error(z(143));return a}};exports.Component=C;exports.PureComponent=E;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=T;
exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(z(267,a));var e=objectAssign({},a.props),d=a.key,k=a.ref,h=a._owner;if(null!=b){void 0!==b.ref&&(k=b.ref,h=G.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)H.call(b,f)&&!I.hasOwnProperty(f)&&(e[f]=void 0===b[f]&&void 0!==g?g[f]:b[f]);}var f=arguments.length-2;if(1===f)e.children=c;else if(1<f){g=Array(f);for(var m=0;m<f;m++)g[m]=arguments[m+2];e.children=g;}return {$$typeof:n,type:a.type,
key:d,ref:k,props:e,_owner:h}};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:r,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:q,_context:a};return a.Consumer=a};exports.createElement=J;exports.createFactory=function(a){var b=J.bind(null,a);b.type=a;return b};exports.createRef=function(){return {current:null}};exports.forwardRef=function(a){return {$$typeof:t,render:a}};exports.isValidElement=L;
exports.lazy=function(a){return {$$typeof:v,_payload:{_status:-1,_result:a},_init:Q}};exports.memo=function(a,b){return {$$typeof:u,type:a,compare:void 0===b?null:b}};exports.useCallback=function(a,b){return S().useCallback(a,b)};exports.useContext=function(a,b){return S().useContext(a,b)};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return S().useEffect(a,b)};exports.useImperativeHandle=function(a,b,c){return S().useImperativeHandle(a,b,c)};
exports.useLayoutEffect=function(a,b){return S().useLayoutEffect(a,b)};exports.useMemo=function(a,b){return S().useMemo(a,b)};exports.useReducer=function(a,b,c){return S().useReducer(a,b,c)};exports.useRef=function(a){return S().useRef(a)};exports.useState=function(a){return S().useState(a)};exports.version="17.0.1";
});

var react_development = createCommonjsModule(function (module, exports) {
});

var react = createCommonjsModule(function (module) {

{
  module.exports = react_production_min;
}
});

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function create(createState) {
  let state;
  const listeners = new Set();

  const setState = (partial, replace) => {
    const nextState = typeof partial === 'function' ? partial(state) : partial;

    if (nextState !== state) {
      const previousState = state;
      state = replace ? nextState : Object.assign({}, state, nextState);
      listeners.forEach(listener => listener(state, previousState));
    }
  };

  const getState = () => state;

  const subscribeWithSelector = (listener, selector = getState, equalityFn = Object.is) => {
    let currentSlice = selector(state);

    function listenerToAdd() {
      const nextSlice = selector(state);

      if (!equalityFn(currentSlice, nextSlice)) {
        const previousSlice = currentSlice;
        listener(currentSlice = nextSlice, previousSlice);
      }
    }

    listeners.add(listenerToAdd); // Unsubscribe

    return () => listeners.delete(listenerToAdd);
  };

  const subscribe = (listener, selector, equalityFn) => {
    if (selector || equalityFn) {
      return subscribeWithSelector(listener, selector, equalityFn);
    }

    listeners.add(listener); // Unsubscribe

    return () => listeners.delete(listener);
  };

  const destroy = () => listeners.clear();

  const api = {
    setState,
    getState,
    subscribe,
    destroy
  };
  state = createState(setState, getState, api);
  return api;
}

const useIsoLayoutEffect = typeof window === 'undefined' ? react.useEffect : react.useLayoutEffect;
function create$1(createState) {
  const api = typeof createState === 'function' ? create(createState) : createState;

  const useStore = (selector = api.getState, equalityFn = Object.is) => {
    const [, forceUpdate] = react.useReducer(c => c + 1, 0);
    const state = api.getState();
    const stateRef = react.useRef(state);
    const selectorRef = react.useRef(selector);
    const equalityFnRef = react.useRef(equalityFn);
    const erroredRef = react.useRef(false);
    const currentSliceRef = react.useRef();

    if (currentSliceRef.current === undefined) {
      currentSliceRef.current = selector(state);
    }

    let newStateSlice;
    let hasNewStateSlice = false; // The selector or equalityFn need to be called during the render phase if
    // they change. We also want legitimate errors to be visible so we re-run
    // them if they errored in the subscriber.

    if (stateRef.current !== state || selectorRef.current !== selector || equalityFnRef.current !== equalityFn || erroredRef.current) {
      // Using local variables to avoid mutations in the render phase.
      newStateSlice = selector(state);
      hasNewStateSlice = !equalityFn(currentSliceRef.current, newStateSlice);
    } // Syncing changes in useEffect.


    useIsoLayoutEffect(() => {
      if (hasNewStateSlice) {
        currentSliceRef.current = newStateSlice;
      }

      stateRef.current = state;
      selectorRef.current = selector;
      equalityFnRef.current = equalityFn;
      erroredRef.current = false;
    });
    const stateBeforeSubscriptionRef = react.useRef(state);
    useIsoLayoutEffect(() => {
      const listener = () => {
        try {
          const nextState = api.getState();
          const nextStateSlice = selectorRef.current(nextState);

          if (!equalityFnRef.current(currentSliceRef.current, nextStateSlice)) {
            stateRef.current = nextState;
            currentSliceRef.current = nextStateSlice;
            forceUpdate();
          }
        } catch (error) {
          erroredRef.current = true;
          forceUpdate();
        }
      };

      const unsubscribe = api.subscribe(listener);

      if (api.getState() !== stateBeforeSubscriptionRef.current) {
        listener(); // state has changed before subscription
      }

      return unsubscribe;
    }, []);
    return hasNewStateSlice ? newStateSlice : currentSliceRef.current;
  };

  Object.assign(useStore, api); // For backward compatibility (No TS types for this)

  useStore[Symbol.iterator] = function* () {
    console.warn('[useStore, api] = create() is deprecated and will be removed in v4');
    yield useStore;
    yield api;
  };

  return useStore;
}

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

var asyncToGenerator = _asyncToGenerator;

var _extends_1 = createCommonjsModule(function (module) {
function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;
});

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var _regeneratorRuntime__default = /*#__PURE__*/_interopDefaultLegacy(regenerator);
var _asyncToGenerator__default = /*#__PURE__*/_interopDefaultLegacy(asyncToGenerator);
var _extends__default = /*#__PURE__*/_interopDefaultLegacy(_extends_1);
var persist = function persist(config, options) {
  return function (set, get, api) {
    var _ref = options || {},
        name = _ref.name,
        _ref$getStorage = _ref.getStorage,
        getStorage = _ref$getStorage === void 0 ? function () {
      return localStorage;
    } : _ref$getStorage,
        _ref$serialize = _ref.serialize,
        serialize = _ref$serialize === void 0 ? JSON.stringify : _ref$serialize,
        _ref$deserialize = _ref.deserialize,
        deserialize = _ref$deserialize === void 0 ? JSON.parse : _ref$deserialize,
        blacklist = _ref.blacklist,
        whitelist = _ref.whitelist,
        onRehydrateStorage = _ref.onRehydrateStorage,
        _ref$version = _ref.version,
        version = _ref$version === void 0 ? 0 : _ref$version;

    var storage;

    try {
      storage = getStorage();
    } catch (e) {// prevent error if the storage is not defined (e.g. when server side rendering a page)
    }

    if (!storage) return config(set, get, api);

    var setItem = /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator__default['default']( /*#__PURE__*/_regeneratorRuntime__default['default'].mark(function _callee() {
        var _storage;

        var state;
        return _regeneratorRuntime__default['default'].wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                state = _extends__default['default']({}, get());

                if (whitelist) {
                  Object.keys(state).forEach(function (key) {
                    !whitelist.includes(key) && delete state[key];
                  });
                }

                if (blacklist) {
                  blacklist.forEach(function (key) {
                    return delete state[key];
                  });
                }

                if (!((_storage = storage) == null)) {
                  _context.next = 7;
                  break;
                }
                _context.next = 13;
                break;

              case 7:
                _context.t0 = _storage;
                _context.t1 = name;
                _context.next = 11;
                return serialize({
                  state: state,
                  version: version
                });

              case 11:
                _context.t2 = _context.sent;

                _context.t0.setItem.call(_context.t0, _context.t1, _context.t2);

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function setItem() {
        return _ref2.apply(this, arguments);
      };
    }();

    var savedSetState = api.setState;

    api.setState = function (state, replace) {
      savedSetState(state, replace);
      setItem();
    };

    _asyncToGenerator__default['default']( /*#__PURE__*/_regeneratorRuntime__default['default'].mark(function _callee2() {
      var postRehydrationCallback, storageValue, deserializedStorageValue;
      return _regeneratorRuntime__default['default'].wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              postRehydrationCallback = (onRehydrateStorage == null ? void 0 : onRehydrateStorage(get())) || undefined;
              _context2.prev = 1;
              _context2.next = 4;
              return storage.getItem(name);

            case 4:
              storageValue = _context2.sent;

              if (!storageValue) {
                _context2.next = 10;
                break;
              }

              _context2.next = 8;
              return deserialize(storageValue);

            case 8:
              deserializedStorageValue = _context2.sent;

              // if versions mismatch, clear storage by storing the new initial state
              if (deserializedStorageValue.version !== version) {
                setItem();
              } else {
                set(deserializedStorageValue.state);
              }

            case 10:
              _context2.next = 15;
              break;

            case 12:
              _context2.prev = 12;
              _context2.t0 = _context2["catch"](1);
              throw new Error("Unable to get to stored state in \"" + name + "\"");

            case 15:
              _context2.prev = 15;
              postRehydrationCallback == null ? void 0 : postRehydrationCallback(get());
              return _context2.finish(15);

            case 18:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 12, 15, 18]]);
    }))();

    return config(function (payload) {
      set(payload);
      setItem();
    }, get, api);
  };
};
var persist_1 = persist;

var properties = {
  '--font-family-default': "'DNB', sans-serif",
  '--font-family-monospace': "'DNBMono', 'Menlo', 'Consolas', 'Roboto Mono',",
  '--font-family-book': "'DNB', sans-serif",
  '--font-family-demi': "'DNB', sans-serif",
  '--font-weight-basis': 'normal',
  '--font-weight-regular': 'normal',
  '--font-weight-medium': '500',
  '--font-weight-bold': '600',
  '--font-weight-default': 'normal',
  '--font-weight-book': 'normal',
  '--font-weight-demi': '500',
  '--font-size-x-small': '0.875rem',
  '--font-size-small': '1rem',
  '--font-size-basis': '1.125rem',
  '--font-size-basis--em': '1em',
  '--font-size-medium': '1.25rem',
  '--font-size-large': '1.625rem',
  '--font-size-x-large': '2.125rem',
  '--font-size-xx-large': '3rem',
  '--line-height-xx-small--em': '1em',
  '--line-height-x-small': '1.125rem',
  '--line-height-small': '1.25rem',
  '--line-height-basis': '1.5rem',
  '--line-height-basis--em': '1.333em',
  '--line-height-medium': '2rem',
  '--line-height-large': '2.5rem',
  '--line-height-x-large': '3.5rem',
  '--color-mint-green-50': '#d2f0e9',
  '--color-mint-green-25': '#e9f8f4',
  '--color-mint-green-12': '#f4fbf9',
  '--color-sea-green-30': '#b3dada',
  '--color-sea-green-alt-30': '#b3dada',
  '--color-signal-yellow-30': '#ffffd7',
  '--color-accent-yellow-30': '#feebc1',
  '--color-signal-orange': '#ff5400',
  '--color-fire-red': '#dc2a2a',
  '--color-success-green': '#008000',
  '--color-fire-red-8': '#fdeeee',
  '--color-black': '#000',
  '--color-black-80': '#333',
  '--color-black-55': '#737373',
  '--color-black-30': '#b3b3b3',
  '--color-black-20': '#ccc',
  '--color-black-8': '#ebebeb',
  '--color-black-3': '#f8f8f8',
  '--color-white': '#fff',
  '--color-black-border': '#cdcdcd',
  '--color-black-background': '#fafafa',
  '--color-sea-green': '#007272',
  '--color-sea-green-alt': '#007272',
  '--color-mint-green': '#a5e1d2',
  '--color-summer-green': '#28b482',
  '--color-emerald-green': '#14555a',
  '--color-ocean-green': '#00343e',
  '--color-signal-yellow': '#ffff7a',
  '--color-accent-yellow': '#fdbb31',
  '--color-indigo': '#23195a',
  '--color-violet': '#6e2382',
  '--color-sky-blue': '#4bbed2',
  '--color-lavender': '#f2f2f5',
  '--color-sand-yellow': '#fbf6ec',
  '--color-pistachio': '#f2f4ec',
  '--color-mint-green-alt': '#ebfffa',
  '--color-indigo-medium': '#6e6491',
  '--color-indigo-light': '#b9afc8',
  '--color-violet-medium': '#a06eaf',
  '--color-violet-light': '#cfb9d7',
  '--color-sky-blue-medium': '#87d2e1',
  '--color-sky-blue-light': '#c3ebf0',
  '--spacing-xx-small': '0.25rem',
  '--spacing-x-small': '0.5rem',
  '--spacing-small': '1rem',
  '--spacing-medium': '1.5rem',
  '--spacing-large': '2rem',
  '--spacing-x-large': '3rem',
  '--spacing-xx-large': '3.5rem',
  '--layout-small': '40em',
  '--layout-medium': '50em',
  '--layout-large': '60em',
  '--layout-x-large': '72em',
  '--layout-xx-large': '80em',
  '--layout-xxx-large': '90em'
};

var originalColorsAsObject = getOriginalColorsAsObject();
var originalColorsAsArray = getOriginalColorsAsArray();
function getOriginalColorsAsArray() {
  var colors = Object.entries(originalColorsAsObject).map(function (_ref4) {
    var _ref5 = _slicedToArray(_ref4, 2),
        key = _ref5[0],
        value = _ref5[1];

    var name = key.replace(/--color-/g, ' ').replace(/-/g, ' ').trim().replace(/(^|\s)([a-z])/g, function (s) {
      return s.toUpperCase();
    });
    return {
      key: key,
      name: name,
      value: value
    };
  });
  return colors;
}
function getOriginalColorsAsObject() {
  var colors = Object.entries(properties).filter(function (_ref6) {
    var _ref7 = _slicedToArray(_ref6, 1),
        name = _ref7[0];

    return name.includes('--color-');
  }).reduce(function (acc, _ref8) {
    var _ref9 = _slicedToArray(_ref8, 2),
        key = _ref9[0],
        value = _ref9[1];

    acc[key] = value;
    if (key.includes('-border')) delete acc[key];
    if (key.includes('-background')) delete acc[key];
    if (key.includes('-light')) delete acc[key];
    if (key.includes('-medium')) delete acc[key];
    return acc;
  }, {});
  delete colors['--color-sea-green-alt-30'];
  delete colors['--color-signal-yellow-30'];
  delete colors['--color-black-30'];
  delete colors['--color-sea-green-alt'];
  delete colors['--color-signal-yellow'];
  return colors;
}

var extensionStorePlain = create$1(themesStore);
var useThemeStore = create$1(persist_1(themesStore, getPersistConfig('eufemia-theme-data')));
var useAppStore = create$1(persist_1(hostStore, getPersistConfig('eufemia-theme-app')));
var useWindowStore = create$1(persist_1(hostStore, getPersistConfig('eufemia-theme-window')));
var useErrorStore = create$1(errorStore);

function themesStore(set, get) {
  return {
    themes: {},
    getThemes: function getThemes() {
      var _get = get(),
          getThemeConstructs = _get.getThemeConstructs,
          themes = _get.themes;

      if (!themes['dnb-ui']) {
        themes['dnb-ui'] = getThemeConstructs();
        themes['demo'] = getThemeConstructs();
      }

      if (!themes['blue-test']) {
        themes['blue-test'] = getThemeConstructs();
      }

      if (!themes['2x-test']) {
        themes['2x-test'] = getThemeConstructs();
      }

      return themes;
    },
    importThemes: function importThemes(themesData) {
      var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          overwrite = _ref.overwrite;

      try {
        if (themesData) {
          var existingThemes = get().themes;
          var themes = Object.entries(themesData).reduce(function (acc, _ref2) {
            var _ref3 = _slicedToArray(_ref2, 2),
                key = _ref3[0],
                theme = _ref3[1];

            if (!['dnb-ui', 'blue-test', '2x-test'].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }

            return acc;
          }, _objectSpread2({}, existingThemes));
          set({
            themes: themes
          });
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: function createEmptyTheme(themeId) {
      var _get2 = get(),
          themes = _get2.themes,
          getThemeConstructs = _get2.getThemeConstructs;

      if (!themes[themeId]) {
        themes[themeId] = _objectSpread2({}, getThemeConstructs());
        set({
          themes: themes
        });
      }
    },
    copySelectedTheme: function copySelectedTheme(themeId) {
      var _get3 = get(),
          themes = _get3.themes,
          selectedThemeId = _get3.selectedThemeId;

      if (!themes[themeId]) {
        themes[themeId] = _objectSpread2({}, themes[selectedThemeId]);
        set({
          themes: themes
        });
      }
    },
    removeTheme: function removeTheme(themeId) {
      var themes = get().themes;

      if (themes[themeId]) {
        delete themes[themeId];
        set({
          themes: themes
        });
      }
    },
    getThemeConstructs: function getThemeConstructs() {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: function getTheme() {
      var themeId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (!themeId) {
        themeId = get().selectedThemeId;
      }

      var setState = function setState(object) {
        var themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object); // themes[themeId] = { ...(themes[themeId] || {}), ...object }

        var state = {
          themes: themes
        };
        state.selectedThemeId = themeId;
        set(state);
      };

      var getState = function getState() {
        var theme = get().themes[themeId] || null; // || get().getThemeConstructs()

        return theme;
      };

      var getThemeChanges = function getThemeChanges() {
        switch (themeId) {
          case 'dnb-ui':
            {
              return _toConsumableArray(originalColorsAsArray.map(function (_ref4) {
                var key = _ref4.key,
                    value = _ref4.value;
                return {
                  key: key,
                  change: value
                };
              }));
            }

          case 'blue-test':
            {
              return _toConsumableArray(originalColorsAsArray.map(function (_ref5) {
                var key = _ref5.key;
                return {
                  key: key,
                  change: 'blue'
                };
              }));
            }

          case '2x-test':
            {
              return [{
                css: 'html{font-size: 200%;}'
              }];
            }

          default:
            {
              var theme = getState();
              return [].concat(_toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.colorsList) || []), _toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.spacingsList) || []), _toConsumableArray((theme === null || theme === void 0 ? void 0 : theme.fontsizesList) || []));
            }
        }
      }; // Color utils


      var changeColor = function changeColor(origKey, object) {
        var theme = getState();
        var found = false;
        object.key = origKey;
        var colorsList = ((theme === null || theme === void 0 ? void 0 : theme.colorsList) || []).map(function (item) {
          if (item.key === origKey) {
            item = _objectSpread2(_objectSpread2({}, item), object);
            found = Boolean(item);
          }

          return item;
        });

        if (!found) {
          colorsList.push(object);
        }

        setState({
          colorsList: colorsList
        });
      };

      var setColor = function setColor(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeColor(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetColor = function resetColor(rmKey) {
        changeColor(rmKey, {
          change: null,
          useCustomColor: null
        });
      };

      var useColorTools = function useColorTools() {
        return {
          changeColor: changeColor,
          setColor: setColor,
          resetColor: resetColor
        };
      }; // Spacing utils


      var changeSpacing = function changeSpacing(origKey, object) {
        var theme = getState();
        var found;
        var spacingsList = ((theme === null || theme === void 0 ? void 0 : theme.spacingsList) || []).map(function (item) {
          if (item.key === origKey) {
            found = item = _objectSpread2(_objectSpread2({}, item), object);
          }

          return item;
        });

        if (!found) {
          spacingsList.push(Object.assign(object));
        }

        setState({
          spacingsList: spacingsList
        });
      };

      var setSpacing = function setSpacing(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetSpacing = function resetSpacing(rmKey) {
        changeSpacing(rmKey, {
          change: null
        });
      };

      var useSpacingTools = function useSpacingTools() {
        return {
          changeSpacing: changeSpacing,
          setSpacing: setSpacing,
          resetSpacing: resetSpacing
        };
      }; // Font-size utils


      var changeFontsize = function changeFontsize(origKey, object) {
        var theme = getState();
        var found;
        var fontsizesList = ((theme === null || theme === void 0 ? void 0 : theme.fontsizesList) || []).map(function (item) {
          if (item.key === origKey) {
            found = item = _objectSpread2(_objectSpread2({}, item), object);
          }

          return item;
        });

        if (!found) {
          fontsizesList.push(Object.assign(object));
        }

        setState({
          fontsizesList: fontsizesList
        });
      };

      var setFontsize = function setFontsize(origKey, change) {
        var fallbackParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change: change
        }));
      };

      var resetFontsize = function resetFontsize(rmKey) {
        changeFontsize(rmKey, {
          change: null
        });
      };

      var useFontsizeTools = function useFontsizeTools() {
        return {
          changeFontsize: changeFontsize,
          setFontsize: setFontsize,
          resetFontsize: resetFontsize
        };
      };

      return _objectSpread2(_objectSpread2({
        themeId: themeId
      }, getState()), {}, {
        setState: setState,
        getState: getState,
        getThemeChanges: getThemeChanges,
        useColorTools: useColorTools,
        useSpacingTools: useSpacingTools,
        useFontsizeTools: useFontsizeTools
      });
    }
  };
}

var defaultFallback = {
  enabled: false,
  selectedTab: 'colors',
  currentThemeId: null,
  selectedThemeId: 'demo'
};

function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: function setEnabled(enabled) {
      get().setByHost({
        enabled: enabled
      });
    },
    setFilter: function setFilter(cacheKey, filter) {
      var _get$getHostData;

      var filters = ((_get$getHostData = get().getHostData()) === null || _get$getHostData === void 0 ? void 0 : _get$getHostData.filters) || {};
      var existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({
        filters: filters
      });
    },
    getFilter: function getFilter(cacheKey) {
      var data = get().getHostData();
      return (data === null || data === void 0 ? void 0 : data.filters) ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: function setCurrentThemeId(currentThemeId) {
      get().setByHost({
        currentThemeId: currentThemeId
      });
    },
    setSelectedThemeId: function setSelectedThemeId(selectedThemeId) {
      get().setByHost({
        selectedThemeId: selectedThemeId
      });
    },
    setSelectedTab: function setSelectedTab(selectedTab) {
      get().setByHost({
        selectedTab: selectedTab
      });
    },
    getHostData: function getHostData() {
      var _get4 = get(),
          hosts = _get4.hosts;

      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: function setByHost(data) {
      var _get5 = get(),
          hosts = _get5.hosts;

      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({
        hosts: hosts
      });
    },
    importAppData: function importAppData(hostsData) {
      var _ref6 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          overwrite = _ref6.overwrite;

      try {
        if (hostsData) {
          var existingData = get().hosts;
          var hosts = Object.entries(hostsData).reduce(function (acc, _ref7) {
            var _ref8 = _slicedToArray(_ref7, 2),
                key = _ref8[0],
                data = _ref8[1];

            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }

            return acc;
          }, _objectSpread2({}, existingData));
          set({
            hosts: hosts
          });
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}

function errorStore(set) {
  return {
    error: null,
    setError: function setError(error) {
      console.warn(error);
      set({
        error: error
      });
    },
    hideError: function hideError() {
      set({
        error: null
      });
    }
  };
} // function postRehydrationMiddleware() {
//   const theme = useTheme.getState().getTheme()
//   ...
// }


function getPersistConfig(name) {
  var writeTimeoutId;
  return {
    name: name,
    // blacklist: ['colorTools', 'sgetItempacingTools'],
    // whitelist: ['colorTools', 'spacingTools'],
    // postRehydrationMiddleware,
    // onRehydrateStorage: () => {
    //   console.log('onRehydrateStorage')
    // },
    getStorage: function getStorage() {
      return {
        getItem: function getItem(name) {
          return new Promise(function (resolve, reject) {
            if ( browser && browser.storage !== 'undefined') {
              try {
                var _browser$storage;

                (_browser$storage = browser.storage) === null || _browser$storage === void 0 ? void 0 : _browser$storage.sync.get([name], function (_ref9) {
                  var themeData = _ref9[name];

                  if (browser.runtime.lastError) {
                    useErrorStore.getState().setError(browser.runtime.lastError.message);
                  } else {
                    // const themeData = data?.themeData || data || '{}'
                    resolve(themeData);
                  }
                });
              } catch (e) {
                var _window$localStorage;

                useErrorStore.getState().setError(e.message);
                resolve(((_window$localStorage = window.localStorage) === null || _window$localStorage === void 0 ? void 0 : _window$localStorage.getItem(name)) || '{}');
              }
            } else {
              var _window$localStorage2;

              resolve(((_window$localStorage2 = window.localStorage) === null || _window$localStorage2 === void 0 ? void 0 : _window$localStorage2.getItem(name)) || '{}');
            }
          });
        },
        setItem: function setItem(name, themeData) {
          if ( browser && browser.storage !== 'undefined') {
            /**
             * Because of the message: setError This request exceeds the MAX_WRITE_OPERATIONS_PER_MINUTE quota.
             * we do debounce the write
             */
            var write = function write() {
              try {
                var _browser$storage2;

                (_browser$storage2 = browser.storage) === null || _browser$storage2 === void 0 ? void 0 : _browser$storage2.sync.set(_defineProperty({}, name, themeData), function () {
                  // console.lo('setItem:', name, themeData)
                  if (browser.runtime.lastError) {
                    useErrorStore.getState().setError(browser.runtime.lastError.message);
                  }
                });
              } catch (e) {
                var _window$localStorage3;

                useErrorStore.getState().setError(e.message);
                (_window$localStorage3 = window.localStorage) === null || _window$localStorage3 === void 0 ? void 0 : _window$localStorage3.setItem(name, themeData);
              }
            };

            if (!writeTimeoutId) {
              writeTimeoutId = 1;
              write();
            } else {
              clearTimeout(writeTimeoutId);
              writeTimeoutId = setTimeout(function () {
                write();
              }, 1e3);
            }
          } else {
            var _window$localStorage4;

            (_window$localStorage4 = window.localStorage) === null || _window$localStorage4 === void 0 ? void 0 : _window$localStorage4.setItem(name, themeData);
          }
        }
      };
    }
  };
}

function listenForBackgroundMessages() {
  var _browser$runtime3, _browser$runtime3$onM;

  browser === null || browser === void 0 ? void 0 : (_browser$runtime3 = browser.runtime) === null || _browser$runtime3 === void 0 ? void 0 : (_browser$runtime3$onM = _browser$runtime3.onMessage) === null || _browser$runtime3$onM === void 0 ? void 0 : _browser$runtime3$onM.addListener(function (request, sender, response) {
    switch (request.type) {
      case 'get-themes':
        {
          var _backgroundStore$getS = useThemeStore.getState(),
              themes = _backgroundStore$getS.themes;

          response({
            themes: themes
          });
          break;
        }

      case 'set-themes':
        {
          var _themes = request.themes;
          useThemeStore.setState({
            themes: _themes
          });
          response({
            themes: _themes
          });
          break;
        }

      default:
        return false;
    }

    return true;
  });
} // Only hacky WIP code – to experiment on load the extension inline
// export function insertInlineExtension() {
//   const iframe = document.createElement('iframe')
//   const button = document.createElement('button')
//   const elem = document.body.firstChild
//   iframe.style.position = 'absolute'
//   button.style.position = 'absolute'
//   iframe.style.zIndex = '1000'
//   button.style.zIndex = '1000'
//   iframe.style.width = '42rem'
//   iframe.style.height = '100vh'
//   button.innerHTML = 'Open'
//   button.addEventListener('click', (evt) => {
//     evt.preventDefault()
//     browser?.runtime.sendMessage({ type: 'url' }, (response) => {
//       if (response) {
//         iframe.src = response
//         // elem.appendChild(iframe)
//         document.body.insertBefore(
//           iframe,
//           elem
//           //
//         )
//       }
//     })
//   })
//   // elem.appendChild(button)
//   document.body.insertBefore(button, elem)
// }

listenForBackgroundMessages();
