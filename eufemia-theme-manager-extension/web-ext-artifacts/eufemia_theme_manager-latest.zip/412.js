(self["webpackChunkeufemia_theme_manager_extension"] = self["webpackChunkeufemia_theme_manager_extension"] || []).push([[412],{

/***/ 8412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./src/shared/Browser.js
var Browser = __webpack_require__(5101);
// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(4339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(7888);
// EXTERNAL MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js + 2 modules
var emotion_styled_browser_esm = __webpack_require__(5462);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.reflect.construct.js
var es_reflect_construct = __webpack_require__(6346);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(691);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(4973);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__(8802);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/toConsumableArray.js + 3 modules
var toConsumableArray = __webpack_require__(2707);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(1295);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(7817);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__(6934);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(7198);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(8465);
// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(3086);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(225);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(4565);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(4185);
// EXTERNAL MODULE: ../node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(395);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(6654);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(9332);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(6091);
// EXTERNAL MODULE: ../node_modules/prop-types/index.js
var prop_types = __webpack_require__(6050);
// EXTERNAL MODULE: ../node_modules/classnames/index.js
var classnames = __webpack_require__(855);
// EXTERNAL MODULE: ../node_modules/keycode/index.js
var keycode = __webpack_require__(1984);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/component-helper.js
var component_helper = __webpack_require__(1218);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/custom-element.js + 3 modules
var custom_element = __webpack_require__(6357);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/AlignmentHelper.js
var AlignmentHelper = __webpack_require__(2294);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/SpacingHelper.js
var SpacingHelper = __webpack_require__(3039);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/skeleton/SkeletonHelper.js
var SkeletonHelper = __webpack_require__(5818);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-label/FormLabel.js
var FormLabel = __webpack_require__(6799);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-status/FormStatus.js
var FormStatus = __webpack_require__(3427);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-row/FormRow.js
var FormRow = __webpack_require__(1530);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Context.js + 3 modules
var Context = __webpack_require__(3898);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/helpers/Suffix.js
var Suffix = __webpack_require__(8231);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/RadioGroupContext.js

var RadioGroupContext = react.createContext({});
/* harmony default export */ const radio_RadioGroupContext = (RadioGroupContext);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/RadioGroup.js









var _AlignmentHelper;

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}











var RadioGroup = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(RadioGroup2, _React$PureComponent);
  var _super = _createSuper(RadioGroup2);
  function RadioGroup2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, RadioGroup2);
    _this = _super.call(this, props);
    _this.onChangeHandler = function(_ref) {
      var value = _ref.value, event = _ref.event;
      _this.setState({
        value,
        _listenForPropChanges: false
      });
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        value,
        event
      });
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._name = props.name || _this._id;
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(RadioGroup2, [{
    key: "render",
    value: function render() {
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, RadioGroup2.defaultProps, this.context.FormRow, this.context.RadioGroup);
      var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, label_position = props.label_position, vertical = props.vertical, layout_direction = props.layout_direction, no_fieldset = props.no_fieldset, size = props.size, disabled = props.disabled, skeleton = props.skeleton, className = props.className, _className = props.class, _id = props.id, _name = props.name, _value = props.value, attributes = props.attributes, children = props.children, on_change = props.on_change, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "label_position", "vertical", "layout_direction", "no_fieldset", "size", "disabled", "skeleton", "className", "class", "id", "name", "value", "attributes", "children", "on_change", "custom_method", "custom_element"]);
      var value = this.state.value;
      var id = this._id;
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var classes = classnames("dnb-radio-group dnb-radio-group--".concat(layout_direction, " dnb-form-component"), (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-radio-group__status--".concat(status_state));
      var params = (0,esm_extends/* default */.Z)({}, rest);
      if (showStatus || suffix) {
        params["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(params, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (label) {
        params["aria-labelledby"] = id + "-label";
      }
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, params);
      var context = {
        name: this._name,
        value,
        size,
        disabled,
        label_position,
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id,
        label,
        label_id: id + "-label",
        label_direction,
        label_sr_only,
        direction: label_direction,
        vertical,
        disabled,
        skeleton,
        no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(radio_RadioGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, _AlignmentHelper || (_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(FormRow/* default */.ZP, formRowParams, react.createElement("span", (0,esm_extends/* default */.Z)({
        id,
        className: "dnb-radio-group__shell",
        role: "radiogroup"
      }, params), children, suffix && react.createElement(Suffix/* default */.Z, {
        className: "dnb-radio-group__suffix",
        id: id + "-suffix",
        context: props
      }, suffix), showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text: status,
        status: status_state,
        text_id: id + "-status",
        width_selector: id + ", " + id + "-label",
        animation: status_animation,
        skeleton
      })))));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(RadioGroup2.tagName, RadioGroup2, RadioGroup2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.value !== state._value) {
          state.value = props.value;
        }
        if (typeof props.value !== "undefined") {
          state._value = props.value;
        }
      }
      state._listenForPropChanges = true;
      return state;
    }
  }]);
  return RadioGroup2;
}(react.PureComponent);
RadioGroup.tagName = "dnb-radio-group";
RadioGroup.contextType = Context/* default */.Z;
RadioGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  label_position: null,
  title: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  size: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: "row",
  value: void 0,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};
RadioGroup.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/radio/Radio.js









var Radio_AlignmentHelper, _span, _span2;

function Radio_createSuper(Derived) {
  var hasNativeReflectConstruct = Radio_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function Radio_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}














var Radio = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(Radio2, _React$PureComponent);
  var _super = Radio_createSuper(Radio2);
  function Radio2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, Radio2);
    _this = _super.call(this, props);
    _this.onKeyDownHandler = function(event) {
      var key = keycode(event);
      if (_this.isInNoGroup()) {
        switch (key) {
          case "enter":
            _this.onChangeHandler(event);
            break;
        }
      } else if (_this.isContextGroupOrSingle()) {
        switch (key) {
          case "space":
          case "enter": {
            var value = _this.context.value;
            if (value !== null && typeof value !== "undefined") {
              event.preventDefault();
            }
            if (key === "enter") {
              var checked = !_this.state.checked;
              _this.setState({
                checked,
                _listenForPropChanges: false
              });
            }
            break;
          }
        }
      } else {
        switch (key) {
          case "space": {
            event.preventDefault();
            break;
          }
        }
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_key_down", {
        event
      });
    };
    _this.onChangeHandler = function(_event) {
      var event = _event;
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      var value = event.target.value;
      var checked = !_this.state.checked;
      if (_this.isPlainGroup()) {
        setTimeout(function() {
          _this.setState({
            checked,
            _listenForPropChanges: false
          }, function() {
            return _this.callOnChange({
              value,
              checked,
              event
            });
          });
        }, 1);
      } else {
        _this.setState({
          checked,
          _listenForPropChanges: false
        });
        _this.callOnChange({
          value,
          checked,
          event
        });
      }
    };
    _this.isContextGroupOrSingle = function() {
      return typeof _this.context.value !== "undefined" && !_this.props.group;
    };
    _this.isPlainGroup = function() {
      return typeof _this.context.value === "undefined" && _this.props.group;
    };
    _this.isInNoGroup = function() {
      return typeof _this.context.value === "undefined" && !_this.props.group;
    };
    _this.onClickHandler = function(event) {
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      if (!_this.isPlainGroup()) {
        return;
      }
      var value = event.target.value;
      var checked = event.target.checked;
      _this.callOnChange({
        value,
        checked,
        event
      });
    };
    _this.callOnChange = function(_ref) {
      var value = _ref.value, checked = _ref.checked, event = _ref.event;
      var group = _this.props.group;
      if (_this.context.onChange) {
        _this.context.onChange({
          value
        });
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        group,
        checked,
        value,
        event
      });
      if (_this._refInput.current) {
        _this._refInput.current.focus();
      }
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(Radio2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      return react.createElement(Context/* default.Consumer */.Z.Consumer, null, function(context) {
        var props = (0,component_helper/* extendPropsWithContext */.Xw)(_this2.props, Radio2.defaultProps, _this2.context, {
          skeleton: context === null || context === void 0 ? void 0 : context.skeleton
        }, context.FormRow, context.Radio);
        var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_sr_only = props.label_sr_only, label_position = props.label_position, size = props.size, readOnly = props.readOnly, skeleton = props.skeleton, className = props.className, _className = props.class, _id = props.id, _group = props.group, _value = props.value, _checked = props.checked, _disabled = props.disabled, attributes = props.attributes, children = props.children, on_change = props.on_change, on_state_update = props.on_state_update, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_sr_only", "label_position", "size", "readOnly", "skeleton", "className", "class", "id", "group", "value", "checked", "disabled", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);
        var checked = _this2.state.checked;
        var value = props.value, group = props.group, disabled = props.disabled;
        var hasContext = typeof _this2.context.name !== "undefined";
        if (hasContext) {
          if (typeof _this2.context.value !== "undefined") {
            checked = _this2.context.value === value;
          }
          group = _this2.context.name;
          disabled = (0,component_helper/* isTrue */.oA)(_this2.context.disabled);
        } else if (typeof rest.name !== "undefined") {
          group = rest.name;
        }
        var id = _this2._id;
        var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
        var mainParams = {
          className: classnames("dnb-radio", (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-radio__status--".concat(status_state), size && "dnb-radio--".concat(size), label && "dnb-radio--label-position-".concat(label_position || "right"))
        };
        var inputParams = (0,esm_extends/* default */.Z)({
          role: hasContext || group ? "radio" : null,
          type: hasContext || group ? "radio" : "checkbox"
        }, rest);
        if (showStatus || suffix) {
          inputParams["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(inputParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
        }
        if (readOnly) {
          inputParams["aria-readonly"] = inputParams.readOnly = true;
        }
        if (!group) {
          inputParams.type = "checkbox";
          inputParams.role = "radio";
        }
        (0,SkeletonHelper/* skeletonDOMAttributes */.rZ)(inputParams, skeleton, _this2.context);
        (0,component_helper/* validateDOMAttributes */.L_)(_this2.props, inputParams);
        var labelComp = label && react.createElement(FormLabel/* default */.Z, {
          id: id + "-label",
          for_id: id,
          text: label,
          disabled,
          skeleton,
          sr_only: label_sr_only
        });
        return react.createElement("span", mainParams, react.createElement("span", {
          className: "dnb-radio__order"
        }, label_position === "left" && labelComp, react.createElement("span", {
          className: "dnb-radio__inner"
        }, Radio_AlignmentHelper || (Radio_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), showStatus && react.createElement(FormStatus/* default */.ZP, {
          id: id + "-form-status",
          global_status_id,
          label,
          text_id: id + "-status",
          width_selector: id + ", " + id + "-label",
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton
        }), react.createElement("span", {
          className: "dnb-radio__row"
        }, react.createElement("span", {
          className: "dnb-radio__shell"
        }, react.createElement("input", (0,esm_extends/* default */.Z)({
          type: "radio",
          value,
          id,
          name: group,
          className: "dnb-radio__input",
          checked,
          "aria-checked": checked,
          disabled: (0,component_helper/* isTrue */.oA)(disabled),
          ref: _this2._refInput
        }, inputParams, {
          onChange: _this2.onChangeHandler,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler
        })), react.createElement("span", {
          className: classnames("dnb-radio__button", (0,SkeletonHelper/* createSkeletonClass */.BD)("shape", skeleton, _this2.context)),
          "aria-hidden": true
        }), _span || (_span = react.createElement("span", {
          className: "dnb-radio__focus",
          "aria-hidden": true
        })), _span2 || (_span2 = react.createElement("span", {
          className: "dnb-radio__dot",
          "aria-hidden": true
        }))), label_position !== "left" && labelComp, suffix && react.createElement(Suffix/* default */.Z, {
          className: "dnb-radio__suffix",
          id: id + "-suffix",
          context: props
        }, suffix)))));
      });
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(Radio2.tagName, Radio2, Radio2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = Radio2.parseChecked(props.checked);
        }
      }
      state._listenForPropChanges = true;
      if (state.checked !== state.__checked) {
        (0,component_helper/* dispatchCustomElementEvent */.RW)({
          props
        }, "on_state_update", {
          checked: state.checked
        });
      }
      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);
  return Radio2;
}(react.PureComponent);
Radio.tagName = "dnb-radio";
Radio.contextType = radio_RadioGroupContext;
Radio.defaultProps = {
  label: null,
  label_sr_only: null,
  label_position: null,
  checked: null,
  disabled: false,
  id: null,
  size: null,
  group: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: "",
  attributes: null,
  readOnly: false,
  skeleton: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
Radio.Group = RadioGroup;
Radio.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/checkbox/Checkbox.js
var Checkbox = __webpack_require__(4742);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/button/Button.js + 7 modules
var Button = __webpack_require__(9826);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__(4348);
// EXTERNAL MODULE: ../node_modules/core-js/modules/es.array.index-of.js
var es_array_index_of = __webpack_require__(5860);
;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButtonGroupContext.js

var ToggleButtonGroupContext = react.createContext({});
/* harmony default export */ const toggle_button_ToggleButtonGroupContext = (ToggleButtonGroupContext);

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButtonGroup.js









var ToggleButtonGroup_AlignmentHelper;








function ToggleButtonGroup_createSuper(Derived) {
  var hasNativeReflectConstruct = ToggleButtonGroup_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function ToggleButtonGroup_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}











var ToggleButtonGroup = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(ToggleButtonGroup2, _React$PureComponent);
  var _super = ToggleButtonGroup_createSuper(ToggleButtonGroup2);
  function ToggleButtonGroup2(props) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, ToggleButtonGroup2);
    _this = _super.call(this, props);
    _this.onChangeHandler = function(_ref) {
      var value = _ref.value, event = _ref.event;
      var multiselect = _this.props.multiselect;
      var values = _this.state.values || [];
      if ((0,component_helper/* isTrue */.oA)(multiselect)) {
        if (!values.includes(value)) {
          values.push(value);
        } else {
          values.splice(values.indexOf(value), 1);
        }
      }
      _this.setState({
        value,
        values,
        _listenForPropChanges: false
      });
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        value,
        values,
        event
      });
    };
    _this._refInput = react.createRef();
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._name = props.name || (0,component_helper/* makeUniqueId */.Xo)();
    _this.state = {
      _listenForPropChanges: true
    };
    return _this;
  }
  (0,createClass/* default */.Z)(ToggleButtonGroup2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      var props = (0,component_helper/* extendPropsWithContext */.Xw)(this.props, ToggleButtonGroup2.defaultProps, this.context.getTranslation(this.props).ToggleButton, this.context.FormRow, this.context.ToggleButtonGroup);
      var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label_direction = props.label_direction, label_sr_only = props.label_sr_only, vertical = props.vertical, layout_direction = props.layout_direction, label = props.label, variant = props.variant, left_component = props.left_component, no_fieldset = props.no_fieldset, disabled = props.disabled, skeleton = props.skeleton, className = props.className, _className = props.class, multiselect = props.multiselect, _id = props.id, _name = props.name, _value = props.value, _values = props.values, attributes = props.attributes, children = props.children, on_change = props.on_change, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label_direction", "label_sr_only", "vertical", "layout_direction", "label", "variant", "left_component", "no_fieldset", "disabled", "skeleton", "className", "class", "multiselect", "id", "name", "value", "values", "attributes", "children", "on_change", "custom_method", "custom_element"]);
      var _this$state = this.state, value = _this$state.value, values = _this$state.values;
      var id = this._id;
      var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
      var classes = classnames("dnb-toggle-button-group dnb-toggle-button-group--".concat(layout_direction, " dnb-form-component"), ((0,component_helper/* isTrue */.oA)(vertical) || label_direction) && "dnb-form-row--".concat((0,component_helper/* isTrue */.oA)(vertical) ? "vertical" : label_direction, "-label"), (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-toggle-button-group__status--".concat(status_state), !label && "dnb-toggle-button-group--no-label");
      var params = (0,esm_extends/* default */.Z)({}, rest);
      if (showStatus || suffix) {
        params["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(params, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
      }
      if (label) {
        params["aria-labelledby"] = id + "-label";
      }
      (0,component_helper/* validateDOMAttributes */.L_)(this.props, params);
      var context = {
        name: this._name,
        value,
        values,
        multiselect: (0,component_helper/* isTrue */.oA)(multiselect),
        variant,
        left_component,
        disabled,
        skeleton,
        setContext: function setContext(context2) {
          if (typeof context2 === "function") {
            context2 = context2(_this2._tmp);
          }
          _this2._tmp = (0,esm_extends/* default */.Z)({}, _this2._tmp, context2);
          _this2.setState((0,esm_extends/* default */.Z)({}, context2, {
            _listenForPropChanges: false
          }));
        },
        onChange: this.onChangeHandler
      };
      var formRowParams = {
        id,
        label,
        label_id: id + "-label",
        label_direction,
        label_sr_only,
        direction: label_direction,
        vertical,
        disabled,
        skeleton,
        no_fieldset,
        skipContentWrapperIfNested: true
      };
      return react.createElement(toggle_button_ToggleButtonGroupContext.Provider, {
        value: context
      }, react.createElement("div", {
        className: classes
      }, ToggleButtonGroup_AlignmentHelper || (ToggleButtonGroup_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(FormRow/* default */.ZP, formRowParams, react.createElement("span", (0,esm_extends/* default */.Z)({
        id,
        className: "dnb-toggle-button-group__shell",
        role: "group"
      }, params), showStatus && react.createElement(FormStatus/* default */.ZP, {
        id: id + "-form-status",
        global_status_id,
        label,
        text_id: id + "-status",
        text: status,
        status: status_state,
        animation: status_animation,
        skeleton
      }), react.createElement("span", {
        className: "dnb-toggle-button-group__children"
      }, children, suffix && react.createElement(Suffix/* default */.Z, {
        className: "dnb-toggle-button-group__suffix",
        id: id + "-suffix",
        context: props
      }, suffix))))));
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(ToggleButtonGroup2.tagName, ToggleButtonGroup2, ToggleButtonGroup2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (typeof props.value !== "undefined" && props.value !== state.value) {
          state.value = props.value;
        }
        if (typeof props.values !== "undefined" && props.values !== state.values) {
          state.values = ToggleButtonGroup2.getValues(props);
        }
      }
      state._listenForPropChanges = true;
      return state;
    }
  }, {
    key: "getValues",
    value: function getValues(props) {
      if (typeof props.values === "string" && props.values[0] === "[") {
        return JSON.parse(props.values);
      }
      return props.values;
    }
  }]);
  return ToggleButtonGroup2;
}(react.PureComponent);
ToggleButtonGroup.tagName = "dnb-toggle-button-group";
ToggleButtonGroup.contextType = Context/* default */.Z;
ToggleButtonGroup.defaultProps = {
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  multiselect: null,
  variant: null,
  left_component: null,
  no_fieldset: null,
  disabled: null,
  skeleton: null,
  id: null,
  name: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  vertical: null,
  layout_direction: "row",
  value: void 0,
  values: void 0,
  attributes: null,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null
};

 false ? 0 : void 0;

;// CONCATENATED MODULE: ../node_modules/@dnb/eufemia/components/toggle-button/ToggleButton.js











var ToggleButton_AlignmentHelper;







function ToggleButton_createSuper(Derived) {
  var hasNativeReflectConstruct = ToggleButton_isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = (0,getPrototypeOf/* default */.Z)(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return (0,possibleConstructorReturn/* default */.Z)(this, result);
  };
}
function ToggleButton_isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}
















var ToggleButton = function(_React$PureComponent) {
  (0,inherits/* default */.Z)(ToggleButton2, _React$PureComponent);
  var _super = ToggleButton_createSuper(ToggleButton2);
  function ToggleButton2(props, context) {
    var _this;
    (0,classCallCheck/* default */.Z)(this, ToggleButton2);
    _this = _super.call(this, props);
    _this.onKeyDownHandler = function(event) {
      switch (keycode(event)) {
        case "enter":
          _this.onClickHandler(event);
          break;
      }
    };
    _this.onKeyUpHandler = function(event) {
      switch (keycode(event)) {
        case "enter":
          _this.onClickHandler(event);
          break;
      }
    };
    _this.onClickHandler = function(_ref) {
      var event = _ref.event;
      if ((0,component_helper/* isTrue */.oA)(_this.props.readOnly)) {
        return event.preventDefault();
      }
      event.persist();
      if (!(0,component_helper/* isTrue */.oA)(_this.context.multiselect) && _this.props.value === _this.context.value) {
        return;
      }
      var checked = !_this.state.checked;
      _this.setState({
        checked,
        _listenForPropChanges: false
      });
      _this.callOnChange({
        checked,
        event
      });
      if (_this._refButton.current && checked) {
        try {
          _this._refButton.current._ref.current.focus();
        } catch (e) {
          (0,component_helper/* warn */.ZK)(e);
        }
      }
    };
    _this.callOnChange = function(_ref2) {
      var checked = _ref2.checked, event = _ref2.event;
      var value = _this.props.value;
      if (_this.context.onChange) {
        _this.context.onChange({
          value,
          event
        });
      }
      (0,component_helper/* dispatchCustomElementEvent */.RW)((0,assertThisInitialized/* default */.Z)(_this), "on_change", {
        checked,
        value,
        event
      });
    };
    _this._id = props.id || (0,component_helper/* makeUniqueId */.Xo)();
    _this._refButton = react.createRef();
    _this.state = {
      _listenForPropChanges: true
    };
    if (context.name && typeof props.value !== "undefined") {
      if (typeof context.value !== "undefined") {
        _this.state.checked = context.value === props.value;
        _this.state._listenForPropChanges = false;
      } else if (context.values && Array.isArray(context.values)) {
        _this.state.checked = context.values.includes(props.value);
        _this.state._listenForPropChanges = false;
      } else if (ToggleButton2.parseChecked(props.checked)) {
        if (context.setContext) {
          if (context.multiselect) {
            context.setContext(function(tmp) {
              return {
                values: tmp && Array.isArray(tmp.values) ? [].concat((0,toConsumableArray/* default */.Z)(tmp.values), [props.value]) : [props.value]
              };
            });
          } else {
            context.setContext({
              value: props.value
            });
          }
        }
      }
    }
    return _this;
  }
  (0,createClass/* default */.Z)(ToggleButton2, [{
    key: "render",
    value: function render() {
      var _this2 = this;
      return react.createElement(Context/* default.Consumer */.Z.Consumer, null, function(context) {
        var _componentParams;
        var props = (0,component_helper/* extendPropsWithContext */.Xw)(_this2.props, ToggleButton2.defaultProps, _this2.context, context.translation.ToggleButton, context.FormRow, context.ToggleButton);
        var status = props.status, status_state = props.status_state, status_animation = props.status_animation, global_status_id = props.global_status_id, suffix = props.suffix, label = props.label, label_direction = props.label_direction, label_sr_only = props.label_sr_only, text = props.text, title = props.title, readOnly = props.readOnly, className = props.className, _className = props.class, disabled = props.disabled, skeleton = props.skeleton, variant = props.variant, left_component = props.left_component, icon = props.icon, icon_size = props.icon_size, icon_position = props.icon_position, propValue = props.value, _id = props.id, _checked = props.checked, attributes = props.attributes, children = props.children, on_change = props.on_change, on_state_update = props.on_state_update, custom_method = props.custom_method, custom_element = props.custom_element, rest = (0,objectWithoutProperties/* default */.Z)(props, ["status", "status_state", "status_animation", "global_status_id", "suffix", "label", "label_direction", "label_sr_only", "text", "title", "readOnly", "className", "class", "disabled", "skeleton", "variant", "left_component", "icon", "icon_size", "icon_position", "value", "id", "checked", "attributes", "children", "on_change", "on_state_update", "custom_method", "custom_element"]);
        var checked = _this2.state.checked;
        if (!(0,component_helper/* isTrue */.oA)(_this2.context.multiselect) && typeof _this2.context.value !== "undefined") {
          var contextValue = _this2.context.value;
          if (typeof propValue === "string" || typeof propValue === "number") {
            checked = propValue === contextValue;
          } else if (typeof JSON !== "undefined") {
            checked = JSON.stringify(propValue) === JSON.stringify(contextValue);
          }
        }
        var id = _this2._id;
        var showStatus = (0,component_helper/* getStatusState */.Bx)(status);
        var mainParams = {
          className: classnames("dnb-toggle-button", (0,SpacingHelper/* createSpacingClasses */.HU)(props), className, _className, status && "dnb-toggle-button__status--".concat(status_state), checked && "dnb-toggle-button--checked", label_direction && "dnb-toggle-button--".concat(label_direction))
        };
        (0,component_helper/* validateDOMAttributes */.L_)(_this2.props, rest);
        var buttonParams = (0,esm_extends/* default */.Z)((0,defineProperty/* default */.Z)({
          id,
          disabled,
          skeleton,
          text: text || children,
          title,
          icon,
          icon_size,
          icon_position
        }, "aria-pressed", String(checked)), rest);
        var componentParams = (_componentParams = {
          checked,
          disabled
        }, (0,defineProperty/* default */.Z)(_componentParams, "aria-hidden", true), (0,defineProperty/* default */.Z)(_componentParams, "tabIndex", "-1"), _componentParams);
        if (status) {
          if (status_state === "info") {
            componentParams.status_state = "info";
          } else {
            componentParams.status = "error";
          }
        }
        if (showStatus || suffix) {
          buttonParams["aria-describedby"] = (0,component_helper/* combineDescribedBy */.u5)(buttonParams, showStatus ? id + "-status" : null, suffix ? id + "-suffix" : null);
        }
        if (readOnly) {
          buttonParams["aria-readonly"] = buttonParams.readOnly = true;
        }
        var leftComponent = null;
        switch (variant) {
          case "radio":
            leftComponent = react.createElement(Radio, (0,esm_extends/* default */.Z)({
              id: "".concat(id, "-radio")
            }, componentParams));
            break;
          case "checkbox":
            leftComponent = react.createElement(Checkbox/* default */.Z, (0,esm_extends/* default */.Z)({
              id: "".concat(id, "-checkbox")
            }, componentParams));
            break;
          case "default":
          default:
            leftComponent = left_component;
            break;
        }
        return react.createElement("span", mainParams, label && react.createElement(FormLabel/* default */.Z, {
          id: id + "-label",
          for_id: id,
          text: label,
          disabled,
          skeleton,
          label_direction,
          sr_only: label_sr_only
        }), react.createElement("span", {
          className: "dnb-toggle-button__inner"
        }, showStatus && react.createElement(FormStatus/* default */.ZP, {
          id: id + "-form-status",
          global_status_id,
          label,
          text_id: id + "-status",
          text: status,
          status: status_state,
          animation: status_animation,
          skeleton
        }), react.createElement("span", {
          className: "dnb-toggle-button__shell"
        }, ToggleButton_AlignmentHelper || (ToggleButton_AlignmentHelper = react.createElement(AlignmentHelper/* default */.Z, null)), react.createElement(Button/* default */.ZP, (0,esm_extends/* default */.Z)({
          variant: "secondary",
          className: "dnb-toggle-button__button"
        }, buttonParams, {
          ref: _this2._refButton,
          onClick: _this2.onClickHandler,
          onKeyDown: _this2.onKeyDownHandler,
          onKeyUp: _this2.onKeyUpHandler
        }), leftComponent && react.createElement("span", {
          className: "dnb-toggle-button__component"
        }, leftComponent)), suffix && react.createElement(Suffix/* default */.Z, {
          className: "dnb-toggle-button__suffix",
          id: id + "-suffix",
          context: props
        }, suffix))));
      });
    }
  }], [{
    key: "enableWebComponent",
    value: function enableWebComponent() {
      (0,custom_element/* registerElement */.ui)(ToggleButton2.tagName, ToggleButton2, ToggleButton2.defaultProps);
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (state._listenForPropChanges) {
        if (props.checked !== state._checked) {
          state.checked = ToggleButton2.parseChecked(props.checked);
        }
      }
      state._listenForPropChanges = true;
      if (state.checked !== state.__checked) {
        (0,component_helper/* dispatchCustomElementEvent */.RW)({
          props
        }, "on_state_update", {
          checked: state.checked
        });
      }
      state._checked = props.checked;
      state.__checked = state.checked;
      return state;
    }
  }]);
  return ToggleButton2;
}(react.PureComponent);
ToggleButton.Group = ToggleButtonGroup;
ToggleButton.tagName = "dnb-toggle-button";
ToggleButton.contextType = toggle_button_ToggleButtonGroupContext;
ToggleButton.defaultProps = {
  text: null,
  label: null,
  label_direction: null,
  label_sr_only: null,
  title: null,
  checked: void 0,
  variant: null,
  left_component: null,
  disabled: null,
  skeleton: null,
  id: null,
  status: null,
  status_state: "error",
  status_animation: null,
  global_status_id: null,
  suffix: null,
  value: "",
  icon: null,
  icon_position: "right",
  icon_size: null,
  attributes: null,
  readOnly: false,
  class: null,
  className: null,
  children: null,
  custom_element: null,
  custom_method: null,
  on_change: null,
  on_state_update: null
};
ToggleButton.parseChecked = function(state) {
  return /true|on/.test(String(state));
};

 false ? 0 : void 0;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/Space.js
var Space = __webpack_require__(7171);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js + 5 modules
var Dropdown = __webpack_require__(8755);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/P.js
var P = __webpack_require__(3731);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Provider.js
var Provider = __webpack_require__(4024);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_up.js
var chevron_up = __webpack_require__(1);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/chevron_down.js
var chevron_down = __webpack_require__(9444);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/add.js
var add = __webpack_require__(43);
// EXTERNAL MODULE: ./src/shared/ColorController.js
var ColorController = __webpack_require__(4513);
// EXTERNAL MODULE: ../node_modules/zustand/index.js
var zustand = __webpack_require__(2742);
// EXTERNAL MODULE: ../node_modules/zustand/middleware.js
var middleware = __webpack_require__(1818);
// EXTERNAL MODULE: ./src/shared/Compiler.js
var Compiler = __webpack_require__(9301);
// EXTERNAL MODULE: ./src/shared/DOM.js
var DOM = __webpack_require__(9494);
;// CONCATENATED MODULE: ./src/extension/editor/EditorStore.js




const useEditorStore = (0,zustand/* default */.Z)((0,middleware/* persist */.tJ)((set, get) => ({
  enabled: false,
  themesHash: null,
  modifications: {},
  addModification: ({path, themeId = null}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  setTheme: ({path, themeId}) => {
    const {modifications} = get();
    modifications[path] = {themeId};
    set({modifications});
  },
  removeTheme: ({path}) => {
    const {modifications} = get();
    delete modifications[path];
    set({modifications});
  },
  setEnabled: (enabled) => {
    set({enabled});
  }
}), getPersistConfig()));
function listenForModifications({onModification} = {}) {
  return useEditorStore.subscribe(() => {
    if (typeof onModification === "function") {
      onModification();
    }
  });
}
function getPersistConfig() {
  return {
    name: "eufemia-theme-editor",
    blacklist: ["themesHash"]
  };
}
function applyModifications({themes}) {
  const {modifications} = useEditorStore.getState();
  const {css} = (0,Compiler/* compileModifications */.VV)({
    modifications,
    themes,
    modifyDeclaration: ({key, change}) => {
      return `${key}: ${change};${key.replace("--", `--theme-`)}: ${change};`;
    }
  });
  (0,DOM/* insertCSS */.Q4)(css, {elementId: "eufemia-theme-custom"});
}
function removeCustomModifications() {
  (0,DOM/* insertCSS */.Q4)("", {elementId: "eufemia-theme-custom"});
}
function flushThemesHash() {
  useEditorStore.setState({themesHash: Date.now()});
}

// EXTERNAL MODULE: ./src/shared/Bridge.js
var Bridge = __webpack_require__(8208);
;// CONCATENATED MODULE: ./src/extension/editor/ExtensionEditor.jsx











const Layout = emotion_styled_browser_esm/* default.div */.Z.div`
  position: fixed;
  z-index: 10000;
  top: 1.5rem;
  bottom: 0;
  left: 2px;

  display: flex;
  flex-direction: column;

  width: var(--ete-width);
  height: 100vh;
  padding: 0.5rem;
  padding-top: 1rem;

  background-color: var(--color-black-3);
  border: 1px solid var(--color-black-8);
`;
const EditorButton = (0,emotion_styled_browser_esm/* default */.Z)(ToggleButton)`
  position: fixed;
  z-index: 10001;
  top: 2px;
  left: 2px;

  button {
    border-radius: 0;
    color: var(--color-white);
  }

  button[aria-pressed='false'] {
    padding: 0;
    opacity: 0.5;
    box-shadow: none;
    background-color: var(--color-black-55);
  }
  button[aria-pressed='true'] {
    width: var(--ete-width);
  }
`;
const EteApp = emotion_styled_browser_esm/* default.div */.Z.div`
  --ete-width: 10rem;
  ${(0,ColorController/* generateThemeIgnoreColors */.RZ)()}
`;
const App = () => {
  const {enabled, setEnabled} = useEditorStore();
  const [logPath, setLogPath] = react.useState(null);
  const [toggleEnabled] = react.useState(() => ({checked}) => setEnabled(checked));
  return /* @__PURE__ */ react.createElement(EteApp, null, /* @__PURE__ */ react.createElement(EditorButton, {
    title: "Eufemia Theme Editor",
    id: "ete-toggle-enabled",
    size: "small",
    checked: enabled,
    on_change: toggleEnabled,
    icon: enabled ? chevron_up/* default */.Z : chevron_down/* default */.Z
  }), enabled && /* @__PURE__ */ react.createElement(Layout, {
    id: "ete",
    className: "dnb-core-style"
  }, /* @__PURE__ */ react.createElement(InspectorHandler, {
    onHover: ({path}) => {
      setLogPath(path);
    },
    onCancel: () => {
      setLogPath(null);
    }
  }), logPath ? /* @__PURE__ */ react.createElement(Path, {
    top: "1rem",
    modifier: "x-small"
  }, logPath) : /* @__PURE__ */ react.createElement(ModificationManager, {
    top: "1rem"
  })));
};
function InspectorHandler({onHover, onCancel}) {
  const {addModification} = useEditorStore();
  const [inspect, setInspect] = react.useState(false);
  const [toggleEnabled] = react.useState(() => () => setInspect((s) => {
    if (s && onCancel) {
      onCancel();
    }
    return !s;
  }));
  const [inspector] = react.useState(() => (0,DOM/* createDOMInspector */.yQ)({
    exclude: ["#ete", "#ete-toggle-inspector"],
    onHover: ({element, path}) => {
      if (onHover) {
        onHover({element, path});
      }
    },
    onClick: ({element, path}) => {
      if (onCancel) {
        onCancel({element, path});
      }
      setInspect(false);
      addModification({path});
    }
  }));
  if (inspect) {
    inspector.enable();
  } else {
    inspector.cancel();
  }
  return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(ToggleButton, {
    id: "ete-toggle-inspector",
    icon: add/* default */.Z,
    icon_position: "left",
    checked: inspect,
    on_change: toggleEnabled
  }, inspect ? "Cancel" : "Inspect"));
}
const marker = (0,DOM/* createInspectorMarker */.gD)();
function hideOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.hide();
  });
}
function showOutline({path}) {
  document.querySelectorAll(path)?.forEach((elem) => {
    marker.show(elem);
  });
}
function useThemes(themesHash) {
  const [listOfThemes, setListOfThemes] = react.useState([]);
  react.useEffect(() => {
    (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
      setListOfThemes(Object.keys(themes).map((key) => key).filter((key) => !["blue-test", "2x-test"].includes(key)));
    }).catch((e) => {
      console.warn(e);
    });
  }, [themesHash]);
  return listOfThemes;
}
function ModificationManager(props) {
  const {modifications, themesHash, setTheme, removeTheme} = useEditorStore();
  const listOfThemes = useThemes(themesHash);
  return /* @__PURE__ */ react.createElement(Space/* default */.Z, {
    ...props
  }, /* @__PURE__ */ react.createElement(List, null, Object.entries(modifications).map(([path, {themeId}]) => {
    const dontExist = !document.querySelectorAll(path);
    return /* @__PURE__ */ react.createElement("li", {
      key: path
    }, /* @__PURE__ */ react.createElement("div", {
      onMouseOver: () => showOutline({path}),
      onMouseOut: () => hideOutline({path})
    }, /* @__PURE__ */ react.createElement(Path, {
      className: dontExist ? "dont-exist" : "",
      modifier: "x-small"
    }, path), /* @__PURE__ */ react.createElement(StyledDropdown, {
      size: "small",
      skip_portal: true,
      data: [
        ...listOfThemes,
        {content: "Inactive", selected_key: "inactive"},
        {content: "Remove", selected_key: "remove"}
      ],
      value: themeId && listOfThemes ? listOfThemes.indexOf(themeId) : "inactive",
      on_change: ({data}) => {
        const themeId2 = typeof data?.selected_key !== "undefined" ? data?.selected_key : data;
        switch (themeId2) {
          case "remove": {
            removeTheme({path});
            break;
          }
          default: {
            setTheme({path, themeId: themeId2});
          }
        }
      }
    })));
  })));
}
const Path = (0,emotion_styled_browser_esm/* default */.Z)(P/* default */.Z)`
  color: var(--color-success-green);
  &.dont-exist {
    color: var(--color-fire-red);
  }
`;
const StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  display: flex;
  --dropdown-width: 8rem;
`;
const List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  list-style: none;
  padding: 0;

  > li {
    margin-top: 0.5rem;
    background-color: var(--color-pistachio);
  }
`;
function createThemeEditor() {
  let root = document.getElementById("eufemia-theme-editor");
  if (!root) {
    root = document.createElement("div");
    root.setAttribute("id", "eufemia-theme-editor");
    document.body.insertBefore(root, document.body.firstChild);
  }
  react_dom.render(/* @__PURE__ */ react.createElement(Provider/* default */.Z, {
    locale: "en-GB"
  }, /* @__PURE__ */ react.createElement(App, null)), root);
}
function removeThemeEditor() {
  const root = document.getElementById("eufemia-theme-editor");
  if (root) {
    root.remove();
  }
}

;// CONCATENATED MODULE: ./src/extension/content.js




if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
  setLocalThemeModifications();
  (0,Bridge/* getThemesAsync */.ys)().then(({themes}) => {
    (0,Bridge/* setLocalThemeData */.YB)({themes});
    setLocalThemeModifications();
  });
}
(0,Bridge/* listenForExtensionRequests */.Pb)({
  onResponse: (response) => {
    switch (response.type) {
      case "store-themes": {
        const themes = response.themes;
        (0,Bridge/* setLocalThemeData */.YB)({themes});
        setLocalThemeModifications();
        flushThemesHash();
        if (response.themeId === "blue-test" && response.css) {
          removeCustomModifications();
        }
        break;
      }
      default: {
      }
    }
  }
});
Browser/* default.unsub */.Z.unsub;
function setLocalThemeModifications() {
  if ((0,Bridge/* hasEnabledLocalThemeData */.R)()) {
    (0,Bridge/* setLocalThemeCSS */.eF)();
    const themes = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
    if (themes) {
      applyModifications({themes});
    }
    createThemeEditor();
    if (typeof Browser/* default.unsub */.Z.unsub === "undefined") {
      Browser/* default.unsub */.Z.unsub = listenForModifications({
        onModification: () => {
          const themes2 = (0,Bridge/* getLocalThemeData */.$x)()?.themes;
          applyModifications({themes: themes2});
        }
      });
    }
  } else if (typeof Browser/* default.unsub */.Z.unsub === "function") {
    removeThemeEditor();
    removeCustomModifications();
    Browser/* default.unsub */.Z.unsub();
    Browser/* default.unsub */.Z.unsub = void 0;
  }
}


/***/ })

}]);
//# sourceMappingURL=412.js.map