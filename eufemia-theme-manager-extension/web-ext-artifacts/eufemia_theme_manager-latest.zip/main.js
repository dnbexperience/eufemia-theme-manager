/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 68138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ph": () => (/* binding */ extensionStorePlain),
/* harmony export */   "fl": () => (/* binding */ useThemeStore),
/* harmony export */   "qr": () => (/* binding */ useAppStore),
/* harmony export */   "q0": () => (/* binding */ useWindowStore),
/* harmony export */   "Xt": () => (/* binding */ useErrorStore),
/* harmony export */   "Fg": () => (/* binding */ useTheme)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2742);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71818);
/* harmony import */ var _shared_Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15101);
/* harmony import */ var _shared_ColorController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44513);




const extensionStorePlain = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(themesStore);
const useThemeStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(themesStore, getPersistConfig("eufemia-theme-data")));
const useAppStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-app")));
const useWindowStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)(hostStore, getPersistConfig("eufemia-theme-window")));
const useErrorStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(errorStore);
function useTheme(themeId) {
  const {getTheme} = useThemeStore();
  return getTheme(themeId);
}
function themesStore(set, get) {
  return {
    themes: {},
    getThemes: () => {
      const {getThemeConstructs, themes} = get();
      if (!themes["dnb-ui"]) {
        themes["dnb-ui"] = getThemeConstructs();
        themes["demo"] = getThemeConstructs();
      }
      if (!themes["blue-test"]) {
        themes["blue-test"] = getThemeConstructs();
      }
      if (!themes["2x-test"]) {
        themes["2x-test"] = getThemeConstructs();
      }
      return themes;
    },
    importThemes: (themesData, {overwrite} = {}) => {
      try {
        if (themesData) {
          const existingThemes = get().themes;
          const themes = Object.entries(themesData).reduce((acc, [key, theme]) => {
            if (!["dnb-ui", "blue-test", "2x-test"].includes(key)) {
              if (overwrite) {
                acc[key] = theme;
              } else if (!acc[key]) {
                acc[key] = theme;
              }
            }
            return acc;
          }, {...existingThemes});
          set({themes});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    },
    createEmptyTheme: (themeId) => {
      const {themes, getThemeConstructs} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...getThemeConstructs()};
        set({themes});
      }
    },
    copySelectedTheme: (themeId) => {
      const {themes, selectedThemeId} = get();
      if (!themes[themeId]) {
        themes[themeId] = {...themes[selectedThemeId]};
        set({themes});
      }
    },
    removeTheme: (themeId) => {
      const themes = get().themes;
      if (themes[themeId]) {
        delete themes[themeId];
        set({themes});
      }
    },
    getThemeConstructs: () => {
      return {
        colorsList: [],
        spacingsList: [],
        fontsizesList: []
      };
    },
    getTheme: (themeId = null) => {
      if (!themeId) {
        themeId = get().selectedThemeId;
      }
      const setState = (object) => {
        const themes = get().themes;
        themes[themeId] = Object.assign(themes[themeId] || {}, object);
        const state = {themes};
        state.selectedThemeId = themeId;
        set(state);
      };
      const getState = () => {
        const theme = get().themes[themeId] || null;
        return theme;
      };
      const getThemeChanges = () => {
        switch (themeId) {
          case "dnb-ui": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key, value}) => ({
                key,
                change: value
              }))
            ];
          }
          case "blue-test": {
            return [
              ..._shared_ColorController__WEBPACK_IMPORTED_MODULE_1__/* .originalColorsAsArray.map */ .v0.map(({key}) => ({
                key,
                change: "blue"
              }))
            ];
          }
          case "2x-test": {
            return [
              {
                css: "html{font-size: 200%;}"
              }
            ];
          }
          default: {
            const theme = getState();
            return [
              ...theme?.colorsList || [],
              ...theme?.spacingsList || [],
              ...theme?.fontsizesList || []
            ];
          }
        }
      };
      const changeColor = (origKey, object) => {
        const theme = getState();
        let found = false;
        object.key = origKey;
        const colorsList = (theme?.colorsList || []).map((item) => {
          if (item.key === origKey) {
            item = {...item, ...object};
            found = Boolean(item);
          }
          return item;
        });
        if (!found) {
          colorsList.push(object);
        }
        setState({colorsList});
      };
      const setColor = (origKey, change, fallbackParams = {}) => {
        changeColor(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetColor = (rmKey) => {
        changeColor(rmKey, {
          change: null
        });
      };
      const useColorTools = () => {
        return {
          changeColor,
          setColor,
          resetColor
        };
      };
      const changeSpacing = (origKey, object) => {
        const theme = getState();
        let found;
        const spacingsList = (theme?.spacingsList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          spacingsList.push(Object.assign(object));
        }
        setState({spacingsList});
      };
      const setSpacing = (origKey, change, fallbackParams = {}) => {
        changeSpacing(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetSpacing = (rmKey) => {
        changeSpacing(rmKey, {
          change: null
        });
      };
      const useSpacingTools = () => {
        return {
          changeSpacing,
          setSpacing,
          resetSpacing
        };
      };
      const changeFontsize = (origKey, object) => {
        const theme = getState();
        let found;
        const fontsizesList = (theme?.fontsizesList || []).map((item) => {
          if (item.key === origKey) {
            found = item = {...item, ...object};
          }
          return item;
        });
        if (!found) {
          fontsizesList.push(Object.assign(object));
        }
        setState({fontsizesList});
      };
      const setFontsize = (origKey, change, fallbackParams = {}) => {
        changeFontsize(origKey, Object.assign(fallbackParams, {
          change
        }));
      };
      const resetFontsize = (rmKey) => {
        changeFontsize(rmKey, {
          change: null
        });
      };
      const useFontsizeTools = () => {
        return {
          changeFontsize,
          setFontsize,
          resetFontsize
        };
      };
      return {
        themeId,
        ...getState(),
        setState,
        getState,
        getThemeChanges,
        useColorTools,
        useSpacingTools,
        useFontsizeTools
      };
    }
  };
}
const defaultFallback = {
  enabled: false,
  selectedTab: "colors",
  currentThemeId: null,
  selectedThemeId: "demo"
};
function hostStore(set, get) {
  return {
    hosts: {},
    setEnabled: (enabled) => {
      get().setByHost({enabled});
    },
    setFilter: (cacheKey, filter) => {
      const filters = get().getHostData()?.filters || {};
      const existing = get().getFilter(cacheKey) || {};
      filters[cacheKey] = Object.assign(existing, filter);
      get().setByHost({filters});
    },
    getFilter: (cacheKey) => {
      const data = get().getHostData();
      return data?.filters ? data.filters[cacheKey] : null;
    },
    setCurrentThemeId: (currentThemeId) => {
      get().setByHost({currentThemeId});
    },
    setSelectedThemeId: (selectedThemeId) => {
      get().setByHost({selectedThemeId});
    },
    setSelectedTab: (selectedTab) => {
      get().setByHost({selectedTab});
    },
    getHostData: () => {
      const {hosts} = get();
      return hosts[window.EXTENSION_HOST] || defaultFallback;
    },
    setByHost: (data) => {
      const {hosts} = get();
      hosts[window.EXTENSION_HOST] = Object.assign(hosts[window.EXTENSION_HOST] || defaultFallback, data);
      set({hosts});
    },
    importAppData: (hostsData, {overwrite} = {}) => {
      try {
        if (hostsData) {
          const existingData = get().hosts;
          const hosts = Object.entries(hostsData).reduce((acc, [key, data]) => {
            if (overwrite) {
              acc[key] = data;
            } else if (!acc[key]) {
              acc[key] = data;
            }
            return acc;
          }, {...existingData});
          set({hosts});
        }
      } catch (e) {
        useErrorStore.getState().setError(e.message);
      }
    }
  };
}
function errorStore(set) {
  return {
    error: null,
    setError: (error) => {
      console.warn(error);
      set({error});
    },
    hideError: () => {
      set({error: null});
    }
  };
}
function getPersistConfig(name) {
  let writeTimeoutId;
  const useBrowserStorage = true;
  return {
    name,
    getStorage: () => ({
      getItem: (name2) => {
        return new Promise((resolve, reject) => {
          if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.get */ .Z.storage.sync.get([name2], ({[name2]: themeData}) => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                } else {
                  resolve(themeData);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              resolve(window.localStorage?.getItem(name2) || "{}");
            }
          } else {
            resolve(window.localStorage?.getItem(name2) || "{}");
          }
        });
      },
      setItem: (name2, themeData) => {
        if (useBrowserStorage && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z && _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage */ .Z.storage !== "undefined") {
          const write = () => {
            try {
              _shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.storage.sync.set */ .Z.storage.sync.set({[name2]: themeData}, () => {
                if (_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError */ .Z.runtime.lastError) {
                  useErrorStore.getState().setError(_shared_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.lastError.message */ .Z.runtime.lastError.message);
                }
              });
            } catch (e) {
              useErrorStore.getState().setError(e.message);
              window.localStorage?.setItem(name2, themeData);
            }
          };
          if (!writeTimeoutId) {
            writeTimeoutId = 1;
            write();
          } else {
            clearTimeout(writeTimeoutId);
            writeTimeoutId = setTimeout(() => {
              write();
            }, 1e3);
          }
        } else {
          window.localStorage?.setItem(name2, themeData);
        }
      }
    })
  };
}


/***/ }),

/***/ 13621:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: ../node_modules/react/index.js
var react = __webpack_require__(94339);
// EXTERNAL MODULE: ../node_modules/react-dom/index.js
var react_dom = __webpack_require__(77888);
// EXTERNAL MODULE: ../node_modules/@emotion/react/dist/emotion-react.browser.esm.js
var emotion_react_browser_esm = __webpack_require__(4477);
// EXTERNAL MODULE: ../node_modules/@emotion/styled/dist/emotion-styled.browser.esm.js + 2 modules
var emotion_styled_browser_esm = __webpack_require__(65462);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/tabs/Tabs.js + 3 modules
var Tabs = __webpack_require__(9146);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/space/Space.js
var Space = __webpack_require__(7171);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/fragments/scroll-view/ScrollView.js
var ScrollView = __webpack_require__(25317);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/P.js
var P = __webpack_require__(93731);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/H1.js
var H1 = __webpack_require__(29918);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-row/FormRow.js
var FormRow = __webpack_require__(51530);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/dropdown/Dropdown.js + 5 modules
var Dropdown = __webpack_require__(38755);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/switch/Switch.js
var Switch = __webpack_require__(81194);
// EXTERNAL MODULE: ./src/app/core/Store.js
var Store = __webpack_require__(68138);
;// CONCATENATED MODULE: ./src/app/views/ThemeSelector.jsx




function ThemeSelector(props) {
  return /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
    ...props
  }, /* @__PURE__ */ react.createElement(ThemePicker, {
    right: "1rem"
  }), /* @__PURE__ */ react.createElement(ToggleEnabled, {
    right: "1rem"
  }));
}
function ThemePicker(props) {
  const {getThemes} = (0,Store/* useThemeStore */.fl)();
  const {getHostData, setCurrentThemeId} = (0,Store/* useAppStore */.qr)();
  const {currentThemeId} = getHostData();
  const themesList = Object.entries(getThemes()).map(([key]) => key);
  return /* @__PURE__ */ react.createElement(StyledDropdown, {
    fixed_position: true,
    label: "Theme in use:",
    title: "Used theme:",
    value: currentThemeId,
    data: themesList,
    on_change: ({data}) => {
      setCurrentThemeId(data);
    },
    ...props
  });
}
const StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  --dropdown-width: 10rem;
`;
function ToggleEnabled(props) {
  const {setEnabled, getHostData} = (0,Store/* useAppStore */.qr)();
  const {enabled, currentThemeId} = getHostData();
  return /* @__PURE__ */ react.createElement(Switch/* default */.Z, {
    label: "Enabled",
    label_position: "left",
    checked: enabled,
    disabled: !currentThemeId,
    on_change: ({checked}) => setEnabled(checked),
    ...props
  });
}

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/modal/Modal.js + 2 modules
var Modal = __webpack_require__(2622);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/textarea/Textarea.js
var Textarea = __webpack_require__(91411);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-set/FormSet.js
var FormSet = __webpack_require__(8752);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/button/Button.js + 7 modules
var Button = __webpack_require__(79826);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/checkbox/Checkbox.js
var Checkbox = __webpack_require__(44742);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/send.js
var send = __webpack_require__(36067);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/download.js
var download = __webpack_require__(16889);
// EXTERNAL MODULE: ./src/shared/Bridge.js
var Bridge = __webpack_require__(68208);
;// CONCATENATED MODULE: ./src/app/views/ImportExport.jsx





function ImportExport(props) {
  return /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
    ...props
  }, /* @__PURE__ */ react.createElement(Modal/* default */.Z, {
    title: "Export",
    size: "small",
    right: "x-small",
    trigger_icon: send/* default */.Z,
    on_click: () => {
    }
  }, () => /* @__PURE__ */ react.createElement(ExportContent, null)), /* @__PURE__ */ react.createElement(Modal/* default */.Z, {
    title: "Import",
    size: "small",
    trigger_icon: download/* default */.Z,
    on_click: () => {
    }
  }, () => /* @__PURE__ */ react.createElement(ImportContent, null)));
}
function ExportContent() {
  const {hosts} = (0,Store/* useAppStore */.qr)();
  const {themes} = (0,Store/* useThemeStore */.fl)();
  const ref = react.useRef();
  const [data, setData] = react.useState(async () => {
    const {modifications} = await (0,Bridge/* getModificationsFromContentAsync */.zn)();
    setData({themes, modifications, hosts});
    return "Preparing data ...";
  });
  return /* @__PURE__ */ react.createElement(Textarea/* default */.Z, {
    readOnly: true,
    stretch: true,
    rows: "10",
    inner_ref: ref,
    onMouseDown: () => {
      if (ref?.current) {
        ref?.current.select();
      }
    }
  }, JSON.stringify(data, null, 2));
}
function ImportContent() {
  const [json, jsonSet] = react.useState(null);
  const [overwrite, overwriteSet] = react.useState(false);
  const {importThemes} = (0,Store/* useThemeStore */.fl)();
  const {importAppData} = (0,Store/* useAppStore */.qr)();
  return /* @__PURE__ */ react.createElement(FormSet/* default */.Z, {
    on_submit: () => {
      if (json) {
        try {
          const data = JSON.parse(json);
          importThemes(data.themes, {overwrite});
          importAppData(data.hosts, {overwrite});
        } catch (e) {
          Store/* useErrorStore.getState */.Xt.getState().setError(e.message);
        }
      }
    },
    prevent_submit: true
  }, /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
    direction: "vertical"
  }, /* @__PURE__ */ react.createElement(Textarea/* default */.Z, {
    placeholder: "Paste JSON data ...",
    stretch: true,
    rows: "10",
    value: json,
    on_change: ({value}) => {
      jsonSet(value);
    }
  }), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
    direction: "horizontal",
    centered: true,
    top: "0.5rem"
  }, /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
    type: "submit",
    text: "Import",
    right: true
  }), /* @__PURE__ */ react.createElement(Checkbox/* default */.Z, {
    checked: overwrite,
    on_change: ({checked}) => {
      overwriteSet(checked);
    },
    label: "Replace current Data"
  }))));
}

;// CONCATENATED MODULE: ./src/app/views/Header.jsx





function Header() {
  return /* @__PURE__ */ react.createElement(HeaderArea, null, /* @__PURE__ */ react.createElement(H1/* default */.Z, {
    className: "dnb-sr-only",
    size: "medium"
  }, "Eufemia Theme Manager"), /* @__PURE__ */ react.createElement(ThemeSelector, null), /* @__PURE__ */ react.createElement(ImportExport, {
    left: "1rem"
  }));
}
const HeaderArea = emotion_styled_browser_esm/* default.header */.Z.header`
  position: fixed;
  z-index: 10;
  top: 0;
  left: 0;
  right: 0;

  display: flex;
  align-items: center;
  justify-content: space-between;

  min-height: 4rem;

  padding: 0 1rem;

  .dnb-form-row__fieldset {
    width: auto;
  }
  h1 {
    white-space: nowrap;
  }

  &,
  label {
    color: var(--color-white);
  }

  background: var(--color-black-80);
`;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/input/Input.js
var Input = __webpack_require__(62229);
;// CONCATENATED MODULE: ./src/app/views/ThemeFilter.jsx




function ThemeFilter({cacheKey, ...props}) {
  return /* @__PURE__ */ react.createElement(FormRowArea, {
    ...props
  }, /* @__PURE__ */ react.createElement(SearchInput, {
    cacheKey,
    right: "1rem"
  }), /* @__PURE__ */ react.createElement(ToggleActive, {
    cacheKey,
    right: "1rem"
  }));
}
let timeout;
function SearchInput({cacheKey, ...props}) {
  const {setFilter, getFilter} = (0,Store/* useAppStore */.qr)();
  const filter = getFilter(cacheKey);
  const [value, setValue] = react.useState(filter?.value);
  return /* @__PURE__ */ react.createElement(Input/* default */.ZP, {
    label: "Filter:",
    placeholder: "Search value ...",
    value,
    on_change: ({value: value2}) => {
      setValue(value2);
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        setFilter(cacheKey, {value: value2});
      }, 300);
    },
    ...props
  });
}
const FormRowArea = (0,emotion_styled_browser_esm/* default */.Z)(FormRow/* default */.ZP)`
  padding: 1rem;
  background: var(--color-white);
`;
function ToggleActive({cacheKey, ...props}) {
  const {setFilter, getFilter} = (0,Store/* useAppStore */.qr)();
  const filter = getFilter(cacheKey);
  return /* @__PURE__ */ react.createElement(Switch/* default */.Z, {
    label: "Changed values",
    checked: filter?.active,
    on_change: ({checked: active}) => setFilter(cacheKey, {active}),
    ...props
  });
}

// EXTERNAL MODULE: ./src/shared/ColorController.js
var ColorController = __webpack_require__(44513);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/style/properties.js
var properties = __webpack_require__(37034);
;// CONCATENATED MODULE: ./src/shared/SpacingController.js

const originalSpacingsAsObject = getOriginalSpacingsAsObject();
const originalSpacingsAsArray = getOriginalSpacingsAsArray();
function fillRemaningSpacings(originalSpacingsList, customSpacingsList) {
  const keyRef = originalSpacingsAsObject;
  const notInList = (customSpacingsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalSpacingsList.map((item) => ({
    ...item,
    ...(customSpacingsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalSpacingsAsArray() {
  const spacings = Object.entries(originalSpacingsAsObject).map(([key, value]) => {
    const name = key.replace(/--spacing-/g, " ").trim();
    return {key, name, value};
  });
  return spacings;
}
function getOriginalSpacingsAsObject() {
  const spacings = Object.entries(properties/* default */.Z).filter(([name]) => name.includes("--spacing-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});
  return spacings;
}
const generateThemeIgnoreSpacings = () => originalSpacingsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");

;// CONCATENATED MODULE: ./src/shared/FontsizeController.js

const originalFontsizesAsObject = getOriginalFontsizesAsObject();
const originalFontsizesAsArray = getOriginalFontsizesAsArray();
function fillRemaningFontsizes(originalFontsizesList, customFontsizesList) {
  const keyRef = originalFontsizesAsObject;
  const notInList = (customFontsizesList || []).filter(({key}) => !keyRef[key]);
  if (!(customFontsizesList?.findIndex(({key}) => key === "font-size") > -1)) {
    originalFontsizesList = [
      {key: "font-size", name: "Global font-size", value: null, change: null}
    ].concat(originalFontsizesList);
  }
  return notInList.concat(originalFontsizesList.map((item) => ({
    ...item,
    ...(customFontsizesList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalFontsizesAsArray() {
  const fontsizes = Object.entries(originalFontsizesAsObject).map(([key, value]) => {
    const name = key.replace(/--font-size-/g, " ").trim();
    return {key, name, value};
  });
  return fontsizes;
}
function getOriginalFontsizesAsObject() {
  const fontsizes = Object.entries(properties/* default */.Z).filter(([name]) => name.includes("--font-size-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("--em"))
      delete acc[key];
    return acc;
  }, {});
  return fontsizes;
}
const generateThemeIgnoreFontsizes = () => originalFontsizesAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/exclamation_circled.js
var exclamation_circled = __webpack_require__(12617);
;// CONCATENATED MODULE: ./src/app/views/ThemeManager.jsx





function ThemeManager(props) {
  const {getThemes, createEmptyTheme, copySelectedTheme} = (0,Store/* useThemeStore */.fl)();
  const {getHostData, setSelectedThemeId} = (0,Store/* useAppStore */.qr)();
  const {selectedThemeId} = getHostData();
  const themesList = Object.entries(getThemes()).map(([key]) => key).filter((key) => !["dnb-ui", "blue-test", "2x-test"].includes(key));
  const [showInput, changeCreateInput] = react.useState(false);
  const [toggleCreateInput] = react.useState(() => () => changeCreateInput((s) => !s));
  return /* @__PURE__ */ react.createElement(ThemeManagerArea, {
    ...props
  }, showInput ? /* @__PURE__ */ react.createElement(CreateTheme, {
    onSave: (themeId, {makeCopy}) => {
      if (themeId) {
        if (makeCopy) {
          copySelectedTheme(themeId);
        } else {
          createEmptyTheme(themeId);
        }
        setSelectedThemeId(themeId);
      }
      toggleCreateInput();
    },
    onCancel: toggleCreateInput
  }) : /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(ThemeManager_StyledDropdown, {
    title: "Select or create a new Theme",
    label: "Theme to Edit:",
    right: "1rem",
    skip_portal: true,
    direction: "top",
    value: selectedThemeId,
    data: themesList,
    on_change: ({data}) => {
      setSelectedThemeId(data);
    }
  }), /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
    right: "1rem",
    icon: "add",
    on_click: toggleCreateInput
  }), /* @__PURE__ */ react.createElement(RemoveTheme, null)));
}
const ThemeManager_StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  --dropdown-width: 10rem;
`;
const ThemeManagerArea = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  align-items: center;
  min-height: 3rem;
`;
function CreateTheme({onSave, onCancel}) {
  const {getThemes} = (0,Store/* useThemeStore */.fl)();
  const themes = Object.keys(getThemes());
  const [value, setValue] = react.useState(null);
  const [errorMessage, setErrorMessage] = react.useState(null);
  const [makeCopy, setMakeCopy] = react.useState(false);
  return /* @__PURE__ */ react.createElement(FormSet/* default */.Z, {
    on_submit: () => {
      if (/[^a-z0-9-]/.test(value)) {
        setErrorMessage("The Theme Name has to be list-case!");
        return;
      }
      if (themes.includes(value)) {
        setErrorMessage("That Theme exists already!");
        return;
      }
      onSave(value, {makeCopy});
    },
    prevent_submit: true
  }, /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
    top: true,
    bottom: true
  }, /* @__PURE__ */ react.createElement(Input/* default */.ZP, {
    label: "New Theme:",
    placeholder: "Name (lisp-case)",
    right: "0.5rem",
    on_change: ({value: value2}) => {
      setValue(value2);
      setErrorMessage(null);
    },
    status: errorMessage
  }), /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
    type: "submit",
    text: "Create",
    size: "medium",
    right: "0.5rem"
  }), /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
    text: "Cancel",
    size: "medium",
    on_click: onCancel,
    variant: "secondary",
    right: "0.5rem"
  }), /* @__PURE__ */ react.createElement(Checkbox/* default */.Z, {
    label: "Copy",
    checked: makeCopy,
    on_change: ({checked}) => setMakeCopy(checked)
  })));
}
function RemoveTheme(props) {
  const {removeTheme} = (0,Store/* useThemeStore */.fl)();
  const {getHostData, setSelectedThemeId} = (0,Store/* useAppStore */.qr)();
  const {selectedThemeId} = getHostData();
  return ["dnb-ui", "blue-test", "2x-test"].includes(selectedThemeId) ? null : /* @__PURE__ */ react.createElement(StyledRemoveButton, {
    variant: "tertiary",
    text: `Delete "${selectedThemeId}"`,
    icon: exclamation_circled/* default */.Z,
    icon_position: "left",
    on_click: () => {
      if (selectedThemeId !== "dnb-ui") {
        setSelectedThemeId("dnb-ui");
        removeTheme(selectedThemeId);
        window.scrollTo({top: 0, behavior: "smooth"});
      }
    },
    ...props
  });
}
const StyledRemoveButton = (0,emotion_styled_browser_esm/* default */.Z)(Button/* default */.ZP)`
  /* color: var(--color-fire-red); */
`;

;// CONCATENATED MODULE: ./src/app/views/Toolbar.jsx



function Toolbar() {
  return /* @__PURE__ */ react.createElement(ToolbarArea, null, /* @__PURE__ */ react.createElement(ThemeManager, null));
}
const ToolbarArea = emotion_styled_browser_esm/* default.footer */.Z.footer`
  display: flex;
  align-items: center;

  position: fixed;
  z-index: 10;
  bottom: 0;
  left: 0;
  right: 0;
  padding-left: var(--spacing-small);

  width: var(--extension-width);
  min-height: 4rem;

  background: var(--color-white);
  box-shadow: 0 -1px 6px rgba(0, 0, 0, 0.16);
  /* border-bottom: 1px solid var(--color-black-80); */
  border-top: none;
`;

// EXTERNAL MODULE: ../node_modules/classnames/index.js
var classnames = __webpack_require__(50855);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ../node_modules/react-color/es/index.js + 60 modules
var es = __webpack_require__(41758);
// EXTERNAL MODULE: ../node_modules/color/index.js
var color = __webpack_require__(85452);
var color_default = /*#__PURE__*/__webpack_require__.n(color);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/form-status/FormStatus.js
var FormStatus = __webpack_require__(53427);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/icon/Icon.js
var Icon = __webpack_require__(43231);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/number-format/NumberFormat.js
var NumberFormat = __webpack_require__(8740);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/Hr.js
var Hr = __webpack_require__(98570);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/elements/H3.js
var H3 = __webpack_require__(17172);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/icons/arrow_right.js
var arrow_right = __webpack_require__(2296);
;// CONCATENATED MODULE: ./src/app/core/Utils.js
function waitForPromise(promise) {
  let status = "pending";
  let response;
  const suspender = promise.then((res) => {
    status = "success";
    response = res;
  }, (err) => {
    status = "error";
    response = err;
  });
  return () => {
    switch (status) {
      case "pending":
        throw suspender;
      case "error":
        throw response;
      default:
        return response;
    }
  };
}
function applyFilter(filter, list) {
  if (filter) {
    if (filter?.value?.length > 0) {
      const endsWithWhiteSpace = /\s$/.test(filter.value);
      const listOfSearchValues = filter.value.split(/\s+/g);
      list = list.filter(({key}) => {
        if (listOfSearchValues.length > 0) {
          return listOfSearchValues.some((item) => {
            return key.includes(item);
          });
        } else {
          if (endsWithWhiteSpace) {
            return new RegExp(`.*${filter.value.trim()}$`).test(key);
          }
          return key.includes(filter.value.trim());
        }
      });
    }
    if (filter?.active) {
      list = list.filter(({change}) => {
        return change;
      });
    }
  }
  return list;
}

;// CONCATENATED MODULE: ./src/app/hooks/Window.jsx


const useScrollPosition = (elem = window) => {
  const {getHostData, setByHost} = (0,Store/* useWindowStore */.q0)();
  const {selectedThemeId} = getHostData();
  return react.useEffect(() => {
    let timeout;
    const onScroll = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        setByHost({
          [`scroll-pos-${selectedThemeId}`]: window.scrollY
        });
      }, 100);
    };
    elem.addEventListener("scroll", onScroll);
    const top = parseFloat(getHostData()[`scroll-pos-${selectedThemeId}`]) || 0;
    if (top > -1) {
      document.documentElement.style.scrollBehavior = "auto";
      window.scrollTo({
        top,
        behavior: "auto"
      });
      document.documentElement.style.scrollBehavior = "smooth";
    }
    return () => {
      clearTimeout(timeout);
      elem.removeEventListener("scroll", onScroll);
    };
  }, [selectedThemeId, elem, getHostData, setByHost]);
};

;// CONCATENATED MODULE: ./src/app/views/ColorItems.jsx












const originalPickerColors = ColorController/* originalColorsAsArray.map */.v0.map(({value}) => value);
const originalPickerColorsWithTitle = ColorController/* originalColorsAsArray.map */.v0.map(({key, value}) => ({color: value, title: key}));
function ColorItems({cacheKey = "colors"} = {}) {
  useScrollPosition();
  const {getHostData, getFilter} = (0,Store/* useAppStore */.qr)();
  const {selectedThemeId} = getHostData();
  const {colorsList, useColorTools} = (0,Store/* useTheme */.Fg)(selectedThemeId);
  const {setColor, resetColor, changeColor} = useColorTools();
  if (["dnb-ui", "blue-test", "2x-test"].includes(selectedThemeId)) {
    return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(Hr/* default */.Z, {
      fullscreen: true,
      top: "1rem"
    }), /* @__PURE__ */ react.createElement(FormStatus/* default */.ZP, {
      top: "1rem",
      state: "info"
    }, "The Theme ", /* @__PURE__ */ react.createElement("b", null, selectedThemeId), " can't be chnaged. Create another one."));
  }
  const filter = getFilter(cacheKey);
  const colors = applyFilter(filter, (0,ColorController/* fillRemaningColors */.U9)(ColorController/* originalColorsAsArray */.v0, colorsList));
  return /* @__PURE__ */ react.createElement(List, null, colors.length === 0 && /* @__PURE__ */ react.createElement(Item, {
    key: "empty"
  }, /* @__PURE__ */ react.createElement(ItemLayout, null, "Noting found \u{1F937}\u200D\u2642\uFE0F")), colors.map((params) => {
    const {key, value, name, change} = params;
    const contrastValue = change ? color_default()(value).contrast(color_default()(change)) : null;
    const enabled = change ? true : false;
    return /* @__PURE__ */ react.createElement(Item, {
      key,
      className: classnames_default()(enabled && "is-enabled")
    }, /* @__PURE__ */ react.createElement(ItemLayout, null, /* @__PURE__ */ react.createElement(ColorArea, {
      right: "1rem",
      bottom: "1rem"
    }, /* @__PURE__ */ react.createElement(H3/* default */.Z, {
      bottom: "0.5rem",
      size: "small"
    }, name), /* @__PURE__ */ react.createElement(ColorAreaHorizontal, null, /* @__PURE__ */ react.createElement(OriginalColor, {
      style: {color: value},
      "aria-label": `Original Color ${value}`
    }, value), /* @__PURE__ */ react.createElement(P/* default */.Z, null, /* @__PURE__ */ react.createElement(Icon/* default */.ZP, {
      right: "0.25rem",
      icon: arrow_right/* default */.Z
    }), contrastValue && /* @__PURE__ */ react.createElement("span", {
      className: "dnb-p--x-small",
      title: "Contrast"
    }, /* @__PURE__ */ react.createElement(NumberFormat/* default */.Z, {
      decimals: 1
    }, contrastValue))), /* @__PURE__ */ react.createElement(NewColor, {
      style: {color: change || value},
      "aria-label": `New Color ${value}`
    }, enabled ? change || value : /* @__PURE__ */ react.createElement("svg", null, /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0"
    }), /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%"
    }))))), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      direction: "vertical"
    }, /* @__PURE__ */ react.createElement(SimpleColorPicker, null, /* @__PURE__ */ react.createElement(es/* TwitterPicker */.e8, {
      width: "21.5rem",
      color: change || value,
      colors: originalPickerColors,
      triangle: "hide",
      onChange: ({hex}) => setColor(key, hex, params)
    })), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      top: "0.5rem",
      centered: true,
      direction: "horizontal"
    }, enabled && /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
      text: "Reset color",
      variant: "tertiary",
      icon: "close",
      icon_position: "left",
      right: "1rem",
      size: "small",
      on_click: () => resetColor(key)
    })))));
  }));
}
const SimpleColorPicker = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  /** Works best on CirclePicker and TwitterPicker */
  span div {
    border: 1px solid var(--color-black-8);
  }
`;
const OriginalColor = emotion_styled_browser_esm/* default.section */.Z.section`
  width: 4rem;
  height: 4rem;

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-20);
  background-color: currentColor;
  color: #e9e9e9;
`;
const NewColor = (0,emotion_styled_browser_esm/* default */.Z)(OriginalColor)`
  background-color: transparent;
  .is-enabled & {
    background-color: currentColor;
  }

  svg {
    width: 100%;
    height: 100%;
    padding: 0.5rem;
  }
  svg line {
    stroke: var(--color-black-20);
    stroke-width: 1;
  }
`;
const List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  padding: 0 var(--spacing-small);
  list-style: none;
`;
const Item = emotion_styled_browser_esm/* default.li */.Z.li`
  margin-bottom: var(--spacing-x-small);

  /* opacity: 0.6; */
  /* &.is-enabled {
    opacity: 1;
  } */
`;
const ItemLayout = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: flex-start;

  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-black-3);
`;
const ColorArea = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: column;
  /* align-items: space-evenly; */

  min-width: 13.5rem;
  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-white);

  *[class*='dnb-h--'] {
    white-space: nowrap;
    margin-top: 0;
    text-align: center;
  }
`;
const ColorAreaHorizontal = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/slider/Slider.js
var Slider = __webpack_require__(80825);
;// CONCATENATED MODULE: ./src/app/views/SpacingItems.jsx










const originalPickerSpacingsWithTitle = originalSpacingsAsArray.map(({key, name, value}) => ({
  content: `${name} (${value})`,
  key,
  value
}));
originalPickerSpacingsWithTitle.unshift({
  content: "Custom Spacing",
  key: "custom-spacing",
  value: "16px"
});
function SpacingTools({cacheKey = "spacing"} = {}) {
  useScrollPosition();
  const {getHostData, getFilter} = (0,Store/* useAppStore */.qr)();
  const {selectedThemeId} = getHostData();
  const {spacingsList, useSpacingTools} = (0,Store/* useTheme */.Fg)(selectedThemeId);
  const {setSpacing, resetSpacing} = useSpacingTools();
  if (["dnb-ui", "blue-test", "2x-test"].includes(selectedThemeId)) {
    return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(Hr/* default */.Z, {
      fullscreen: true,
      top: "1rem"
    }), /* @__PURE__ */ react.createElement(FormStatus/* default */.ZP, {
      top: "1rem",
      state: "info"
    }, "The Theme ", /* @__PURE__ */ react.createElement("b", null, selectedThemeId), " can't be chnaged. Create another one."));
  }
  const filter = getFilter(cacheKey);
  const spacings = applyFilter(filter, fillRemaningSpacings(originalSpacingsAsArray, spacingsList));
  return /* @__PURE__ */ react.createElement(SpacingItems_List, null, spacings.length === 0 && /* @__PURE__ */ react.createElement(SpacingItems_Item, {
    key: "empty"
  }, /* @__PURE__ */ react.createElement(SpacingItems_ItemLayout, null, "Noting found \u{1F937}\u200D\u2642\uFE0F")), spacings.map((params) => {
    const {key, value, name, change} = params;
    const enabled = change ? true : false;
    return /* @__PURE__ */ react.createElement(SpacingItems_Item, {
      key,
      className: classnames_default()(enabled && "is-enabled")
    }, /* @__PURE__ */ react.createElement(SpacingItems_ItemLayout, null, /* @__PURE__ */ react.createElement(SpacingArea, {
      right: "1rem",
      bottom: "1rem"
    }, /* @__PURE__ */ react.createElement(H3/* default */.Z, {
      bottom: "0.5rem",
      size: "small"
    }, name), /* @__PURE__ */ react.createElement(SpacingAreaHorizontal, null, /* @__PURE__ */ react.createElement(OriginalSpacing, {
      "aria-label": `Original Spacing ${value}`
    }, value), /* @__PURE__ */ react.createElement(Icon/* default */.ZP, {
      right: "0.25rem",
      icon: arrow_right/* default */.Z
    }), /* @__PURE__ */ react.createElement(NewSpacing, {
      "aria-label": `New Spacing ${value}`
    }, enabled ? change || value : /* @__PURE__ */ react.createElement("svg", null, /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0"
    }), /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%"
    }))))), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      direction: "vertical"
    }, /* @__PURE__ */ react.createElement(SimpleSpacingPicker, null, change && change.endsWith("px") ? /* @__PURE__ */ react.createElement(SpacingSlider, {
      value: parseFloat(change) || 16,
      onDoubleClick: () => resetSpacing(key),
      on_change: ({value: value2}) => {
        setSpacing(key, `${value2}px`, params);
      }
    }) : /* @__PURE__ */ react.createElement(SpacingItems_StyledDropdown, {
      title: "Choose a spacing",
      skip_portal: true,
      value: originalPickerSpacingsWithTitle.findIndex(({value: value2}) => value2 === change),
      data: originalPickerSpacingsWithTitle,
      on_change: ({data: {key: _key, value: _value}}) => {
        if (_key === "custom-spacing") {
          const v = parseFloat(value);
          if (v > 0) {
            _value = `${v * 16}px`;
          }
        }
        setSpacing(key, _value, params);
      }
    })), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      top: "0.5rem",
      centered: true,
      direction: "horizontal"
    }, enabled && /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
      text: "Reset spacing",
      variant: "tertiary",
      icon: "close",
      icon_position: "left",
      size: "small",
      on_click: () => {
        resetSpacing(key);
      }
    })))));
  }));
}
const SpacingSlider = (props) => /* @__PURE__ */ react.createElement(Slider/* default */.Z, {
  stretch: true,
  min: 2,
  max: 256,
  step: 1,
  title: "Set custom spacing",
  ...props
});
const SpacingItems_StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  --dropdown-width: 14rem;
`;
const SimpleSpacingPicker = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  /** Works best on CirclePicker and TwitterPicker */
  span div {
    border: 1px solid var(--color-black-8);
  }
`;
const OriginalSpacing = emotion_styled_browser_esm/* default.section */.Z.section`
  display: flex;
  justify-content: center;
  align-items: center;

  width: 5rem;
  height: 2rem;

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-20);
`;
const NewSpacing = (0,emotion_styled_browser_esm/* default */.Z)(OriginalSpacing)`
  svg {
    width: 2rem;
    height: 2rem;
    padding: 0.5rem;
  }
  svg line {
    stroke: var(--color-black-20);
    stroke-width: 1;
  }
`;
const SpacingItems_List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  padding: 0 var(--spacing-small);
  list-style: none;
`;
const SpacingItems_Item = emotion_styled_browser_esm/* default.li */.Z.li`
  margin-bottom: var(--spacing-x-small);
`;
const SpacingItems_ItemLayout = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: flex-start;

  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-black-3);
`;
const SpacingArea = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: column;

  min-width: 16rem;
  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-white);

  *[class*='dnb-h--'] {
    white-space: nowrap;
    margin-top: 0;
    text-align: center;
  }
`;
const SpacingAreaHorizontal = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

;// CONCATENATED MODULE: ./src/app/views/FontsizeItems.jsx










const originalPickerFontsizesWithTitle = originalFontsizesAsArray.map(({key, name, value}) => ({
  content: `${name} (${value})`,
  key,
  value
}));
originalPickerFontsizesWithTitle.unshift({
  content: "Custom font-size",
  key: "custom-font-size",
  value: "16px"
});
function FontsizeTools({cacheKey = "fontsize"} = {}) {
  useScrollPosition();
  const {getHostData, getFilter} = (0,Store/* useAppStore */.qr)();
  const {selectedThemeId} = getHostData();
  const {fontsizesList, useFontsizeTools} = (0,Store/* useTheme */.Fg)(selectedThemeId);
  const {setFontsize, resetFontsize} = useFontsizeTools();
  if (["dnb-ui", "blue-test", "2x-test"].includes(selectedThemeId)) {
    return /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(Hr/* default */.Z, {
      fullscreen: true,
      top: "1rem"
    }), /* @__PURE__ */ react.createElement(FormStatus/* default */.ZP, {
      top: "1rem",
      state: "info"
    }, "The Theme ", /* @__PURE__ */ react.createElement("b", null, selectedThemeId), " can't be chnaged. Create another one."));
  }
  const filter = getFilter(cacheKey);
  const fontsizes = applyFilter(filter, fillRemaningFontsizes(originalFontsizesAsArray, fontsizesList));
  return /* @__PURE__ */ react.createElement(FontsizeItems_List, null, fontsizes.length === 0 && /* @__PURE__ */ react.createElement(FontsizeItems_Item, {
    key: "empty"
  }, /* @__PURE__ */ react.createElement(FontsizeItems_ItemLayout, null, "Noting found \u{1F937}\u200D\u2642\uFE0F")), fontsizes.map((params) => {
    const {key, value, name, change} = params;
    const enabled = change ? true : false;
    return /* @__PURE__ */ react.createElement(FontsizeItems_Item, {
      key,
      className: classnames_default()(enabled && "is-enabled")
    }, /* @__PURE__ */ react.createElement(FontsizeItems_ItemLayout, null, /* @__PURE__ */ react.createElement(FontsizeArea, {
      right: "1rem",
      bottom: "1rem"
    }, /* @__PURE__ */ react.createElement(H3/* default */.Z, {
      bottom: "0.5rem",
      size: "small"
    }, name), /* @__PURE__ */ react.createElement(FontsizeAreaHorizontal, null, /* @__PURE__ */ react.createElement(OriginalFontsize, {
      "aria-label": `Original Fontsize ${value}`
    }, value || (key === "font-size" ? "16px" : "")), /* @__PURE__ */ react.createElement(Icon/* default */.ZP, {
      right: "0.25rem",
      icon: arrow_right/* default */.Z
    }), /* @__PURE__ */ react.createElement(NewFontsize, {
      "aria-label": `New Fontsize ${value}`
    }, enabled ? change || value : /* @__PURE__ */ react.createElement("svg", null, /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0"
    }), /* @__PURE__ */ react.createElement("line", {
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%"
    }))))), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      direction: "vertical"
    }, /* @__PURE__ */ react.createElement(SimpleFontsizePicker, null, key === "font-size" || change && change.endsWith("px") ? /* @__PURE__ */ react.createElement(FontSizeSlider, {
      value: parseFloat(change) || 16,
      onDoubleClick: () => resetFontsize(key),
      on_change: ({value: value2}) => {
        setFontsize(key, `${value2}px`, params);
      }
    }) : /* @__PURE__ */ react.createElement(FontsizeItems_StyledDropdown, {
      title: "Choose a font-size",
      skip_portal: true,
      value: originalPickerFontsizesWithTitle.findIndex(({value: value2}) => value2 === change),
      data: originalPickerFontsizesWithTitle,
      on_change: ({data: {key: _key, value: _value}}) => {
        if (_key === "custom-font-size") {
          const v = parseFloat(value);
          if (v > 0) {
            _value = `${v * 16}px`;
          }
        }
        setFontsize(key, _value, params);
      }
    })), /* @__PURE__ */ react.createElement(FormRow/* default */.ZP, {
      top: "0.5rem",
      centered: true,
      direction: "horizontal"
    }, enabled && /* @__PURE__ */ react.createElement(Button/* default */.ZP, {
      text: "Reset font-size",
      variant: "tertiary",
      icon: "close",
      icon_position: "left",
      size: "small",
      on_click: () => {
        resetFontsize(key);
      }
    })))));
  }));
}
const FontSizeSlider = (props) => /* @__PURE__ */ react.createElement(Slider/* default */.Z, {
  stretch: true,
  min: 8,
  max: 64,
  step: 1,
  title: "Set custom font-size",
  ...props
});
const FontsizeItems_StyledDropdown = (0,emotion_styled_browser_esm/* default */.Z)(Dropdown/* default */.Z)`
  --dropdown-width: 14rem;
`;
const SimpleFontsizePicker = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  /** Works best on CirclePicker and TwitterPicker */
  span div {
    border: 1px solid var(--color-black-8);
  }
`;
const OriginalFontsize = emotion_styled_browser_esm/* default.section */.Z.section`
  display: flex;
  justify-content: center;
  align-items: center;

  width: 5rem;
  height: 2rem;

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-20);
`;
const NewFontsize = (0,emotion_styled_browser_esm/* default */.Z)(OriginalFontsize)`
  svg {
    width: 2rem;
    height: 2rem;
    padding: 0.5rem;
  }
  svg line {
    stroke: var(--color-black-20);
    stroke-width: 1;
  }
`;
const FontsizeItems_List = emotion_styled_browser_esm/* default.ul */.Z.ul`
  padding: 0 var(--spacing-small);
  list-style: none;
`;
const FontsizeItems_Item = emotion_styled_browser_esm/* default.li */.Z.li`
  margin-bottom: var(--spacing-x-small);
`;
const FontsizeItems_ItemLayout = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: flex-start;

  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-black-3);
`;
const FontsizeArea = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: column;

  min-width: 16rem;
  padding: var(--spacing-small);

  border-radius: 0.5rem;
  border: 1px solid var(--color-black-8);
  background-color: var(--color-white);

  *[class*='dnb-h--'] {
    white-space: nowrap;
    margin-top: 0;
    text-align: center;
  }
`;
const FontsizeAreaHorizontal = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/components/global-status/GlobalStatus.js + 1 modules
var GlobalStatus = __webpack_require__(52598);
;// CONCATENATED MODULE: ./src/app/views/ExtensionError.jsx



function ExtensionError(props) {
  const {error, hideError} = (0,Store/* useErrorStore */.Xt)();
  return error ? /* @__PURE__ */ react.createElement(GlobalStatus/* default */.Z, {
    left: true,
    show: true,
    text: error,
    on_close: hideError,
    ...props
  }) : null;
}

// EXTERNAL MODULE: ./src/shared/Browser.js
var Browser = __webpack_require__(15101);
;// CONCATENATED MODULE: ./src/app/hooks/StoreUtils.jsx


function useRehydrationMiddleware() {
  react.useEffect(() => {
    if (Browser/* isDev */.r) {
      Promise.all(/* import() */[__webpack_require__.e(216), __webpack_require__.e(409)]).then(__webpack_require__.bind(__webpack_require__, 29409));
    }
  }, []);
}

// EXTERNAL MODULE: ./src/shared/Compiler.js
var Compiler = __webpack_require__(19301);
;// CONCATENATED MODULE: ./src/app/App.jsx






















function GlobalStyles() {
  const [dnbThemeIgnore__willBeReplaced] = react.useState(() => {
    return [
      (0,ColorController/* generateThemeIgnoreColors */.RZ)(),
      generateThemeIgnoreSpacings(),
      generateThemeIgnoreFontsizes()
    ].join("");
  });
  return /* @__PURE__ */ react.createElement(emotion_react_browser_esm/* Global */.xB, {
    styles: emotion_react_browser_esm/* css */.iv`
        :root {
          --extension-width: 40rem; /* max 800px (50rem) */
          --extension-height: 37.5rem; /* max 600px */

          overscroll-behavior-y: none; /* Disable smooth overscroll during an open modal  */
        }

        ${Browser/* isDev */.r ? "html{ font-size: 100% !important; }" : ""}

        body {
          /* The extension has it's own scroller, so this helps the Modal */
          width: var(--extension-width);
          height: var(--extension-height);
          overscroll-behavior-x: none;
          overscroll-behavior-y: none;

          background-color: var(--color-white);
        }

        .dnb-theme-ignore__willBeReplaced {
          ${dnbThemeIgnore__willBeReplaced}
        }
      `
  });
}
function App() {
  return /* @__PURE__ */ react.createElement(ThemeIgnore, null, /* @__PURE__ */ react.createElement(GlobalStyles, null), /* @__PURE__ */ react.createElement(react.Suspense, {
    fallback: /* @__PURE__ */ react.createElement(Indicator, null)
  }, /* @__PURE__ */ react.createElement(Content, null)));
}
const useAsyncHost = waitForPromise((0,Bridge/* getHost */.XF)());
const Content = () => {
  window.EXTENSION_HOST = useAsyncHost();
  (0,Compiler/* useCompilerListener */.JJ)();
  useRehydrationMiddleware();
  return /* @__PURE__ */ react.createElement(Layout, null, /* @__PURE__ */ react.createElement(Header, null), /* @__PURE__ */ react.createElement(Toolbar, null), /* @__PURE__ */ react.createElement(TabsWithContent, null));
};
function TabsWithContent() {
  const {getHostData, setSelectedTab} = (0,Store/* useAppStore */.qr)();
  const {selectedTab} = getHostData();
  return /* @__PURE__ */ react.createElement(Main, null, /* @__PURE__ */ react.createElement(ErrorArea, null, /* @__PURE__ */ react.createElement(ExtensionError, null)), /* @__PURE__ */ react.createElement(TabsArea, {
    left: "small"
  }, /* @__PURE__ */ react.createElement(Tabs/* default */.Z, {
    id: "main-view",
    tabs_style: "mint-green",
    data: [
      {title: "Colors", key: "colors"},
      {title: "Spacing", key: "spacings"},
      {title: "Font Size", key: "fontsizes"}
    ],
    selected_key: selectedTab,
    on_change: ({selected_key}) => {
      setSelectedTab(selected_key);
    }
  })), /* @__PURE__ */ react.createElement(ScrollView/* default */.Z, null, /* @__PURE__ */ react.createElement(Tabs/* default.Content */.Z.Content, {
    id: "main-view"
  }, ({key}) => {
    const content = {
      colors: () => /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(StyledFilterArea, {
        key: "colors",
        cacheKey: "colors"
      }), /* @__PURE__ */ react.createElement(ColorItems, null)),
      spacings: () => /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(StyledFilterArea, {
        key: "spacing",
        cacheKey: "spacing"
      }), /* @__PURE__ */ react.createElement(SpacingTools, null)),
      fontsizes: () => /* @__PURE__ */ react.createElement(react.Fragment, null, /* @__PURE__ */ react.createElement(StyledFilterArea, {
        key: "fontsize",
        cacheKey: "fontsize"
      }), /* @__PURE__ */ react.createElement(FontsizeTools, null))
    };
    return content[key]();
  })));
}
const ErrorArea = emotion_styled_browser_esm/* default.div */.Z.div`
  position: fixed;
  z-index: 11;
  top: 0;
  left: 0;
  right: 0;
`;
const StyledFilterArea = (0,emotion_styled_browser_esm/* default */.Z)(ThemeFilter)`
  padding-top: 6rem;
  background-color: var(--color-white);
`;
const TabsArea = (0,emotion_styled_browser_esm/* default */.Z)(Space/* default */.Z)`
  position: fixed;
  z-index: 10;
  top: 4rem;
  left: 0;
  right: 0;

  background-color: var(--color-white);
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.16);
`;
const Layout = emotion_styled_browser_esm/* default.div */.Z.div`
  /* Fixes the Modal issues */
  width: var(--extension-width);
  height: var(--extension-height);
`;
const Main = emotion_styled_browser_esm/* default.main */.Z.main`
  /* To ensure we have a scrollbar in HTML */
  min-height: 101vh;

  padding-bottom: 6rem;
`;
const IndicatorArea = emotion_styled_browser_esm/* default.div */.Z.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  width: var(--extension-width);
  min-height: var(--extension-height);
`;
function Indicator() {
  return /* @__PURE__ */ react.createElement(IndicatorArea, null, /* @__PURE__ */ react.createElement(P/* default */.Z, null, "Booting up"));
}
function ThemeIgnore({children}) {
  return /* @__PURE__ */ react.createElement("div", {
    className: "dnb-theme-ignore__willBeReplaced"
  }, children);
}

// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/style/index.js + 3 modules
var style = __webpack_require__(45903);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/style/stylis.js
var stylis = __webpack_require__(46599);
// EXTERNAL MODULE: ../node_modules/@dnb/eufemia/shared/Provider.js
var Provider = __webpack_require__(14024);
// EXTERNAL MODULE: ../node_modules/@emotion/react/dist/emotion-element-4fbd89c5.browser.esm.js
var emotion_element_4fbd89c5_browser_esm = __webpack_require__(279);
// EXTERNAL MODULE: ../node_modules/@emotion/cache/dist/emotion-cache.browser.esm.js + 1 modules
var emotion_cache_browser_esm = __webpack_require__(49332);
;// CONCATENATED MODULE: ./src/app/root.jsx








const emotionCache = (0,emotion_cache_browser_esm/* default */.Z)({
  key: "extension",
  stylisPlugins: [stylis/* default */.Z]
});
react_dom.render(/* @__PURE__ */ react.createElement(react.StrictMode, null, /* @__PURE__ */ react.createElement(emotion_element_4fbd89c5_browser_esm.C, {
  value: emotionCache
}, /* @__PURE__ */ react.createElement(Provider/* default */.Z, {
  locale: "en-GB"
}, /* @__PURE__ */ react.createElement(App, null)))), document.getElementById("root"));


/***/ }),

/***/ 68208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pb": () => (/* binding */ listenForExtensionRequests),
/* harmony export */   "ys": () => (/* binding */ getThemesAsync),
/* harmony export */   "zn": () => (/* binding */ getModificationsFromContentAsync),
/* harmony export */   "$x": () => (/* binding */ getLocalThemeData),
/* harmony export */   "YB": () => (/* binding */ setLocalThemeData),
/* harmony export */   "eF": () => (/* binding */ setLocalThemeCSS),
/* harmony export */   "R": () => (/* binding */ hasEnabledLocalThemeData),
/* harmony export */   "nn": () => (/* binding */ insertCSSIntoPage),
/* harmony export */   "rc": () => (/* binding */ storeCSSInPage),
/* harmony export */   "XF": () => (/* binding */ getHost),
/* harmony export */   "XW": () => (/* binding */ storeThemesInPage)
/* harmony export */ });
/* unused harmony exports getTabId, listenForBackgroundMessages */
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15101);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9494);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68138);



const extensionId =  false || void 0;
function getTabId(cbFunc) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.query */ .Z.tabs.query({currentWindow: true, active: true}, (tabs) => {
      const tabId = tabs[0].id;
      cbFunc(tabId);
    });
  } else {
    cbFunc(null);
  }
}
function listenForExtensionRequests({onResponse = null} = {}) {
  if (!_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    return;
  }
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.onMessage.addListener */ .Z.runtime.onMessage.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-extension-url": {
        getTabId((tabId) => {
          _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.browserAction.getPopup */ .Z.browserAction.getPopup({tabId}, (popup) => {
            response(popup);
          });
        });
        break;
      }
      case "insert-css": {
        const {elementId, css} = request;
        if (typeof css !== "undefined") {
          (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(css, {elementId});
        }
        response(request);
        break;
      }
      case "store-css": {
        const {css} = request;
        if (typeof css !== "undefined") {
          setLocalThemeData({css});
        }
        response(request);
        break;
      }
      case "store-themes": {
        const {themes} = request;
        if (typeof themes !== "undefined") {
          setLocalThemeData({themes});
        }
        response(request);
        break;
      }
      case "get-modifications": {
        const modifications = JSON.parse(window.localStorage.getItem("eufemia-theme-editor") || "{}");
        response({modifications});
        break;
      }
      default:
        response(request);
        return false;
    }
    if (typeof onResponse === "function") {
      onResponse(request);
    }
    return true;
  });
}
function getThemesAsync() {
  return new Promise((resolve, reject) => {
    if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
      try {
        sendMessageToRuntime({
          type: "get-themes"
        }, (response) => {
          resolve(response || {themes: []});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({themes: null});
    }
  });
}
function getModificationsFromContentAsync() {
  return new Promise((resolve, reject) => {
    if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
      try {
        sendMessageToTab({
          type: "get-modifications"
        }, (response) => {
          resolve(response || {modifications: {}});
        });
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({modifications: {}});
    }
  });
}
function getLocalThemeData() {
  return JSON.parse(window.localStorage?.getItem("eufemia-theme-content") || "{}");
}
function setLocalThemeData(data) {
  const localData = getLocalThemeData();
  window.localStorage?.setItem("eufemia-theme-content", JSON.stringify({...localData, ...data}));
}
function setLocalThemeCSS() {
  const localData = getLocalThemeData();
  if (localData && localData.css) {
    (0,_DOM__WEBPACK_IMPORTED_MODULE_2__/* .insertCSS */ .Q4)(localData.css, {elementId: "eufemia-theme"});
  }
}
function hasEnabledLocalThemeData() {
  const localData = getLocalThemeData();
  return Boolean(localData && localData.css);
}
function insertCSSIntoPage(data, responseFunc = null) {
  sendMessageToTab({type: "insert-css", ...data}, responseFunc);
}
function storeCSSInPage(data, responseFunc = null) {
  sendMessageToTab({type: "store-css", ...data}, responseFunc);
}
async function getHost() {
  return new Promise((resolve) => {
    if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
      _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.query */ .Z.tabs.query({currentWindow: true, active: true}, (tabs) => {
        const url = new URL(tabs[0].url);
        resolve(url.hostname);
      });
    } else {
      resolve("localhost");
    }
  });
}
function storeThemesInPage(themes, responseFunc = null) {
  sendMessageToRuntime({type: "set-themes", themes}, responseFunc);
  sendMessageToTab({type: "store-themes", themes}, responseFunc);
}
function sendMessageToRuntime(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.runtime.sendMessage */ .Z.runtime.sendMessage(extensionId, data, responseFunc);
}
function sendMessageToTab(data, responseFunc = (r) => console.log("Defualt Response", r)) {
  if (_Browser__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z) {
    getTabId((tabId) => {
      const themeId = window.EXTENSION_HOST ? _app_core_Store__WEBPACK_IMPORTED_MODULE_1__/* .useAppStore.getState */ .qr.getState().getHostData().currentThemeId : null;
      _Browser__WEBPACK_IMPORTED_MODULE_0__/* .default.tabs.sendMessage */ .Z.tabs.sendMessage(tabId, Object.assign(data, {themeId}), responseFunc);
    });
  } else if (responseFunc) {
    responseFunc("localhost");
  }
}
function listenForBackgroundMessages() {
  browser?.runtime?.onMessage?.addListener((request, sender, response) => {
    switch (request.type) {
      case "get-themes": {
        const {themes} = backgroundStore.getState();
        response({themes});
        break;
      }
      case "set-themes": {
        const {themes} = request;
        backgroundStore.setState({themes});
        response({themes});
        break;
      }
      default:
        return false;
    }
    return true;
  });
}


/***/ }),

/***/ 15101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ isDev),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
let useBrowser = void 0;
const isDev =  false && 0;
if (!isDev) {
  if ({"RUNTIME_BROWSER":"chrome","NODE_ENV":"production"}.RUNTIME_BROWSER === "chrome") {
    useBrowser = window.chrome;
  } else {
    useBrowser = window.browser;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useBrowser);


/***/ }),

/***/ 44513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v0": () => (/* binding */ originalColorsAsArray),
/* harmony export */   "U9": () => (/* binding */ fillRemaningColors),
/* harmony export */   "RZ": () => (/* binding */ generateThemeIgnoreColors)
/* harmony export */ });
/* unused harmony exports originalColorsAsObject, getOriginalColorsAsArray, getOriginalColorsAsObject */
/* harmony import */ var _dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37034);

const originalColorsAsObject = getOriginalColorsAsObject();
const originalColorsAsArray = getOriginalColorsAsArray();
function fillRemaningColors(originalColorsList, customColorsList) {
  const keyRef = originalColorsAsObject;
  const notInList = (customColorsList || []).filter(({key}) => !keyRef[key]);
  return notInList.concat(originalColorsList.map((item) => ({
    ...item,
    ...(customColorsList || []).find(({key}) => key === item.key)
  })).filter(({key}) => key));
}
function getOriginalColorsAsArray() {
  const colors = Object.entries(originalColorsAsObject).map(([key, value]) => {
    const name = key.replace(/--color-/g, " ").replace(/-/g, " ").trim().replace(/(^|\s)([a-z])/g, (s) => s.toUpperCase());
    return {key, name, value};
  });
  return colors;
}
function getOriginalColorsAsObject() {
  const colors = Object.entries(_dnb_eufemia_style_properties__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z).filter(([name]) => name.includes("--color-")).reduce((acc, [key, value]) => {
    acc[key] = value;
    if (key.includes("-border"))
      delete acc[key];
    if (key.includes("-background"))
      delete acc[key];
    if (key.includes("-light"))
      delete acc[key];
    if (key.includes("-medium"))
      delete acc[key];
    return acc;
  }, {});
  delete colors["--color-sea-green-alt-30"];
  delete colors["--color-signal-yellow-30"];
  delete colors["--color-black-30"];
  delete colors["--color-sea-green-alt"];
  delete colors["--color-signal-yellow"];
  return colors;
}
const generateThemeIgnoreColors = () => originalColorsAsArray.map(({key, value}) => {
  return `${key}: ${value};`;
}).join("\n");


/***/ }),

/***/ 19301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JJ": () => (/* binding */ useCompilerListener),
/* harmony export */   "VV": () => (/* binding */ compileModifications)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(94339);
/* harmony import */ var _Browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15101);
/* harmony import */ var _app_core_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68138);
/* harmony import */ var _DOM__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9494);
/* harmony import */ var _shared_Bridge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68208);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {enumerable: true, configurable: true, writable: true, value}) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};





const useCompilerListener = () => react__WEBPACK_IMPORTED_MODULE_0__.useState(() => new Compiler().listen());
class Compiler {
  constructor() {
    __publicField(this, "run", () => {
      const {themes} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
      const {getHostData} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.getState */ .qr.getState();
      const {enabled, currentThemeId} = getHostData();
      if (enabled) {
        const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.getState */ .fl.getState();
        const theme = getTheme(currentThemeId);
        const css = this.compileList(theme.getThemeChanges());
        this.setCSS(css);
        this.storeCSS(css);
      } else {
        this.reset();
      }
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeThemesInPage */ .XW)(themes);
    });
  }
  listen() {
    const unsubStore = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useThemeStore.subscribe */ .fl.subscribe(this.run);
    const unsubHost = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .useAppStore.subscribe */ .qr.subscribe(this.run);
    return () => {
      unsubStore();
      unsubHost();
    };
  }
  reset() {
    this.setCSS("");
    this.storeCSS("");
  }
  compileList(listWithChanges) {
    const declarations = this.buildDeclarations(listWithChanges);
    const css = listWithChanges.filter((cur) => cur.css).map(({css: css2}) => css2).join("");
    return css + this.combineWithRoot(declarations);
  }
  setCSS(css, elementId = "eufemia-theme") {
    const hash = String(css) + String(elementId);
    if (this._cssMemoHash === hash) {
      return;
    }
    this._cssMemoHash = hash;
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .insertCSSIntoPage */ .nn)({css, elementId});
    } else {
      (0,_DOM__WEBPACK_IMPORTED_MODULE_4__/* .insertCSS */ .Q4)(css, {elementId});
    }
  }
  storeCSS(css) {
    if (_Browser__WEBPACK_IMPORTED_MODULE_1__/* .default.tabs */ .Z.tabs) {
      (0,_shared_Bridge__WEBPACK_IMPORTED_MODULE_3__/* .storeCSSInPage */ .rc)({css});
    }
  }
  compileFromTheme(theme, opts) {
    return this.buildDeclarations(theme.getThemeChanges(), opts);
  }
  buildDeclarations(listWithChanges, {modifyDeclaration = null} = {}) {
    return listWithChanges.filter((cur) => cur.change).map(({key, change}) => {
      if (typeof modifyDeclaration === "function") {
        return modifyDeclaration({key, change});
      }
      return `${key}: ${change};`;
    });
  }
  combineWithRoot(declarations) {
    return declarations?.length ? `:root{${declarations.join("")}}` : "";
  }
}
function compileModifications({modifications, themes, ...opts}) {
  if (themes) {
    _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.setState */ .ph.setState({themes});
    const {getTheme} = _app_core_Store__WEBPACK_IMPORTED_MODULE_2__/* .extensionStorePlain.getState */ .ph.getState();
    const css = Object.entries(modifications).map(([path, {themeId}]) => {
      if (themeId && themeId !== "inactive") {
        const theme = getTheme(themeId);
        const themeCSS = new Compiler().compileFromTheme(theme, opts).join("");
        return `${path}{${themeCSS}}`;
      }
      return null;
    }).filter(Boolean).join("\n");
    return {css};
  }
  return {css: ""};
}


/***/ }),

/***/ 9494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q4": () => (/* binding */ insertCSS),
/* harmony export */   "yQ": () => (/* binding */ createDOMInspector),
/* harmony export */   "gD": () => (/* binding */ createInspectorMarker)
/* harmony export */ });
/* harmony import */ var _dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36620);

const containers = [];
const styleElements = [];
function insertCSS(css, {
  elementId = "inserted-css",
  replace = true,
  prepend = false,
  targetElement = document.querySelector("head")
} = {}) {
  css = String(css || "");
  const position = prepend === true ? "prepend" : "append";
  let containerId = containers.indexOf(targetElement);
  if (containerId === -1) {
    containerId = containers.push(targetElement) - 1;
    styleElements[containerId] = {};
  }
  let styleElement;
  if (typeof styleElements[containerId] !== "undefined" && typeof styleElements[containerId][elementId] !== "undefined") {
    styleElement = styleElements[containerId][elementId];
  } else {
    styleElement = styleElements[containerId][elementId] = createStyleElement({
      elementId
    });
    if (position === "prepend") {
      targetElement.insertBefore(styleElement, targetElement.childNodes[0]);
    } else {
      targetElement.appendChild(styleElement);
    }
  }
  if (css.charCodeAt(0) === 65279) {
    css = css.substr(1, css.length);
  }
  if (replace) {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = css;
    } else {
      styleElement.textContent = css;
    }
  } else {
    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText += css;
    } else {
      styleElement.textContent += css;
    }
  }
  return styleElement;
}
function createStyleElement({elementId = null} = {}) {
  const styleElement = document.createElement("style");
  styleElement.setAttribute("type", "text/css");
  if (elementId) {
    styleElement.setAttribute("id", elementId);
  }
  return styleElement;
}
function constructCSSPath(el) {
  if (!(el instanceof Element)) {
    return;
  }
  const VALID_CLASSNAME = /^[_a-zA-Z\- ]*$/;
  let path = [];
  while (el.nodeType === Node.ELEMENT_NODE) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) {
      selector += `#${el.id}`;
      path.unshift(selector);
      break;
    } else if (el.className && VALID_CLASSNAME.test(el.className)) {
      selector += `.${el.className.trim().replace(/\s+/g, ".")}`;
    } else {
      let sib = el, nth = 1;
      while (sib = sib.previousElementSibling) {
        if (sib.nodeName.toLowerCase() === selector)
          nth++;
      }
      if (nth !== 1)
        selector += ":nth-of-type(" + nth + ")";
    }
    path.unshift(selector);
    el = el.parentNode;
  }
  return path.join(" > ");
}
function createDOMInspector({
  root = "body",
  exclude = [],
  preventClick = true,
  outlineStyle = "0.5rem solid rgba(0, 114, 114, 0.5)",
  onClick,
  onHover
} = {}) {
  let selected, excludedElements;
  const removeHighlight = (el) => {
    if (el) {
      el.style.outline = "";
      el.style.cursor = "";
    }
  };
  const highlight = (el) => {
    if (preventClick) {
      el.style.cursor = "";
    }
    el.style.outline = outlineStyle;
    el.style.outlineOffset = `-${el.style.outlineWidth}`;
  };
  const shouldBeExcluded = (ev) => {
    if (excludedElements && excludedElements.length && excludedElements.some((parent) => parent === ev.target || parent.contains(ev.target))) {
      return true;
    }
  };
  const handleMouseOver = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    selected = ev.target;
    highlight(selected);
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onHover === "function") {
      onHover({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const handleMouseOut = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    removeHighlight(ev.target);
  };
  const handleMouseDown = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  };
  const handleClick = (ev) => {
    if (shouldBeExcluded(ev)) {
      return;
    }
    if (preventClick) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    if (typeof onClick === "function") {
      onClick({element: ev.target, path: constructCSSPath(ev.target)});
    }
  };
  const prepareExcluded = (rootEl) => {
    if (!exclude.length) {
      return [];
    }
    const excludedNested = exclude.flatMap((element) => {
      if (typeof element === "string" || element instanceof String) {
        return Array.from(rootEl.querySelectorAll(element));
      } else if (element instanceof Element) {
        return [element];
      } else if (element.length > 0 && element[0] instanceof Element) {
        return Array.from(element);
      }
      return [];
    });
    return Array.from(excludedNested).flat();
  };
  const enable = (onClickCallback) => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    if (exclude) {
      excludedElements = prepareExcluded(rootEl);
    }
    rootEl.addEventListener("mouseover", handleMouseOver, true);
    rootEl.addEventListener("mouseout", handleMouseOut, true);
    rootEl.addEventListener("mousedown", handleMouseDown, true);
    rootEl.addEventListener("click", handleClick, true);
    if (onClickCallback) {
      onClick = onClickCallback;
    }
  };
  const cancel = () => {
    const rootEl = document.querySelector(root);
    if (!rootEl) {
      return;
    }
    rootEl.removeEventListener("mouseover", handleMouseOver, true);
    rootEl.removeEventListener("mouseout", handleMouseOut, true);
    rootEl.removeEventListener("mousedown", handleMouseDown, true);
    rootEl.removeEventListener("click", handleClick, true);
    removeHighlight(selected);
  };
  return {
    enable,
    cancel
  };
}
function createInspectorMarker() {
  try {
    let markerEl = document.getElementById("eufmeia-theme-inspector-marker");
    if (!markerEl) {
      markerEl = document.createElement("div");
      markerEl.setAttribute("id", "eufmeia-theme-inspector-marker");
      markerEl.style.display = "none";
      markerEl.style.position = "absolute";
      markerEl.style.zIndex = "9000";
      markerEl.style.transition = "background 2s ease";
      markerEl.style.outline = "0.5rem solid rgba(0, 114, 114, 0.5)";
      document.body.appendChild(markerEl);
    }
    return {
      element: markerEl,
      hide: () => {
        if (markerEl) {
          markerEl.style.display = "none";
        }
      },
      show: (element) => {
        if (markerEl) {
          const style = getComputedStyle(element);
          markerEl.style.display = "block";
          markerEl.style.top = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetTop */ .oJ)(element)}px`;
          markerEl.style.left = `${(0,_dnb_eufemia_shared_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getOffsetLeft */ .pB)(element)}px`;
          markerEl.style.width = style.width;
          markerEl.style.height = style.height;
          markerEl.style.background = "rgba(0, 114, 114, 0.5)";
          setTimeout(() => {
            try {
              markerEl.style.background = "transparent";
            } catch (e) {
              console.warn(e);
            }
          }, 300);
        }
      }
    };
  } catch (e) {
    console.warn(e);
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					result = fn();
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get mini-css chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.miniCssF = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "main.css";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "eufemia-theme-manager-extension:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			;
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 179;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			179: 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						} else installedChunks[chunkId] = 0;
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			for(moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			__webpack_require__.O();
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkeufemia_theme_manager_extension"] = self["webpackChunkeufemia_theme_manager_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [216], () => (__webpack_require__(13621)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=main.js.map